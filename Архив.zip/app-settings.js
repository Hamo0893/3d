// app-settings.js
(function () {
    const Q = window.QDApp;
    if (!Q) return;

    // DOM элементтерді QDApp-тен аламыз
        const {
            widthInput,
            heightInput,
            depthInput,
        corpusMaterial,
        corpusThickness,
        facadeMaterial,
        facadeThickness,
        facadeType,
        corpusColorInput,
        facadeColorInput,
        facadeStyle,
        facadeFrameWidthInput,
        wallGapInput,
        plinthHeightInput,
        backMaterial,
        bottomMountInput,

        sectionSelect,
        splitPatternInput,
        splitSectionBtn,
        sectionWidthInput,

        shelfCountInput,
        autoShelvesBtn,
        shelfHeightInput,
        addShelfBtn,
        shelfSelect,
        editShelfHeightInput,
        updateShelfBtn,
        shelfGapInput,
        applyShelfGapBtn,
        insertShelfBetweenBtn,
        insertTypeSelect,
        addInsertBtn,
        insertList,
        drawerVariantSelect,
        drawerDepthSelect,
        drawerDepthBrandSelect,
        drawerFacadeMaterial,
        drawerSubList,
        drawerFacadeGapInput,
        drawerFrontOffsetInput,
        drawerBodyHeightInput,
        drawerStackGapInput,
        drawerRunnerThkInput,
        insertGapLeftInput,
        insertGapRightInput,
        pipeColorInput,
        drawerRunnerTypeSelect,

        partNameInput,
        partTypeInput,
        partSectionInput,
        partSizeInput,
        partOffsetFrontInput,
        edgeFrontInput,
        edgeBackInput,
        edgeLeftInput,
        edgeRightInput,
        partDrillingInput,
        offsetFrontInput,
        offsetBackInput,
        offsetBottomInput,
        offsetTopInput,

        viewButtons,
        modeButtons,
        animToggleBtn,
        toggleDimsBtn,
        toggleFacadeBtn,
        toggleEdgeBtn,
        toggleInfoBtn,
        undoBtn,
        redoBtn
    } = Q;

    // =========================
    // TOOL TABS (иконкалар)
    // 📏 Өлшем, 📦 Корпус, 🚪 Фасад, ▭ Секция, ⧉ Полка, ◫ Бөлшек
    // =========================
    const toolTabs   = document.querySelectorAll('.tool-tab');
    const toolPanels = document.querySelectorAll('.tool-panel');

    Q.activatePanel = function (name) {
        toolTabs.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.panel === name);
        });
        toolPanels.forEach(panel => {
            panel.classList.toggle('active', panel.id === 'panel-' + name);
        });
    };

    toolTabs.forEach(btn => {
        btn.addEventListener('click', () => {
            const name = btn.dataset.panel;
            if (!name) return;
            Q.activatePanel(name);
        });
    });

    // =========================
    // 📏 ӨЛШЕМ (width/height/depth + плінтус)
    // Enter басқанда ғана қолдану
    const sizeFields = [widthInput, heightInput, depthInput, plinthHeightInput, corpusThickness, wallGapInput].filter(Boolean);

    function handleSizeEnter(e) {
        if (e.key !== 'Enter') return;
        const t = e.target;
        if (!t || !(t instanceof HTMLElement)) return;
        const tag = t.tagName.toLowerCase();
        if (tag !== 'input' && tag !== 'select') return; // textarea-ға кедергі жасамаймыз
        if (!sizeFields.includes(t)) return;
        e.preventDefault();
        Q.runUndoable(() => {
            Q.rebuildWithCurrentSize(true); // preserve layout
        });
        if (typeof t.blur === 'function') t.blur();
    }

    sizeFields.forEach(el => {
        el.addEventListener('keydown', handleSizeEnter);
    });

    [
        corpusMaterial, corpusThickness,
        facadeMaterial, facadeThickness, facadeType,
        corpusColorInput, facadeColorInput, facadeStyle, facadeFrameWidthInput,
        backMaterial, drawerFacadeGapInput, drawerBodyHeightInput, drawerStackGapInput, drawerRunnerThkInput, insertGapLeftInput, insertGapRightInput, drawerFacadeMaterial,
        drawerRunnerTypeSelect, drawerDepthBrandSelect, pipeColorInput, bottomMountInput
    ].forEach(el => {
        if (!el) return;
        el.addEventListener('change', () => {
            Q.runUndoable(() => {
                Q.rebuildWithCurrentSize(true); // layout сақталсын
            });
        });
    });

    // =========================
    // VIEW (Көлеңке / Эскиз / Ренген)
    // =========================
    if (viewButtons && viewButtons.length) {
        viewButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const mode = btn.dataset.view;
                if (!mode) return;
                Q.setViewMode(mode);
                viewButtons.forEach(b => b.classList.toggle('active', b === btn));
            });
        });
    }

    // =========================
    // Таңдау режимі: ▭ Секция / ◫ Бөлшек
    // =========================
    if (modeButtons && modeButtons.length) {
        modeButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const mode = btn.dataset.mode || 'section';
                Q.selectionMode = mode;
                modeButtons.forEach(b => b.classList.toggle('active', b === btn));
            });
        });
    }

    // =========================
    // Өлшем сызықтарын көрсету/жасыру
    // =========================
    if (toggleDimsBtn) {
        toggleDimsBtn.addEventListener('click', () => {
            Q.dimensionsVisible = !Q.dimensionsVisible;
            toggleDimsBtn.classList.toggle('active', Q.dimensionsVisible);
        });
    }

    // =========================
    // Фасадты жасыру / көрсету
    // =========================
    if (toggleFacadeBtn) {
        toggleFacadeBtn.addEventListener('click', () => {
            Q.facadesHidden = !Q.facadesHidden;
            toggleFacadeBtn.classList.toggle('active', !Q.facadesHidden);
        });
    }

    // =========================
    // Кромканы көрсету/жасыру
    // =========================
    if (toggleEdgeBtn) {
        toggleEdgeBtn.addEventListener('click', () => {
            Q.edgeHighlightEnabled = !Q.edgeHighlightEnabled;
            Q.applyEdgeHighlightVisibility();
        });
    }

    // =========================
    // Ақпарат боксын көрсету/жасыру
    // =========================
    if (toggleInfoBtn) {
        toggleInfoBtn.addEventListener('click', () => {
            Q.infoPanelVisible = !Q.infoPanelVisible;
            toggleInfoBtn.classList.toggle('active', Q.infoPanelVisible);
        });
    }

    // =========================
    // Undo / Redo
    // =========================
    if (undoBtn) {
        undoBtn.addEventListener('click', () => {
            Q.undo();
        });
    }
    if (redoBtn) {
        redoBtn.addEventListener('click', () => {
            Q.redo();
        });
    }

    // =========================
    // ▭ СЕКЦИЯ НАСТРОЙКАЛАРЫ
    // =========================

    // Ескі select емес, қазір bizde .section-list div – бірақ бұл listener зиян келтірмейді
    if (sectionSelect && sectionSelect.tagName === 'SELECT') {
        sectionSelect.addEventListener('change', () => {
            const id = parseInt(sectionSelect.value, 10);
            if (isNaN(id)) return;
            Q.selectedSectionId = id;
            Q.updateSelectedSectionHelper();
            Q.rebuildSectionSelect();
            Q.rebuildShelvesUI();
        });
    }

    if (sectionWidthInput) {
        sectionWidthInput.addEventListener('change', () => {
            const newW = parseFloat(sectionWidthInput.value);
            if (!newW || newW <= 50) return;
            const secId = Q.selectedSectionId;
            if (!secId) return;
            Q.runUndoable(() => {
                Q.resizeSectionWidth(secId, newW);
            });
        });
    }

    if (splitSectionBtn) {
        splitSectionBtn.addEventListener('click', () => {
            const secId = Q.selectedSectionId;
            if (!secId) return;
            const pattern = (splitPatternInput && splitPatternInput.value)
                ? splitPatternInput.value
                : '1/1';
            Q.runUndoable(() => {
                Q.splitSectionByPattern(secId, pattern);
            });
        });
    }

    // =========================
    // ⧉ ПОЛКА НАСТРОЙКАЛАРЫ
    // =========================

    // 🔧 ЕҢ МАҢЫЗДЫ ФУНКЦИЯ: Таңдалған секцияны алу
    function getSelectedSection() {
        const secs = Q.sections || [];
        if (!secs.length) return null;

        let id = Q.selectedSectionId;

        // Егер еш секция таңдалмаған болса – автоматты түрде бірінші секцияны таңдаймыз
        if (!id) {
            id = secs[0].id;
            Q.selectedSectionId = id;

            if (typeof Q.updateSelectedSectionHelper === 'function') {
                Q.updateSelectedSectionHelper();
            }
            if (typeof Q.rebuildSectionSelect === 'function') {
                Q.rebuildSectionSelect();
            }
            // Полка панеліндегі UI-ды да жаңартып қоямыз
            if (typeof Q.rebuildShelvesUI === 'function') {
                Q.rebuildShelvesUI();
            }
        }

        return secs.find(s => s.id === id) || secs[0] || null;
    }

    // Полка қосу (қолмен біреу)
    if (addShelfBtn) {
        addShelfBtn.addEventListener('click', () => {
            const sec = getSelectedSection();
            if (!sec) return;

            const h = parseFloat(shelfHeightInput.value);
            if (!h || h <= 0 || h >= sec.h - 20) return;

            Q.runUndoable(() => {
                const shelves = Q.sectionShelves;
                if (!shelves[sec.id]) shelves[sec.id] = [];
                shelves[sec.id].push(h);

                Q.rebuildShelvesUI();
                Q.rebuildShelvesGroup();
            });
        });
    }

    // Авто полкалар
    if (autoShelvesBtn) {
        const handleAutoShelves = () => {
            const sec = getSelectedSection();
            if (!sec) return;

            let count = parseInt(shelfCountInput.value, 10);
            if (isNaN(count) || count <= 0) count = 1;

            const marginTop = 80;
            const marginBot = 80;
            const usable = Math.max(100, sec.h - marginTop - marginBot);
            const step = usable / (count + 1);

            const newList = [];
            for (let i = 1; i <= count; i++) {
                const h = marginTop + step * i;
                if (h > 0 && h < sec.h - 20) {
                    newList.push(h);
                }
            }

            Q.runUndoable(() => {
                const shelves = Q.sectionShelves;
                shelves[sec.id] = newList;

                Q.rebuildShelvesUI();
                Q.rebuildShelvesGroup();
            });
        };
        autoShelvesBtn.addEventListener('click', handleAutoShelves);
        if (shelfCountInput) {
            shelfCountInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAutoShelves();
                }
            });
        }
    }

    // Полка биіктігін тізімнен редакциялау
    if (updateShelfBtn) {
        const handleUpdateShelf = () => {
            const sec = getSelectedSection();
            if (!sec) return;

            const shelves = Q.sectionShelves;
            const list = shelves[sec.id] || [];
            if (!list.length) return;

            const oldVal = parseFloat(shelfSelect.value);
            if (isNaN(oldVal)) return;

            const newVal = parseFloat(editShelfHeightInput.value);
            if (!newVal || newVal <= 0 || newVal >= sec.h - 20) return;

            const idx = list.indexOf(oldVal);
            if (idx === -1) return;

            Q.runUndoable(() => {
                list[idx] = newVal;
                shelves[sec.id] = list;

                Q.rebuildShelvesUI();
                Q.rebuildShelvesGroup();
            });
        };
        updateShelfBtn.addEventListener('click', handleUpdateShelf);
        if (editShelfHeightInput) {
            editShelfHeightInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    handleUpdateShelf();
                }
            });
        }
    }

    // Таңдалған полкадан кейінгі арақашықтықты өзгерту
    if (applyShelfGapBtn) {
        applyShelfGapBtn.addEventListener('click', () => {
            const sec = getSelectedSection();
            if (!sec) return;

            const shelves = Q.sectionShelves;
            const list = shelves[sec.id] || [];
            if (!list.length) return;

            const hSel = parseFloat(shelfSelect.value);
            if (isNaN(hSel)) return;

            const gap = parseFloat(shelfGapInput.value);
            if (!gap || gap <= 0) return;

            const sorted = list.slice().sort((a, b) => a - b);
            const idx = sorted.indexOf(hSel);
            if (idx === -1 || idx === sorted.length - 1) return;

            const current = sorted[idx];
            const next    = sorted[idx + 1];

            const newNext = current + gap;
            if (newNext <= current + 20 || newNext >= sec.h - 20) return;

            Q.runUndoable(() => {
                const origIdx = list.indexOf(next);
                if (origIdx !== -1) {
                    list[origIdx] = newNext;
                }

                shelves[sec.id] = list;
                Q.rebuildShelvesUI();
                Q.rebuildShelvesGroup();
            });
        });
    }

    // Екі полканың арасына жаңа полка қосу
    if (insertShelfBetweenBtn) {
        insertShelfBetweenBtn.addEventListener('click', () => {
            const sec = getSelectedSection();
            if (!sec) return;

            const shelves = Q.sectionShelves;
            const list = shelves[sec.id] || [];
            if (!list.length) return;

            const hSel = parseFloat(shelfSelect.value);
            if (isNaN(hSel)) return;

            const sorted = list.slice().sort((a, b) => a - b);
            const idx = sorted.indexOf(hSel);
            if (idx === -1 || idx === sorted.length - 1) return;

            const nextH = sorted[idx + 1];
            const mid   = (hSel + nextH) / 2;
            if (mid <= 0 || mid >= sec.h - 20) return;

            Q.runUndoable(() => {
                list.push(mid);
                shelves[sec.id] = list;

                Q.rebuildShelvesUI();
                Q.rebuildShelvesGroup();
            });
        });
    }

    // =========================
    // ◫ БӨЛШЕК НАСТРОЙКАЛАРЫ
    // =========================
    if (partOffsetFrontInput) {
        partOffsetFrontInput.addEventListener('input', () => {
            const parts = Q.parts;
            const pid = Q.selectedPartId;
            if (!pid || !parts[pid]) return;
            const p = parts[pid];
            p.frontOffset = parseFloat(partOffsetFrontInput.value) || 0;
            if (typeof Q.applyPartOffsets === 'function') {
                Q.applyPartOffsets(p);
            }
            if (typeof Q.refreshPartPreview === 'function') {
                Q.refreshPartPreview();
            }
        });
    }

    function refreshStructureListAfterEdgeChange() {
        if (typeof Q.rebuildStructureList === 'function') {
            Q.rebuildStructureList();
        }
    }

    function edgeChanged() {
        const parts = Q.parts;
        const pid = Q.selectedPartId;
        if (!pid || !parts[pid]) return;
        const p = parts[pid];
        p.edge = p.edge || {};
        p.edge.front = !!(edgeFrontInput && edgeFrontInput.checked);
        p.edge.back  = !!(edgeBackInput  && edgeBackInput.checked);
        p.edge.left  = !!(edgeLeftInput  && edgeLeftInput.checked);
        p.edge.right = !!(edgeRightInput && edgeRightInput.checked);
        if (typeof Q.refreshPartPreview === 'function') {
            Q.refreshPartPreview();
        }
        if (typeof Q.applyEdgeHighlightVisibility === 'function' && typeof Q.rebuildEdgeHighlightForPart === 'function') {
            Q.rebuildEdgeHighlightForPart(p);
            Q.applyEdgeHighlightVisibility();
            refreshStructureListAfterEdgeChange();
        }
    }

    [edgeFrontInput, edgeBackInput, edgeLeftInput, edgeRightInput].forEach(el => {
        if (!el) return;
        el.addEventListener('change', edgeChanged);
    });

    if (partDrillingInput) {
        partDrillingInput.addEventListener('input', () => {
            const parts = Q.parts;
            const pid = Q.selectedPartId;
            if (!pid || !parts[pid]) return;
            parts[pid].drilling = partDrillingInput.value || '';
        });
    }

    function resolveDrawerValueFromExtra(extra, key) {
        let target = extra;
        let depth = 0;
        while (target && typeof target === 'object' && depth < 8) {
            if (Object.prototype.hasOwnProperty.call(target, key)) {
                return target[key];
            }
            target = target.extra;
            depth++;
        }
        return null;
    }

    function isDrawerEdgePanel(part) {
        if (!part) return false;
        const drawerPart = resolveDrawerValueFromExtra(part && part.extra, 'drawerPart');
        if (drawerPart === 'back' || drawerPart === 'front') {
            return true;
        }
        const typeLower = (part.type || '').toLowerCase();
        return typeLower === 'plinth';
    }

    function offsetsChanged() {
        const parts = Q.parts;
        const pid = Q.selectedPartId;
        if (!pid || !parts[pid]) return;
        const p = parts[pid];
        p.offsets = p.offsets || { front:0, back:0, bottom:0, top:0, left:0, right:0 };
        const typeLower = (p.type || '').toLowerCase();
        const isDrawerFacade = (typeLower === 'drawer_facade');
        const isDrawerEdgePanelFlag = isDrawerEdgePanel(p);
        const drawerPart = resolveDrawerValueFromExtra(p && p.extra, 'drawerPart');
        const isDrawerBottomPanel = drawerPart === 'bottom';
        const isDoorPanel = (typeLower === 'door');
        const isTopPanel = (typeLower === 'top');
        const isShelfPanel = (typeLower === 'shelf');
        const isBottomPanel = (typeLower === 'bottom');
        const isBackPanel = (typeLower === 'back');
        const isHorizontalPanel = isTopPanel || isShelfPanel;
        const useFacadeOffsetMode = isDrawerFacade || isDrawerEdgePanelFlag || isDoorPanel || isBackPanel;

        const frontVal = parseFloat(offsetFrontInput && offsetFrontInput.value) || 0;
        const backVal = parseFloat(offsetBackInput && offsetBackInput.value) || 0;
        const bottomVal = parseFloat(offsetBottomInput && offsetBottomInput.value) || 0;
        const topVal = parseFloat(offsetTopInput && offsetTopInput.value) || 0;

        if (useFacadeOffsetMode) {
            p.offsets.front = 0;
            p.offsets.back = 0;
            p.offsets.bottom = frontVal;
            p.offsets.top = backVal;
            p.offsets.left = bottomVal;
            p.offsets.right = topVal;
        } else if (isHorizontalPanel || isBottomPanel || isDrawerBottomPanel) {
            p.offsets.front = frontVal;
            p.offsets.back = backVal;
            p.offsets.bottom = 0;
            p.offsets.top = 0;
            p.offsets.left = bottomVal;
            p.offsets.right = topVal;
        } else {
            p.offsets.front = frontVal;
            p.offsets.back = backVal;
            p.offsets.bottom = bottomVal;
            p.offsets.top = topVal;
            p.offsets.left = 0;
            p.offsets.right = 0;
        }

        if (typeof Q.applyPartOffsets === 'function') {
            Q.applyPartOffsets(p);
        }
        if (typeof Q.refreshPartPreview === 'function') {
            Q.refreshPartPreview();
        }
    }

    [offsetFrontInput, offsetBackInput, offsetBottomInput, offsetTopInput].forEach(el => {
        if (!el) return;
        el.addEventListener('input', offsetsChanged);
    });

})();
