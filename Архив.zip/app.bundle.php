<?php
declare(strict_types=1);

header('Content-Type: application/javascript; charset=utf-8');
header('X-Content-Type-Options: nosniff');
// Dev-friendly defaults: avoid stale cache while iterating over split JS files.
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$root = __DIR__;
$parts = [
    $root . '/app.renderer.js',
    $root . '/app.ui.js',
    $root . '/app.model.js',
];

foreach ($parts as $file) {
    if (!is_file($file)) {
        http_response_code(500);
        $name = basename($file);
        echo "console.error('Missing bundle part: " . addslashes($name) . "');\n";
        exit;
    }
    readfile($file);
    echo "\n";
}

