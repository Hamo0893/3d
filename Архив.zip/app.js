// app.js (deprecated)
// This project now loads `app.bundle.php` which concatenates:
//   - app.renderer.js
//   - app.ui.js
//   - app.model.js
// The previous monolithic file is kept as `app.legacy.js` for backup.
