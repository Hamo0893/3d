// app.js
(function () {
    const errorBox     = document.getElementById('errorBox');
    const errorClose   = document.getElementById('errorClose');
    const errorText    = document.getElementById('errorText');
    const dimensionBox = document.getElementById('dimensionBox');

    function showError(msg) {
        if (!errorBox) return;
        if (errorText) errorText.textContent = msg;
        else errorBox.textContent = msg;
        errorBox.style.display = 'flex';
    }

    if (errorClose && errorBox) {
        errorClose.addEventListener('click', () => {
            errorBox.style.display = 'none';
        });
    }

    try {
        if (!window.THREE || !THREE.OrbitControls) {
            showError('THREE немесе OrbitControls жүктелген жоқ');
            return;
        }

        const wrap = document.getElementById('canvas-wrap');
        if (!wrap) {
            showError('#canvas-wrap табылмады');
            return;
        }

        // Renderer
        const renderer = new THREE.WebGLRenderer({antialias: true});
        renderer.setPixelRatio(window.devicePixelRatio || 1);
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        wrap.appendChild(renderer.domElement);

        // Scene + Camera
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0xf3f3f3);

        // Негізгі перспективалық камера (Изометрия үшін)
        const perspCamera = new THREE.PerspectiveCamera(45, 1, 1, 10000);
        perspCamera.position.set(3800, 2600, 3800);

        // Орфографиялық камера (Алды / Жаны / Үсті – параллель вид)
        const aspectInit = (wrap.clientWidth || 800) / (wrap.clientHeight || 600);
        const orthoSizeInit = 3000;
        const orthoCamera = new THREE.OrthographicCamera(
            -orthoSizeInit * aspectInit,
            +orthoSizeInit * aspectInit,
            +orthoSizeInit,
            -orthoSizeInit,
            1,
            10000
        );
        orthoCamera.position.set(3800, 2600, 3800);
        orthoCamera.lookAt(0, 1200, 0);

        // Қолданылып жатқан актив камера
        let activeCamera = perspCamera;

        const controls = new THREE.OrbitControls(activeCamera, renderer.domElement);
        controls.target.set(0, 1200, 0);
        controls.update();

        // Lights
        scene.add(new THREE.AmbientLight(0xffffff, 0.4));
        const dirLight = new THREE.DirectionalLight(0xffffff, 1.15);
        dirLight.position.set(2000, 3000, 2000);
        dirLight.castShadow = true;
        dirLight.shadow.mapSize.width  = 4096;
        dirLight.shadow.mapSize.height = 4096;
        dirLight.shadow.bias = -0.0005;
        dirLight.shadow.normalBias = 0.02;
        scene.add(dirLight);

        // Floor
        const floorGeo = new THREE.PlaneGeometry(6000, 6000);
        const floorMat = new THREE.ShadowMaterial({ color: 0x000000, opacity: 0.25 });
        const floor = new THREE.Mesh(floorGeo, floorMat);
        floor.rotation.x = -Math.PI / 2;
        floor.position.y = 0;
        floor.receiveShadow = true;
        scene.add(floor);

        // Grid
        const grid = new THREE.GridHelper(5000, 50, 0xcccccc, 0xeeeeee);
        scene.add(grid);

        // Raycaster
        const raycaster = new THREE.Raycaster();
        const mouse     = new THREE.Vector2();

        let cabinetGroup           = null;
        let innerVolumeMesh        = null;
        let doorsGroup             = null;
        let plinthGroup            = null;
        let shelvesGroup           = null;
        let insertsGroup           = null;
        let dividersGroup          = null;
        let bodyCore               = null;
        let falshGroup             = null;
        let facadesHidden          = false;
        let allMeshes              = [];  // тек негізгі Mesh (Edges емес)
        let allEdges               = [];
        let currentViewMode        = 'sketch';

        // Секциялар (вертикаль)
        let sections               = [];  // {id,x,y,w,h}
        let nextSectionId          = 1;
        let innerW = 0;
        let innerH = 0;
        let prevInnerW = 0;
        let prevInnerH = 0;

        let globalThickness = 16;
        let globalDepth     = 600;
        let plinthHeight    = 100;
        let currentW = 0, currentH = 0, currentD = 0;
        let wallGap          = 10;
        let selectedSectionId      = null;
        let selectedSectionHelper  = null;
        let selectedShelfSubId     = null; // `${sectionId}:${idx}`
        let selectedShelfSubHelper = null;
        const subHighlightBaseColor   = new THREE.Color(0x4fa3ff);
        let sectionHighlightStart  = performance.now ? performance.now() : Date.now();
        const sectionHighlightBaseColor    = new THREE.Color(0xff77bb);
        const sectionHighlightBrightColor  = new THREE.Color(0xffa6d7);
        const sectionHighlightTempColor    = new THREE.Color();
        let sectionShelves         = {}; // sectionId => [heights]
        let sectionShelfOffsets    = {}; // sectionId => алдынан отступ (мм)
        let shelfInserts           = {}; // key `${sectionId}:${idx}` => [{ type, variant? }]
        let selectedInsertKey      = null; // `${sectionId}:${idx}#${insertIndex}`
        let facadeDividerCenters    = [];  // Накладной фасадта есік аралықтарының ортасы
        let shelfNameCounter        = 1;   // rebuild сайын полка атауларының уникальды санағы
        let cabinetOffsetX          = 0;   // сол жақ артқы бұрыштқыдан ығысқан (origin)
        let cabinetOffsetZ          = 0;
        const WALL_THICKNESS_DEFAULT = 1;
        let edgeHighlightEnabled    = false;
        let wallGroup               = null;
        let walls                   = [];
        let nextWallId              = 1;
        let selectedWallId          = null;
        let wallEnabled             = false;
        let currentAxisView         = 'iso';
        let wallPreviewInsertIndex  = null;
        let newWalls                = [];
        let newWallGroup            = null;
        let selectedNewWallId       = null;
        let wallSections            = {}; // wallId => [{id,parentId,x,y,w,h}]
        let selectedWallSectionId   = null;
        let selectedWallSectionHelper = null;
        let wallSectionHighlightStart = performance.now ? performance.now() : Date.now();
        const wallSectionHighlightBaseColor   = new THREE.Color(0x2bbf6a);
        const wallSectionHighlightBrightColor = new THREE.Color(0x66ff9c);
        const wallSectionHighlightTempColor   = new THREE.Color();
        let wallSectionPlusSprites  = [];
        let nextWallSectionId       = 1;

        let falshPanels             = [];
        let nextFalshId             = 1;
        let falshLeftSideEnabled    = false;
        let falshRightSideEnabled   = false;
        let falshLeftSideSize       = null;
        let falshRightSideSize      = null;

        let cabinetSpawned          = false;
        let cabinetBaseOffset       = { x: 0, y: 0, z: 0 };
        let cabinetRotationY        = 0;
        let cabinetWallId           = null;
        let cabinetSectionId        = null;
        let cabinets                = []; // [{id, wallId, sectionId, baseOffset, state, group}]
        let activeCabinetId         = null;
        const getAllCabinetGroups = () => {
            const arr = [];
            cabinets.forEach(c => {
                if (c.hidden) return;
                if (c.group) {
                    arr.push({ group: c.group, cabinet: c });
                }
            });
            const activeHidden = isCabinetHidden(activeCabinetId);
            const activeCab = cabinets.find(c => c.id === activeCabinetId);
            if (cabinetGroup && !activeHidden && !arr.some(x => x.group === cabinetGroup)) {
                arr.push({ group: cabinetGroup, cabinet: activeCab || null });
            }
            return arr;
        };

        function computeGlobalMaxSectionId() {
            let maxId = 0;
            const collect = (list) => {
                (list || []).forEach(s => {
                    const sid = parseFloat(s.id);
                    if (Number.isFinite(sid)) {
                        if (sid > maxId) maxId = sid;
                    }
                });
            };
            collect(sections);
            cabinets.forEach(c => {
                if (c && c.state && Array.isArray(c.state.sections)) {
                    collect(c.state.sections);
                }
            });
            return maxId;
        }

        function refreshNextSectionIdGlobal() {
            nextSectionId = computeGlobalMaxSectionId() + 1;
        }

        function isCabinetHidden(id) {
            if (!id) return false;
            const c = cabinets.find(x => x.id === id);
            return !!(c && c.hidden);
        }

        function setCabinetHidden(id, hidden) {
            const c = cabinets.find(x => x.id === id);
            if (!c) return;
            c.hidden = !!hidden;
            if (c.group) c.group.visible = !hidden;
            syncActiveCabinetRecord();
            rebuildDimensionHelpers();
        }

        function applyActiveCabinetVisibility() {
            getAllCabinetGroups().forEach(({ group, cabinet }) => {
                if (!group || !cabinet) return;
                const hidden = isCabinetHidden(cabinet.id);
                group.visible = !hidden; // белсенді емес шкафтар да көрінеді, егер жасырылмаған болса
                if (!group.parent) scene.add(group);
            });
            if (cabinetGroup && !cabinetGroup.parent) {
                const hidden = isCabinetHidden(activeCabinetId);
                cabinetGroup.visible = !hidden;
                scene.add(cabinetGroup);
            }
            syncCabinetVisibilityBtn();
        }

        function getActiveWallInfo() {
            if (!newWalls || !newWalls.length) return null;
            let wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) wall = newWalls[0];
            const w = wall.w || 0;
            const h = wall.h || 0;
            const x = wall.x || 0;
            const y = wall.y || 0;
            const z = wall.z || 0;
            const type = wall.type || 'frontal';
            return { w, h, x, y, z, type };
        }

        // Бөлшектер (part) инфо
        let parts          = {}; // partId => {...}
        let nextPartId     = 1;
        let selectedPartId = null;
        let selectedPartBoxHelper = null;
        const transientPartTypes = new Set(['shelf']);

        // Таңдау режимі: 'section' | 'part'
        let selectionMode = 'section';

        // Есіктер анимациясы
        let doorAnimEnabled = false;
        let doorGlobalOpen  = false; // deprecated toggle removed
        // Есіктер анимациясы – плавный open/close + звук
        let doorAnimations      = [];
        let drawerAnimations    = [];
        let doorSound           = null;
        let drawerSound         = null;
        let pendingDoorStates   = null; // createCabinet қолданар алдында state-тен берілетін есік күйі
        try {
            doorSound = new Audio('door-sound.mp3');
            doorSound.volume = 0.35;
        } catch (e) {
            doorSound = null;
        }
        try {
            drawerSound = new Audio('box.mp3');
            drawerSound.volume = 0.35;
        } catch (e) {
            drawerSound = null;
        }


        

        function getDoorOpenSignByIndex(patternStr, doorIndex, totalDoors) {
            patternStr = (patternStr || '').replace(/\s+/g, '');
            let sign = -1;

            // 1 / 1 → екі есік, екі жаққа (сол, оң)
            if (patternStr === '1/1') {
                sign = (doorIndex === 0 ? -1 : +1);
            }
            // 2 → бір секцияда 2 есік: сол жақ есік солға, оң жақ есік оңға
            else if (patternStr === '2') {
                sign = (doorIndex === 0 ? -1 : +1);
            }
            // 2 / 1 → алғашқы екі есік – екі жаққа, үшінші есік – оңға
            else if (patternStr === '2/1') {
                if (doorIndex === 0) sign = -1;
                else sign = +1;
            }
            // 1 / 2 → алғашқы есік солға, келесі екі есік – екі жаққа
            else if (patternStr === '1/2') {
                if (doorIndex === 0) sign = -1;
                else if (doorIndex === 1) sign = -1;
                else sign = +1;
            }
            // 1 / 1 / 1 → алғашқы есік солға, келесі екеуі – оңға
            else if (patternStr === '1/1/1') {
                if (doorIndex === 0) sign = -1;
                else sign = +1;
            }

            return sign;
        }

        function findDoorsGroupFromObject(obj) {
            let o = obj;
            while (o) {
                if (o.userData && o.userData.isDoorsGroup) return o;
                o = o.parent;
            }
            return null;
        }

        function animateDoorHinge(hinge) {
            if (!hinge) return;
            const ownerDoorsGroup = findDoorsGroupFromObject(hinge);
            if (!ownerDoorsGroup) return;

            // Есіктер тізімін солдан оңға қарай аламыз (нақты осы кабинеттің group-ынан)
            const hinges = [];
            ownerDoorsGroup.traverse(obj => {
                if (obj.userData && obj.userData.isDoorHinge) {
                    hinges.push(obj);
                }
            });
            hinges.sort((a, b) => a.position.x - b.position.x);

            const totalDoors = hinges.length || 1;
            let doorIndex = hinges.indexOf(hinge);
            if (doorIndex < 0) doorIndex = 0;

            const patternStr = (ownerDoorsGroup.userData && ownerDoorsGroup.userData.splitPattern)
                ? ownerDoorsGroup.userData.splitPattern
                : (splitPatternInput ? splitPatternInput.value : '');
            let rawSign = getDoorOpenSignByIndex(patternStr, doorIndex, totalDoors);
            if (!rawSign) rawSign = -1; // default – солға ашылатын

            // Бірінші рет ашылса – айналу осін дұрыстап қоямыз
            if (!hinge.userData.pivotPrepared) {
                const doorW     = hinge.userData.doorWidth;
                const doorGroup = hinge.userData.doorGroup;

                if (doorW && doorGroup) {
                    // Оң жаққа ашылатын есік → осі оң жақ қырына ауысады
                    if (rawSign > 0) {
                        hinge.position.x += doorW;
                        doorGroup.position.x = -doorW / 2;
                    } else {
                        // Сол жаққа ашылатын есік → осі сол жақ қырында қалады
                        doorGroup.position.x = doorW / 2;
                    }
                }
                hinge.userData.pivotPrepared = true;
            }

            // Есіктердің барлығы сыртқа (қолданушыға қарай) ашылуы үшін – бастапқы бағытты қолданамыз
            const sign = rawSign;

            const isOpen  = hinge.userData.open || false;
            const nowOpen = !isOpen;
            hinge.userData.open = nowOpen;

            const from = hinge.rotation.y || 0;
            const to   = nowOpen ? sign * (Math.PI / 2) : 0;
            const duration = 350; // мс – плавная анимация

            if (Array.isArray(doorAnimations)) {
                doorAnimations.push({
                    hinge: hinge,
                    from: from,
                    to: to,
                    start: performance.now(),
                    duration: duration
                });
            }

            if (doorSound) {
                try {
                    doorSound.currentTime = 0;
                    const p = doorSound.play();
                    if (p && typeof p.catch === 'function') {
                        p.catch(()=>{});
                    }
                } catch (e) {}
            }
        }

        function getSelectedInsertTypeForSettings() {
            if (selectedInsertKey) {
                const [subId, idxStr] = selectedInsertKey.split('#');
                const idx = parseInt(idxStr, 10);
                if (subId && Number.isInteger(idx)) {
                    const arr = shelfInserts[subId] || [];
                    if (arr[idx]) return arr[idx].type || null;
                }
            }
            return null;
        }

        function updateInsertSettingsVisibility() {
            const type = getSelectedInsertTypeForSettings() || (insertTypeSelect ? insertTypeSelect.value : null);
            const showDrawer = type === 'drawer';
            const showPipe   = type === 'pipe';
            const drawerElems = document.querySelectorAll('.drawer-settings');
            const pipeElems   = document.querySelectorAll('.pipe-settings');
            drawerElems.forEach(el => {
                if (!el) return;
                el.style.display = showDrawer ? '' : 'none';
            });
            pipeElems.forEach(el => {
                if (!el) return;
                el.style.display = showPipe ? '' : 'none';
            });
        }

        function getPipeColorHex() {
            if (!pipeColorInput || !pipeColorInput.value) return 0x111111;
            const v = pipeColorInput.value.trim();
            const normalized = v.startsWith('#') ? v.slice(1) : v;
            if (/^[0-9a-fA-F]{6}$/.test(normalized)) {
                return parseInt(normalized, 16);
            }
            return 0x111111;
        }

        function rebuildInsertsUI() {
            if (!insertList) return;
            insertList.innerHTML = '';

            const subsAll = getShelfSubSections();
            sanitizeShelfInserts(subsAll);
            const entries = [];
            const targetSubs = selectedShelfSubId
                ? subsAll.filter(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId)
                : subsAll;
            targetSubs.forEach(sub => {
                const key = `${sub.sectionId}:${sub.idx}`;
                const arr = shelfInserts[key] || [];
                arr.forEach((ins, i) => entries.push({ sub, ins, idxInSub: i }));
            });

            if (!entries.length) {
                insertList.textContent = 'Наполнение жоқ';
                selectedInsertKey = null;
                updateInsertSettingsVisibility();
                return;
            }

            // Таңдау жоғалса, бірінші элементті автоматты түрде таңдаймыз
            const hasSelection = selectedInsertKey && entries.some(e => `${e.sub.sectionId}:${e.sub.idx}#${e.idxInSub}` === selectedInsertKey);
            if (!hasSelection) {
                const first = entries[0];
                selectedInsertKey = `${first.sub.sectionId}:${first.sub.idx}#${first.idxInSub}`;
                selectedShelfSubId = `${first.sub.sectionId}:${first.sub.idx}`;
            }

            entries.forEach(({ sub, ins, idxInSub }) => {
                const key = `${sub.sectionId}:${sub.idx}`;
                const row = document.createElement('div');
                row.className = 'simple-list-item shelf-sub-row';
                row.dataset.subId = key;
                row.dataset.insertIdx = String(idxInSub);
                const thisKey = `${key}#${idxInSub}`;
                const isSelected = selectedInsertKey && selectedInsertKey === thisKey;
                if (isSelected) {
                    row.classList.add('active');
                }

                const name = document.createElement('div');
                name.className = 'meta';
                const drawerLabel = (ins.variant === 'tandembox')
                    ? 'Тандем бокс'
                    : (ins.variant === 'tandem')
                        ? 'Тандем'
                        : 'Телескопический';
                const labelShort = sub.sectionId + '.' + sub.idx;
                const pipeLabel = ins.type === 'pipe'
                    ? 'Труба #' + (idxInSub + 1)
                    : 'Ящик (' + drawerLabel + ')';
                name.textContent = labelShort + ' · ' + pipeLabel;

                const delBtn = document.createElement('button');
                delBtn.type = 'button';
                delBtn.textContent = '🗑';
                delBtn.className = 'danger-btn';

                row.appendChild(name);
                row.appendChild(delBtn);

                row.addEventListener('click', () => {
                    selectedShelfSubId = row.dataset.subId;
                    selectedInsertKey = `${row.dataset.subId}#${row.dataset.insertIdx}`;
                    syncDrawerDepthSelect(sub);
                    const activeRows = insertList.querySelectorAll('.shelf-sub-row.active');
                    activeRows.forEach(r => r.classList.remove('active'));
                    row.classList.add('active');
                    updateSelectedShelfSubHelper();
                    syncDrawerActiveRow();
                    updateInsertSettingsVisibility();
                });
                delBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const arr = Array.isArray(shelfInserts[key]) ? shelfInserts[key] : [];
                    arr.splice(idxInSub, 1);
                    shelfInserts[key] = arr;
                    if (selectedShelfSubId === key && arr.length === 0) selectedShelfSubId = null;
                    if (selectedInsertKey === `${key}#${idxInSub}`) selectedInsertKey = null;
                    rebuildInsertsUI();
                    rebuildInsertsGroup();
                });

                insertList.appendChild(row);
            });

            const activeEntry = entries.find(e => `${e.sub.sectionId}:${e.sub.idx}#${e.idxInSub}` === selectedInsertKey);
            if (activeEntry) {
                syncDrawerDepthSelect(activeEntry.sub);
            }

            rebuildDrawerSubList();
            updateInsertSettingsVisibility();
        }

// Өлшемдік кесінділер (стрелкасыз)
        let dimensionHelpersGroup = null;
        let dimensionsVisible     = true;
        let infoPanelVisible      = false;
        let structureVisible      = false;

        // Undo/Redo стек
        let undoStack = [];
        let redoStack = [];
        let hasUnsavedChanges = false;

        // Материал түстері
        function colorFromInputById(id, fallback) {
            const el = document.getElementById(id);
            if (!el || !el.value) return fallback;
            const hexStr = String(el.value).trim();
            if (!/^#?[0-9a-fA-F]{6}$/.test(hexStr)) return fallback;
            return parseInt(hexStr.replace('#', ''), 16);
        }

        function getCorpusColor(value) {
            let base = 0xf5f5f5;
            if (value === 'sonoma')   base = 0xd2b48c;
            if (value === 'graphite') base = 0x444444;
            return colorFromInputById('corpusColor', base);
        }

        function getFacadeColor(value) {
            let base = 0xffffff;
            if (value === 'beige') base = 0xf5e1c4;
            if (value === 'black') base = 0x111111;
            return colorFromInputById('facadeColor', base);
        }

        // === ІШКІ ТЕРЕҢДІК: ФАСАДҚА БАЙЛАНЫСТЫ ===
        // - Вкладной: фасад қалыңдығынан 2 мм ге ішке кіреді
        // - Накладной: корпуспен бірдей тереңдік
        function computeInnerParams() {
            const facadeTypeEl      = document.getElementById('facadeType');
            const facadeThicknessEl = document.getElementById('facadeThickness');

            const typeVal  = facadeTypeEl ? facadeTypeEl.value : 'vkladnoy';
            const thickVal = facadeThicknessEl ? (parseFloat(facadeThicknessEl.value) || 18) : 18;

            const backPlaneInside  = -globalDepth / 2;
            let frontPlaneInside = globalDepth / 2;

            let extraFront = 0;
            if (typeVal === 'vkladnoy') {
                extraFront = thickVal + 2;
            }
            frontPlaneInside -= extraFront;

            const depthInside = frontPlaneInside - backPlaneInside;
            const centerZ     = backPlaneInside + depthInside / 2;

            return {
                depthInside: depthInside,
                centerZ: centerZ
            };
        }

        function readWallGap() {
            const parsed = parseFloat(wallGapInput ? wallGapInput.value : '');
            wallGap = Number.isFinite(parsed) ? parsed : 10;
            return wallGap;
        }

        function readDrawerFacadeGap() {
            if (!drawerFacadeGapInput) return 3;
            let v = parseFloat(drawerFacadeGapInput.value);
            if (!isFinite(v) || v < 0) v = 3;
            drawerFacadeGapInput.value = v;
            return v;
        }

        function readDrawerStackGap() {
            if (!drawerStackGapInput) return 0;
            let v = parseFloat(drawerStackGapInput.value);
            if (!isFinite(v) || v < 0) v = 0;
            drawerStackGapInput.value = v;
            return v;
        }

        function readDrawerBodyHeight() {
            if (!drawerBodyHeightInput) return 120;
            let v = parseFloat(drawerBodyHeightInput.value);
            if (!isFinite(v) || v < 40) v = 120;
            drawerBodyHeightInput.value = v;
            return v;
        }

        function readDrawerFrontOffset() {
            if (!drawerFrontOffsetInput) return 0;
            let v = parseFloat(drawerFrontOffsetInput.value);
            if (!isFinite(v) || v < 0) v = 16;
            drawerFrontOffsetInput.value = v;
            return v;
        }

        function readDrawerRunnerThk() {
            if (!drawerRunnerThkInput) return 13;
            let v = parseFloat(drawerRunnerThkInput.value);
            if (!isFinite(v) || v < 0) v = 13;
            drawerRunnerThkInput.value = v;
            return v;
        }

        function readDrawerDepthBrand() {
            if (!drawerDepthBrandSelect) return 'standard';
            const val = drawerDepthBrandSelect.value;
            return val ? val : 'standard';
        }

        function getDrawerDepthBrandOffset() {
            const brand = readDrawerDepthBrand();
            if (brand === 'blum' || brand === 'china') return 10;
            return 0;
        }

        function readInsertGapValue(input, fallback) {
            if (!input) return fallback;
            let v = parseFloat(input.value);
            if (!isFinite(v) || v < 0) v = fallback;
            input.value = v;
            return v;
        }

        function readInsertSideGaps() {
            return {
                left: readInsertGapValue(insertGapLeftInput, 50),
                right: readInsertGapValue(insertGapRightInput, 50)
            };
        }

        const drawerDepthPresets = [250,300,350,400,450,500,550];
        function pickDrawerDepthForSub(sub) {
            const innerParams = computeInnerParams();
            let depth = innerParams.depthInside;
            if (sub && sub.sectionId && sectionShelfOffsets[sub.sectionId] != null) {
                const off = sectionShelfOffsets[sub.sectionId] || 0;
                depth = Math.max(10, depth - off);
            }
            // Корпус тереңдігінен шамамен 50 мм резерв қалдырамыз (арқа/фасад/жабдық)
            const usable = Math.max(0, depth - 50);
            let best = drawerDepthPresets[0];
            let found = false;
            drawerDepthPresets.forEach(d => {
                if (d <= usable && d >= best) {
                    best = d;
                    found = true;
                }
            });
            if (!found) {
                // Егер бірде-бір preset сыймаса, ең кіші preset аламыз
                best = drawerDepthPresets[0];
            }
            return best;
        }

        function syncDrawerDepthSelect(sub) {
            if (!drawerDepthSelect) return;
            const auto = pickDrawerDepthForSub(sub || null);
            const key = sub ? `${sub.sectionId}:${sub.idx}` : selectedShelfSubId;
            let val = auto;
            if (key && shelfInserts[key]) {
                const arr = shelfInserts[key] || [];
                if (selectedInsertKey && selectedInsertKey.startsWith(key + '#')) {
                    const idxStr = selectedInsertKey.split('#')[1];
                    const idx = parseInt(idxStr, 10);
                    if (Number.isInteger(idx) && arr[idx] && arr[idx].type === 'drawer' && arr[idx].depth) {
                        val = arr[idx].depth;
                    }
                }
                if (!drawerDepthPresets.includes(val)) {
                    const firstDrawer = arr.find(it => it && it.type === 'drawer' && it.depth);
                    if (firstDrawer && drawerDepthPresets.includes(firstDrawer.depth)) {
                        val = firstDrawer.depth;
                    }
                }
            }
            if (!drawerDepthPresets.includes(val)) val = auto;
            drawerDepthSelect.value = val;
        }

        function disposeMat(m) {
            if (!m) return;
            if (Array.isArray(m)) {
                m.forEach(disposeMat);
                return;
            }
            if (m.dispose) m.dispose();
        }

        function disposeGroup(group) {
            if (!group) return;
            scene.remove(group);
            group.traverse(obj => {
                if (obj.geometry) obj.geometry.dispose();
                if (obj.material) obj.material.dispose();
            });
        }

        function disposeCabinetGroupsById(cabinetId) {
            if (!scene || cabinetId == null) return;
            scene.children
                .filter(obj => obj.userData && obj.userData.cabinetId === cabinetId)
                .forEach(disposeGroup);
        }

        // Mesh + edges + part helper
        function solidWithEdges(geometry, colorHex, partInfo) {
            const group = new THREE.Group();

            const isGlassDoor = partInfo && partInfo.type && String(partInfo.type).toLowerCase() === 'door' &&
                partInfo.materialType === 'glass';
            const mat = new THREE.MeshStandardMaterial({
                color: isGlassDoor ? 0x6db7ff : colorHex,
                metalness: isGlassDoor ? 0.0 : 0.2,
                roughness: isGlassDoor ? 0.1 : 0.7,
                transparent: isGlassDoor,
                opacity: isGlassDoor ? 0.35 : 1.0
            });
            const mesh = new THREE.Mesh(geometry, mat);
            mesh.castShadow = true;
            mesh.receiveShadow = true;
            mesh.userData.baseColor = isGlassDoor ? 0x6db7ff : colorHex;
            if (isGlassDoor) {
                mesh.userData.isGlass = true;
            }
            mesh.userData.partPickable = true;

            const pid = nextPartId++;
            mesh.userData.partId = pid;
            const params = geometry.parameters || {};
            parts[pid] = {
                id: pid,
                type: (partInfo && partInfo.type) || 'unknown',
                name: (partInfo && partInfo.name) || '',
                sectionId: (partInfo && partInfo.sectionId) || null,
                cabinetId: activeCabinetId || null,
                width: (partInfo && partInfo.width) || params.width || 0,
                height: (partInfo && partInfo.height) || params.height || 0,
                depth: (partInfo && partInfo.depth) || params.depth || 0,
                baseDims: {
                    width: (partInfo && partInfo.width) || params.width || 0,
                    height: (partInfo && partInfo.height) || params.height || 0,
                    depth: (partInfo && partInfo.depth) || params.depth || 0
                },
                meshBasePosition: mesh.position.clone(),
                offsets: { front:0, back:0, bottom:0, top:0 },
                frontOffset: 0,
                edge: (function(){
                    const t = (partInfo && partInfo.type) ? partInfo.type.toLowerCase() : '';
                    const mountType = (partInfo && partInfo.mountType) ? String(partInfo.mountType).toLowerCase() : '';
                    const isNakladnoyBottom = (mountType === 'nakladnoy');
                    if (t === 'side') {
                        // Бүйір: алды + үсті, төменгі кромка вкладной дно болса ғана
                        return { front:true, back:false, left:!isNakladnoyBottom, right:true };
                    }
                    if (t === 'top') {
                        // Top: default front edge
                        return { front:true, back:false, left:false, right:false };
                    }
                    if (t === 'bottom') {
                        // Дно: алдыңғысы үнемі, накладнойда оң/сол кромка қосылады
                        const sideEdge = isNakladnoyBottom;
                        return { front:true, back:false, left:sideEdge, right:sideEdge };
                    }
                    if (t === 'divider') {
                        // Стойка: default front edge
                        return { front:true, back:false, left:false, right:false };
                    }
                    if (t === 'shelf') {
                        // Полка: default front edge
                        return { front:true, back:false, left:false, right:false };
                    }
                    if (t === 'plinth') {
                        // Plinth front board: default bottom edge (front)
                        return { front:true, back:false, left:false, right:false };
                    }
                    return { front:false, back:false, left:false, right:false };
                })(),
                drilling: '',
                extra: partInfo || {},
                mesh: mesh
            };

            group.add(mesh);

            const edgesGeo = new THREE.EdgesGeometry(geometry);
            const edgesMat = new THREE.LineBasicMaterial({
                color: 0x222222,
                linewidth: 1
            });
            const edges = new THREE.LineSegments(edgesGeo, edgesMat);
            mesh.add(edges); // attach to mesh so scaling/offsets keep outlines in sync

            allMeshes.push(mesh);
            edges.__parentMesh = mesh;
            allEdges.push(edges);

            rebuildEdgeHighlightForPart(parts[pid]);
            return group;
        }

        function disposeWallGroup() {
            if (!wallGroup) return;
            scene.remove(wallGroup);
            wallGroup.traverse(obj => {
                if (obj.geometry) obj.geometry.dispose();
                if (obj.material) {
                    if (obj.material.map && obj.material.map.dispose) obj.material.map.dispose();
                    obj.material.dispose();
                }
            });
            wallGroup = null;
        }

        function disposeNewWallGroup() {
            if (!newWallGroup) return;
            scene.remove(newWallGroup);
            newWallGroup.traverse(obj => {
                if (obj.geometry) obj.geometry.dispose();
                if (obj.material) {
                    if (obj.material.map && obj.material.map.dispose) obj.material.map.dispose();
                    obj.material.dispose();
                }
            });
            newWallGroup = null;
            selectedWallSectionHelper = null;
            wallSectionPlusSprites = [];
        }

        function createWallLabelSprite(text) {
            // Кабинет өлшем лейбл стиліне жақындатамыз
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = 2048;
            canvas.height = 1024;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#000000';
            ctx.font = '150px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(text, canvas.width / 2, canvas.height / 2);

            const texture = new THREE.CanvasTexture(canvas);
            texture.minFilter = THREE.LinearFilter;
            texture.magFilter = THREE.LinearFilter;

            const material = new THREE.SpriteMaterial({
                map: texture,
                transparent: true,
                depthTest: false
            });
            const sprite = new THREE.Sprite(material);
            sprite.scale.set(600, 300, 1);
            return sprite;
        }

        function createWallPlusSprite() {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = 512;
            canvas.height = 512;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            // Тек "+" белгісі, фон/шеңберсіз
            ctx.fillStyle = '#000';
            ctx.font = '240px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('+', 256, 260);

            const texture = new THREE.CanvasTexture(canvas);
            texture.minFilter = THREE.LinearFilter;
            texture.magFilter = THREE.LinearFilter;

            const material = new THREE.SpriteMaterial({
                map: texture,
                transparent: true,
                depthTest: false
            });
            const sprite = new THREE.Sprite(material);
            sprite.scale.set(300, 300, 1);
            sprite.renderOrder = 1200;
            return sprite;
        }

        function applyWallViewMode() {
            if (!wallGroup) return;
            wallGroup.traverse(obj => {
                if (obj.isMesh && obj.material) {
                    const mat = obj.material;
                    if (currentViewMode === 'xray') {
                        mat.transparent = true;
                        mat.opacity = 0.25;
                        mat.depthWrite = false;
                        mat.depthTest = true;
                    } else if (currentViewMode === 'sketch') {
                        mat.transparent = true;
                        mat.opacity = 0.8;
                        mat.depthWrite = true;
                        mat.depthTest = true;
                    } else {
                        mat.transparent = false;
                        mat.opacity = 1;
                        mat.depthWrite = true;
                        mat.depthTest = true;
                    }
                }
            });
        }

        function updateWallDecorations() {
            if (!wallGroup) return;
            wallGroup.traverse(obj => {
                if (obj.userData && obj.userData.isWallEdges) {
                    obj.visible = (currentAxisView !== 'iso');
                }
            });
        }

        function ensureDefaultWalls() {
            walls = [];
            selectedWallId = null;
            wallEnabled = false;
        }

        function rebuildWallsUI() {
            return;
        }

        function fillWallForm(w) { return; }

        function getDefaultWallAngle(insertIndex) { return 0; }

        function addWallFromForm(insertIndex) { return; }

        function deleteWall(id) { return; }

        function updateSelectedWallFromForm() { return; }

        function rebuildWalls() {
            disposeWallGroup();
            wallGroup = null;
            drawWallSketch();
        }

        function getWallsWithPreview() {
            return [];
        }

        function computeWallSegmentsForSketch() {
            return { segments: [], bounds: null };
        }

        function resizeWallSketchCanvas() {
            if (!wallSketchCanvas || !wallSketchCtx) return;
            const rect = wallSketchCanvas.getBoundingClientRect();
            const dpr = window.devicePixelRatio || 1;
            wallSketchCanvas.width  = Math.max(1, Math.round(rect.width * dpr));
            wallSketchCanvas.height = Math.max(1, Math.round(rect.height * dpr));
            wallSketchCtx.setTransform(1, 0, 0, 1, 0, 0);
            wallSketchCtx.scale(dpr, dpr);
        }

        function drawWallSketch() {
            // Эскиз қажет емес – бос функция
            return;
        }

        function setWallPreview(insertIndex) { return; }
        function clearWallPreview() { return; }

        function applyViewModeToGroup(group, mode) {
            if (!group) return;
            const meshes = [];
            const edges  = [];
            group.traverse(obj => {
                if (obj.isMesh && obj.userData && obj.userData.baseColor !== undefined) {
                    meshes.push(obj);
                } else if (obj.type === 'LineSegments' && obj.__parentMesh) {
                    edges.push(obj);
                }
            });

            meshes.forEach(mesh => {
                const baseColor = mesh.userData.baseColor || 0xffffff;
                if (mesh.material) disposeMat(mesh.material);

                let newMat;
                if (mode === 'shadow') {
                    newMat = new THREE.MeshStandardMaterial({
                        color: baseColor,
                        metalness: 0.2,
                        roughness: 0.7
                    });
                    newMat.transparent = false;
                } else if (mode === 'xray') {
                    newMat = new THREE.MeshStandardMaterial({
                        color: baseColor,
                        metalness: 0.0,
                        roughness: 0.1
                    });
                    newMat.transparent = true;
                    newMat.opacity     = 0.25;
                } else { // sketch
                    newMat = new THREE.MeshLambertMaterial({
                        color: baseColor,
                        flatShading: true
                    });
                    newMat.transparent = true;
                    newMat.opacity = 0.8;
                }
                mesh.material = newMat;
            });

            edges.forEach(edge => {
                edge.visible = true;
                edge.material.color.set(
                    mode === 'shadow' ? 0x222222 : 0x000000
                );
            });
        }

        // View mode
        function setViewMode(mode) {
            currentViewMode = mode;

            if (mode === 'shadow') {
                renderer.shadowMap.enabled = true;
                dirLight.castShadow = true;
                floor.visible = true;
            } else if (mode === 'xray') {
                renderer.shadowMap.enabled = false;
                dirLight.castShadow = false;
                floor.visible = false;
            } else { // sketch
                renderer.shadowMap.enabled = false;
                dirLight.castShadow = false;
                floor.visible = false;
            }

            getAllCabinetGroups().forEach(({ group }) => applyViewModeToGroup(group, mode));
            applyWallViewMode();
            updateSectionEdgeHighlight();
            updateSectionFaceHighlight();
            syncFacadesVisibilityAll();
            syncShelfSubHelperVisibility();
            if (viewButtons && viewButtons.length) {
                viewButtons.forEach(btn => {
                    const m = btn.dataset.view;
                    btn.classList.toggle('active', m === mode);
                });
            }
        }

        // Өлшемдік кесінділер (сыртқы өлшемдер + ұштарында тік сызық, ортасында үлкен сан)
        function updateDimensionLabelAngles() {
            if (!dimensionHelpersGroup || !activeCamera || !renderer) return;
            const domW = (renderer.domElement && renderer.domElement.clientWidth) || 1;
            const domH = (renderer.domElement && renderer.domElement.clientHeight) || 1;
            dimensionHelpersGroup.traverse(obj => {
                if (!obj.isSprite) return;
                const ls = obj.userData && obj.userData.lineStart;
                const le = obj.userData && obj.userData.lineEnd;
                if (!ls || !le) return;
                const a = ls.clone().project(activeCamera);
                const b = le.clone().project(activeCamera);
                const ax = (a.x * 0.5 + 0.5) * domW;
                const ay = (-a.y * 0.5 + 0.5) * domH;
                const bx = (b.x * 0.5 + 0.5) * domW;
                const by = (-b.y * 0.5 + 0.5) * domH;
                let angle = Math.atan2(by - ay, bx - ax);
                if (angle > Math.PI / 2) angle -= Math.PI;
                if (angle < -Math.PI / 2) angle += Math.PI;
                if (obj.material) obj.material.rotation = angle;
            });
        }

        function rebuildDimensionHelpers() {
            if (dimensionHelpersGroup) {
                scene.remove(dimensionHelpersGroup);
                dimensionHelpersGroup.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
                dimensionHelpersGroup = null;
            }

            dimensionHelpersGroup = new THREE.Group();

            const isXray = (currentViewMode === 'xray');
            const colorCab = 0xff0000;
            const colorWall = 0x00aa00;

            function hexToCss(hex) {
                return '#' + hex.toString(16).padStart(6, '0');
            }

            function addLine(p1, p2, opts) {
                const color = opts && opts.color !== undefined ? opts.color : colorCab;
                const overlay = opts && opts.overlay;
                const depthTest = (opts && opts.depthTest !== undefined)
                    ? opts.depthTest
                    : (!isXray || !overlay);
                const geo = new THREE.BufferGeometry().setFromPoints([p1, p2]);
                const mat = new THREE.LineBasicMaterial({
                    color,
                    depthTest,
                    depthWrite: false
                });
                const line = new THREE.Line(geo, mat);
                line.renderOrder = overlay ? 1000 : (isXray ? 100 : 0);
                dimensionHelpersGroup.add(line);

                // Стрелка (конус) ұштары
                if (!opts || opts.noArrow !== true) {
                    const len = p1.distanceTo(p2);
                    const arrowH = Math.max(10, Math.min(40, len * 0.05));
                    const arrowR = arrowH * 0.35;
                    const coneGeo = new THREE.ConeGeometry(arrowR, arrowH, 8);
                    const coneMat = new THREE.MeshBasicMaterial({
                        color,
                        depthTest,
                        depthWrite: false
                    });
                    const dir = new THREE.Vector3().subVectors(p1, p2).normalize(); // іштен сыртқа қарай
                    const quat = new THREE.Quaternion().setFromUnitVectors(
                        new THREE.Vector3(0, 1, 0),
                        dir
                    );
                    const cone1 = new THREE.Mesh(coneGeo, coneMat);
                    cone1.quaternion.copy(quat);
                    cone1.position.copy(p1).add(dir.clone().negate().multiplyScalar(arrowH * 0.4));
                    cone1.renderOrder = line.renderOrder;
                    dimensionHelpersGroup.add(cone1);

                    const cone2 = new THREE.Mesh(coneGeo.clone(), coneMat.clone());
                    const quat2 = new THREE.Quaternion().setFromUnitVectors(
                        new THREE.Vector3(0, 1, 0),
                        dir.clone().negate()
                    );
                    cone2.quaternion.copy(quat2);
                    cone2.position.copy(p2).add(dir.clone().multiplyScalar(arrowH * 0.4));
                    cone2.renderOrder = line.renderOrder;
                    dimensionHelpersGroup.add(cone2);
                }
            }

            // Үлкен label (спрайт)
            function addLabel(text, position, lineStart, lineEnd, opts) {
                const overlay = opts && opts.overlay;
                const depthTestFlag = opts && opts.depthTest;
                const colorStr = (opts && opts.color) ? opts.color : '#000000';
                const canvas = document.createElement('canvas');
                const ctx    = canvas.getContext('2d');

                canvas.width  = 2048;
                canvas.height = 1024;

                ctx.clearRect(0, 0, canvas.width, canvas.height);

                ctx.fillStyle = colorStr;
                ctx.font = '150px Arial';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';

                ctx.fillText(text, canvas.width / 2, canvas.height / 2);

                const texture = new THREE.CanvasTexture(canvas);
                const mat = new THREE.SpriteMaterial({
                    map: texture,
                    transparent: true,
                    depthTest: (overlay ? !!depthTestFlag : !isXray),
                    depthWrite: false
                });
                const sprite = new THREE.Sprite(mat);
                sprite.renderOrder = overlay ? 1001 : (isXray ? 101 : 0);

                sprite.position.copy(position);
                sprite.scale.set(600, 300, 1);
                if (lineStart && lineEnd) {
                    sprite.userData.lineStart = lineStart.clone();
                    sprite.userData.lineEnd   = lineEnd.clone();
                }

                // Экранда өлшем мәтіні сызыққа параллель болсын
                if (lineStart && lineEnd && activeCamera) {
                    const a = lineStart.clone().project(activeCamera);
                    const b = lineEnd.clone().project(activeCamera);

                    const domW = (renderer && renderer.domElement && renderer.domElement.clientWidth)  || 1;
                    const domH = (renderer && renderer.domElement && renderer.domElement.clientHeight) || 1;

                    // NDC → экран координаттары (y төмен бағытта)
                    const ax = (a.x * 0.5 + 0.5) * domW;
                    const ay = (-a.y * 0.5 + 0.5) * domH;
                    const bx = (b.x * 0.5 + 0.5) * domW;
                    const by = (-b.y * 0.5 + 0.5) * domH;

                    // Keep text upright: clamp rotation to +/-90deg so labels (depth especially) are not upside down
                    let angle = Math.atan2(by - ay, bx - ax);
                    if (angle > Math.PI / 2) angle -= Math.PI;
                    if (angle < -Math.PI / 2) angle += Math.PI;
                    sprite.material.rotation = angle;
                }

                dimensionHelpersGroup.add(sprite);
            }

            const allCabGroups = getAllCabinetGroups();
            let any = false;
            allCabGroups.forEach((cab, idx) => {
            const g = cab.group || cabinetGroup;
            if (!g) return;
            // Фасад/есік жасырылған болса да габаритті дұрыс алу үшін уақытша көрсетеміз
            const restoreVisibility = [];
            if (g.userData && g.userData.doorsGroup) {
                const dg = g.userData.doorsGroup;
                restoreVisibility.push({ obj: dg, vis: dg.visible });
                dg.visible = true;
            }
            const box = new THREE.Box3().setFromObject(g);
            restoreVisibility.forEach(r => { if (r.obj) r.obj.visible = r.vis; });
            if (!isFinite(box.min.x) || !isFinite(box.max.x)) return;
            any = true;

                const size = new THREE.Vector3();
                box.getSize(size);
                const center = new THREE.Vector3();
                box.getCenter(center);
                const leftX   = box.min.x;
                const rightX  = box.max.x;
                const bottomY = box.min.y;
                const topY    = box.max.y;
                const backZ   = box.min.z;
                const frontZ  = box.max.z;

            const state = (cab.cabinet && cab.cabinet.state) || {};
            const totalWidth  = state.W || size.x;
            const totalHeight = state.H || size.y;
            const corpusThick = parseFloat(state.corpusThickness) || globalThickness || 16;
            const backMatVal  = state.backMaterial || 'hdf';
            const backThick   = (backMatVal === 'hdf') ? 4 : corpusThick;
            const facadeThick = parseFloat(state.facadeThickness) || 18;
            const facadeTypeVal = state.facadeType || 'nakladnoy';
            let totalDepth;
            if (state.D) {
                totalDepth = state.D + backThick;
                if (facadeTypeVal === 'nakladnoy') {
                    totalDepth += facadeThick;
                }
            } else {
                totalDepth = size.z;
            }

            const halfW = totalWidth / 2;
            const halfH = totalHeight / 2;
            const halfD = totalDepth / 2;

                const q = new THREE.Quaternion();
                g.getWorldQuaternion(q);
                const xAxis = new THREE.Vector3(1, 0, 0).applyQuaternion(q).normalize();
                const yAxis = new THREE.Vector3(0, 1, 0).applyQuaternion(q).normalize();
                const zAxis = new THREE.Vector3(0, 0, 1).applyQuaternion(q).normalize();

                const offset  = 150; // шкафтан тұрақты арақашықтық
                const tickLen = 50;

                // ЕНІ (кабинетке параллель)
                const widthPlaneOffset = yAxis.clone().multiplyScalar(halfH + offset)
                    .add(zAxis.clone().multiplyScalar(-halfD - offset));
                const w1 = center.clone().add(xAxis.clone().multiplyScalar(-halfW)).add(widthPlaneOffset);
                const w2 = center.clone().add(xAxis.clone().multiplyScalar(halfW)).add(widthPlaneOffset);

                addLine(w1, w2);
                addLine(
                    w1.clone(),
                    w1.clone().add(yAxis.clone().multiplyScalar(-tickLen)),
                    { color: colorCab }
                );
                addLine(
                    w2.clone(),
                    w2.clone().add(yAxis.clone().multiplyScalar(-tickLen)),
                    { color: colorCab }
                );

                const wMid = w1.clone().add(w2).multiplyScalar(0.5).add(yAxis.clone().multiplyScalar(40));
                addLabel(Math.round(totalWidth) + ' мм', wMid, w1, w2, { color: hexToCss(colorCab) });

                // БИІКТІК
                const heightPlaneOffset = xAxis.clone().multiplyScalar(halfW + offset)
                    .add(zAxis.clone().multiplyScalar(-halfD - offset));
                const h1 = center.clone().add(yAxis.clone().multiplyScalar(-halfH)).add(heightPlaneOffset);
                const h2 = center.clone().add(yAxis.clone().multiplyScalar(halfH)).add(heightPlaneOffset);

                addLine(h1, h2);
                addLine(
                    h1.clone(),
                    h1.clone().add(xAxis.clone().multiplyScalar(-tickLen)),
                    { color: colorCab }
                );
                addLine(
                    h2.clone(),
                    h2.clone().add(xAxis.clone().multiplyScalar(-tickLen)),
                    { color: colorCab }
                );

                const hMid = h1.clone().add(h2).multiplyScalar(0.5).add(xAxis.clone().multiplyScalar(60));
                addLabel(Math.round(totalHeight) + ' мм', hMid, h1, h2, { color: hexToCss(colorCab) });

                // ТЕРЕҢДІК
                const depthPlaneOffset = yAxis.clone().multiplyScalar(halfH + offset)
                    .add(xAxis.clone().multiplyScalar(-halfW));
                const d1 = center.clone().add(zAxis.clone().multiplyScalar(-halfD)).add(depthPlaneOffset);
                const d2 = center.clone().add(zAxis.clone().multiplyScalar(halfD)).add(depthPlaneOffset);

                addLine(d1, d2);
                addLine(
                    d1.clone(),
                    d1.clone().add(yAxis.clone().multiplyScalar(-tickLen)),
                    { color: colorCab }
                );
                addLine(
                    d2.clone(),
                    d2.clone().add(yAxis.clone().multiplyScalar(-tickLen)),
                    { color: colorCab }
                );

                const dMid = d1.clone().add(d2).multiplyScalar(0.5).add(yAxis.clone().multiplyScalar(40));
                addLabel(Math.round(totalDepth) + ' мм', dMid, d1, d2, { color: hexToCss(colorCab) });

                // Стенаның жалпы ұзындығы (жасыл, шкаф өлшемінен жоғары)
                const wallInfo = getActiveWallInfo();
                if (newWalls && newWalls.length) {
                    newWalls.forEach(wallInfo => {
                        if (!wallInfo || !wallInfo.w) return;
                        const offsetWall = offset + 200;
                        const wallTopY = (wallInfo.y || 0) + (wallInfo.h || 0);
                        const halfW = wallInfo.w / 2;
                        const isVertWall = (wallInfo.type === 'vertical');
                        const dir = isVertWall
                            ? new THREE.Vector3(0, 0, 1)   // ұзындығы Z бойымен
                            : new THREE.Vector3(1, 0, 0);  // ұзындығы X бойымен
                        const perp = isVertWall
                            ? new THREE.Vector3(-1, 0, 0)  // вертикаль стена – X арқылы ығысу
                            : new THREE.Vector3(0, 0, -1); // фронтал – Z арқылы ығысу
                        const base = new THREE.Vector3(
                            isVertWall
                                ? (wallInfo.x || 0)
                                : (wallInfo.x || 0) + halfW,
                            wallTopY + offsetWall,
                            isVertWall
                                ? (wallInfo.z || 0) + halfW
                                : (wallInfo.z || 0)
                        );
                        const offsetVec = perp.clone().multiplyScalar(offsetWall);
                        const w1w = base.clone().add(dir.clone().multiplyScalar(-halfW)).add(offsetVec);
                        const w2w = base.clone().add(dir.clone().multiplyScalar(halfW)).add(offsetVec);
                        addLine(w1w, w2w, { color: colorWall });
                        addLine(
                            w1w.clone(),
                            w1w.clone().add(new THREE.Vector3(0, -tickLen, 0)),
                            { color: colorWall }
                        );
                        addLine(
                            w2w.clone(),
                            w2w.clone().add(new THREE.Vector3(0, -tickLen, 0)),
                            { color: colorWall }
                        );
                        const midWall = w1w.clone().add(w2w).multiplyScalar(0.5).add(new THREE.Vector3(0, 40, 0));
                        addLabel(Math.round(wallInfo.w) + ' мм', midWall, w1w, w2w, { color: hexToCss(colorWall) });
                    });
                }

                if (selectedNewWallId) {
                    const wall = newWalls.find(w => w.id === selectedNewWallId);
                    if (wall) {
                        const sections = wallSections[wall.id] || [];
                        if (sections.length) {
                            const startX = wall.x || 0;
                            const startY = wall.y || 0;
                            const startZ = wall.z || 0;
                            const isVertWall = (wall.type === 'vertical');
                            sections.forEach(sec => {
                                const left = startX + (isVertWall ? 0 : sec.x);
                                const right = left + sec.w;
                                const bottom = startY + sec.y;
                                const top = bottom + sec.h;
                                const zPlane = isVertWall ? startZ : startZ;
                                const centerX = isVertWall ? startX : (left + right) / 2;
                                const centerY = (bottom + top) / 2;
                                const centerZ = isVertWall ? (startZ + sec.x + sec.w / 2) : zPlane;

                                const widthStart = isVertWall
                                    ? new THREE.Vector3(startX, centerY, startZ + sec.x)
                                    : new THREE.Vector3(left, centerY, zPlane);
                                const widthEnd = isVertWall
                                    ? new THREE.Vector3(startX, centerY, startZ + sec.x + sec.w)
                                    : new THREE.Vector3(right, centerY, zPlane);
                                const heightStart = new THREE.Vector3(centerX, bottom, centerZ);
                                const heightEnd = new THREE.Vector3(centerX, top, centerZ);

                                let labelText;
                                let lineStart;
                                let lineEnd;
                                if (sec.dir === 'horizontal') {
                                    labelText = Math.round(sec.h || 0) + ' мм';
                                    lineStart = heightStart;
                                    lineEnd = heightEnd;
                                } else if (sec.dir === 'grid') {
                                    labelText = `${Math.round(sec.w || 0)} × ${Math.round(sec.h || 0)} мм`;
                                    lineStart = widthStart;
                                    lineEnd = widthEnd;
                                } else {
                                    labelText = Math.round(sec.w || 0) + ' мм';
                                    lineStart = widthStart;
                                    lineEnd = widthEnd;
                                }

                                addLabel(
                                    labelText,
                                    new THREE.Vector3(centerX, centerY, centerZ),
                                    lineStart,
                                    lineEnd,
                                    { color: '#111111', overlay: true, depthTest: true }
                                );
                            });
                        }
                    }
                }

                // Тек актив шкаф үшін ішкі өлшемдер (полка аралығы)
                if (cab.id && activeCabinetId && cab.id === activeCabinetId && sections && sections.length && sectionShelves) {
                    const innerParamsShelves = computeInnerParams();
                    const depthInsideShelves = innerParamsShelves.depthInside;
                    const backInsideZ        = innerParamsShelves.centerZ - depthInsideShelves / 2 + cabinetOffsetZ + (cabinetBaseOffset.z || 0);

                    const shelfThickLocal = globalThickness;

                    const secSortedForShelves = sections.slice().sort((a, b) => a.x - b.x);

                    secSortedForShelves.forEach(sec => {
                        const list = sectionShelves[sec.id];
                        if (!list || !list.length) return;

                        // Алдынан отступ: фронтты қысқартып көрсетеміз
                        const secFrontOffset = sectionShelfOffsets[sec.id] || 0;
                        const shelfDepth     = Math.max(10, depthInsideShelves - secFrontOffset);
                        const shelfFrontZ    = backInsideZ + shelfDepth;
                        // Сәл ішке (front ішкі жазықтығының ішінде), overlay бәрібір көрінеді
                        const zShelvesDim    = shelfFrontZ - Math.min(20, shelfDepth * 0.1);

                        const heights = list.slice().sort((a, b) => a - b);
                        const augmented = [0, ...heights, sec.h]; // дно мен крышаны қосамыз
                        let subIdx = 1;

                        const secLeft  = -innerW / 2 + sec.x + cabinetOffsetX + (cabinetBaseOffset.x || 0);
                        const secRight = secLeft + sec.w;
                        const xMid     = (secLeft + secRight) / 2;

                        for (let i = 0; i < augmented.length - 1; i++) {
                            const h1 = augmented[i];
                            const h2 = augmented[i + 1];

                            const isBottom = (i === 0);
                            const isTop    = (i === augmented.length - 2);

                            let gap = h2 - h1;
                            if (!isBottom) gap -= shelfThickLocal; // төмендегі полка қалыңдығын алып тастаймыз
                            if (gap <= 0) continue;

                            const y1 = (cabinetBaseOffset.y || 0) + plinthHeight + globalThickness + (isBottom ? 0 : h1 + shelfThickLocal);
                            const y2 = (cabinetBaseOffset.y || 0) + plinthHeight + globalThickness + (isTop ? sec.h : h2);

                            const p1 = new THREE.Vector3(xMid, y1, zShelvesDim);
                            const p2 = new THREE.Vector3(xMid, y2, zShelvesDim);

                            const overlayDepthTest = (currentViewMode === 'xray')
                                ? false        // ренгенде әрқашан көрінсін (depth off)
                                : !facadesHidden; // қалған режимде фасад жабық болса жасырылады

                            // Негізгі тік сызық (фасад ашық болса depth off, жабық болса depth on)
                            addLine(p1, p2, { overlay: true, depthTest: overlayDepthTest, color: colorCab });

                            // Жоғарғы / төменгі "тычоктар"
                            addLine(
                                new THREE.Vector3(xMid - tickLen / 2, y1, zShelvesDim),
                                new THREE.Vector3(xMid + tickLen / 2, y1, zShelvesDim),
                                { overlay: true, depthTest: overlayDepthTest, color: colorCab }
                            );
                            addLine(
                                new THREE.Vector3(xMid - tickLen / 2, y2, zShelvesDim),
                                new THREE.Vector3(xMid + tickLen / 2, y2, zShelvesDim),
                                { overlay: true, depthTest: overlayDepthTest, color: colorCab }
                            );

                            // Екі полка арасындағы ара қашықтықты жазу
                            const mid = p1.clone().add(p2).multiplyScalar(0.5);
                            mid.x += 40;
                            const subName = 'Секция ' + sec.id + '.' + subIdx;
                            addLabel(subName + ' · ' + Math.round(gap) + ' мм', mid, p1, p2, { overlay: true, depthTest: overlayDepthTest, color: hexToCss(colorCab) });
                            subIdx++;
                        }
                    });
                }
            });

            if (!any) return;

            dimensionHelpersGroup.visible = dimensionsVisible;
            scene.add(dimensionHelpersGroup);
            syncDimensionsVisibility();
            syncInfoVisibility();
            updateDimensionLabelAngles();
        }

        // DOM элементтер
        const widthInput        = document.getElementById('widthInput');
        const heightInput       = document.getElementById('heightInput');
        const depthInput        = document.getElementById('depthInput');
        const wallGapInput      = document.getElementById('wallGapInput');
        const wallAngleInput    = null;
        const wallColorInput    = null;
        const wallWidthInput    = null;
        const wallHeightInput   = null;
        const wallListContainer = null;
        const wallSketchCanvas  = null;
        const wallSketchCtx     = null;
        const newWallTypeInput   = document.getElementById('newWallType'); // no longer used (select removed)
        const newWallWidthInput  = null;
        const newWallHeightInput = null;
        const newWallStartXInput = null;
        const newWallStartYInput = null;
        const newWallStartZInput = null;
        const addWallFrontalBtn  = document.getElementById('addWallFrontalBtn');
        const addWallVerticalBtn = document.getElementById('addWallVerticalBtn');
        const newWallList       = document.getElementById('newWallList');
        const wallSectionList   = document.getElementById('wallSectionList');
        const wallLineMeasurements = document.getElementById('wallLineMeasurements');
        const cabinetList       = document.getElementById('cabinetList');
        const splitWallSectionV = document.getElementById('splitWallSectionV');
        const splitWallSectionH = document.getElementById('splitWallSectionH');
        const splitVerticalCountInput = document.getElementById('splitVerticalCount');
        const splitHorizontalCountInput = document.getElementById('splitHorizontalCount');
        const splitWallGridBtn = document.getElementById('splitWallGridBtn');

        const corpusMaterial    = document.getElementById('corpusMaterial');
        const corpusThickness   = document.getElementById('corpusThickness');
        const corpusColorInput  = document.getElementById('corpusColor');
        const bottomMountInput  = document.getElementById('bottomMount');
        const facadeMaterial    = document.getElementById('facadeMaterial');
        const facadeThickness   = document.getElementById('facadeThickness');
        const facadeType        = document.getElementById('facadeType');
        const facadeColorInput  = document.getElementById('facadeColor');
        const facadeStyle       = document.getElementById('facadeStyle');
        const facadeFrameWidthInput = document.getElementById('facadeFrameWidth');
        const plinthHeightInput = document.getElementById('plinthHeight');
        const backMaterial      = document.getElementById('backMaterial');
        const facadeStyleRow    = (function(){
            const el = document.getElementById('facadeStyle');
            return el ? el.closest('.fields-row') : null;
        })();
        const facadeFrameRow    = (function(){
            const el = document.getElementById('facadeFrameWidth');
            return el ? el.closest('.fields-row') : null;
        })();

        const sectionSelect       = document.getElementById('sectionSelect');
        const splitPatternInput   = document.getElementById('splitPattern');
        const splitSectionBtn     = document.getElementById('splitSectionBtn');
        const sectionWidthInput   = document.getElementById('sectionWidthInput');

        const shelfCountInput       = document.getElementById('shelfCountInput');
        const autoShelvesBtn        = document.getElementById('autoShelvesBtn');
        const shelfHeightInput      = document.getElementById('shelfHeightInput');
        const addShelfBtn           = document.getElementById('addShelfBtn');
        const shelfSelect           = document.getElementById('shelfSelect');
        const editShelfHeightInput  = document.getElementById('editShelfHeightInput');
        const updateShelfBtn        = document.getElementById('updateShelfBtn');
        const shelfGapInput         = document.getElementById('shelfGapInput');
        const applyShelfGapBtn      = document.getElementById('applyShelfGapBtn');
        const insertShelfBetweenBtn = document.getElementById('insertShelfBetweenBtn');
        const shelfOffsetInput      = document.getElementById('shelfOffsetInput');
        const shelfList             = document.getElementById('shelfList');
        const insertTypeSelect      = document.getElementById('insertTypeSelect');
        const addInsertBtn          = document.getElementById('addInsertBtn');
        const insertList            = document.getElementById('insertList');
        const drawerVariantSelect   = document.getElementById('drawerVariantSelect');
        const drawerDepthSelect     = document.getElementById('drawerDepthSelect');
        const drawerDepthBrandSelect= document.getElementById('drawerDepthBrandSelect');
        const drawerFacadeMaterial  = document.getElementById('drawerFacadeMaterial');
        const drawerSubList         = document.getElementById('drawerSubList');
        const drawerFacadeGapInput  = document.getElementById('drawerFacadeGap');
        const drawerFrontOffsetInput= document.getElementById('drawerFrontOffset');
        const drawerBodyHeightInput = document.getElementById('drawerBodyHeight');
        const drawerStackGapInput   = document.getElementById('drawerStackGap');
        const drawerRunnerThkInput  = document.getElementById('drawerRunnerThk');
        const insertGapLeftInput    = document.getElementById('insertGapLeft');
        const insertGapRightInput   = document.getElementById('insertGapRight');
        const pipeColorInput        = document.getElementById('pipeColor');
        const drawerRunnerTypeSelect= document.getElementById('drawerRunnerType');
        const falshSideSelect       = document.getElementById('falshSide');
        const falshSizeInput        = document.getElementById('falshSize');
        const addFalshBtn           = document.getElementById('addFalshBtn');
        const falshList             = document.getElementById('falshList');
        const falshLeftSideCheckbox = document.getElementById('falshLeftSide');
        const falshRightSideCheckbox= document.getElementById('falshRightSide');
        const falshLeftSideSizeInput  = document.getElementById('falshLeftSideSize');
        const falshRightSideSizeInput = document.getElementById('falshRightSideSize');

        function ensureSelectedSubIdFromUI() {
            const activeRow = drawerSubList ? drawerSubList.querySelector('.shelf-sub-row.active') : null;
            if (activeRow && activeRow.dataset && activeRow.dataset.subId) {
                selectedShelfSubId = activeRow.dataset.subId;
                return;
            }
            const subs = getShelfSubSections();
            const scoped = subs.filter(s => s.sectionId === selectedSectionId);
            const pool = scoped.length ? scoped : subs;
            if (!selectedShelfSubId && pool.length) {
                selectedShelfSubId = `${pool[0].sectionId}:${pool[0].idx}`;
            }
        }
        function syncDrawerActiveRow() {
            if (!drawerSubList) return;
            const rows = drawerSubList.querySelectorAll('.shelf-sub-row');
            rows.forEach(r => {
                const isActive = selectedShelfSubId && r.dataset && r.dataset.subId === selectedShelfSubId;
                r.classList.toggle('active', !!isActive);
            });
        }

        function getFalshSizeForSide(side) {
            const raw = parseFloat(falshSizeInput ? falshSizeInput.value : '');
            if (isFinite(raw) && raw > 0) return raw;
            return side === 'top' ? 120 : 50;
        }
        function readSideOverlaySize(side) {
            const input = side === 'left' ? falshLeftSideSizeInput : falshRightSideSizeInput;
            const raw = parseFloat(input ? input.value : '');
            const fallback = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
            const val = Number.isFinite(raw) && raw > 0 ? raw : fallback;
            if (input && (!input.value || raw <= 0 || !isFinite(raw))) {
                input.value = Math.round(val);
            }
            if (side === 'left') falshLeftSideSize = val; else falshRightSideSize = val;
            return val;
        }
        if (facadeMaterial && facadeThickness) {
            facadeMaterial.addEventListener('change', () => {
                const val = facadeMaterial.value;
                let thick = parseFloat(facadeThickness.value) || 18;
                if (val === 'ldsp') thick = 16;
                if (val === 'mdf') thick = 18;
                if (val === 'glass') thick = 4;
                if (val === 'glass_frame') thick = 20;
                facadeThickness.value = thick;
                rebuildWithCurrentSize(true);
                if (facadeStyleRow) {
                    facadeStyleRow.style.display = (val === 'mdf') ? 'flex' : 'none';
                }
                if (facadeFrameRow) {
                    const showFrame = (facadeStyle && facadeStyle.value === 'frame' && val === 'mdf');
                    facadeFrameRow.style.display = showFrame ? 'flex' : 'none';
                }
                if (facadeStyle) {
                    // ЛДСП/Стекло/Стекло рамка → модерн стиліне күштеп ауыстыру
                    if (val === 'ldsp' || val === 'glass') {
                        facadeStyle.value = 'modern';
                    } else if (val === 'glass_frame') {
                        facadeStyle.value = 'frame';
                        if (facadeFrameWidthInput) {
                            facadeFrameWidthInput.value = 20;
                        }
                    }
                }
                // Егер фасад материалы ЛДСП болса, есік кромкасы толық белсенді (Асты/Үсті/Сол/Оң)
                if (val === 'ldsp') {
                    Object.values(parts || {}).forEach(p => {
                        if ((p.type || '').toLowerCase() === 'door') {
                            p.edge = { front:true, back:true, left:true, right:true };
                            rebuildEdgeHighlightForPart(p);
                        }
                    });
                    applyEdgeHighlightVisibility();
                    updatePartUI();
                }
            });
        }
        if (facadeStyleRow && facadeMaterial) {
            facadeStyleRow.style.display = (facadeMaterial.value === 'mdf') ? 'flex' : 'none';
        }
        if (facadeFrameRow && facadeMaterial && facadeStyle) {
            facadeFrameRow.style.display = (facadeMaterial.value === 'mdf' && facadeStyle.value === 'frame') ? 'flex' : 'none';
            facadeStyle.addEventListener('change', () => {
                if (!facadeFrameRow) return;
                const show = (facadeMaterial.value === 'mdf' && facadeStyle.value === 'frame');
                facadeFrameRow.style.display = show ? 'flex' : 'none';
            });
        }

	        if (addFalshBtn) {
	            addFalshBtn.addEventListener('click', () => {
	                if (!cabinetSpawned) {
	                    showError('Алдымен шкафты құрыңыз');
	                    return;
	                }
	                const side = falshSideSelect ? falshSideSelect.value : 'left';
	                const size = getFalshSizeForSide(side);
	                runUndoable(() => {
	                    falshPanels.push({ id: nextFalshId++, side, size });
	                    rebuildFalshList();
	                    rebuildWithCurrentSize(true);
	                    syncActiveCabinetRecord();
	                    if (falshSizeInput) falshSizeInput.value = size;
	                });
	            });
	        }
        if (falshSideSelect && falshSizeInput) {
            falshSideSelect.addEventListener('change', () => {
                const side = falshSideSelect.value || 'left';
                if (!falshSizeInput.value || parseFloat(falshSizeInput.value) <= 0) {
                    falshSizeInput.value = getFalshSizeForSide(side);
                }
                // Авто: Төбе таңдалса, биіктікті қайта есептеу
                if (side === 'top' && cabinetSpawned) {
                    rebuildWithCurrentSize(true);
                    syncActiveCabinetRecord();
                }
            });
        }
	        if (falshLeftSideCheckbox) {
	            falshLeftSideCheckbox.addEventListener('change', () => {
	                if (!cabinetSpawned) {
	                    falshLeftSideCheckbox.checked = falshLeftSideEnabled;
	                    showError('Алдымен шкафты құрыңыз');
	                    return;
	                }
	                runUndoable(() => {
	                    falshLeftSideEnabled = falshLeftSideCheckbox.checked;
	                    rebuildWithCurrentSize(true);
	                    syncActiveCabinetRecord();
	                });
	            });
	        }
	        if (falshRightSideCheckbox) {
	            falshRightSideCheckbox.addEventListener('change', () => {
	                if (!cabinetSpawned) {
	                    falshRightSideCheckbox.checked = falshRightSideEnabled;
	                    showError('Алдымен шкафты құрыңыз');
	                    return;
	                }
	                runUndoable(() => {
	                    falshRightSideEnabled = falshRightSideCheckbox.checked;
	                    rebuildWithCurrentSize(true);
	                    syncActiveCabinetRecord();
	                });
	            });
	        }
	        function handleSideOverlaySizeChange(side) {
	            if (side === 'left') {
	                if (falshLeftSideEnabled) {
	                    runUndoable(() => {
	                        falshLeftSideSize = readSideOverlaySize('left');
	                        rebuildWithCurrentSize(true);
	                        syncActiveCabinetRecord();
	                    });
	                } else {
	                    falshLeftSideSize = readSideOverlaySize('left');
	                }
	            } else {
	                if (falshRightSideEnabled) {
	                    runUndoable(() => {
	                        falshRightSideSize = readSideOverlaySize('right');
	                        rebuildWithCurrentSize(true);
	                        syncActiveCabinetRecord();
	                    });
	                } else {
	                    falshRightSideSize = readSideOverlaySize('right');
	                }
	            }
	            rebuildFalshList();
	        }
        if (falshLeftSideSizeInput) {
            falshLeftSideSizeInput.addEventListener('change', () => handleSideOverlaySizeChange('left'));
        }
        if (falshRightSideSizeInput) {
            falshRightSideSizeInput.addEventListener('change', () => handleSideOverlaySizeChange('right'));
        }

        const viewButtons    = document.querySelectorAll('#canvas-toolbar [data-view]');
        const modeButtons    = document.querySelectorAll('#canvas-toolbar [data-mode]');
        const animToggleBtn  = document.getElementById('animToggleBtn');
        const viewToolbar    = document.getElementById('view-toolbar');

        const toggleDimsBtn  = document.getElementById('toggleDimsBtn');
        const toggleFacadeBtn= document.getElementById('toggleFacadeBtn');
        const toggleEdgeBtn  = document.getElementById('toggleEdgeBtn');
        const toggleInfoBtn  = document.getElementById('toggleInfoBtn');
        const structureBtn   = document.getElementById('structureBtn');
        const structureList  = document.getElementById('structureList');
        const cabinetIconList= document.getElementById('cabinetIconList');
        const cabinetDeleteBtn= document.getElementById('cabinetDeleteBtn');
        const cabinetHideBtn = document.getElementById('cabinetHideBtn');
        const undoBtn        = document.getElementById('undoBtn');
        const redoBtn        = document.getElementById('redoBtn');
        const saveProjectBtn = document.getElementById('saveProjectBtn');
        const loadProjectBtn = document.getElementById('loadProjectBtn');
        const loadProjectInput = document.getElementById('loadProjectInput');

        // Бөлшек UI
        const partNameInput       = document.getElementById('partName');
        const partTypeInput       = document.getElementById('partType');
        const partSectionInput    = document.getElementById('partSection');
        const partSizeInput       = document.getElementById('partSize');
        const partOffsetFrontInput= document.getElementById('partOffsetFront');
        const edgeFrontInput      = document.getElementById('edgeFront');
        const edgeBackInput       = document.getElementById('edgeBack');
        const edgeLeftInput       = document.getElementById('edgeLeft');
        const edgeRightInput      = document.getElementById('edgeRight');
        const edgeFrontLabel      = document.getElementById('edgeFrontLabel');
        const edgeBackLabel       = document.getElementById('edgeBackLabel');
        const edgeLeftLabel       = document.getElementById('edgeLeftLabel');
        const edgeRightLabel      = document.getElementById('edgeRightLabel');
        const offsetFrontInput    = document.getElementById('offsetFront');
        const offsetBackInput     = document.getElementById('offsetBack');
        const offsetBottomInput   = document.getElementById('offsetBottom');
        const offsetTopInput      = document.getElementById('offsetTop');
        const offsetFrontLabel    = document.getElementById('offsetFrontLabel');
        const offsetBackLabel     = document.getElementById('offsetBackLabel');
        const offsetBottomLabel   = document.getElementById('offsetBottomLabel');
        const offsetTopLabel      = document.getElementById('offsetTopLabel');
        const partDrillingInput   = document.getElementById('partDrilling');
        const partPreviewCanvas   = document.getElementById('partPreviewCanvas');
        const partPreviewCaption  = document.getElementById('partPreviewCaption');
        const partPreviewEmpty    = document.getElementById('partPreviewEmpty');
        const partPreviewName     = document.getElementById('partPreviewName');
        const partPreviewDeleteBtn= document.getElementById('partPreviewDeleteBtn');
        const partEmptyState      = document.getElementById('partEmptyState');
        const partPreviewCtx      = partPreviewCanvas ? partPreviewCanvas.getContext('2d') : null;
	        const handlePartDelete = () => {
	            if (!selectedPartId) return;
	            const ok = window.confirm('Таңдалған бөлшекті өшіру керек пе?');
	            if (!ok) return;
	            const pid = selectedPartId;
	            runUndoable(() => {
	                deletePart(pid);
	            });
	        };
        if (partPreviewDeleteBtn) {
            partPreviewDeleteBtn.addEventListener('click', handlePartDelete);
        }

        // Қабырға UI жоқ

        // ===== ЖАҢА СТЕНАЛАР (контур)
        function ensureWallSections(wall) {
            if (!wall) return [];
            if (!wallSections[wall.id]) {
                wallSections[wall.id] = [{
                    id: nextWallSectionId++,
                    parentId: null,
                    x: 0,
                    y: 0,
                    w: wall.w || 0,
                    h: wall.h || 0,
                    dir: 'base',
                    widthLocked: false,
                    heightLocked: false
                }];
                selectedWallSectionId = wallSections[wall.id][0].id;
            }
            wallSections[wall.id].forEach(sec => {
                const legacyLocked = !!sec.locked;
                sec.widthLocked = !!(sec.widthLocked || legacyLocked);
                sec.heightLocked = !!(sec.heightLocked || legacyLocked);
                delete sec.locked;
            });
            return wallSections[wall.id];
        }

        function hasCabinetInSection(wallId, sectionId) {
            return cabinets.some(c => c.wallId === wallId && c.sectionId === sectionId);
        }

        function getCabinetsByWallId(wallId) {
            return cabinets.filter(c => c.wallId === wallId);
        }

        // Белгілі бір стена/секцияға байланған барлық шкафтарды қайта құру
        function refreshCabinetsForSection(wallId, sectionId, preserveLayout) {
            const targets = cabinets.filter(c => c.wallId === wallId && c.sectionId === sectionId);
            if (!targets.length) return;
            const prevActive = activeCabinetId;
            const prevSelectedWall = selectedNewWallId;
            const prevSelectedSection = selectedWallSectionId;

            targets.forEach(cab => {
                setActiveCabinet(cab.id);
                updateCabinetFromSection(preserveLayout);
            });

            if (prevActive && prevActive !== activeCabinetId) {
                setActiveCabinet(prevActive);
            } else if (!prevActive) {
                selectedNewWallId = prevSelectedWall;
                selectedWallSectionId = prevSelectedSection;
                rebuildWallSectionList();
                rebuildNewWalls();
            }
        }

        function sameSectionParent(a, b) {
            return (a && b && (a.parentId || null) === (b.parentId || null));
        }

        function redistributeWidthsForSiblings(sections, sec, desiredW, minSize) {
            if (!sec || sec.dir !== 'vertical' || sec.parentId == null) return false;
            const siblings = sections.filter(s => s.parentId === sec.parentId && !s.widthLocked);
            if (siblings.length < 2) return false;
            const totalPrev = siblings.reduce((sum, s) => sum + (s._prevW || s.w || 0), 0);
            const otherCount = siblings.length - 1;
            const maxForChanged = totalPrev - minSize * otherCount;
            const newW = Math.min(Math.max(desiredW, minSize), maxForChanged);
            const others = siblings.filter(s => s !== sec);
            const totalOthersPrev = others.reduce((sum, s) => sum + (s._prevW || s.w || 0), 0);
            const remaining = totalPrev - newW;
            sec.w = newW;
            if (remaining < minSize * others.length) return false;
            others.forEach(o => {
                const ratio = totalOthersPrev > 0 ? ((o._prevW || o.w || 0) / totalOthersPrev) : (1 / others.length);
                o.w = Math.max(minSize, remaining * ratio);
            });
            const totalAfter = siblings.reduce((sum, s) => sum + (s.w || 0), 0);
            let diff = totalPrev - totalAfter;
            if (Math.abs(diff) > 0.001) {
                others[0].w += diff;
            }
            const sorted = siblings.slice().sort((a, b) => (a._prevX || a.x || 0) - (b._prevX || b.x || 0));
            let cursor = Math.min(...sorted.map(s => s._prevX || s.x || 0));
            sorted.forEach(s => {
                s.x = cursor;
                cursor += s.w || 0;
            });
            return true;
        }

        function redistributeHeightsForSiblings(sections, sec, desiredH, minSize) {
            if (!sec || sec.dir !== 'horizontal' || sec.parentId == null) return false;
            const siblings = sections.filter(s => s.parentId === sec.parentId && !s.heightLocked);
            if (siblings.length < 2) return false;
            const totalPrev = siblings.reduce((sum, s) => sum + (s._prevH || s.h || 0), 0);
            const otherCount = siblings.length - 1;
            const maxForChanged = totalPrev - minSize * otherCount;
            const newH = Math.min(Math.max(desiredH, minSize), maxForChanged);
            const others = siblings.filter(s => s !== sec);
            const totalOthersPrev = others.reduce((sum, s) => sum + (s._prevH || s.h || 0), 0);
            const remaining = totalPrev - newH;
            sec.h = newH;
            if (remaining < minSize * others.length) return false;
            others.forEach(o => {
                const ratio = totalOthersPrev > 0 ? ((o._prevH || o.h || 0) / totalOthersPrev) : (1 / others.length);
                o.h = Math.max(minSize, remaining * ratio);
            });
            const totalAfter = siblings.reduce((sum, s) => sum + (s.h || 0), 0);
            let diff = totalPrev - totalAfter;
            if (Math.abs(diff) > 0.001) {
                others[0].h += diff;
            }
            const sorted = siblings.slice().sort((a, b) => (a._prevY || a.y || 0) - (b._prevY || b.y || 0));
            let cursor = Math.min(...sorted.map(s => s._prevY || s.y || 0));
            sorted.forEach(s => {
                s.y = cursor;
                cursor += s.h || 0;
            });
            return true;
        }

        function alignHorizontalGroupWidth(sections, sec) {
            if (!sec || sec.dir !== 'horizontal' || sec.parentId == null) return false;
            const group = sections.filter(s => s.parentId === sec.parentId && s.dir === 'horizontal' && !s.widthLocked);
            if (group.length < 2) return false;
            group.forEach(s => {
                s.w = sec.w;
            });
            return true;
        }

        function adjustHorizontalColumnNeighborWidth(sections, sec, minSize) {
            if (!sec || sec.parentId == null) return false;
            const prevW = (sec._prevW != null) ? sec._prevW : sec.w;
            const prevX = (sec._prevX != null) ? sec._prevX : (sec.x || 0);
            const delta = (sec.w || 0) - prevW;
            const eps = 0.001;
            if (Math.abs(delta) < eps) {
                sec.w = prevW;
                sec.x = prevX;
                return false;
            }
            const overlapY = (s) => {
                const top = Math.max(s.y || 0, sec.y || 0);
                const bottom = Math.min((s.y || 0) + (s.h || 0), (sec.y || 0) + (sec.h || 0));
                return bottom > top + eps;
            };
            const prevRight = prevX + prevW;
            const prevLeft = prevX;
            const rightNeighbors = sections.filter(s =>
                overlapY(s) &&
                !s.widthLocked &&
                Math.abs((s.x || 0) - prevRight) < eps
            );
            const leftNeighbors = sections.filter(s =>
                overlapY(s) &&
                !s.widthLocked &&
                Math.abs(((s.x || 0) + (s.w || 0)) - prevLeft) < eps
            );
            let neighbors = rightNeighbors;
            let neighborSide = 'right';
            if (!neighbors.length) {
                neighbors = leftNeighbors;
                neighborSide = 'left';
            }
            if (!neighbors.length) {
                sec.w = prevW;
                sec.x = prevX;
                return false;
            }

            const neighborChange = -delta;
            if (neighborChange < 0) {
                const minNeighborPrev = Math.min(...neighbors.map(n => (n._prevW != null) ? n._prevW : (n.w || 0)));
                if (minNeighborPrev + neighborChange < minSize) {
                    sec.w = prevW;
                    sec.x = prevX;
                    return false;
                }
            }

            neighbors.forEach(n => {
                const prevNeighborW = (n._prevW != null) ? n._prevW : (n.w || 0);
                const desired = prevNeighborW + neighborChange;
                n.w = Math.max(minSize, desired);
            });

            if (neighborSide === 'right') {
                const boundary = (sec.x || prevX) + (sec.w || 0);
                neighbors.forEach(n => {
                    n.x = boundary;
                });
            } else {
                const boundary = Math.max(...neighbors.map(n => (n.x || 0) + (n.w || 0)));
                sec.x = boundary;
            }
            return true;
        }

        function reflowHorizontalSiblingPositions(sections, sec) {
            if (!sec || sec.parentId == null) return;
            const siblings = sections.filter(s => s.parentId === sec.parentId && s.dir === 'vertical');
            if (!siblings.length) return;
            const start = Math.min(...siblings.map(s => s.x || 0));
            const sorted = siblings.slice().sort((a, b) => (a.x || 0) - (b.x || 0));
            let cursor = start;
            sorted.forEach(s => {
                s.x = cursor;
                cursor += (s.w || 0);
            });
        }

        function reflowVerticalSiblingPositions(sections, sec) {
            if (!sec || sec.parentId == null) return;
            const siblings = sections.filter(s => s.parentId === sec.parentId && s.dir === 'horizontal');
            if (!siblings.length) return;
            const start = Math.min(...siblings.map(s => s.y || 0));
            const sorted = siblings.slice().sort((a, b) => (a.y || 0) - (b.y || 0));
            let cursor = start;
            sorted.forEach(s => {
                s.y = cursor;
                cursor += (s.h || 0);
            });
        }

        function alignVerticalGroupHeight(sections, sec) {
            if (!sec || sec.dir !== 'vertical' || sec.parentId == null) return false;
            const group = sections.filter(s => s.parentId === sec.parentId && s.dir === 'vertical' && !s.heightLocked);
            if (group.length < 2) return false;
            group.forEach(s => {
                s.h = sec.h;
            });
            return true;
        }

        function adjustVerticalRowNeighborHeight(sections, sec, minSize) {
            if (!sec || sec.parentId == null) return false;
            const prevH = (sec._prevH != null) ? sec._prevH : sec.h;
            const prevY = (sec._prevY != null) ? sec._prevY : (sec.y || 0);
            const delta = (sec.h || 0) - prevH;
            const eps = 0.001;
            if (Math.abs(delta) < eps) {
                sec.h = prevH;
                sec.y = prevY;
                return false;
            }
            const overlapX = (s) => {
                const left = Math.max(s.x || 0, sec.x || 0);
                const right = Math.min((s.x || 0) + (s.w || 0), (sec.x || 0) + (sec.w || 0));
                return right > left + eps;
            };
            const prevTop = prevY + prevH;
            const prevBottom = prevY;
            const topNeighbors = sections.filter(s =>
                overlapX(s) &&
                !s.heightLocked &&
                Math.abs((s.y || 0) - prevTop) < eps
            );
            const bottomNeighbors = sections.filter(s =>
                overlapX(s) &&
                !s.heightLocked &&
                Math.abs(((s.y || 0) + (s.h || 0)) - prevBottom) < eps
            );
            let neighbors = topNeighbors;
            let neighborSide = 'top';
            if (!neighbors.length) {
                neighbors = bottomNeighbors;
                neighborSide = 'bottom';
            }
            if (!neighbors.length) {
                sec.h = prevH;
                sec.y = prevY;
                return false;
            }

            const neighborChange = -delta;
            if (neighborChange < 0) {
                const minNeighborPrev = Math.min(...neighbors.map(n => (n._prevH != null) ? n._prevH : (n.h || 0)));
                if (minNeighborPrev + neighborChange < minSize) {
                    sec.h = prevH;
                    sec.y = prevY;
                    return false;
                }
            }

            neighbors.forEach(n => {
                const prevNeighborH = (n._prevH != null) ? n._prevH : (n.h || 0);
                const desired = prevNeighborH + neighborChange;
                n.h = Math.max(minSize, desired);
            });

            if (neighborSide === 'top') {
                const boundary = (sec.y || prevY) + (sec.h || 0);
                neighbors.forEach(n => {
                    n.y = boundary;
                });
            } else {
                const boundary = Math.max(...neighbors.map(n => (n.y || 0) + (n.h || 0)));
                sec.y = boundary;
            }
            return true;
        }

        function clampSectionToWall(sec, wall, minSize) {
            if (!sec || !wall) return;
            const maxW = Math.max(minSize, wall.w || 0);
            const maxH = Math.max(minSize, wall.h || 0);
            sec.x = Math.max(0, Math.min(sec.x || 0, maxW - minSize));
            sec.y = Math.max(0, Math.min(sec.y || 0, maxH - minSize));
            sec.w = Math.max(minSize, Math.min(sec.w || minSize, maxW - sec.x));
            sec.h = Math.max(minSize, Math.min(sec.h || minSize, maxH - sec.y));
        }

        function clampSectionsToWall(wall, sections, minSize) {
            if (!wall || !sections) return;
            sections.forEach(sec => clampSectionToWall(sec, wall, minSize));
        }

        function saveActiveCabinetState() {
            if (!activeCabinetId) return;
            const idx = cabinets.findIndex(c => c.id === activeCabinetId);
            if (idx === -1) return;
            cabinets[idx].state      = captureCabinetSnapshot();
            cabinets[idx].baseOffset = { ...cabinetBaseOffset };
            cabinets[idx].wallId     = cabinetWallId;
            cabinets[idx].sectionId  = cabinetSectionId;
            cabinets[idx].rotationY  = cabinetRotationY;
            cabinets[idx].group      = cabinetGroup;
        }

        function setActiveCabinet(cabinetId) {
            saveActiveCabinetState();
            const cab = cabinets.find(c => c.id === cabinetId);
            if (!cab) return;

            // Алдыңғы кабинеттің секция хелперін алып тастаймыз (басқа шкафтан қалмасын)
            if (selectedSectionHelper && selectedSectionHelper.parent) {
                selectedSectionHelper.parent.remove(selectedSectionHelper);
                selectedSectionHelper.geometry.dispose();
                disposeMat(selectedSectionHelper.material);
                selectedSectionHelper = null;
            }
            if (selectedShelfSubHelper && selectedShelfSubHelper.parent) {
                selectedShelfSubHelper.parent.remove(selectedShelfSubHelper);
                selectedShelfSubHelper.geometry.dispose();
                disposeMat(selectedShelfSubHelper.material);
                selectedShelfSubHelper = null;
            }

            // Ескі group-ты жоймаймыз, сол group-пен жұмыс істейміз (басқа шкафтарды жоғалтпау үшін)
            cabinetGroup = null; // жаңа актив үшін
            activeCabinetId = cabinetId;
            cabinetWallId   = cab.wallId;
            cabinetSectionId= cab.sectionId;
            cabinetBaseOffset = cab.baseOffset || { x: 0, y: 0, z: 0 };
            cabinetRotationY = cab.rotationY || 0;
            selectedNewWallId = cab.wallId;
            selectedWallSectionId = cab.sectionId;
            selectedShelfSubId = null;

            // Әрқашан стейттен қайта құрамыз — innerVolumeMesh, sections дұрыс жаңарады
            applyCabinetState(cab.state);
            const idx = cabinets.findIndex(c => c.id === cabinetId);
            if (idx !== -1) {
                cabinets[idx].group = cabinetGroup;
            }
            applyActiveCabinetVisibility();
            syncActiveCabinetRecord();
            rebuildSectionSelect();
            updateSelectedSectionHelper();
            rebuildShelvesUI();
            rebuildDimensionHelpers();
            rebuildCabinetList();
            rebuildCabinetIcons();
        }

	        function removeCabinet(cabinetId) {
	            const idx = cabinets.findIndex(c => c.id === cabinetId);
	            if (idx === -1) return;
	            runUndoable(() => {
	                const cab = cabinets[idx];
	                if (cab.group) {
	                    disposeGroup(cab.group);
	                    if (cabinetGroup === cab.group) {
	                        cabinetGroup = null;
	                    }
	                }
	                if (activeCabinetId === cabinetId && cabinetGroup && cabinetGroup !== cab.group) {
	                    disposeGroup(cabinetGroup);
	                    cabinetGroup = null;
	                }
	                // Сценада userData.cabinetId сәйкес келетін басқа group қалмасын
	                scene.children
	                    .filter(obj => obj.userData && obj.userData.cabinetId === cabinetId)
	                    .forEach(disposeGroup);

	                cabinets.splice(idx, 1);
	                if (activeCabinetId === cabinetId) {
	                    cabinetGroup = null;
	                    activeCabinetId = null;
	                    cabinetWallId = null;
	                    cabinetSectionId = null;
	                    cabinetSpawned = false;
	                    cabinetRotationY = 0;
	                }
	                if (cabinets.length) {
	                    // Тек белсенді group-ты жаңадан салу, басқа шкафтарды қозғамаймыз
	                    const lastId = cabinets[cabinets.length - 1].id;
	                    activeCabinetId = null;
	                    setActiveCabinet(lastId);
	                } else {
	                    // Ешқандай шкаф қалмаса – сценадан толық тазалаймыз
	                    disposeGroup(cabinetGroup);
	                    cabinetGroup = null;
	                    rebuildNewWalls();
	                    rebuildCabinetList();
	                }
	                rebuildCabinetList();
	                rebuildCabinetIcons();
	                rebuildDimensionHelpers();
	            });
	        }

        function syncActiveCabinetRecord() {
            if (!activeCabinetId) return;
            const idx = cabinets.findIndex(c => c.id === activeCabinetId);
            if (idx === -1) return;
            cabinets[idx].state = captureCabinetSnapshot();
            cabinets[idx].group = cabinetGroup;
            cabinets[idx].baseOffset = { ...cabinetBaseOffset };
            cabinets[idx].wallId = cabinetWallId;
            cabinets[idx].sectionId = cabinetSectionId;
            cabinets[idx].rotationY = cabinetRotationY;
            cabinets[idx].hidden = isCabinetHidden(cabinets[idx].id);
        }

        function rebuildWallSectionList() {
            if (!wallSectionList) return;
            wallSectionList.innerHTML = '';
            if (!selectedNewWallId) {
                wallSectionList.textContent = 'Стенаны таңдаңыз';
                return;
            }
            const sections = ensureWallSections(newWalls.find(w => w.id === selectedNewWallId));
            if (!sections.length) {
                wallSectionList.textContent = 'Секция жоқ';
                return;
            }
            sections.forEach(sec => {
                const row = document.createElement('div');
                row.className = 'simple-list-item wall-section-row';
                if (sec.id === selectedWallSectionId) row.classList.add('active');

                const info = document.createElement('div');
                info.className = 'meta';
                const dirLabel = (sec.dir === 'vertical')
                    ? 'В'
                    : (sec.dir === 'horizontal')
                        ? 'Г'
                        : 'B';
                info.textContent = `${dirLabel} · ID ${sec.id}`;

                const inputsWrap = document.createElement('div');
                inputsWrap.className = 'wall-section-inputs';

                const widthLocked = !!sec.widthLocked;
                const heightLocked = !!sec.heightLocked;
                sec.widthLocked = widthLocked;
                sec.heightLocked = heightLocked;

                const wInput = document.createElement('input');
                wInput.type = 'number';
                wInput.value = Math.round(sec.w || 0);
                wInput.step = '10';
                wInput.title = 'Ені (мм)';
                wInput.disabled = widthLocked;
                const hInput = document.createElement('input');
                hInput.type = 'number';
                hInput.value = Math.round(sec.h || 0);
                hInput.step = '10';
                hInput.title = 'Биіктігі (мм)';
                hInput.disabled = heightLocked;

                const lockWidthBtn = document.createElement('button');
                lockWidthBtn.type = 'button';
                lockWidthBtn.className = 'wall-section-lock-btn wall-section-lock-btn--width' + (widthLocked ? ' locked' : '');
                lockWidthBtn.title = widthLocked ? 'Ені құлыптан босату' : 'Ені құлыптау';
                lockWidthBtn.setAttribute('aria-label', lockWidthBtn.title);
                lockWidthBtn.innerHTML = `<i class="fa-solid ${widthLocked ? 'fa-lock' : 'fa-lock-open'}" aria-hidden="true"></i>`;
                lockWidthBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    sec.widthLocked = !sec.widthLocked;
                    rebuildWallSectionList();
                });

                const lockHeightBtn = document.createElement('button');
                lockHeightBtn.type = 'button';
                lockHeightBtn.className = 'wall-section-lock-btn wall-section-lock-btn--height' + (heightLocked ? ' locked' : '');
                lockHeightBtn.title = heightLocked ? 'Биіктігі құлыптан босату' : 'Биіктігі құлыптау';
                lockHeightBtn.setAttribute('aria-label', lockHeightBtn.title);
                lockHeightBtn.innerHTML = `<i class="fa-solid ${heightLocked ? 'fa-lock' : 'fa-lock-open'}" aria-hidden="true"></i>`;
                lockHeightBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    sec.heightLocked = !sec.heightLocked;
                    rebuildWallSectionList();
                });

                const widthBlock = document.createElement('div');
                widthBlock.className = 'wall-section-measure';
                widthBlock.appendChild(wInput);
                widthBlock.appendChild(lockWidthBtn);

                const heightBlock = document.createElement('div');
                heightBlock.className = 'wall-section-measure';
                heightBlock.appendChild(hInput);
                heightBlock.appendChild(lockHeightBtn);

                const delBtn = document.createElement('button');
                delBtn.type = 'button';
                delBtn.textContent = '🗑';
                delBtn.title = 'Секцияны өшіру';
                if (widthLocked || heightLocked) {
                    delBtn.disabled = true;
                    delBtn.classList.add('disabled');
                }

                wInput.addEventListener('change', (e) => {
                    const newW = parseFloat(e.target.value) || sec.w;
                    resizeWallSection(sec.id, { w: newW });
                });
                hInput.addEventListener('change', (e) => {
                    const newH = parseFloat(e.target.value) || sec.h;
                    resizeWallSection(sec.id, { h: newH });
                });
                [lockWidthBtn, lockHeightBtn, wInput, hInput, delBtn].forEach(inp => {
                    inp.addEventListener('mousedown', ev => ev.stopPropagation());
                    inp.addEventListener('click', ev => ev.stopPropagation());
                    inp.addEventListener('focus', ev => ev.stopPropagation());
                });
                delBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    deleteWallSection(sec.id);
                });

                inputsWrap.appendChild(widthBlock);
                inputsWrap.appendChild(heightBlock);
                inputsWrap.appendChild(delBtn);

                row.appendChild(info);
                row.appendChild(inputsWrap);

                row.addEventListener('click', () => {
                    selectedWallSectionId = sec.id;
                    rebuildWallSectionList();
                    rebuildNewWalls();
                });
                wallSectionList.appendChild(row);
            });
            if (wallLineMeasurements) {
                rebuildWallLineMeasurements();
            }
        }

        function rebuildWallLineMeasurements() {
            if (!wallLineMeasurements) return;
            wallLineMeasurements.innerHTML = '';
            if (!selectedNewWallId) {
                wallLineMeasurements.textContent = 'Стена таңдаңыз';
                return;
            }
            const wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) {
                wallLineMeasurements.textContent = 'Стена жоқ';
                return;
            }
            const sections = ensureWallSections(wall);
            if (!sections.length) {
                wallLineMeasurements.textContent = 'Сызық жоқ';
                return;
            }
            const sorted = sections.slice().sort((a, b) => {
                if ((a.y || 0) !== (b.y || 0)) return (a.y || 0) - (b.y || 0);
                return (a.x || 0) - (b.x || 0);
            });
            sorted.forEach(sec => {
                const row = document.createElement('div');
                row.className = 'simple-list-item wall-line-row';

                const info = document.createElement('div');
                info.className = 'wall-line-info';
                const axisLabel = (sec.dir === 'horizontal') ? 'Г'
                    : (sec.dir === 'grid') ? 'В/Г'
                    : 'В';
                const axisBadge = document.createElement('span');
                axisBadge.className = 'wall-line-axis';
                axisBadge.textContent = axisLabel;
                const infoText = document.createElement('span');
                infoText.className = 'meta';
                infoText.textContent = `ID ${sec.id}`;
                info.appendChild(axisBadge);
                info.appendChild(infoText);

                const inputsWrap = document.createElement('div');
                inputsWrap.className = 'wall-line-inputs';

                const createField = (labelText, value, title, handler) => {
                    const wrap = document.createElement('div');
                    wrap.style.display = 'flex';
                    wrap.style.alignItems = 'center';
                    wrap.style.gap = '4px';
                    const label = document.createElement('span');
                    label.textContent = labelText;
                    label.style.fontSize = '12px';
                    const input = document.createElement('input');
                    input.type = 'number';
                    input.value = Math.round(value || 0);
                    input.min = '50';
                    input.step = '10';
                    input.title = title;
                    input.addEventListener('change', (e) => {
                        const parsed = parseFloat(e.target.value);
                        if (!Number.isFinite(parsed) || parsed <= 0) return;
                        handler(Math.max(50, parsed));
                    });
                    wrap.appendChild(label);
                    wrap.appendChild(input);
                    return wrap;
                };

                const wField = createField('Ені', sec.w, 'Ені (мм)', (val) => resizeWallSection(sec.id, { w: val }));
                const hField = createField('Биіктігі', sec.h, 'Биіктігі (мм)', (val) => resizeWallSection(sec.id, { h: val }));
                inputsWrap.appendChild(wField);
                inputsWrap.appendChild(hField);

                row.appendChild(info);
                row.appendChild(inputsWrap);
                wallLineMeasurements.appendChild(row);
            });
        }

        function rebuildCabinetList() {
            if (!cabinetList) return;
            cabinetList.style.display = 'none';
            cabinetList.innerHTML = '';
            // intentionally hidden as per latest requirement
        }

        function rebuildNewWallList() {
            if (!newWallList) return;
            newWallList.innerHTML = '';
            if (!newWalls.length) {
                newWallList.textContent = 'Стена жоқ';
                return;
            }
            newWalls.forEach((w, idx) => {
                const row = document.createElement('div');
                row.className = 'simple-list-item wall-list-row';
                if (w.id === selectedNewWallId) row.classList.add('active');
                const header = document.createElement('div');
                header.className = 'wall-row-header';

                const title = document.createElement('div');
                const typeLabel = (w.type === 'vertical') ? 'V' : 'F';
                title.textContent = `${typeLabel} · ID ${idx + 1}`;
                header.appendChild(title);

                const whInputs = document.createElement('div');
                whInputs.className = 'wall-wh-inputs';
                const wInput = document.createElement('input');
                wInput.type = 'number';
                wInput.value = Math.round(w.w || 0);
                wInput.step = '10';
                wInput.title = 'Ені (мм)';
                wInput.placeholder = 'l';
                const hInput = document.createElement('input');
                hInput.type = 'number';
                hInput.value = Math.round(w.h || 0);
                hInput.step = '10';
                hInput.title = 'Биіктік (мм)';
                hInput.placeholder = 'h';
                whInputs.appendChild(wInput);
                whInputs.appendChild(hInput);
                header.appendChild(whInputs);

                const del = document.createElement('button');
                del.textContent = '🗑';
                del.title = 'Өшіру';
                del.style.marginLeft = 'auto';
                del.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const cabinetsOnWall = getCabinetsByWallId(w.id);
                    if (cabinetsOnWall.length) {
                        const msg = `Бұл стенаны өшірсеңіз, осы стенамен байланысқан ${cabinetsOnWall.length} шкаф та өшеді. Өшіруді растайсыз ба?`;
                        const ok = window.confirm(msg);
                        if (!ok) return;
                        const ids = cabinetsOnWall.map(c => c.id);
                        ids.forEach(removeCabinet);
                    }
                    newWalls = newWalls.filter(x => x.id !== w.id);
                    if (selectedNewWallId === w.id) selectedNewWallId = null;
                    delete wallSections[w.id];
                    selectedWallSectionId = null;
                    if (cabinetWallId === w.id) {
                        cabinetWallId = null;
                        cabinetSectionId = null;
                        cabinetSpawned = false;
                        cabinetBaseOffset = { x: 0, y: 0, z: 0 };
                        cabinetRotationY = 0;
                        if (cabinetGroup) {
                            scene.remove(cabinetGroup);
                            cabinetGroup = null;
                        }
                        cabinets.forEach(c => {
                            if (c.wallId === w.id && c.group) {
                                scene.remove(c.group);
                            }
                        });
                        cabinets = cabinets.filter(c => c.wallId !== w.id);
                        activeCabinetId = null;
                    }
                    rebuildNewWallList();
                    rebuildNewWalls();
                    rebuildCabinetList();
                    rebuildCabinetIcons();
                });
                header.appendChild(del);

                const posRow = document.createElement('div');
                posRow.className = 'wall-xyz-inputs';
                const xInput = document.createElement('input');
                xInput.type = 'number';
                xInput.value = Math.round(w.x || 0);
                xInput.step = '10';
                xInput.title = 'X (мм)';
                xInput.placeholder = 'x';
                const yInput = document.createElement('input');
                yInput.type = 'number';
                yInput.value = Math.round(w.y || 0);
                yInput.step = '10';
                yInput.title = 'Y (мм)';
                yInput.placeholder = 'y';
                const zInput = document.createElement('input');
                zInput.type = 'number';
                zInput.value = Math.round(w.z || 0);
                zInput.step = '10';
                zInput.title = 'Z (мм)';
                zInput.placeholder = 'z';
                posRow.appendChild(xInput);
                posRow.appendChild(yInput);
                posRow.appendChild(zInput);

                wInput.addEventListener('change', (e) => {
                    const newW = parseFloat(e.target.value) || w.w;
                    updateWallSizeById(w.id, { w: newW });
                });
                hInput.addEventListener('change', (e) => {
                    const newH = parseFloat(e.target.value) || w.h;
                    updateWallSizeById(w.id, { h: newH });
                });
                xInput.addEventListener('change', (e) => {
                    const nx = parseFloat(e.target.value);
                    updateWallSizeById(w.id, { x: isNaN(nx) ? w.x : nx });
                });
                yInput.addEventListener('change', (e) => {
                    const ny = parseFloat(e.target.value);
                    updateWallSizeById(w.id, { y: isNaN(ny) ? w.y : ny });
                });
                zInput.addEventListener('change', (e) => {
                    const nz = parseFloat(e.target.value);
                    updateWallSizeById(w.id, { z: isNaN(nz) ? w.z : nz });
                });

                [wInput, hInput, xInput, yInput, zInput].forEach(inp => {
                    inp.addEventListener('mousedown', e => e.stopPropagation());
                    inp.addEventListener('click', e => e.stopPropagation());
                    inp.addEventListener('focus', e => e.stopPropagation());
                });

                row.addEventListener('click', () => {
                    selectedNewWallId = w.id;
                    if (cabinetWallId === w.id && cabinetSectionId) {
                        selectedWallSectionId = cabinetSectionId;
                    }
                    ensureWallSections(w);
                    selectedWallSectionId = selectedWallSectionId || (wallSections[w.id] && wallSections[w.id][0] && wallSections[w.id][0].id) || null;
                    rebuildNewWallList();
                    rebuildWallSectionList();
                    rebuildNewWalls();
                    rebuildCabinetList();
                });

                row.appendChild(header);
                row.appendChild(posRow);
                newWallList.appendChild(row);
            });

            rebuildWallSectionList();
        }

        function rebuildNewWalls() {
            disposeNewWallGroup();
            if (!newWalls.length) return;
            newWallGroup = new THREE.Group();
            const lineMat = new THREE.LineBasicMaterial({ color: 0x00aa00, linewidth: 2, depthTest: true });
            const sectionMat = new THREE.LineBasicMaterial({ color: 0x0077ff, linewidth: 1, depthTest: true });
            wallSectionPlusSprites = [];
            selectedWallSectionHelper = null;

            newWalls.forEach(w => {
                const isVert = (w.type === 'vertical');
                const sizeX = isVert ? 1 : (w.w || 1000);
                const sizeZ = isVert ? (w.w || 1000) : 1;
                const sizeY = w.h || 1000;
                const geo = new THREE.BoxGeometry(sizeX, sizeY, sizeZ);
                const edges = new THREE.EdgesGeometry(geo);
                const line = new THREE.LineSegments(edges, lineMat.clone());
                const startX = w.x || 0;
                const startY = w.y || 0;
                const startZ = w.z || 0;
                const centerX = startX + (isVert ? 0 : sizeX / 2);
                const centerZ = startZ + (isVert ? sizeZ / 2 : 0);
                line.position.set(centerX, startY + sizeY / 2, centerZ);
                newWallGroup.add(line);

                // Секцияларды салу
                const sections = ensureWallSections(w);
                sections.forEach(sec => {
                    const left   = startX + (isVert ? 0 : sec.x);
                    const right  = left + sec.w;
                    const bottom = startY + sec.y;
                    const top    = bottom + sec.h;
                    const zPlane = isVert ? startZ : startZ;
                    const xPlane = isVert ? startX : null;

                    const pts = isVert
                        ? [
                            new THREE.Vector3(xPlane, bottom, startZ + sec.x),
                            new THREE.Vector3(xPlane, bottom, startZ + sec.x + sec.w),
                            new THREE.Vector3(xPlane, top,    startZ + sec.x + sec.w),
                            new THREE.Vector3(xPlane, top,    startZ + sec.x),
                            new THREE.Vector3(xPlane, bottom, startZ + sec.x)
                        ]
                        : [
                            new THREE.Vector3(left,  bottom, zPlane),
                            new THREE.Vector3(right, bottom, zPlane),
                            new THREE.Vector3(right, top,    zPlane),
                            new THREE.Vector3(left,  top,    zPlane),
                            new THREE.Vector3(left,  bottom, zPlane)
                        ];
                    const secGeo = new THREE.BufferGeometry().setFromPoints(pts);
                    const secLine = new THREE.Line(secGeo, sectionMat.clone());
                    secLine.userData.isWallSection = true;
                    newWallGroup.add(secLine);

                    const isSelectedSection = (selectedWallSectionId === sec.id) && (selectedNewWallId === w.id);
                    if (isSelectedSection) {
                        const planeGeo = new THREE.PlaneGeometry(
                            isVert ? sec.w : sec.w,
                            sec.h
                        );
                        const planeMat = new THREE.MeshBasicMaterial({
                            color: wallSectionHighlightBaseColor.getHex(),
                            opacity: 0.35,
                            transparent: true,
                            depthWrite: false,
                            side: THREE.DoubleSide
                        });
                        const plane = new THREE.Mesh(planeGeo, planeMat);

                        const centerX = isVert ? xPlane : (left + right) / 2;
                        const centerY = (bottom + top) / 2;
                        const centerZ = isVert ? (startZ + sec.x + sec.w / 2) : zPlane;
                        plane.position.set(centerX, centerY, centerZ);
                        if (isVert) {
                            plane.rotation.y = Math.PI / 2;
                        }
                        const offset = 0.1;
                        if (isVert) {
                            plane.position.x += (w.type === 'vertical') ? offset : 0;
                        } else {
                            plane.position.z += offset;
                        }
                        plane.renderOrder = 1500;

                        selectedWallSectionHelper = plane;
                        newWallGroup.add(plane);
                    }

                    // Плюс белгісі (егер осы секцияда шкаф байланбаған болса)
                    const isLinkedCabinet = hasCabinetInSection(w.id, sec.id);
                    if (!isLinkedCabinet) {
                        const plus = createWallPlusSprite();
                        const cX = isVert ? xPlane : (left + right) / 2;
                        const cZ = isVert ? (startZ + sec.x + sec.w / 2) : zPlane;
                        plus.position.set(cX, (bottom + top) / 2, cZ);
                        plus.userData.isWallSectionPlus = true;
                        plus.userData.wallId = w.id;
                        plus.userData.sectionId = sec.id;
                        wallSectionPlusSprites.push(plus);
                        newWallGroup.add(plus);
                    }
                });

            });

            scene.add(newWallGroup);
        }

        function addNewWall(typeOverride) {
            saveActiveCabinetState();
            const type = typeOverride || 'frontal';
            const wVal = 3000;
            const hVal = 3000;
            const xVal = 0;
            const yVal = 0;
            const zVal = 0;
            const id = Date.now() + Math.random();
            newWalls.push({ id, type, w: wVal, h: hVal, x: xVal, y: yVal, z: zVal });
            selectedNewWallId = id;
            wallSections[id] = [{
                id: nextWallSectionId++,
                parentId: null,
                x: 0,
                y: 0,
                w: wVal,
                h: hVal,
                dir: 'base',
                widthLocked: false,
                heightLocked: false
            }];
            selectedWallSectionId = wallSections[id][0].id;
            if (!cabinetWallId) {
                cabinetWallId = id;
                cabinetSectionId = selectedWallSectionId;
            }
            if (newWallList) newWallList.scrollTop = newWallList.scrollHeight;
            rebuildNewWallList();
            rebuildNewWalls();
        }

        if (addWallFrontalBtn) {
            addWallFrontalBtn.addEventListener('click', () => addNewWall('frontal'));
        }
        if (addWallVerticalBtn) {
            addWallVerticalBtn.addEventListener('click', () => addNewWall('vertical'));
        }

        function updateWallSizeById(wallId, opts) {
            const idx = newWalls.findIndex(w => w.id === wallId);
            if (idx === -1) return;
            const wall = newWalls[idx];
            const newW = (opts && opts.w != null) ? opts.w : wall.w;
            const newH = (opts && opts.h != null) ? opts.h : wall.h;
            const newX = (opts && opts.x != null) ? opts.x : wall.x;
            const newY = (opts && opts.y != null) ? opts.y : wall.y;
            const newZ = (opts && opts.z != null) ? opts.z : wall.z;
            const prevW = (opts && opts.prevW) || wall.w || 1;
            const prevH = (opts && opts.prevH) || wall.h || 1;
            newWalls[idx] = { ...wall, w: newW, h: newH, x: newX, y: newY, z: newZ };
            if (wallSections[wallId] && wallSections[wallId].length) {
                const list = wallSections[wallId];
                const scaleW = newW / prevW;
                const scaleH = newH / prevH;
                wallSections[wallId] = list.map(sec => ({
                    ...sec,
                    x: sec.x * scaleW,
                    y: sec.y * scaleH,
                    w: sec.w * scaleW,
                    h: sec.h * scaleH
                }));
            }
            rebuildNewWallList();
            rebuildNewWalls();
            if (cabinetWallId === wallId) {
                updateCabinetFromSection(true);
            }
        }

        function applySelectedWallInputs() {
            if (!selectedNewWallId) return;
            const idx = newWalls.findIndex(x => x.id === selectedNewWallId);
            if (idx === -1) return;
            const type = newWalls[idx].type;
            const prevW = newWalls[idx].w || 1;
            const prevH = newWalls[idx].h || 1;
            updateWallSizeById(newWalls[idx].id, {
                w: newWalls[idx].w,
                h: newWalls[idx].h,
                x: newWalls[idx].x,
                y: newWalls[idx].y,
                z: newWalls[idx].z,
                prevW,
                prevH
            });
        }

        [newWallWidthInput, newWallHeightInput, newWallStartXInput, newWallStartYInput, newWallStartZInput].forEach(inp => {
            if (inp) {
                inp.addEventListener('input', applySelectedWallInputs);
                inp.addEventListener('change', applySelectedWallInputs);
            }
        });

        function getSplitCount(input, fallback = 2) {
            if (!input) return fallback;
            const parsed = parseInt(input.value, 10);
            if (isNaN(parsed)) return fallback;
            return Math.max(2, parsed);
        }

        function confirmAndClearWallCabinets(wallId) {
            const cabinetIds = getCabinetsByWallId(wallId).map(c => c.id);
            if (!cabinetIds.length) return true;
            const msg = 'Осы стенадағы барлық шкафты өшіріп, қайта бөліңіз бе?';
            if (!window.confirm(msg)) return false;
            cabinetIds.forEach(removeCabinet);
            return true;
        }

        function splitWallIntoLines(mode, splitCountOverride) {
            if (!selectedNewWallId) return;
            const wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) return;
            const splitCount = Math.max(2, splitCountOverride || (mode === 'vertical'
                ? getSplitCount(splitVerticalCountInput)
                : getSplitCount(splitHorizontalCountInput)));
            if (splitCount < 2) return;
            const minSize = 50;
            const isVertical = (mode === 'vertical');
            const axisLength = isVertical ? wall.w : wall.h;
            if (!isFinite(axisLength) || axisLength < minSize * splitCount) return;
            if (!confirmAndClearWallCabinets(wall.id)) return;

            const sectionSize = axisLength / splitCount;
            const sections = [];
            for (let i = 0; i < splitCount; i++) {
                const size = (i === splitCount - 1)
                    ? Math.max(minSize, axisLength - sectionSize * (splitCount - 1))
                    : sectionSize;
                const sec = {
                    id: nextWallSectionId++,
                    parentId: null,
                    x: isVertical ? sectionSize * i : 0,
                    y: isVertical ? 0 : sectionSize * i,
                    w: isVertical ? size : (wall.w || 0),
                    h: isVertical ? (wall.h || 0) : size,
                    dir: isVertical ? 'vertical' : 'horizontal',
                    widthLocked: false,
                    heightLocked: false
                };
                sections.push(sec);
            }
            clampSectionsToWall(wall, sections, minSize);
            wallSections[wall.id] = sections;
            selectedWallSectionId = sections[0] ? sections[0].id : null;
            rebuildWallSectionList();
            rebuildNewWalls();
        }

        function splitWallGrid() {
            if (!selectedNewWallId) return;
            const wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) return;
            const verticalCount = getSplitCount(splitVerticalCountInput);
            const horizontalCount = getSplitCount(splitHorizontalCountInput);
            const minSize = 50;
            if (verticalCount < 2 || horizontalCount < 2) return;
            if (!isFinite(wall.w) || !isFinite(wall.h)) return;
            if (wall.w < minSize * verticalCount || wall.h < minSize * horizontalCount) return;
            if (!confirmAndClearWallCabinets(wall.id)) return;

            const sectionWidth = wall.w / verticalCount;
            const sectionHeight = wall.h / horizontalCount;
            const verticalBands = [];
            let xAcc = 0;
            for (let i = 0; i < verticalCount; i++) {
                const w = (i === verticalCount - 1)
                    ? Math.max(minSize, wall.w - sectionWidth * (verticalCount - 1))
                    : sectionWidth;
                verticalBands.push({ x: xAcc, w });
                xAcc += w;
            }
            const horizontalBands = [];
            let yAcc = 0;
            for (let i = 0; i < horizontalCount; i++) {
                const h = (i === horizontalCount - 1)
                    ? Math.max(minSize, wall.h - sectionHeight * (horizontalCount - 1))
                    : sectionHeight;
                horizontalBands.push({ y: yAcc, h });
                yAcc += h;
            }

            const sections = [];
            verticalBands.forEach(v => {
                horizontalBands.forEach(h => {
                    sections.push({
                        id: nextWallSectionId++,
                        parentId: null,
                        x: v.x,
                        y: h.y,
                        w: v.w,
                        h: h.h,
                        dir: 'grid',
                        widthLocked: false,
                        heightLocked: false
                    });
                });
            });
            clampSectionsToWall(wall, sections, minSize);
            wallSections[wall.id] = sections;
            selectedWallSectionId = sections[0] ? sections[0].id : null;
            rebuildWallSectionList();
            rebuildNewWalls();
        }

        if (splitWallSectionV) {
            splitWallSectionV.addEventListener('click', () => {
                splitWallIntoLines('vertical');
            });
        }
        if (splitWallSectionH) {
            splitWallSectionH.addEventListener('click', () => {
                splitWallIntoLines('horizontal');
            });
        }
        if (splitWallGridBtn) {
            splitWallGridBtn.addEventListener('click', splitWallGrid);
        }


        // СЕКЦИЯ ӨЛШЕМІН ТІКЕЛЕЙ ӨЗГЕРТУ (list inputs)
        function resizeWallSection(sectionId, opts) {
            if (!selectedNewWallId) return;
            const wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) return;
            const sections = ensureWallSections(wall);
            const idx = sections.findIndex(s => s.id === sectionId);
            if (idx === -1) return;
            const sec = sections[idx];
            const newW = (opts && opts.w != null) ? opts.w : sec.w;
            const newH = (opts && opts.h != null) ? opts.h : sec.h;
            const minSize = 50;
            const eps = 0.001;
            // Capture previous sizes for balancing
            sections.forEach(s => {
                s._prevW = s.w;
                s._prevH = s.h;
                s._prevX = s.x;
                s._prevY = s.y;
            });

            // Width adjust (жалпы биіктік бірдей көрші керек)
            if (opts && opts.w != null && !sec.widthLocked) {
                let widthChanged = false;
                // Try sibling redistribution first (for vertical split siblings)
                const redisOk = redistributeWidthsForSiblings(sections, sec, newW, minSize);
                if (redisOk) {
                    widthChanged = true;
                } else {
                let neighbor = sections.find(s =>
                    !s.widthLocked &&
                    Math.abs(s.x - (sec.x + sec.w)) < eps &&
                    Math.abs(s.y - sec.y) < eps &&
                    Math.abs(s.h - sec.h) < eps &&
                    sameSectionParent(s, sec)
                );
                let neighborSide = 'right';
                if (!neighbor) {
                    neighbor = sections.find(s =>
                        !s.widthLocked &&
                        Math.abs((s.x + s.w) - sec.x) < eps &&
                        Math.abs(s.y - sec.y) < eps &&
                        Math.abs(s.h - sec.h) < eps &&
                        sameSectionParent(s, sec)
                    );
                    neighborSide = 'left';
                }
                if (neighbor) {
                    const delta = newW - sec.w;
                    const newNeighW = neighbor.w - delta;
                    if (newW >= minSize && newNeighW >= minSize) {
                        if (neighborSide === 'right') {
                            sec.w = newW;
                            neighbor.w = newNeighW;
                            neighbor.x = sec.x + sec.w;
                        } else {
                            neighbor.w = newNeighW;
                            sec.x = neighbor.x + neighbor.w;
                            sec.w = newW;
                        }
                        widthChanged = true;
                    }
                } else if (newW >= minSize) {
                    sec.w = newW;
                    widthChanged = true;
                }
                }
                if (widthChanged) {
                    if (sec.dir === 'horizontal' && sec.parentId != null) {
                        alignHorizontalGroupWidth(sections, sec);
                        adjustHorizontalColumnNeighborWidth(sections, sec, minSize);
                    }
                    reflowHorizontalSiblingPositions(sections, sec);
                    // already handled positioning inside redistribution or neighbor logic
                }
            }

            // Height adjust (жалпы ені бірдей көрші керек)
            if (opts && opts.h != null && !sec.heightLocked) {
                let heightChanged = false;
                // Баған бойынша (x/w бірдей) пропорциямен қайта бөлу: жалпы биіктікті сақтаймыз
                if (!heightChanged) {
                    const sameColumn = sections.filter(s =>
                        Math.abs((s.x || 0) - (sec.x || 0)) < eps &&
                        Math.abs((s.w || 0) - (sec.w || 0)) < eps
                    );
                    if (sameColumn.length > 1) {
                        const totalPrev = sameColumn.reduce((sum, s) => sum + (s._prevH || s.h || 0), 0);
                        const others = sameColumn.filter(s => s !== sec);
                        const totalOthersPrev = others.reduce((sum, s) => sum + (s._prevH || s.h || 0), 0);
                        const minForOthers = minSize * others.length;
                        const newHClamped = Math.min(Math.max(newH, minSize), totalPrev - minForOthers);
                        const remaining = totalPrev - newHClamped;
                        if (remaining >= minForOthers && totalOthersPrev > 0) {
                            sec.h = newHClamped;
                            others.forEach(o => {
                                const ratio = (o._prevH || o.h || 0) / totalOthersPrev;
                                o.h = Math.max(minSize, remaining * ratio);
                            });
                            const sortedCol = sameColumn.slice().sort((a, b) => (a._prevY || a.y || 0) - (b._prevY || b.y || 0));
                            let cursor = Math.min(...sortedCol.map(s => s._prevY || s.y || 0));
                            sortedCol.forEach(s => {
                                s.y = cursor;
                                cursor += s.h || 0;
                            });
                            heightChanged = true;
                        }
                    }
                }
                // Алдымен бауырлас (бір parent) горизонталь бөліктерге бағытталған логика:
                if (!heightChanged && sec.dir === 'horizontal' && sec.parentId != null) {
                    const siblings = sections.filter(s => s.parentId === sec.parentId && s.dir === sec.dir);
                    if (siblings.length > 1) {
                        const sorted = siblings.slice().sort((a, b) => (a._prevY || a.y || 0) - (b._prevY || b.y || 0));
                        const myIdx = sorted.indexOf(sec);
                        const neighbor = (myIdx < sorted.length - 1) ? sorted[myIdx + 1] : sorted[myIdx - 1];
                        if (neighbor) {
                            const others = siblings.filter(s => s !== sec && s !== neighbor);
                            const totalPrev = siblings.reduce((sum, s) => sum + (s._prevH || s.h || 0), 0);
                            const fixedSum = others.reduce((sum, s) => sum + (s._prevH || s.h || 0), 0);
                            const maxForSec = totalPrev - fixedSum - minSize;
                            const newHClamped = Math.min(Math.max(newH, minSize), maxForSec);
                            const newNeighborH = totalPrev - fixedSum - newHClamped;
                            if (newNeighborH >= minSize) {
                                sec.h = newHClamped;
                                neighbor.h = newNeighborH;
                                const startY = Math.min(...sorted.map(s => s._prevY || s.y || 0));
                                let cursor = startY;
                                sorted.forEach(s => {
                                    s.y = cursor;
                                    cursor += s.h || 0;
                                });
                                heightChanged = true;
                            }
                        }
                    }
                }
                if (!heightChanged) {
                    const redisHOk = redistributeHeightsForSiblings(sections, sec, newH, minSize);
                    if (redisHOk) {
                        heightChanged = true;
                    } else {
                    let neighbor = sections.find(s =>
                        !s.heightLocked &&
                        Math.abs(s.y - (sec.y + sec.h)) < eps &&
                        Math.abs(s.x - sec.x) < eps &&
                        Math.abs(s.w - sec.w) < eps &&
                        sameSectionParent(s, sec)
                    );
                    let neighborSide = 'top';
                    if (!neighbor) {
                        neighbor = sections.find(s =>
                            !s.heightLocked &&
                            Math.abs((s.y + s.h) - sec.y) < eps &&
                            Math.abs(s.x - sec.x) < eps &&
                            Math.abs(s.w - sec.w) < eps &&
                            sameSectionParent(s, sec)
                        );
                        neighborSide = 'bottom';
                    }
                    if (neighbor) {
                        const delta = newH - sec.h;
                        const newNeighH = neighbor.h - delta;
                        if (newH >= minSize && newNeighH >= minSize) {
                            if (neighborSide === 'top') {
                                sec.h = newH;
                                neighbor.h = newNeighH;
                                neighbor.y = sec.y + sec.h;
                            } else {
                                neighbor.h = newNeighH;
                                sec.y = neighbor.y + neighbor.h;
                                sec.h = newH;
                            }
                            heightChanged = true;
                        }
                    } else if (newH >= minSize) {
                        sec.h = newH;
                        heightChanged = true;
                    }
                    }
                }
                if (heightChanged) {
                    if (sec.dir === 'vertical' && sec.parentId != null) {
                        alignVerticalGroupHeight(sections, sec);
                        adjustVerticalRowNeighborHeight(sections, sec, minSize);
                    }
                    reflowVerticalSiblingPositions(sections, sec);
                    // already handled
                }
            }

            wallSections[wall.id] = sections;
            clampSectionsToWall(wall, wallSections[wall.id], minSize);
            rebuildWallSectionList();
            rebuildNewWalls();
            // Cleanup temp fields
            sections.forEach(s => {
                delete s._prevW;
                delete s._prevH;
                delete s._prevX;
                delete s._prevY;
            });
            refreshCabinetsForSection(wall.id, sec.id, true);
        }

        function deleteWallSection(sectionId) {
            if (!selectedNewWallId) return;
            const wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) return;
            const sections = ensureWallSections(wall);
            if (sections.length <= 1) return;
            const idx = sections.findIndex(s => s.id === sectionId);
            if (idx === -1) return;
            const sec = sections[idx];
            if (sec.widthLocked || sec.heightLocked) return;
            const eps = 0.001;
            const overlap1D = (a1, a2, b1, b2) => Math.max(0, Math.min(a2, b2) - Math.max(a1, b1));

            let bestIndex = -1;
            let bestScore = -Infinity;
            let bestMergeType = null; // 'horizontal' (stack) немесе 'vertical' (side by side)

            sections.forEach((s, i) => {
                if (i === idx) return;
                const touchLeft  = Math.abs((sec.x + sec.w) - s.x) < eps;
                const touchRight = Math.abs((s.x + s.w) - sec.x) < eps;
                const touchBottom = Math.abs((sec.y + sec.h) - s.y) < eps;
                const touchTop    = Math.abs((s.y + s.h) - sec.y) < eps;

                // Бүйірден жанасу (x бойынша жанасады) => тік шекара, overlap Y қарастырамыз
                if (touchLeft || touchRight) {
                    const ov = overlap1D(sec.y, sec.y + sec.h, s.y, s.y + s.h);
                    if (ov > 0) {
                        const score = ov + (s.parentId === sec.parentId ? 10000 : 0);
                        if (score > bestScore) {
                            bestScore = score;
                            bestIndex = i;
                            bestMergeType = 'vertical';
                        }
                    }
                }

                // Жоғары/төмен жанасу (y бойынша жанасады) => overlap X қарастырамыз
                if (touchTop || touchBottom) {
                    const ov = overlap1D(sec.x, sec.x + sec.w, s.x, s.x + s.w);
                    if (ov > 0) {
                        const score = ov + (s.parentId === sec.parentId ? 10000 : 0);
                        if (score > bestScore) {
                            bestScore = score;
                            bestIndex = i;
                            bestMergeType = 'horizontal';
                        }
                    }
                }
            });

            if (bestIndex === -1) return;

            const neigh = sections[bestIndex];
            // Біріктіру: толық bounding-box
            const leftX = Math.min(sec.x, neigh.x);
            const rightX = Math.max(sec.x + sec.w, neigh.x + neigh.w);
            const bottomY = Math.min(sec.y, neigh.y);
            const topY = Math.max(sec.y + sec.h, neigh.y + neigh.h);

            neigh.x = leftX;
            neigh.y = bottomY;
            neigh.w = rightX - leftX;
            neigh.h = topY - bottomY;
            neigh.parentId = neigh.parentId != null ? neigh.parentId : sec.parentId;
            neigh.dir = neigh.dir || sec.dir || bestMergeType;
            neigh.widthLocked = neigh.widthLocked || sec.widthLocked;
            neigh.heightLocked = neigh.heightLocked || sec.heightLocked;

            sections.splice(idx, 1);
            wallSections[wall.id] = sections;
            clampSectionsToWall(wall, wallSections[wall.id], 50);
            // Осы секцияға байланған барлық шкафтарды жаңа секцияға көшіреміз
            cabinets.forEach(c => {
                if (c.wallId === wall.id && c.sectionId === sec.id) {
                    c.sectionId = neigh.id;
                    if (activeCabinetId === c.id) {
                        cabinetSectionId = neigh.id;
                    }
                }
            });
            if (selectedWallSectionId === sec.id) {
                selectedWallSectionId = neigh.id;
            }
            rebuildWallSectionList();
            rebuildNewWalls();
            if (cabinetWallId === wall.id) {
                refreshCabinetsForSection(wall.id, neigh.id, true);
            }
        }

        function computeCabinetPlacement(wall, sec, W, D) {
            const thicknessVal     = parseFloat(corpusThickness ? corpusThickness.value : '') || 16;
            const backMaterialVal  = backMaterial ? backMaterial.value : 'hdf';
            const backThickLocal   = (backMaterialVal === 'hdf') ? 4 : thicknessVal;
            const base = { x: 0, y: 0, z: 0 };
            let rotationYLocal = 0;
            base.y = (wall ? (wall.y || 0) : 0) + (sec ? (sec.y || 0) : 0);
            if (wall && wall.type === 'vertical') {
                rotationYLocal = Math.PI / 2;
                base.x = (wall.x || 0) + D / 2 + backThickLocal - W / 2 + wallGap;
                base.z = (wall.z || 0) + (sec ? (sec.x || 0) : 0) + W / 2 - (D / 2 + backThickLocal);
            } else {
                base.x = (wall ? (wall.x || 0) : 0) + (sec ? (sec.x || 0) : 0);
                base.z = (wall ? (wall.z || 0) : 0) + wallGap;
            }
            return { base, rotationY: rotationYLocal };
        }

	        function spawnCabinetForSection(wallId, sectionId) {
	            saveActiveCabinetState();
	            const prevActiveGroup = cabinetGroup; // keep previous cabinet visible
	            cabinetGroup = null;
	            const wall = newWalls.find(w => w.id === wallId);
	            if (!wall) return;
	            const sections = ensureWallSections(wall);
	            const sec = sections.find(s => s.id === sectionId) || sections[0];
	            if (!sec) return;
	            runUndoable(() => {
	                const W = sec.w || parseFloat(widthInput.value) || 1000;
	                const H = sec.h || parseFloat(heightInput.value) || 2200;
	                const D = parseFloat(depthInput.value) || 600;

	                readWallGap();
	                const placement = computeCabinetPlacement(wall, sec, W, D);
	                cabinetBaseOffset = placement.base;
	                cabinetRotationY = placement.rotationY;

	                widthInput.value = Math.round(W);
	                heightInput.value = Math.round(H);

	                cabinetWallId = wallId;
	                cabinetSectionId = sec.id;
	                cabinetSpawned = true;
	                shelfInserts = {};
	                selectedShelfSubId = null;
	                falshPanels = [];
	                nextFalshId = 1;
	                falshLeftSideEnabled = false;
	                falshRightSideEnabled = false;
	                falshLeftSideSize = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
	                falshRightSideSize = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
	                if (falshLeftSideCheckbox) falshLeftSideCheckbox.checked = false;
	                if (falshRightSideCheckbox) falshRightSideCheckbox.checked = false;
	                if (falshLeftSideSizeInput) falshLeftSideSizeInput.value = Math.round(falshLeftSideSize);
	                if (falshRightSideSizeInput) falshRightSideSizeInput.value = Math.round(falshRightSideSize);
	                rebuildFalshList();
	                const newCabinetId = Date.now();
	                activeCabinetId = newCabinetId;
	                cabinetGroup = null; // алдыңғы шкафты өшірмеу үшін null қоямыз
	                createCabinet(W, H, D, false);
	                applyActiveCabinetVisibility();
	                updateSelectedSectionHelper();
	                selectedNewWallId = wallId;
	                selectedWallSectionId = sec.id;
	                cabinets.push({
	                    id: newCabinetId,
	                    wallId: wallId,
	                    sectionId: sec.id,
	                    baseOffset: { ...cabinetBaseOffset },
	                    rotationY: cabinetRotationY,
	                    hidden: false,
	                    state: captureCabinetSnapshot(),
	                    group: cabinetGroup
	                });
	                structureVisible = false;
	                syncStructureVisibility();
	                rebuildWallSectionList();
	                rebuildNewWalls();
	                rebuildCabinetList();
	                rebuildCabinetIcons();
	            });
	        }

        // Өлшем көрсету элементтерімен синхрондау
        function syncDimensionsVisibility() {
            if (dimensionHelpersGroup) {
                dimensionHelpersGroup.visible = dimensionsVisible;
            }
            if (toggleDimsBtn) {
                toggleDimsBtn.classList.toggle('active', dimensionsVisible);
            }
        }

        function syncInfoVisibility() {
            if (dimensionBox) {
                dimensionBox.style.display = infoPanelVisible ? 'block' : 'none';
            }
            if (toggleInfoBtn) {
                toggleInfoBtn.classList.toggle('active', infoPanelVisible);
            }
        }

        function updateCabinetActionsVisibility() {
            const show = !!(structureVisible && cabinets.length && activeCabinetId);
            const display = show ? 'inline-flex' : 'none';
            if (cabinetHideBtn)  cabinetHideBtn.style.display  = display;
            if (cabinetDeleteBtn) cabinetDeleteBtn.style.display = display;
        }

        function syncStructureVisibility() {
            if (structureList) {
                structureList.style.display = structureVisible ? 'block' : 'none';
            }
            if (structureBtn) {
                structureBtn.classList.toggle('active', structureVisible);
            }
            updateCabinetActionsVisibility();
        }

        function syncCabinetVisibilityBtn() {
            if (!cabinetHideBtn) return;
            const hidden = isCabinetHidden(activeCabinetId);
            cabinetHideBtn.classList.toggle('active', hidden);
            cabinetHideBtn.title = hidden ? 'Шкафты көрсету' : 'Шкафты жасыру';
        }

        function setDoorsVisibilityOnGroup(group, visible) {
            if (!group) return;
            group.traverse(obj => {
                const ud = obj.userData || {};
                if (ud.isDoor || ud.isDoorHinge || ud.isDoorsGroup) {
                    obj.visible = visible;
                }
            });
        }

        function getAllDoorGroups() {
            const groups = [];
            if (doorsGroup) groups.push(doorsGroup);
            cabinets.forEach(c => {
                if (c.group && c.group.userData && c.group.userData.doorsGroup) {
                    const dg = c.group.userData.doorsGroup;
                    if (dg) groups.push(dg);
                }
            });
            return groups;
        }

        function readDoorStatesFromGroup(group) {
            const g = group || doorsGroup;
            if (!g || !g.children) return [];
            return g.children.map(h => !!(h.userData && h.userData.open));
        }

        function getFalshExtents() {
            const res = { left: 0, right: 0, top: 0 };
            falshPanels.forEach(fp => {
                const sz = Math.max(0, parseFloat(fp.size) || 0);
                if (fp.side === 'left') res.left = Math.max(res.left, sz);
                else if (fp.side === 'right') res.right = Math.max(res.right, sz);
                else if (fp.side === 'top') res.top = Math.max(res.top, sz);
            });
            const overlayThkL = falshLeftSideEnabled  ? readSideOverlaySize('left')  : 0;
            const overlayThkR = falshRightSideEnabled ? readSideOverlaySize('right') : 0;
            if (overlayThkL > 0) res.left  = Math.max(res.left, overlayThkL);
            if (overlayThkR > 0) res.right = Math.max(res.right, overlayThkR);
            return res;
        }

        function rebuildFalshGroup() {
            if (!cabinetGroup) return;
            if (falshGroup) {
                cabinetGroup.remove(falshGroup);
                falshGroup.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
                falshGroup = null;
            }
            const hasSideOverlay = falshLeftSideEnabled || falshRightSideEnabled;
            if (!falshPanels.length && !hasSideOverlay) {
                rebuildStructureList();
                return;
            }

            const { left: falshLeft, right: falshRight, top: falshTop } = getFalshExtents();
            const bodyW = Math.max(200, (currentW || 0) - falshLeft - falshRight);
            const bodyShiftX = (falshLeft - falshRight) / 2;

            const facadeThickVal = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
            const facadeMatVal   = facadeMaterial ? facadeMaterial.value : 'ldsp';
            const color          = getFacadeColor(facadeMatVal);
            const carcassHeight  = Math.max(50, (currentH || 0) - plinthHeight - falshTop);
            const frontZ         = (currentD || 0) / 2 - facadeThickVal / 2;
            const totalW         = Math.max(10, currentW || (bodyW + falshLeft + falshRight));

            falshGroup = new THREE.Group();
            falshGroup.userData.isFalshGroup = true;

            falshPanels.forEach(fp => {
                const side = fp.side || 'left';
                const size = Math.max(10, parseFloat(fp.size) || (side === 'top' ? 120 : 50));
                let baseW = 0;
                let baseH = 0;
                let pos   = new THREE.Vector3();
                const baseInfo = {
                    type: 'falsh',
                    name: 'Фальш ' + (side === 'left' ? 'сол' : side === 'right' ? 'оң' : 'төбе') + ' (негізгі)',
                    sectionId: cabinetSectionId || null,
                    width: 0,  height: 0,
                    depth: facadeThickVal
                };

                if (side === 'top') {
                    baseW = totalW;
                    baseH = size;
                    pos.set(0, plinthHeight + carcassHeight + size / 2, frontZ);
                    baseInfo.width  = baseW;
                    baseInfo.height = baseH;
                } else {
                    baseW = size;
                    baseH = carcassHeight;
                    const x = side === 'left'
                        ? (bodyShiftX - bodyW / 2 - size / 2)
                        : (bodyShiftX + bodyW / 2 + size / 2);
                    pos.set(x, plinthHeight + carcassHeight / 2, frontZ);
                    baseInfo.width  = baseW;
                    baseInfo.height = baseH;
                }

                const geomBase = new THREE.BoxGeometry(baseW, baseH, facadeThickVal);
                const base = solidWithEdges(geomBase, color, baseInfo);
                base.position.copy(pos);
                base.userData.isFalshPanel = true;
                falshGroup.add(base);

                // Алдыңғы қаптама – фасад қалыңдығымен
                const frontInfo = {
                    ...baseInfo,
                    name: baseInfo.name.replace('(негізгі)', '(алдыңғы)')
                };
                const geomFront = new THREE.BoxGeometry(baseW, baseH, facadeThickVal);
                const frontPos = pos.clone();
                frontPos.z += facadeThickVal;
                const front = solidWithEdges(geomFront, color, frontInfo);
                front.position.copy(frontPos);
                front.userData.isFalshPanel = true;
                falshGroup.add(front);
            });

            const overlayThkL  = falshLeftSideEnabled  ? readSideOverlaySize('left')  : 0;
            const overlayThkR  = falshRightSideEnabled ? readSideOverlaySize('right') : 0;
            const thickness    = globalThickness || 16;
            const depth        = currentD || 0;
            const facadeTypeEl  = document.getElementById('facadeType');
            const facadeTypeVal = facadeTypeEl ? facadeTypeEl.value : 'vkladnoy';
            const facadeFrontZ  = (facadeTypeVal === 'vkladnoy')
                ? (depth / 2 - 1)
                : (depth / 2 + (parseFloat(facadeThickness ? facadeThickness.value : '') || 18) + 1);
            const zMin          = -depth / 2;
            const overlayDepth  = Math.max(10, facadeFrontZ - zMin);
            const overlayCenterZ= (zMin + facadeFrontZ) / 2;
            const bottomMountSide = bottomMountInput ? (bottomMountInput.value || 'vkladnoy') : 'vkladnoy';
            const sideStartsOnBottom = (bottomMountSide === 'nakladnoy');
            const sideStartY    = sideStartsOnBottom ? (plinthHeight + thickness) : 0;
            const sideHeight    = sideStartsOnBottom ? (carcassHeight - thickness) : (carcassHeight + plinthHeight);
            const sideCenterY   = sideStartY + sideHeight / 2;

            function addSideOverlay(side, overlayThk) {
                if (!overlayThk) return;
                const geom = new THREE.BoxGeometry(overlayThk, sideHeight, overlayDepth);
                const info = {
                    type: 'falsh',
                    name: 'Фальш боковина ' + (side === 'left' ? 'сол' : 'оң'),
                    sectionId: cabinetSectionId || null,
                    width: overlayThk,
                    height: sideHeight,
                    depth: overlayDepth
                };
                const g = solidWithEdges(geom, color, info);
                const x = side === 'left'
                    ? (bodyShiftX - bodyW / 2 - overlayThk / 2)
                    : (bodyShiftX + bodyW / 2 + overlayThk / 2);
                g.position.set(x, sideCenterY, overlayCenterZ);
                g.userData.isFalshPanel = true;
                falshGroup.add(g);
            }
            if (falshLeftSideEnabled)  addSideOverlay('left', overlayThkL);
            if (falshRightSideEnabled) addSideOverlay('right', overlayThkR);

            falshGroup.visible = !facadesHidden;
            cabinetGroup.add(falshGroup);
            rebuildStructureList();
        }

        function rebuildFalshList() {
            if (!falshList) return;
            falshList.innerHTML = '';
            if (!falshPanels.length) {
                if (falshLeftSideEnabled || falshRightSideEnabled) {
                    const activeSides = [];
                    if (falshLeftSideEnabled) {
                        const s = Math.round(falshLeftSideSize || readSideOverlaySize('left') || 0);
                        activeSides.push(`Сол жақ фальш боковина · ${s} мм`);
                    }
                    if (falshRightSideEnabled) {
                        const s = Math.round(falshRightSideSize || readSideOverlaySize('right') || 0);
                        activeSides.push(`Оң жақ фальш боковина · ${s} мм`);
                    }
                    falshList.textContent = activeSides.join(' · ');
                } else {
                    falshList.textContent = 'Фальш панель жоқ';
                }
                return;
            }
            falshPanels.forEach(fp => {
                const row = document.createElement('div');
                row.className = 'simple-list-item';
                const label = document.createElement('div');
                label.className = 'meta';
                const sideLabel = fp.side === 'left' ? 'Сол'
                    : fp.side === 'right' ? 'Оң'
                    : 'Төбесі';
                const sizeTxt = Math.round(parseFloat(fp.size) || 0);
                label.textContent = `${sideLabel} · ${sizeTxt} мм`;
                const delBtn = document.createElement('button');
	                delBtn.type = 'button';
	                delBtn.className = 'danger-btn';
	                delBtn.textContent = '🗑';
	                delBtn.addEventListener('click', () => {
	                    runUndoable(() => {
	                        falshPanels = falshPanels.filter(x => x.id !== fp.id);
	                        rebuildFalshList();
	                        rebuildWithCurrentSize(true);
	                        syncActiveCabinetRecord();
	                    });
	                });
                row.appendChild(label);
                row.appendChild(delBtn);
                falshList.appendChild(row);
            });
            if (falshLeftSideEnabled || falshRightSideEnabled) {
                if (falshLeftSideEnabled) {
                    const row = document.createElement('div');
                    row.className = 'simple-list-item';
                    row.textContent = `Сол жақ фальш боковина · ${Math.round(falshLeftSideSize || readSideOverlaySize('left') || 0)} мм`;
                    falshList.appendChild(row);
                }
                if (falshRightSideEnabled) {
                    const row = document.createElement('div');
                    row.className = 'simple-list-item';
                    row.textContent = `Оң жақ фальш боковина · ${Math.round(falshRightSideSize || readSideOverlaySize('right') || 0)} мм`;
                    falshList.appendChild(row);
                }
            }
        }

        function syncFacadesVisibilityAll() {
            const visible = !facadesHidden;
            if (doorsGroup) doorsGroup.visible = visible;
            setDoorsVisibilityOnGroup(cabinetGroup, visible);
            cabinets.forEach(c => {
                if (c.group && c.group !== cabinetGroup) {
                    setDoorsVisibilityOnGroup(c.group, visible);
                }
            });
            const toggleFalsh = (group) => {
                if (!group) return;
                group.traverse(obj => {
                    if (obj.userData && obj.userData.isFalshPanel) {
                        obj.visible = visible;
                    }
                });
            };
            toggleFalsh(cabinetGroup);
            cabinets.forEach(c => toggleFalsh(c.group));
            if (toggleFacadeBtn) toggleFacadeBtn.classList.toggle('active', visible);
        }

        function rebuildCabinetIcons() {
            if (!cabinetIconList) return;
            cabinetIconList.innerHTML = '';
            if (!cabinets.length) {
                cabinetIconList.style.display = 'none';
                structureVisible = false;
                syncStructureVisibility();
                return;
            }

            cabinetIconList.style.display = 'flex';
            cabinets.forEach((c, idx) => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'cabinet-icon-btn';
                btn.textContent = String(idx + 1);
                btn.title = `Шкаф ${c.id}`;
                if (c.id === activeCabinetId) btn.classList.add('active');
                btn.addEventListener('click', () => {
                    if (activeCabinetId === c.id) {
                        structureVisible = !structureVisible;
                        syncStructureVisibility();
                        return;
                    }
                    setActiveCabinet(c.id);
                    structureVisible = true;
                    rebuildStructureList();
                    syncStructureVisibility();
                    rebuildCabinetIcons();
                });
                cabinetIconList.appendChild(btn);
            });
            syncStructureVisibility();
            updateCabinetActionsVisibility();
        }

        function rebuildStructureList() {
            if (!structureList) return;
            const allowedTypes = ['side','top','bottom','divider','shelf','back','plinth','door','drawer','drawer_facade','pipe','flange','runner','falsh'];
            function getDisplayDims(p) {
                const t = (p.type || '').toLowerCase();
                const w = p.width  || 0;
                const h = p.height || 0;
                const d = p.depth  || 0;
                if (t === 'side' || t === 'divider') {
                    return [h, d, w]; // биіктік × тереңдік × қалыңдық
                }
                if (t === 'plinth' || t === 'falsh') {
                    return [w, h, d]; // ұзындық × биіктік × қалыңдық (қалыңдық соңында)
                }
                if (t === 'bottom' || t === 'top' || t === 'shelf') {
                    return [w, d, h]; // ұзындық × тереңдік × қалыңдық
                }
                if (t === 'back' || t === 'door') {
                    return [w, h, d]; // ен × биіктік × қалыңдық
                }
                return [w, h, d];
            }
            const arr = Object.values(parts || {}).filter(p => {
                const mat = (p.extra && (p.extra.materialType || p.extra.material)) || '';
                if (mat === 'hdf' || mat === 'mdf' || mat === 'ldsp') return true;
                const t = (p.type || '').toLowerCase();
                return allowedTypes.includes(t);
            });
            arr.sort((a, b) => {
                const secA = a.sectionId || 0;
                const secB = b.sectionId || 0;
                if (secA !== secB) return secA - secB;
                const typeA = a.type || '';
                const typeB = b.type || '';
                if (typeA !== typeB) return typeA.localeCompare(typeB);
                return (a.id || 0) - (b.id || 0);
            });

            structureList.innerHTML = '';
            if (!arr.length) {
                const empty = document.createElement('div');
                empty.className = 'structure-empty';
                empty.textContent = 'Бөлшектер жоқ';
                structureList.appendChild(empty);
                return;
            }

            arr.forEach((p, idx) => {
                // Шкаф ID бойынша 2 таңбалы префикс, бөлшек нөмірі 2 таңбалы
                const cab = cabinets.find(c => c.id === p.cabinetId);
                const cabNum = cab ? cabinets.indexOf(cab) + 1 : 0;
                const prefix = String(cabNum).padStart(2, '0');
                const partNum = String(idx + 1).padStart(2, '0');
                const displayId = prefix + '.' + partNum;

                const row = document.createElement('div');
                row.className = 'structure-row';
                row.dataset.id = String(p.id);

                const name = document.createElement('div');
                name.className = 'structure-name';
                name.textContent = p.name || ('Бөлшек ' + displayId);

                const meta = document.createElement('div');
                meta.className = 'structure-meta';
                const dims = getDisplayDims(p).map(v => Math.round(v || 0));
                meta.textContent = '№ ' + displayId + ' · ' + dims.join(' × ') + ' мм';

                // Кромка квадрат-бейдж: 4 қыр (асты/үсті/сол/оң)
                const edgeFlags = getEdgeVisualFlags(p);
                const edgeSquare = document.createElement('span');
                edgeSquare.className = 'edge-square';
                [
                    { cls: 'edge-top', on: !!edgeFlags.top },
                    { cls: 'edge-bottom', on: !!edgeFlags.bottom },
                    { cls: 'edge-left', on: !!edgeFlags.left },
                    { cls: 'edge-right', on: !!edgeFlags.right },
                ].forEach(seg => {
                    const s = document.createElement('span');
                    s.className = 'edge-square-seg ' + seg.cls + (seg.on ? ' active' : '');
                    edgeSquare.appendChild(s);
                });
                meta.appendChild(edgeSquare);

                row.appendChild(name);
                row.appendChild(meta);

                row.addEventListener('click', () => {
                    selectPart(p.id);
                    structureVisible = true;
                    syncStructureSelection();
                    syncStructureVisibility();
                });

                structureList.appendChild(row);
            });

            syncStructureSelection();
        }

        function syncStructureSelection() {
            if (!structureList) return;
            const rows = structureList.querySelectorAll('.structure-row');
            rows.forEach(r => {
                r.classList.toggle('active', r.dataset.id === String(selectedPartId));
            });
        }

        function getBaseEdgeColor() {
            return (currentViewMode === 'shadow') ? 0x222222 : 0x000000;
        }

        function updateSectionEdgeHighlight() {
            const baseColor = getBaseEdgeColor();
            const activeId = activeCabinetId;
            allEdges.forEach(edge => {
                const pid = edge.__parentMesh && edge.__parentMesh.userData && edge.__parentMesh.userData.partId;
                const partCabinetId = pid && parts[pid] ? parts[pid].cabinetId : activeCabinetId;
                const isActiveCabinet = (partCabinetId === activeId);
                const color = isActiveCabinet ? baseColor : 0x999999;
                edge.material.color.set(color);
            });
        }

        function updateSectionFaceHighlight() {
            const activeId = activeCabinetId;
            const isSelectedPartMode = (selectionMode === 'part');
            const highlightColor = 0x6bb8ff;
            allMeshes.forEach(mesh => {
                const mat = mesh.material;
                if (!mat) return;
                const pid = mesh.userData && mesh.userData.partId;
                const partCabinetId = pid && parts[pid] ? parts[pid].cabinetId : activeCabinetId;
                const isActiveCabinet = (partCabinetId === activeId);
                const base = mesh.userData.baseColor || 0xffffff;
                const dimColor = 0xd0d0d0;
                const isSelectedPart = isSelectedPartMode && pid && pid === selectedPartId;
                const targetColor = isSelectedPart
                    ? highlightColor
                    : (isActiveCabinet ? base : dimColor);
                if (mat.color) {
                    mat.color.setHex(targetColor);
                }
                if (mat.emissive) {
                    const emissiveHex = isSelectedPart ? 0x4fa3ff : 0x000000;
                    mat.emissive.setHex(emissiveHex);
                    if ('emissiveIntensity' in mat) {
                        mat.emissiveIntensity = isSelectedPart ? 0.8 : 0;
                    }
                }
            });
        }

        function disposeMat(m) {
            if (!m) return;
            if (Array.isArray(m)) {
                m.forEach(x => disposeMat(x));
                return;
            }
            if (m.dispose) m.dispose();
        }

        function resetSectionHighlightBlink() {
            sectionHighlightStart = performance.now ? performance.now() : Date.now();
        }

        function resetWallSectionHighlightBlink() {
            wallSectionHighlightStart = performance.now ? performance.now() : Date.now();
        }

        function animateSectionHighlight(now) {
            if (!selectedSectionHelper) return;
            const mat = selectedSectionHelper.material;
            if (!mat || typeof mat.opacity !== 'number') return;

            // Жыпылықтауды алып тастадық: тұрақты мөлдірлік пен түс
            const opacity = 0.35;
            mat.opacity = opacity;
            if (mat.color) {
                mat.color.copy(sectionHighlightBaseColor);
            }
            mat.needsUpdate = true;
        }

        // Секция визуалды подсветка
        function updateSelectedSectionHelper() {
            if (!cabinetGroup) return;
            if (selectedSectionHelper) {
                if (bodyCore) bodyCore.remove(selectedSectionHelper);
                else cabinetGroup.remove(selectedSectionHelper);
                selectedSectionHelper.geometry.dispose();
                disposeMat(selectedSectionHelper.material);
                selectedSectionHelper = null;
            }
            if (selectedShelfSubHelper) {
                if (bodyCore) bodyCore.remove(selectedShelfSubHelper);
                else cabinetGroup.remove(selectedShelfSubHelper);
                selectedShelfSubHelper.geometry.dispose();
                disposeMat(selectedShelfSubHelper.material);
                selectedShelfSubHelper = null;
            }
            const sec = sections.find(s => s.id === selectedSectionId);
            if (!sec) {
                selectedShelfSubId = null;
                updateDimensionsBox();
                if (sectionWidthInput) sectionWidthInput.value = '';
                updateSectionEdgeHighlight();
                updateSectionFaceHighlight();
                return;
            }
            const hideHelpers = !!doorAnimEnabled || selectionMode === 'part';
            if (selectedShelfSubId) {
                const [secIdStr] = String(selectedShelfSubId).split(':');
                if (parseFloat(secIdStr) !== sec.id) {
                    selectedShelfSubId = null;
                }
            }

            const innerParams = computeInnerParams();
            const depthInside = innerParams.depthInside;

            const geo = new THREE.BoxGeometry(sec.w, sec.h, depthInside);
            const mat = new THREE.MeshBasicMaterial({
                color: sectionHighlightBaseColor.getHex(),
                opacity: 0.25,
                transparent: true,
                depthWrite: false,
                depthTest: true
            });
            if (!hideHelpers) {
                selectedSectionHelper = new THREE.Mesh(geo, mat);
                resetSectionHighlightBlink();

                const xWorld = sec.x + sec.w/2 - innerW/2;
                const yWorld = plinthHeight + globalThickness + sec.y + sec.h/2;
                selectedSectionHelper.position.set(xWorld, yWorld, innerParams.centerZ);

                (bodyCore || cabinetGroup).add(selectedSectionHelper);
            }
            if (sectionWidthInput) {
                sectionWidthInput.value = Math.round(sec.w);
            }
            updateDimensionsBox();
            updateSectionEdgeHighlight();
            updateSectionFaceHighlight();
            updateSelectedShelfSubHelper();
            rebuildInsertsUI();
            rebuildDrawerSubList();
        }

        function updateSelectedShelfSubHelper() {
            if (selectedShelfSubHelper && cabinetGroup) {
                if (bodyCore) bodyCore.remove(selectedShelfSubHelper);
                else cabinetGroup.remove(selectedShelfSubHelper);
                selectedShelfSubHelper.geometry.dispose();
                disposeMat(selectedShelfSubHelper.material);
                selectedShelfSubHelper = null;
            }
            if (!cabinetGroup) return;
            if (!selectedShelfSubId) return;

            const parts = String(selectedShelfSubId).split(':');
            const secId = parseFloat(parts[0]);
            const subIdx = parseInt(parts[1], 10);
            if (!isFinite(secId) || !isFinite(subIdx)) {
                selectedShelfSubId = null;
                return;
            }
            const sec = sections.find(s => s.id === secId);
            if (!sec) {
                selectedShelfSubId = null;
                return;
            }
            const sub = getShelfSubSections().find(s => s.sectionId === secId && s.idx === subIdx);
            if (!sub) {
                selectedShelfSubId = null;
                rebuildInsertsUI();
                return;
            }
            syncDrawerDepthSelect(sub);
            syncDrawerDepthSelect(sub);

            const innerParams = computeInnerParams();
            const depthInside = innerParams.depthInside;
            const frontOffset = sectionShelfOffsets[sec.id] || 0;
            const depth = Math.max(10, depthInside - frontOffset);
            const backInsideZ = innerParams.centerZ - depthInside / 2;
            const zWorld = backInsideZ + depth / 2;

            const region = getSectionShelfRegion(sec.id);
            const effectiveWidth = region ? region.width : sub.width;
            const xCenter = region ? region.center : (sec.x + sub.width / 2 - innerW / 2);

            const geo = new THREE.BoxGeometry(effectiveWidth, sub.height, depth);
            const mat = new THREE.MeshBasicMaterial({
                color: subHighlightBaseColor.getHex(),
                opacity: 0.32,
                transparent: true,
                depthWrite: false,
                depthTest: false
            });
            if (!doorAnimEnabled) {
                selectedShelfSubHelper = new THREE.Mesh(geo, mat);

                const xWorld = xCenter;
                const yWorld = plinthHeight + globalThickness + sec.y + sub.start + sub.height / 2;
                selectedShelfSubHelper.position.set(xWorld, yWorld, zWorld);

                (bodyCore || cabinetGroup).add(selectedShelfSubHelper);
            }
            rebuildInsertsUI();
            rebuildDrawerSubList();
            syncShelfSubHelperVisibility();
        }

        function syncShelfSubHelperVisibility() {
            if (selectedShelfSubHelper) {
                const allowByMode = (currentViewMode === 'xray' || currentViewMode === 'sketch');
                const allowBySelection = selectionMode !== 'part';
                selectedShelfSubHelper.visible = allowByMode && allowBySelection;
            }
        }

        // Секциялар тізімі (ID + ені + корзина)
        function rebuildSectionSelect() {
            if (!sectionSelect) return;

            const sorted = sections.slice().sort((a, b) => a.x - b.x);

            // Таңдалған секция коррект болсын
            if (sorted.length) {
                if (!selectedSectionId || !sorted.some(s => s.id === selectedSectionId)) {
                    selectedSectionId = sorted[0].id;
                }
            } else {
                selectedSectionId = null;
            }

            // Контейнерді тазалау
            sectionSelect.innerHTML = '';

            sorted.forEach(sec => {
                const row = document.createElement('div');
                row.className = 'section-row';
                row.dataset.id = String(sec.id);
                if (sec.id === selectedSectionId) {
                    row.classList.add('active');
                }

                const main = document.createElement('div');
                main.className = 'section-row-main';

                const idSpan = document.createElement('span');
                idSpan.className = 'section-row-id';
                idSpan.textContent = 'Секция ' + sec.id;

                const wSpan = document.createElement('span');
                wSpan.className = 'section-row-width';
                wSpan.textContent = Math.round(sec.w) + ' мм';

                main.appendChild(idSpan);
                main.appendChild(wSpan);

                const delBtn = document.createElement('button');
                delBtn.type = 'button';
                delBtn.className = 'section-row-delete';
                delBtn.title = 'Секцияны өшіру';
                delBtn.textContent = '🗑';

                // Корзина – секцияны өшіру
                const canDelete = (sorted.length > 1);
                if (!canDelete) {
                    delBtn.disabled = true;
                    delBtn.classList.add('disabled');
                }
                delBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    if (!canDelete) return;
                    deleteSection(sec.id);
                });

                // Қатарды басқанда – секцияны таңдау
                row.addEventListener('click', function () {
                    selectedSectionId = sec.id;
                    updateSelectedSectionHelper();
                    rebuildSectionSelect();
                    rebuildShelvesUI();
                });

                row.appendChild(main);
                row.appendChild(delBtn);
                sectionSelect.appendChild(row);
            });

            // Қосымша инфо үшін (бар болса)
            const currentSectionInfo = document.getElementById('currentSectionInfo');
            const widthInputEl = document.getElementById('sectionWidthInput');

            let sel = null;
            if (sorted.length) {
                sel = sorted.find(s => s.id === selectedSectionId) || sorted[0];
            }

            if (currentSectionInfo) {
                if (sel) {
                    currentSectionInfo.value =
                        'ID ' + sel.id + ' · ' + Math.round(sel.w) + ' мм';
                } else {
                    currentSectionInfo.value = '';
                }
            }

            if (shelfOffsetInput) {
                if (sel && sectionShelfOffsets[sel.id] !== undefined) {
                    shelfOffsetInput.value = sectionShelfOffsets[sel.id];
                } else if (sel) {
                    shelfOffsetInput.value = 0;
                }
            }

            if (widthInputEl) {
                widthInputEl.value = sel ? Math.round(sel.w) : '';
            }

            updateDimensionsBox();
        }

        function updateDimensionsBox() {
            if (!dimensionBox) return;
            let html = '';

            function getTotalDepth() {
                const corpusThickVal  = parseFloat(corpusThickness.value) || globalThickness || 16;
                const backMatVal      = backMaterial.value;
                const backThick       = (backMatVal === 'hdf') ? 4 : corpusThickVal;
                const facadeTypeVal   = facadeType.value;
                const facadeThickVal  = parseFloat(facadeThickness.value) || 18;
                let totalDepth = currentD || 0;
                totalDepth += backThick;
                if (facadeTypeVal === 'nakladnoy') {
                    totalDepth += facadeThickVal;
                }
                return totalDepth;
            }

            if (currentW && currentH && currentD) {
                const totalDepth = getTotalDepth();
                html += '<b>Корпус өлшемі:</b> ' +
                    Math.round(currentW) + ' × ' +
                    Math.round(currentH) + ' × ' +
                    Math.round(currentD) + ' мм<br>';
                html += '<b>Цоколь:</b> ' + Math.round(plinthHeight) + ' мм<br>';
                html += '<b>Жалпы биіктік:</b> ' +
                    Math.round(currentH + plinthHeight) + ' мм<br>';
                html += '<b>Сыртқы тереңдік (фасад + артқы қабырғамен):</b> ' +
                    Math.round(totalDepth) + ' мм<br>';

                html += '<b>Сыртқы өлшемдер (Ш × Б × Т):</b> ' +
                    Math.round(currentW) + ' × ' +
                    Math.round(currentH + plinthHeight) + ' × ' +
                    Math.round(totalDepth) + ' мм<br>';
            }

            if (sections && sections.length) {
                html += '<b>Секциялар:</b><br>';
                const sorted = sections.slice().sort((a,b)=>a.x - b.x);
                sorted.forEach(sec => {
                    const mark = (sec.id === selectedSectionId) ? '★ ' : '';
                    html += mark + 'ID ' + sec.id + ': ' +
                        Math.round(sec.w) + ' × ' +
                        Math.round(sec.h) + ' мм<br>';
                });
            }

            const subSections = getShelfSubSections();
            if (subSections.length) {
                html += '<b>Ішкі секциялар (полка арасы):</b><br>';
                subSections.forEach(cell => {
                    const mark = (cell.sectionId === selectedSectionId) ? '★ ' : '';
                    html += mark + cell.name + ': ' +
                        Math.round(cell.width) + ' × ' +
                        Math.round(cell.height) + ' мм<br>';
                });
            }

            dimensionBox.innerHTML = html;
            syncInfoVisibility();
        }

        // Полка тізімін тазалау (валид диапазон, дубльсіз)
        function sanitizeSectionShelves() {
            const tol = 0.001;
            const secMap = new Set(sections.map(s => s.id));
            Object.keys(sectionShelves).forEach(k => {
                if (!secMap.has(parseFloat(k))) delete sectionShelves[k];
            });
            sections.forEach(sec => {
                let arr = (sectionShelves[sec.id] || []).filter(h => isFinite(h));
                const filtered = [];
                arr.forEach(h => {
                    if (h <= 0 || h >= sec.h - 20) return;
                    if (filtered.some(v => Math.abs(v - h) < tol)) return;
                    filtered.push(h);
                });
                filtered.sort((a, b) => a - b);
                sectionShelves[sec.id] = filtered;
            });
        }

        // Полка аралық ішкі секциялар (виртуалды) – Секция 1.1, 1.2 ...
        function getShelfSubSections() {
            const res = [];
            const shelfThickLocal = globalThickness;
            const secSorted = sections.slice().sort((a, b) => a.x - b.x);

            secSorted.forEach(sec => {
                const list = (sectionShelves[sec.id] || []).slice().sort((a, b) => a - b);
                const hasShelves = list.length > 0;
                const augmented = hasShelves ? [0, ...list, sec.h] : [0, sec.h];

                let idx = 1;
                for (let i = 0; i < augmented.length - 1; i++) {
                    const isBottom = (i === 0);
                    const h1 = augmented[i];
                    const h2 = augmented[i + 1];

                    const start = isBottom ? h1 : h1 + shelfThickLocal;
                    const gap = h2 - start;
                    if (gap <= 0) continue;
                    const end = start + gap;

                    res.push({
                        sectionId: sec.id,
                        name: 'Секция ' + sec.id + '.' + idx,
                        idx,
                        start,
                        end,
                        height: gap,
                        width: sec.w
                    });
                    idx++;
                }
            });
            return res;
        }

        // Секциядағы полка нақты ені (сол/оң маржаларымен) және центрі
        function getSectionShelfRegion(sectionId) {
            const secSorted = sections.slice().sort((a, b) => a.x - b.x);
            const idx = secSorted.findIndex(s => s.id === sectionId);
            if (idx === -1) return null;

            const facadeTypeEl  = document.getElementById('facadeType');
            const facadeTypeVal = facadeTypeEl ? facadeTypeEl.value : 'vkladnoy';
            const useFacadeCenters =
                facadeTypeVal === 'nakladnoy' &&
                Array.isArray(facadeDividerCenters) &&
                facadeDividerCenters.length >= Math.max(0, secSorted.length - 1);

            const dividerWorld = [];
            for (let i = 1; i < secSorted.length; i++) {
                const boundaryX = secSorted[i].x;
                const xWorld = useFacadeCenters
                    ? facadeDividerCenters[i - 1]
                    : boundaryX - innerW / 2;
                dividerWorld.push(xWorld);
            }

            const tol = 0.0001;
            const clearance = 0.2;

            const sec = secSorted[idx];
            const leftBoundWorld  = (idx === 0) ? (-innerW / 2) : dividerWorld[idx - 1];
            const rightBoundWorld = (idx === secSorted.length - 1) ? (innerW / 2) : dividerWorld[idx];
            const atLeftWall  = Math.abs(leftBoundWorld + innerW / 2) < tol;
            const atRightWall = Math.abs(rightBoundWorld - innerW / 2) < tol;
            const leftMargin  = atLeftWall  ? 0 : (globalThickness / 2 + clearance);
            const rightMargin = atRightWall ? 0 : (globalThickness / 2 + clearance);
            const width = Math.max(10, (rightBoundWorld - rightMargin) - (leftBoundWorld + leftMargin));
            const center = leftBoundWorld + leftMargin + width / 2;
            return { width, center, left: leftBoundWorld + leftMargin, right: rightBoundWorld - rightMargin };
        }

        function sanitizeShelfInserts(subs) {
            const valid = new Set(subs.map(s => `${s.sectionId}:${s.idx}`));
            Object.keys(shelfInserts).forEach(k => {
                if (!valid.has(k)) delete shelfInserts[k];
            });
            Object.keys(shelfInserts).forEach(k => {
                let arr = shelfInserts[k];
                if (!Array.isArray(arr)) arr = arr ? [arr] : [];
                arr = arr
                    .filter(it => it && it.type)
                    .map(it => {
                        if (it.type === 'drawer' && !it.variant) return { ...it, variant: 'telescope' };
                        return it;
                    });
                shelfInserts[k] = arr;
            });
        }

        function cloneShelfInserts(src) {
            const out = {};
            if (!src) return out;
            Object.keys(src).forEach(key => {
                const arr = Array.isArray(src[key]) ? src[key] : (src[key] ? [src[key]] : []);
                out[key] = arr.map(item => item ? { ...item } : item);
            });
            return out;
        }

        function rebuildDrawerSubList() {
            if (!drawerSubList) return;
            drawerSubList.innerHTML = '';

            const subsAll = getShelfSubSections();
            sanitizeShelfInserts(subsAll);
            const filtered = selectedSectionId
                ? subsAll.filter(s => s.sectionId === selectedSectionId)
                : subsAll;

            if (!filtered.length) {
                drawerSubList.textContent = 'Полка аралығы жоқ';
                return;
            }

            if (!selectedShelfSubId || !filtered.some(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId)) {
                selectedShelfSubId = `${filtered[0].sectionId}:${filtered[0].idx}`;
            }

            filtered.forEach(sub => {
                const key = `${sub.sectionId}:${sub.idx}`;
                const row = document.createElement('div');
                row.className = 'simple-list-item shelf-sub-row';
                row.dataset.subId = key;
                if (selectedShelfSubId === key) {
                    row.classList.add('active');
                }

                const name = document.createElement('div');
                name.className = 'meta';
                const labelShort = sub.sectionId + '.' + sub.idx;
                name.textContent = labelShort;
                name.style.display = 'inline-flex';
                name.style.gap = '8px';
                name.style.alignItems = 'center';
                name.style.flex = '1';

                row.appendChild(name);

                row.addEventListener('click', () => {
                    selectedShelfSubId = key;
                    const active = drawerSubList.querySelectorAll('.shelf-sub-row.active');
                    active.forEach(r => r.classList.remove('active'));
                    row.classList.add('active');
                    rebuildShelvesUI();
                    updateSelectedShelfSubHelper();
                });

                drawerSubList.appendChild(row);
            });
            if (selectedShelfSubId) {
                const sub = filtered.find(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId);
                syncDrawerDepthSelect(sub || filtered[0]);
            }
            syncDrawerActiveRow();
        }

        // Полкалар UI
        function rebuildShelvesUI() {
            const listEl = shelfList;
            if (!listEl) return;

            listEl.innerHTML = '';
            if (!selectedSectionId) return;

            const sec = sections.find(s => s.id === selectedSectionId);
            if (!sec) return;

            sanitizeSectionShelves();
            const subsAll = getShelfSubSections();
            sanitizeShelfInserts(subsAll);
            const subsForSelected = subsAll.filter(s => s.sectionId === selectedSectionId);
            if (subsForSelected.length) {
                const firstKey = `${subsForSelected[0].sectionId}:${subsForSelected[0].idx}`;
                if (!selectedShelfSubId || !subsForSelected.some(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId)) {
                    selectedShelfSubId = firstKey;
                }
            } else {
                selectedShelfSubId = null;
            }

            const shelfThickLocal = globalThickness;

            const list = sectionShelves[selectedSectionId] || [];
            const sorted = list.slice().sort((a, b) => a - b);

            sorted.forEach((h, index) => {
                const row   = document.createElement('div');
                row.className = 'shelf-row';

                const label = document.createElement('span');
                label.className = 'shelf-label';
                label.textContent = 'Полка' + (index + 1);

                const input = document.createElement('input');
                input.type  = 'number';
                input.min   = '0';
                input.step  = '1';

                // Көрсетілетін мән – төмендегі полкадан (немесе еденнен) ара қашықтық
                let gapValue;
                if (index === 0) {
                    gapValue = h;
                } else {
                    gapValue = h - sorted[index - 1] - shelfThickLocal; // полка қалыңдығын шегереміз
                }
                if (!isFinite(gapValue) || gapValue < 0) gapValue = 0;
                input.value = Math.round(gapValue);

                input.className = 'shelf-height-input';

                const btnUpdate = document.createElement('button');
                btnUpdate.type = 'button';
                btnUpdate.textContent = 'өзгерту';

                const btnDelete = document.createElement('button');
                btnDelete.type = 'button';
                btnDelete.textContent = '🗑';
                btnDelete.className = 'danger-btn';

                row.appendChild(label);
                row.appendChild(input);
                row.appendChild(btnUpdate);
                row.appendChild(btnDelete);

                listEl.appendChild(row);

                const oldH = h;
                const shelfIndex = index;

                btnUpdate.addEventListener('click', function () {
                    const gap = parseFloat(input.value);
                    if (!isFinite(gap)) return;

                    if (gap <= 0) {
                        showError('Полка ара қашықтығы 0-ден үлкен болуы керек');
                        return;
                    }

                    let newAbs;
                    if (shelfIndex === 0) {
                        newAbs = gap;
                    } else {
                        newAbs = sorted[shelfIndex - 1] + shelfThickLocal + gap; // төменгі полка қалыңдығын қосамыз
                    }

                    if (newAbs <= 0 || newAbs >= sec.h - 20) {
                        showError('Полка биіктігі секция биіктігіне сай емес');
                        return;
                    }

                    const arr = sectionShelves[sec.id] || [];
                    const idx = arr.findIndex(v => Math.abs(v - oldH) < 0.0001);
                    if (idx === -1) return;

                    arr[idx] = newAbs;
                    arr.sort((a, b) => a - b);
                    sectionShelves[sec.id] = arr;
                    syncShelves();
                });

                btnDelete.addEventListener('click', function () {
                    const arr = sectionShelves[sec.id] || [];
                    const idx = arr.findIndex(v => Math.abs(v - oldH) < 0.0001);
                    if (idx === -1) return;

                    arr.splice(idx, 1);
                    sectionShelves[sec.id] = arr;
                    syncShelves();
                });
            });

            rebuildDrawerSubList();
        }

        // Полкаларды қайта салу
        function rebuildShelvesGroup() {
            if (!cabinetGroup) return;

            // Remove previous shelf parts references
            purgePartsByType(transientPartTypes);

            if (shelvesGroup) {
                if (bodyCore) bodyCore.remove(shelvesGroup);
                else cabinetGroup.remove(shelvesGroup);
                shelvesGroup.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
            }
            if (insertsGroup) {
                if (bodyCore) bodyCore.remove(insertsGroup);
                else cabinetGroup.remove(insertsGroup);
                insertsGroup.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
            }
            shelvesGroup = new THREE.Group();
            insertsGroup = new THREE.Group();

            sanitizeSectionShelves();
            shelfNameCounter = 1;

            const innerParams = computeInnerParams();
            const depthInside = innerParams.depthInside;
            const shelfThick  = globalThickness;
            const corpusMatVal  = corpusMaterial.value;
            const shelfColor    = getCorpusColor(corpusMatVal);

            const secSorted = sections.slice().sort((a,b)=>a.x - b.x);

            // Divider позициясы (шын мәнінде), фасад накладной болса facadeDividerCenters қолданамыз
            const facadeTypeEl  = document.getElementById('facadeType');
            const facadeTypeVal = facadeTypeEl ? facadeTypeEl.value : 'vkladnoy';
            const useFacadeCenters =
                facadeTypeVal === 'nakladnoy' &&
                Array.isArray(facadeDividerCenters) &&
                facadeDividerCenters.length >= Math.max(0, secSorted.length - 1);

            const dividerWorld = [];
            for (let i = 1; i < secSorted.length; i++) {
                const boundaryX = secSorted[i].x;
                const xWorld = useFacadeCenters
                    ? facadeDividerCenters[i - 1]
                    : boundaryX - innerW / 2;
                dividerWorld.push(xWorld);
            }

            secSorted.forEach((sec, idx) => {
                const list = sectionShelves[sec.id];
                if (!list || !list.length) return;

                const sorted = list.slice().sort((a,b) => a - b);
                sorted.forEach(h => {
                    if (h <= 0 || h >= sec.h - 20) return;

                    // dividerWorld координаттары cabinetGroup ішінде жергілікті жүйеде,
                    // сондықтан қабырғаларға қатысты -innerW/2 .. +innerW/2 диапазонын қолданамыз.
                    const leftBoundWorld  = (idx === 0) ? (-innerW / 2) : dividerWorld[idx - 1];
                    const rightBoundWorld = (idx === secSorted.length - 1) ? (innerW / 2) : dividerWorld[idx];
                    const tol = 0.0001;
                    const atLeftWall  = Math.abs(leftBoundWorld + innerW / 2) < tol;
                    const atRightWall = Math.abs(rightBoundWorld - innerW / 2) < tol;
                    const clearance = 0.2;
                    const leftMargin  = atLeftWall  ? 0 : (globalThickness / 2 + clearance);
                    const rightMargin = atRightWall ? 0 : (globalThickness / 2 + clearance);
                    const shelfW = Math.max(10, (rightBoundWorld - rightMargin) - (leftBoundWorld + leftMargin));

                    // Алдынан отступты ескеріп, полка тереңдігін қысқартамыз
                    let frontOffset = sectionShelfOffsets[sec.id] || 0;
                    if (frontOffset < 0) frontOffset = 0;
                    let shelfDepth = Math.max(10, depthInside - frontOffset);

                    const geo   = new THREE.BoxGeometry(shelfW, shelfThick, shelfDepth);
                    const shelf = solidWithEdges(geo, shelfColor, {
                        type: 'shelf',
                        name: 'Полка ' + (shelfNameCounter++),
                        sectionId: sec.id,
                        width: shelfW,
                        height: shelfThick,
                        depth: depthInside,
                        shelfHeight: h,
                        edge: { front: true, back: false, left: false, right: false }
                    });

                    const xWorld = leftBoundWorld + leftMargin + shelfW / 2;
                    const yWorld = plinthHeight + globalThickness + h + shelfThick/2;

                    // Тек алдынан ғана кішірейту: артқы жағы бір орында қалады
                    const backInsideZ = innerParams.centerZ - depthInside / 2;
                    const zWorld      = backInsideZ + shelfDepth / 2;

                    shelf.position.set(xWorld, yWorld, zWorld);
                    shelvesGroup.add(shelf);
                });
            });

            (bodyCore || cabinetGroup).add(shelvesGroup);
            rebuildInsertsGroup();
        }

        function rebuildInsertsGroup() {
            if (!cabinetGroup) return;
            // Барлық наполнение бөлшектерін тазартып, қайта құрамыз
            purgePartsByType(['pipe','flange','drawer','drawer_facade','runner']);
        if (insertsGroup) {
            if (bodyCore) bodyCore.remove(insertsGroup);
            else cabinetGroup.remove(insertsGroup);
            insertsGroup.traverse(obj => {
                if (obj.geometry) obj.geometry.dispose();
                if (obj.material) obj.material.dispose();
            });
        }
            insertsGroup = new THREE.Group();

            const subs = getShelfSubSections();
            sanitizeShelfInserts(subs);
            const innerParams = computeInnerParams();
            const depthInside = innerParams.depthInside;
            const frontOffsetGlobal = sectionShelfOffsets;
            const drawerDepthBrandOffset = getDrawerDepthBrandOffset();
            if (subs.length && (!selectedShelfSubId || !subs.some(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId))) {
                selectedShelfSubId = `${subs[0].sectionId}:${subs[0].idx}`;
            }

            subs.forEach(sub => {
                const key = `${sub.sectionId}:${sub.idx}`;
                const list = Array.isArray(shelfInserts[key]) ? shelfInserts[key] : [];
                if (!list.length) return;

                const sec = sections.find(s => s.id === sub.sectionId);
                if (!sec) return;
                syncDrawerDepthSelect(sub);
                let pipeCounter = 0;
                let drawerCounter = 0;
                const region = getSectionShelfRegion(sub.sectionId);
                const runnerType = drawerRunnerTypeSelect ? drawerRunnerTypeSelect.value : 'softclose';

                const frontOffset = frontOffsetGlobal[sec.id] || 0;
                const depth = Math.max(10, depthInside - frontOffset);
                const backInsideZ = innerParams.centerZ - depthInside / 2;
                const zWorld = backInsideZ + depth / 2;
                const baseWidth = region ? region.width : sub.width;
                const baseCenter = region ? region.center : (sec.x + sub.width / 2 - innerW / 2);
                const sideGaps = readInsertSideGaps();
                let leftGap = Math.max(0, sideGaps.left);
                let rightGap = Math.max(0, sideGaps.right);
                const maxTotalGap = Math.max(0, baseWidth - 10);
                const totalGap = leftGap + rightGap;
                if (totalGap > maxTotalGap) {
                    let overflow = totalGap - maxTotalGap;
                    if (rightGap >= overflow) {
                        rightGap -= overflow;
                    } else {
                        overflow -= rightGap;
                        rightGap = 0;
                        leftGap = Math.max(0, leftGap - overflow);
                    }
                }
                const usableWidth = Math.max(10, baseWidth - leftGap - rightGap);
                const xWorld = baseCenter + (leftGap - rightGap) / 2;
                const gapTopWorld = plinthHeight + globalThickness + sec.y + sub.start + sub.height;
                const gapCenterY  = plinthHeight + globalThickness + sec.y + sub.start + sub.height / 2;
                const gapBottomWorld = plinthHeight + globalThickness + sec.y + sub.start;
                const drawersInSub = list.filter(it => it.type === 'drawer').length;
                const drawerSpacing = readDrawerStackGap();
                const padBody = Math.max(0, readDrawerRunnerThk()); // корпусқа арналған маржа (направляющий қалыңдығы)
                const desiredDrawerH = readDrawerBodyHeight();
                const targetGap = readDrawerFacadeGap(); // фасадтар және үсті/асты саңылау
                const gapTarget = Math.max(targetGap, drawerSpacing);
                const minFacH = 20;
                const panelColor = getCorpusColor(corpusMaterial.value);
                // Вертикаль слот параметрлері: gapY (жоғары/төмен және аралық), facSlotH (фасад биіктігі)
                let gapY = gapTarget;
                let facSlotH;
                if (drawersInSub > 0) {
                    const maxGapAllowed = Math.max(0, (sub.height - minFacH * drawersInSub) / (drawersInSub + 1));
                    gapY = Math.min(gapY, maxGapAllowed);
                    facSlotH = (sub.height - gapY * (drawersInSub + 1)) / drawersInSub;
                    if (facSlotH < minFacH) {
                        gapY = Math.max(gapTarget, Math.max(0, (sub.height - minFacH * drawersInSub) / (drawersInSub + 1)));
                        facSlotH = (sub.height - gapY * (drawersInSub + 1)) / drawersInSub;
                    }
                    facSlotH = Math.max(minFacH, facSlotH);
                } else {
                    gapY = Math.min(gapY, Math.max(0, (sub.height - minFacH) / 2));
                    facSlotH = Math.max(minFacH, sub.height - 2 * gapY);
                }
                const stepY = facSlotH + gapY;
                // Үсті/асты қосымша маржа жоқ, gapY-ды тікелей қолданамыз
                const topMargin = 0;

                const bodyHeight = Math.max(30, Math.min(desiredDrawerH, facSlotH - 2 * padBody));
                if (drawersInSub > 0) {
                    const panelCenterY = gapBottomWorld + sub.height / 2;
                    const baseLeft = baseCenter - baseWidth / 2;
                    const baseRight = baseCenter + baseWidth / 2;
                    const ldspThickness = 16;
                    const gapDepth = depth;
                    const frontLenLeft = Math.max(1, leftGap);
                    const frontLenRight = Math.max(1, rightGap);
                    const frontPanelDepth = 16;
                    const leftSidePanelEnabled = leftGap >= 16;
                    const leftFrontPanelEnabled = leftGap > 16;
                    const frontPlaneZ = innerParams.centerZ + depthInside / 2;
                    const frontSurfaceZ = zWorld + depth / 2 - frontOffset;
                    if (leftSidePanelEnabled) {
                        const leftPanelDepth = Math.max(1, gapDepth - frontPanelDepth);
                        const leftPanelGeo = new THREE.BoxGeometry(ldspThickness, sub.height, leftPanelDepth);
                        const leftPanel = solidWithEdges(leftPanelGeo, panelColor, {
                            type: 'drawer_panel',
                            name: 'Панель сол жақ',
                            sectionId: sub.sectionId,
                            width: ldspThickness,
                            height: sub.height,
                            depth: leftPanelDepth,
                            extra: { side: 'left', subId: key }
                        });
                        const leftPanelX = baseLeft + Math.max(ldspThickness / 2, leftGap - ldspThickness / 2);
                        leftPanel.position.set(leftPanelX, panelCenterY, innerParams.centerZ - frontPanelDepth / 2);
                        insertsGroup.add(leftPanel);
                    }
                    if (rightGap > 0) {
                        const rightPanelDepth = Math.max(1, gapDepth - frontPanelDepth);
                        const rightPanelGeo = new THREE.BoxGeometry(ldspThickness, sub.height, rightPanelDepth);
                        const rightPanel = solidWithEdges(rightPanelGeo, panelColor, {
                            type: 'drawer_panel',
                            name: 'Панель оң жақ',
                            sectionId: sub.sectionId,
                            width: ldspThickness,
                            height: sub.height,
                            depth: rightPanelDepth,
                            extra: { side: 'right', subId: key }
                        });
                        const rightPanelX = baseRight - Math.max(ldspThickness / 2, rightGap - ldspThickness / 2);
                        rightPanel.position.set(rightPanelX, panelCenterY, innerParams.centerZ - frontPanelDepth / 2);
                        insertsGroup.add(rightPanel);
                    }
                    if (leftFrontPanelEnabled) {
                        const leftFrontGeo = new THREE.BoxGeometry(frontLenLeft, sub.height, frontPanelDepth);
                        const leftFrontPanel = solidWithEdges(leftFrontGeo, panelColor, {
                            type: 'drawer_panel',
                            name: 'Фронтальный панель (сол)',
                            sectionId: sub.sectionId,
                            width: frontLenLeft,
                            height: sub.height,
                            depth: frontPanelDepth,
                            extra: { side: 'left-front', subId: key }
                        });
                        const leftFrontX = baseLeft + leftGap / 2;
                        leftFrontPanel.position.set(leftFrontX, panelCenterY, frontSurfaceZ - frontPanelDepth / 2);
                        insertsGroup.add(leftFrontPanel);
                    }
                    if (rightGap > 0) {
                        const rightFrontGeo = new THREE.BoxGeometry(frontLenRight, sub.height, frontPanelDepth);
                        const rightFrontPanel = solidWithEdges(rightFrontGeo, panelColor, {
                            type: 'drawer_panel',
                            name: 'Фронтальный панель (оң)',
                            sectionId: sub.sectionId,
                            width: frontLenRight,
                            height: sub.height,
                            depth: frontPanelDepth,
                            extra: { side: 'right-front', subId: key }
                        });
                        const rightFrontX = baseRight - rightGap / 2;
                        rightFrontPanel.position.set(rightFrontX, panelCenterY, frontSurfaceZ - frontPanelDepth / 2);
                        insertsGroup.add(rightFrontPanel);
                    }
                }
                list.forEach(ins => {
                    if (ins.type === 'pipe') {
                        const r = 12.5; // диаметр 25 мм
                        const flangeT = 10;
                        const pipeColor = getPipeColorHex();
                        let lenMax = Math.max(0, usableWidth - 2 * flangeT - 4); // фланецтерді ескеріп, ішке сыюы керек
                        if (lenMax <= 0) return;
                        let len = Math.min(Math.max(30, usableWidth - 20), lenMax);
                        if (len < 15 && lenMax < 15) len = lenMax; // өте тар секцияда да сыртқа шықпау үшін
                        if (len <= 0) return;
                        const geo = new THREE.CylinderGeometry(r, r, len, 24);
                        geo.rotateZ(Math.PI / 2);
                        const pipe = solidWithEdges(geo, pipeColor, {
                            type: 'pipe',
                            name: 'Труба ' + (pipeCounter + 1),
                            sectionId: sub.sectionId,
                            width: len,
                            height: r * 2,
                            depth: r * 2,
                            extra: { insertType: 'pipe', subId: key }
                        });
                        const minY = plinthHeight + globalThickness + sec.y + sub.start + r;
                        const targetTop = gapTopWorld - 70;
                        const targetMid = gapCenterY - 70;
                        const pipeIndex = pipeCounter++;
                        const yTarget = (pipeIndex === 0) ? targetTop : targetMid;
                        const yPipe = Math.max(minY, yTarget);
                        pipe.position.set(xWorld, yPipe, zWorld);
                        insertsGroup.add(pipe);

                        // Фланец-держательлер (диаметр 45, қалыңдығы 10 мм)
                        const flangeR = 22.5;
                        const flangeGeo = new THREE.CylinderGeometry(flangeR, flangeR, flangeT, 24);
                        flangeGeo.rotateZ(Math.PI / 2); // осьті X бойына бұрамыз
                        const flangeOffset = len / 2 + flangeT / 2;
                        const flangeLeft = solidWithEdges(flangeGeo, pipeColor, {
                            type: 'flange',
                            name: 'Фланец сол',
                            sectionId: sub.sectionId,
                            width: flangeT,
                            height: flangeR * 2,
                            depth: flangeR * 2,
                            extra: { insertType: 'pipe', subId: key }
                        });
                        flangeLeft.position.set(xWorld - flangeOffset, yPipe, zWorld);
                        const flangeRight = solidWithEdges(flangeGeo.clone(), pipeColor, {
                            type: 'flange',
                            name: 'Фланец оң',
                            sectionId: sub.sectionId,
                            width: flangeT,
                            height: flangeR * 2,
                            depth: flangeR * 2,
                            extra: { insertType: 'pipe', subId: key }
                        });
                        flangeRight.position.set(xWorld + flangeOffset, yPipe, zWorld);
                        insertsGroup.add(flangeLeft);
                        insertsGroup.add(flangeRight);
                    } else if (ins.type === 'drawer') {
                        // LDSP қорап + жеке фасад
                const bodyT = globalThickness;
                // Корпус ені: әр жақтан runner қалыңдығына тең бос орын
                const outerW = Math.max(60, usableWidth - 2 * padBody);
                const outerH = Math.max(10, Math.min(bodyHeight, facSlotH - 2));
                const preferredDepth = ins.depth || pickDrawerDepthForSub(sub);
                const effectivePreferredDepth = Math.max(10, preferredDepth - drawerDepthBrandOffset);
                const bodyDepth = Math.max(120, Math.min(effectivePreferredDepth, depth));
                const bodyColor = getCorpusColor(corpusMaterial.value);
                const facadeThk = parseFloat(facadeThickness.value) || 18;
                const drawerFacadeMatVal = drawerFacadeMaterial && drawerFacadeMaterial.value ? drawerFacadeMaterial.value : facadeMaterial.value;
                const facadeColorLocal = getFacadeColor(drawerFacadeMatVal);
                let facadeGap = targetGap;
            const facBaseH = facSlotH;
            const maxGap = Math.max(0, Math.min((usableWidth - 10) / 2, (facBaseH - 10) / 2));
            facadeGap = Math.min(facadeGap, maxGap);
        const groupBody = new THREE.Group();
                // Боковиналар
                        const sideExtension = ins.variant === 'tandem' ? 11 : 0;
                        const sideHeight = outerH + sideExtension;
                        const sideYOffset = sideExtension / 2;
                        const sideGeo = new THREE.BoxGeometry(bodyT, sideHeight, bodyDepth);
                        const leftSide = solidWithEdges(sideGeo, bodyColor, {
                            type: 'drawer',
                            name: 'Ящик сол жақ',
                            sectionId: sub.sectionId,
                            width: bodyT,
                            height: sideHeight,
                            depth: bodyDepth,
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, drawerSide: 'left' },
                            edge: { front: false, back: true, left: true, right: true }
                        });
                        leftSide.position.set(-outerW / 2 + bodyT / 2, -sideYOffset, 0);
                        const rightSide = solidWithEdges(sideGeo.clone(), bodyColor, {
                            type: 'drawer',
                            name: 'Ящик оң жақ',
                            sectionId: sub.sectionId,
                            width: bodyT,
                            height: sideHeight,
                            depth: bodyDepth,
                            edge: { front: false, back: true, left: true, right: true },
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, drawerSide: 'right' }
                        });
                        rightSide.position.set(outerW / 2 - bodyT / 2, -sideYOffset, 0);
                        // Алдыңғы/артқы
                        const frontW = Math.max(10, outerW - 2 * bodyT);
                        const frontGeo = new THREE.BoxGeometry(frontW, outerH - bodyT, bodyT);
                        const front = solidWithEdges(frontGeo, bodyColor, {
                            type: 'drawer',
                            name: 'Ящик алды',
                            sectionId: sub.sectionId,
                            width: frontW,
                            height: outerH - bodyT,
                            depth: bodyT,
                            edge: { front: false, back: true, left: false, right: false },
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, drawerPart: 'front' }
                        });
                        front.position.set(0, bodyT / 2, bodyDepth / 2 - bodyT / 2);
                        const back = solidWithEdges(frontGeo.clone(), bodyColor, {
                            type: 'drawer',
                            name: 'Ящик арты',
                            sectionId: sub.sectionId,
                            width: frontW,
                            height: outerH - bodyT,
                            depth: bodyT,
                            edge: { front: false, back: true, left: false, right: false },
                            extra: {
                                insertType: 'drawer',
                                subId: key,
                                variant: ins.variant,
                                drawerPart: 'back'
                            }
                        });
                        back.position.set(0, bodyT / 2, -bodyDepth / 2 + bodyT / 2);
                        // Түбі
                        const bottomW = Math.max(10, outerW - 2 * bodyT);
                        const bottomD = Math.max(10, bodyDepth);
                        const bottomGeo = new THREE.BoxGeometry(bottomW, bodyT, bottomD);
                        const bottom = solidWithEdges(bottomGeo, bodyColor, {
                            type: 'drawer',
                            name: 'Ящик түбі',
                            sectionId: sub.sectionId,
                            width: bottomW,
                            height: bodyT,
                            depth: bottomD,
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, drawerPart: 'bottom' }
                        });
                        bottom.position.set(0, -outerH / 2 + bodyT / 2, 0);
                        [leftSide, rightSide, front, back, bottom].forEach(m => groupBody.add(m));

                        // Направляющие (визуализация)
                        const sanitizedRunnerThk = Math.max(1, readDrawerRunnerThk());
                        const runnerThk = ins.variant === 'tandem' ? 5 : sanitizedRunnerThk;
                        const runnerH = 30;
                        const runnerD = bodyDepth;
                        const runnerColor = 0x777777;
                        const runnerGeo = new THREE.BoxGeometry(runnerThk, runnerH, runnerD);
                        const leftRunner = solidWithEdges(runnerGeo, runnerColor, {
                            type: 'runner',
                            name: 'Направляющий сол',
                            sectionId: sub.sectionId,
                            width: runnerThk,
                            height: runnerH,
                            depth: runnerD,
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, runnerType }
                        });
                        leftRunner.position.set(-outerW / 2 - runnerThk / 2, 0, 0);
                        const rightRunner = solidWithEdges(runnerGeo.clone(), runnerColor, {
                            type: 'runner',
                            name: 'Направляющий оң',
                            sectionId: sub.sectionId,
                            width: runnerThk,
                            height: runnerH,
                            depth: runnerD,
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, runnerType }
                        });
                        rightRunner.position.set(outerW / 2 + runnerThk / 2, 0, 0);
                        groupBody.add(leftRunner);
                        groupBody.add(rightRunner);

                // Фасад
                const facW = Math.max(20, usableWidth - 2 * facadeGap);
                // Фасад биіктігі слот биіктігіне тең – gapY арқылы бөлінеді (gapY == targetGap мүмкіндігінше)
                const facH = Math.max(20, facBaseH);
                const facGeo = new THREE.BoxGeometry(facW, facH, facadeThk);
                const fac = solidWithEdges(facGeo, facadeColorLocal, {
                    type: 'drawer_facade',
                    name: 'Ящик фасад',
                    sectionId: sub.sectionId,
                    width: facW,
                    height: facH,
                    depth: facadeThk,
                    edge: { front: true, back: true, left: true, right: true },
                    extra: { insertType: 'drawer', subId: key, variant: ins.variant, facadeGap, facadeMaterial: drawerFacadeMatVal }
                });
                fac.position.set(0, 0, bodyDepth / 2 + facadeThk / 2);

                const drawerGroup = new THREE.Group();
                drawerGroup.add(groupBody);
                drawerGroup.add(fac);

                const slotStartY = gapBottomWorld + gapY;
                const yDrawer = slotStartY + facSlotH / 2 + drawerCounter * stepY;
                drawerCounter++;
                // Фасадты алдынан оффсетке қарай артқа жылжытамыз
                const frontOffset = readDrawerFrontOffset();
                const bodyZ = zWorld + (depth / 2 - bodyDepth / 2) - frontOffset;
                drawerGroup.position.set(xWorld, yDrawer, bodyZ);
                fac.position.z = bodyDepth / 2 + facadeThk / 2;
                drawerGroup.userData.isDrawerGroup = true;
                drawerGroup.userData.open = false;
                drawerGroup.userData.closedZ = drawerGroup.position.z;
                drawerGroup.userData.openOffset = bodyDepth;
                drawerGroup.userData.sectionId = sub.sectionId;
                drawerGroup.userData.drawerDepth = preferredDepth;
                // Төмендегі mesh-тер drawerGroup ата-анасы арқылы анимация алады
                insertsGroup.add(drawerGroup);
            }
                });
            });

            (bodyCore || cabinetGroup).add(insertsGroup);
            rebuildStructureList();
            rebuildDrawerSubList();
        }

        // === ПОЛКАЛАРМЕН ЖҰМЫС ІСТЕЙТІН HELPERS ===

        function getSelectedSection() {
            if (!selectedSectionId) return null;
            return sections.find(s => s.id === selectedSectionId) || null;
        }

        function syncShelves() {
            rebuildShelvesGroup();
            rebuildShelvesUI();
            rebuildSectionSelect();
            updateDimensionsBox();
            rebuildDimensionHelpers();
            rebuildStructureList();
            updateSelectedShelfSubHelper();
            rebuildInsertsUI();
            rebuildDrawerSubList();
        }

        // Таңдалған секция үшін алдынан отступты UI-дан оқу
        function updateShelfFrontOffsetFromUI() {
            if (!shelfOffsetInput) return;

            const sec = getSelectedSection();
            if (!sec) {
                showError('Алдымен секцияны таңдаңыз');
                return;
            }

            let v = parseFloat(shelfOffsetInput.value);
            if (!isFinite(v) || v < 0) {
                v = 0;
            }

            const innerParams = computeInnerParams();
            const depthInside = innerParams.depthInside;
            const maxOffset   = Math.max(0, depthInside - 10);
            if (v > maxOffset) v = maxOffset;

            shelfOffsetInput.value = v;
            sectionShelfOffsets[sec.id] = v;

            rebuildShelvesGroup();
            rebuildDimensionHelpers();
        }


        // Қолмен бір полка қосу (биіктігі мм)
        function addShelfManual() {
            const sec = getSelectedSection();
            if (!sec) {
                showError('Алдымен секцияны таңдаңыз');
                return;
            }
            if (!shelfHeightInput) {
                showError('Полка биіктігі үшін input табылмады');
                return;
            }

            const h = parseFloat(shelfHeightInput.value);
            if (!isFinite(h)) {
                showError('Полка биіктігін (мм) дұрыс енгізіңіз');
                return;
            }

            // Секция ішіндегі диапазон: 0 ... sec.h
            if (h <= 0 || h >= sec.h - 20) {
                showError('Полка биіктігі секция ішінде болуы керек');
                return;
            }

            if (!sectionShelves[sec.id]) sectionShelves[sec.id] = [];
            sectionShelves[sec.id].push(h);
            sectionShelves[sec.id].sort((a, b) => a - b);

            syncShelves();
        }

        // Авто полкалар (саны бойынша тең бөлу)
        function autoPlaceShelves() {
            const sec = getSelectedSection();
            if (!sec) {
                showError('Алдымен секцияны таңдаңыз');
                return;
            }

            let count = 0;
            if (shelfCountInput) {
                count = parseInt(shelfCountInput.value, 10);
            }
            if (!isFinite(count) || count <= 0) {
                count = 3; // әдепкі 3 полка
            }

            const shelfT = globalThickness;
            const usable = sec.h - shelfT * count;
            if (usable <= 0) {
                showError('Секция биіктігі полка қоюға өте аз');
                return;
            }

            // Тең арақашықтық: gaps = count + 1
            const gaps = count + 1;
            const baseGap = Math.floor(usable / gaps);
            let remainder = Math.round(usable - baseGap * gaps); // бүтін мм үлестіреміз

            const arr = [];
            let pos = 0;
            for (let i = 0; i < count; i++) {
                const extra = remainder > 0 ? 1 : 0;
                if (remainder > 0) remainder -= 1;
                pos += baseGap + extra;
                arr.push(pos); // полканың түбі
                pos += shelfT; // келесі gap есептеу үшін полка қалыңдығын қосамыз
            }

            sectionShelves[sec.id] = arr;
            syncShelves();
        }

        // Таңдалған полканың биіктігін өзгерту
        function updateSelectedShelfHeight() {
            const sec = getSelectedSection();
            if (!sec) {
                showError('Алдымен секцияны таңдаңыз');
                return;
            }
            if (!shelfSelect || !editShelfHeightInput) return;
            if (shelfSelect.selectedIndex < 0) {
                showError('Алдымен тізімнен полканы таңдаңыз');
                return;
            }

            const oldH = parseFloat(shelfSelect.value);
            let newH = parseFloat(editShelfHeightInput.value);
            if (!isFinite(newH)) {
                showError('Жаңа биіктікті дұрыс енгізіңіз');
                return;
            }

            if (newH <= 0 || newH >= sec.h - 20) {
                showError('Полка биіктігі секция ішінде болуы керек');
                return;
            }

            const list = sectionShelves[sec.id] || [];
            const idx = list.findIndex(v => Math.abs(v - oldH) < 0.0001);
            if (idx === -1) {
                showError('Полканы табу мүмкін болмады');
                return;
            }
            list[idx] = newH;
            list.sort((a, b) => a - b);
            sectionShelves[sec.id] = list;

            syncShelves();
        }

        // Gap бойынша полкаларды қайта санау
        function applyShelfGap() {
            const sec = getSelectedSection();
            if (!sec) {
                showError('Алдымен секцияны таңдаңыз');
                return;
            }
            if (!shelfGapInput) return;

            let gap = parseFloat(shelfGapInput.value);
            if (!isFinite(gap) || gap <= 50) {
                gap = 300; // әдепкі 300 мм
            }

            const margin = 80;
            const usable = sec.h - margin * 2;
            if (usable <= gap) {
                showError('Секция биіктігі gap-тен кіші');
                return;
            }

            const list = [];
            let h = margin + gap;
            while (h < sec.h - margin - 20) {
                list.push(h);
                h += gap;
            }

            if (!list.length) {
                showError('Берілген gap бойынша полка қоюға орын жоқ');
                return;
            }

            sectionShelves[sec.id] = list;
            syncShelves();
        }

        // Екі полканың арасына қосымша полка қою
        function insertShelfBetween() {
            const sec = getSelectedSection();
            if (!sec) {
                showError('Алдымен секцияны таңдаңыз');
                return;
            }
            if (!shelfSelect) return;
            if (shelfSelect.selectedIndex <= 0) {
                showError('Кем дегенде екінші полканы таңдаңыз (аралық табылады)');
                return;
            }

            const list = (sectionShelves[sec.id] || []).slice().sort((a,b)=>a-b);
            const idx  = shelfSelect.selectedIndex;
            if (idx >= list.length) return;

            const h1 = list[idx - 1];
            const h2 = list[idx];
            const mid = (h1 + h2) / 2;

            if (!isFinite(mid) || mid <= 0 || mid >= sec.h - 20) {
                showError('Аралық дұрыс емес');
                return;
            }

            list.push(mid);
            list.sort((a,b)=>a-b);
            sectionShelves[sec.id] = list;

            syncShelves();
        }

	        // ПОЛКА КНОПКАЛАРЫНА EVENT LISTENER БАЙЛАУ
	        if (addShelfBtn) {
	            addShelfBtn.addEventListener('click', function () {
	                runUndoable(() => {
	                    addShelfManual();
	                });
	            });
	        }

	        if (autoShelvesBtn) {
	            autoShelvesBtn.addEventListener('click', function () {
	                runUndoable(() => {
	                    autoPlaceShelves();
	                });
	            });
	        }

	        if (updateShelfBtn) {
	            updateShelfBtn.addEventListener('click', function () {
	                runUndoable(() => {
	                    updateSelectedShelfHeight();
	                });
	            });
	        }

	        if (applyShelfGapBtn) {
	            applyShelfGapBtn.addEventListener('click', function () {
	                runUndoable(() => {
	                    applyShelfGap();
	                });
	            });
	        }

	        if (insertShelfBetweenBtn) {
	            insertShelfBetweenBtn.addEventListener('click', function () {
	                runUndoable(() => {
	                    insertShelfBetween();
	                });
	            });
	        }

        if (addInsertBtn) {
            addInsertBtn.addEventListener('click', function () {
                ensureSelectedSubIdFromUI();
                if (!selectedShelfSubId) {
                    showError('Алдымен полкалар арасындағы секцияны таңдаңыз');
                    return;
                }
                const type = insertTypeSelect ? insertTypeSelect.value : 'pipe';
                let variant = null;
	                if (type === 'drawer') {
	                    variant = drawerVariantSelect ? drawerVariantSelect.value : 'telescope';
	                    if (!variant) variant = 'telescope';
	                    syncDrawerDepthSelect(getShelfSubSections().find(s=>`${s.sectionId}:${s.idx}`===selectedShelfSubId));
	                }
	                if (!type) return;
	                runUndoable(() => {
	                    const arr = Array.isArray(shelfInserts[selectedShelfSubId]) ? shelfInserts[selectedShelfSubId] : [];
	                    let depth = null;
	                    if (type === 'drawer') {
	                        let dSel = drawerDepthSelect ? parseFloat(drawerDepthSelect.value) : NaN;
	                        if (!isFinite(dSel) || !drawerDepthPresets.includes(dSel)) {
	                            const sub = getShelfSubSections().find(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId);
	                            dSel = pickDrawerDepthForSub(sub);
	                        }
	                        depth = dSel;
	                    }
	                    const newIdx = arr.length;
	                    arr.push({ type, variant, depth });
	                    shelfInserts[selectedShelfSubId] = arr;
	                    selectedInsertKey = `${selectedShelfSubId}#${newIdx}`;
	                    rebuildInsertsUI();
	                    rebuildInsertsGroup();
	                    updateSelectedShelfSubHelper();
	                });
	            });
	        }
        if (insertTypeSelect) {
            insertTypeSelect.addEventListener('change', () => {
                updateInsertSettingsVisibility();
            });
        }

	        if (drawerBodyHeightInput) {
	            drawerBodyHeightInput.addEventListener('change', () => {
	                runUndoable(() => {
	                    readDrawerBodyHeight();
	                    rebuildInsertsGroup();
	                    rebuildInsertsUI();
	                });
	            });
	        }

	        if (drawerStackGapInput) {
	            drawerStackGapInput.addEventListener('change', () => {
	                runUndoable(() => {
	                    rebuildInsertsGroup();
	                    rebuildInsertsUI();
	                });
	            });
	        }
	        if (drawerRunnerThkInput) {
	            drawerRunnerThkInput.addEventListener('change', () => {
	                runUndoable(() => {
	                    rebuildInsertsGroup();
	                    rebuildInsertsUI();
	                });
	            });
	        }
        if (drawerVariantSelect) {
            drawerVariantSelect.addEventListener('change', () => {
                if (drawerVariantSelect.value === 'tandem' && drawerRunnerThkInput) {
                    drawerRunnerThkInput.value = 5;
                }
            });
        }
        if (drawerDepthBrandSelect) {
            drawerDepthBrandSelect.addEventListener('change', () => {
                runUndoable(() => {
                    rebuildInsertsGroup();
                    rebuildInsertsUI();
                });
            });
        }
	        if (insertGapLeftInput) {
	            insertGapLeftInput.addEventListener('change', () => {
	                runUndoable(() => {
	                    rebuildInsertsGroup();
	                    rebuildInsertsUI();
	                });
	            });
	        }
	        if (insertGapRightInput) {
	            insertGapRightInput.addEventListener('change', () => {
	                runUndoable(() => {
	                    rebuildInsertsGroup();
	                    rebuildInsertsUI();
	                });
	            });
	        }
	        if (drawerRunnerTypeSelect) {
	            drawerRunnerTypeSelect.addEventListener('change', () => {
	                runUndoable(() => {
	                    rebuildInsertsGroup();
	                    rebuildInsertsUI();
	                });
	            });
	        }
	        if (pipeColorInput) {
	            pipeColorInput.addEventListener('change', () => {
	                runUndoable(() => {
	                    rebuildInsertsGroup();
	                });
	            });
	        }
        if (drawerDepthSelect) {
            drawerDepthSelect.addEventListener('change', () => {
                if (!selectedShelfSubId) return;
                const sub = getShelfSubSections().find(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId);
                const depthVal = parseFloat(drawerDepthSelect.value);
	                if (!isFinite(depthVal)) {
	                    syncDrawerDepthSelect(sub);
	                    return;
	                }
	                runUndoable(() => {
	                    const arr = Array.isArray(shelfInserts[selectedShelfSubId]) ? shelfInserts[selectedShelfSubId] : [];
	                    const updated = arr.map((it, idx) => {
	                        const isTarget = selectedInsertKey && selectedInsertKey === `${selectedShelfSubId}#${idx}`;
	                        if (it && it.type === 'drawer') {
	                            if (isTarget || !selectedInsertKey) {
	                                return { ...it, depth: depthVal };
	                            }
	                        }
	                        return it;
	                    });
	                    shelfInserts[selectedShelfSubId] = updated;
	                    rebuildInsertsUI();
	                    rebuildInsertsGroup();
	                    syncDrawerDepthSelect(sub);
	                });
	            });
	        }
	        if (drawerFrontOffsetInput) {
	            drawerFrontOffsetInput.addEventListener('change', () => {
	                runUndoable(() => {
	                    readDrawerFrontOffset();
	                    rebuildInsertsGroup();
	                });
	            });
	        }
	        if (drawerFacadeMaterial) {
	            drawerFacadeMaterial.addEventListener('change', () => {
	                runUndoable(() => {
	                    rebuildInsertsGroup();
	                });
	            });
	        }

	        if (shelfOffsetInput) {
	            const commitShelfOffset = () => {
	                runUndoable(() => {
	                    updateShelfFrontOffsetFromUI();
	                });
	            };

            // Enter басқанда да бірден қолдану үшін
            shelfOffsetInput.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    commitShelfOffset();
                }
            });

            shelfOffsetInput.addEventListener('change', function () {
                commitShelfOffset();
            });
        }

        function resolveDrawerValueFromExtra(extra, key) {
            let target = extra;
            let depth = 0;
            while (target && typeof target === 'object' && depth < 8) {
                if (Object.prototype.hasOwnProperty.call(target, key)) {
                    return target[key];
                }
                target = target.extra;
                depth++;
            }
            return null;
        }

        function resolveDrawerSideFromExtra(extra) {
            return resolveDrawerValueFromExtra(extra, 'drawerSide');
        }

        function isDrawerEdgePanel(part) {
            if (!part) return false;
            const drawerPart = resolveDrawerValueFromExtra(part && part.extra, 'drawerPart');
            if (drawerPart === 'back' || drawerPart === 'front') {
                return true;
            }
            const typeLower = (part.type || '').toLowerCase();
            return typeLower === 'plinth';
        }

        function isVerticalPanelPart(part) {
            if (!part) return false;
            const typeLower = (part.type || '').toLowerCase();
            if (typeLower === 'side' || typeLower === 'divider') {
                return true;
            }
            if (typeLower === 'drawer') {
                const extra = part.extra || {};
                if (resolveDrawerSideFromExtra(extra)) {
                    return true;
                }
                const name = (part.name || '').toLowerCase();
                if (/ящик\s+(сол|оң)\s+жақ/i.test(name)) {
                    return true;
                }
            }
            return false;
        }

        function disposeEdgeHighlight(part) {
            if (!part || !part.edgeGroup) return;
            const grp = part.edgeGroup;
            if (grp.parent) grp.parent.remove(grp);
            grp.traverse(obj => {
                if (obj.geometry) obj.geometry.dispose();
                if (obj.material) obj.material.dispose();
            });
            part.edgeGroup = null;
        }

        function rebuildEdgeHighlightForPart(part) {
            if (!part || !part.mesh) return;
            disposeEdgeHighlight(part);
            const e = part.edge || {};
            const hasEdge = e.front || e.back || e.left || e.right;
            if (!hasEdge) return;

            const band = 1;
            const w = Math.abs(part.width || 0);
            const h = Math.abs(part.height || 0);
            const d = Math.abs(part.depth || 0);
            const group = new THREE.Group();
            const baseMat = new THREE.MeshBasicMaterial({ color: 0xdd0000, transparent: false });

            const addBand = (bw, bh, bd, x, y, z) => {
                const g = new THREE.BoxGeometry(Math.max(1, bw), Math.max(1, bh), Math.max(1, bd));
                const m = baseMat.clone();
                const mesh = new THREE.Mesh(g, m);
                mesh.position.set(x, y, z);
                mesh.userData.partId = part.id;
                group.add(mesh);
            };

            const tLower = (part.type || '').toLowerCase();
            const isVerticalPanel = isVerticalPanelPart(part);
            const isPlinth = (tLower === 'plinth');
            const isBottomPanel = (tLower === 'bottom');
            const isTopPanel = (tLower === 'top');

            const frontFlag = !!e.front;
            const backFlag  = !!e.back;
            const leftFlag  = !!e.left;
            const rightFlag = !!e.right;

            // Map edge flags to faces
            let bottomFlag = (isBottomPanel || isTopPanel) ? false : (isVerticalPanel ? leftFlag  : (isPlinth ? frontFlag : frontFlag));
            let topFlag    = (isBottomPanel || isTopPanel) ? false : (isVerticalPanel ? rightFlag : (isPlinth ? backFlag  : backFlag));
            const sideLeft   = isVerticalPanel ? backFlag  : leftFlag;
            const sideRight  = isVerticalPanel ? frontFlag : rightFlag;
            // Беттерге кромка: есікке тек үсті/асты қыр, фронт/бэк беті боялмасын
            let frontFace  = isPlinth ? false : frontFlag;
            let backFace   = isPlinth ? false : backFlag;
            const isDrawerPanel = (tLower === 'drawer_panel');
            const isDrawerFacade = (tLower === 'drawer_facade');
            const isDrawerEdgePanelFlag = isDrawerEdgePanel(part);
            if (tLower === 'door') {
                frontFace = false;
                backFace = false;
                // Есікте фронт флагын төменгіге, бэкті жоғарғыға қолданамыз
                bottomFlag = frontFlag;
                topFlag = backFlag;
            }
            if (isDrawerPanel) {
                frontFace = false;
                backFace = false;
            }
            if (isDrawerFacade || isDrawerEdgePanelFlag) {
                frontFace = false;
                backFace = false;
                bottomFlag = frontFlag;
                topFlag = backFlag;
            }

            // Полка: төмен/жоғары кромкасыз
            if ((part.type || '').toLowerCase() === 'shelf') {
                bottomFlag = false;
                topFlag = false;
            }

            if (frontFace) addBand(w, h, band, 0, 0, d / 2 + band / 2);
            if (backFace)  addBand(w, h, band, 0, 0, -d / 2 - band / 2);

            if (bottomFlag) addBand(w, band, d, 0, -h / 2 - band / 2, 0);
            if (topFlag)    addBand(w, band, d, 0,  h / 2 + band / 2, 0);
            if (!isVerticalPanel) {
                if (sideLeft)  addBand(band, h, d, -w / 2 - band / 2, 0, 0);
                if (sideRight) addBand(band, h, d,  w / 2 + band / 2, 0, 0);
            }

            const sx = part.mesh.scale.x || 1;
            const sy = part.mesh.scale.y || 1;
            const sz = part.mesh.scale.z || 1;
            group.scale.set(1 / sx, 1 / sy, 1 / sz); // avoid double-scaling when mesh already scaled
            part.mesh.add(group);
            part.edgeGroup = group;
            part.edgeGroup.visible = !!(edgeHighlightEnabled && (frontFlag || backFlag || leftFlag || rightFlag));
        }

        function getEdgeVisualFlags(part) {
            const e = part.edge || {};
            const typeLower = (part.type || '').toLowerCase();
            const isVerticalPanel = isVerticalPanelPart(part);
            const isPlinth = (typeLower === 'plinth');
            const isBottomPanel = (typeLower === 'bottom');
            const isTopPanel = (typeLower === 'top');

            if (isVerticalPanel) {
                return {
                    top: !!e.right,
                    bottom: !!e.left,
                    left: !!e.back,
                    right: !!e.front
                };
            }
            if (isPlinth) {
                return {
                    top: !!e.back,
                    bottom: !!e.front,
                    left: !!e.left,
                    right: !!e.right
                };
            }
            if (isBottomPanel) {
                return {
                    top: !!e.back,
                    bottom: !!e.front,
                    left: !!e.left,
                    right: !!e.right
                };
            }
            if (isTopPanel) {
                return {
                    top: !!e.back,
                    bottom: !!e.front,
                    left: !!e.left,
                    right: !!e.right
                };
            }
            if (typeLower === 'shelf') {
                return {
                    top: false,
                    bottom: false,
                    left: !!e.left,
                    right: !!e.right
                };
            }
            return {
                top:   !!e.back,
                bottom:!!e.front,
                left:  !!e.left,
                right: !!e.right
            };
        }

        function applyPartOffsets(part) {
            if (!part || !part.mesh) return;
            const base = part.baseDims || { width: part.width || 0, height: part.height || 0, depth: part.depth || 0 };
            const offs = part.offsets || { front:0, back:0, bottom:0, top:0 };
            const baseDepth = Math.max(1, base.depth || 0.001);
            const baseHeight = Math.max(1, base.height || 0.001);
            const newDepth = Math.max(1, base.depth + (offs.front || 0) + (offs.back || 0));
            const newHeight = Math.max(1, base.height + (offs.top || 0) + (offs.bottom || 0));
            const scaleZ = newDepth / baseDepth;
            const scaleY = newHeight / baseHeight;

            part.mesh.scale.set(part.mesh.scale.x, scaleY, scaleZ);

            const basePos = part.meshBasePosition || new THREE.Vector3();
            const dz = ((offs.front || 0) - (offs.back || 0)) / 2;
            const dy = ((offs.top || 0) - (offs.bottom || 0)) / 2;
            part.mesh.position.set(basePos.x, basePos.y + dy, basePos.z + dz);

            part.height = newHeight;
            part.depth  = newDepth;

            rebuildEdgeHighlightForPart(part);
            applyEdgeHighlightVisibility();
        }

        function applyEdgeHighlightVisibility() {
            Object.values(parts || {}).forEach(p => {
                const e = p.edge || {};
                const hasEdge = e.front || e.back || e.left || e.right;
                if (edgeHighlightEnabled && hasEdge && !p.edgeGroup) {
                    rebuildEdgeHighlightForPart(p);
                }
                if (p.edgeGroup) {
                    p.edgeGroup.visible = !!(edgeHighlightEnabled && hasEdge);
                }
            });
            if (toggleEdgeBtn) {
                toggleEdgeBtn.classList.toggle('active', edgeHighlightEnabled);
            }
        }

        function getPartPreviewAxes(part) {
            const emptyAxes = {
                horizontal: { value: 0, label: 'Ені' },
                vertical: { value: 0, label: 'Биіктік' }
            };
            if (!part) return emptyAxes;
            const t = (part.type || '').toLowerCase();
            const abs = (v) => Math.abs(v || 0);
            if (t === 'side' || t === 'divider') {
                return {
                    horizontal: { value: abs(part.depth), label: 'Тереңдік' },
                    vertical: { value: abs(part.height), label: 'Биіктік' }
                };
            }
            if (t === 'back' || t === 'door') {
                return {
                    horizontal: { value: abs(part.width), label: 'Ені' },
                    vertical: { value: abs(part.height), label: 'Биіктік' }
                };
            }
            if (t === 'top' || t === 'bottom' || t === 'shelf' || t === 'plinth') {
                return {
                    horizontal: { value: abs(part.width), label: 'Ені' },
                    vertical: { value: abs(part.depth), label: 'Тереңдік' }
                };
            }
            return {
                horizontal: { value: abs(part.width), label: 'Ені' },
                vertical: { value: abs(part.depth) || abs(part.height), label: 'Тереңдік' }
            };
        }

        function getDisplayDimsThicknessLast(part) {
            const w = Math.abs(part.width || 0);
            const h = Math.abs(part.height || 0);
            const d = Math.abs(part.depth || 0);
            const type = (part.type || '').toLowerCase();
            if (type === 'side' || type === 'divider') {
                // биіктік × тереңдік × қалыңдық
                return [h, d, w];
            }
            if (type === 'back' || type === 'door') {
                // ен × биіктік × қалыңдық (depth)
                return [w, h, d];
            }
            if (type === 'plinth' || type === 'falsh') {
                // ен × биіктік × қалыңдық (depth)
                return [w, h, d];
            }
            if (type === 'drawer_panel' || type === 'drawer_panel_front') {
                // биіктік × ен × қалыңдық
                return [h, w, d];
            }
            if (type === 'top' || type === 'bottom' || type === 'shelf') {
                // ен × тереңдік × қалыңдық (height)
                return [w, d, h];
            }
            // Басқа бөлшектер: ең кіші өлшемді қалыңдық деп алып, соңына қойамыз
            const dims = [w, h, d];
            const minIdx = dims.indexOf(Math.min(w, h, d));
            const thickness = dims[minIdx];
            const others = dims.filter((_, idx) => idx !== minIdx);
            let result = [...others, thickness];
            const name = (part.name || '').toLowerCase();
            if (type === 'drawer' && /сол\s+жақ|оң\s+жақ/i.test(name)) {
                if (result.length >= 2) {
                    [result[0], result[1]] = [result[1], result[0]];
                }
            }
            return result;
        }

        function formatPartDims(part) {
            if (!part) return '–';
            const dims = getDisplayDimsThicknessLast(part).map(v => Math.round(v));
            const type = (part && part.type || '').toLowerCase();
            if (type === 'door' && dims.length >= 2 && dims[0] < dims[1]) {
                [dims[0], dims[1]] = [dims[1], dims[0]];
            }
            return dims.join(' × ');
        }

        function renderPartPreview(part) {
            if (!partPreviewCanvas || !partPreviewCtx) return;
            const dpr = window.devicePixelRatio || 1;
            const displayWidth  = partPreviewCanvas.clientWidth  || 320;
            const displayHeight = partPreviewCanvas.clientHeight || 200;
            const targetW = Math.round(displayWidth * dpr);
            const targetH = Math.round(displayHeight * dpr);
            if (partPreviewCanvas.width !== targetW || partPreviewCanvas.height !== targetH) {
                partPreviewCanvas.width  = targetW;
                partPreviewCanvas.height = targetH;
            }

            const ctx = partPreviewCtx;
            ctx.save();
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            ctx.clearRect(0, 0, displayWidth, displayHeight);

            if (!part) {
                if (partPreviewEmpty) partPreviewEmpty.style.display = 'flex';
                if (partPreviewCaption) partPreviewCaption.textContent = '–';
                if (partPreviewName) partPreviewName.textContent = 'Бөлшек таңдалмаған';
                ctx.restore();
                return;
            }

            if (partPreviewEmpty) partPreviewEmpty.style.display = 'none';
            if (partPreviewName) partPreviewName.textContent = part.name || 'Бөлшек';

            const axes = getPartPreviewAxes(part);
            const horizVal = Math.abs(axes.horizontal.value || 0);
            const vertVal  = Math.abs(axes.vertical.value  || 0);
            const safeHoriz = Math.max(1, horizVal);
            const safeVert  = Math.max(1, vertVal);

            if (partPreviewCaption) {
                partPreviewCaption.textContent = formatPartDims(part) + ' мм';
            }

            const padding = 18;
            const scale = Math.min(
                (displayWidth - padding * 2) / safeHoriz,
                (displayHeight - padding * 2) / safeVert
            );
            const rectW = Math.max(24, safeHoriz * scale);
            const rectH = Math.max(24, safeVert * scale);
            const x = (displayWidth - rectW) / 2;
            const y = (displayHeight - rectH) / 2;

            ctx.fillStyle = '#ecf1fb';
            ctx.strokeStyle = '#4b5b78';
            ctx.lineWidth = 1.4;
            ctx.beginPath();
            ctx.rect(x, y, rectW, rectH);
            ctx.fill();
            ctx.stroke();

            const edgeFlags = getEdgeVisualFlags(part);
            const edgeThickness = 8;
            ctx.fillStyle = 'rgba(220, 40, 40, 0.32)';
            if (edgeFlags.bottom) ctx.fillRect(x, y + rectH - edgeThickness, rectW, edgeThickness);
            if (edgeFlags.top)    ctx.fillRect(x, y, rectW, edgeThickness);
            if (edgeFlags.left)   ctx.fillRect(x, y, edgeThickness, rectH);
            if (edgeFlags.right)  ctx.fillRect(x + rectW - edgeThickness, y, edgeThickness, rectH);

            ctx.fillStyle = '#1d2433';
            ctx.font = '12px system-ui, -apple-system, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(
                formatPartDims(part) + ' мм',
                displayWidth / 2,
                displayHeight / 2
            );

            ctx.restore();
        }

        function refreshPartPreview() {
            const p = (selectedPartId && parts[selectedPartId]) ? parts[selectedPartId] : null;
            renderPartPreview(p);
        }

        function updatePartUI() {
            if (!partNameInput) return;
            const syncEdgeLabels = (part) => {
                const t = (part && part.type) ? part.type.toLowerCase() : '';
                const partName = (part && part.name) ? String(part.name) : '';
                const isVerticalPanel = (t === 'side' || t === 'divider');
                const isPlinth = (t === 'plinth');
                const leftTxt   = isPlinth ? 'Сол'   : (isVerticalPanel ? 'Асты' : 'Сол');
                const rightTxt  = isPlinth ? 'Оң'    : (isVerticalPanel ? 'Үсті' : 'Оң');
                const isDrawerPanel = (t === 'drawer_panel');
                const isDoorPanel = (t === 'door');
                const isDrawerEdgePanelFlag = isDrawerEdgePanel(part);
                const useFacadeLabels = (isPlinth || isDrawerPanel || isDoorPanel || isDrawerEdgePanelFlag);
                const frontTxt  = useFacadeLabels ? 'Асты'  : 'Алды';
                const backTxt   = useFacadeLabels ? 'Үсті'  : 'Арты';

                if (edgeLeftLabel)   edgeLeftLabel.textContent   = leftTxt;
                if (edgeRightLabel)  edgeRightLabel.textContent  = rightTxt;
                if (edgeFrontLabel)  edgeFrontLabel.textContent  = frontTxt;
                if (edgeBackLabel)   edgeBackLabel.textContent   = backTxt;
                if (offsetBottomLabel) offsetBottomLabel.textContent = leftTxt;
                if (offsetTopLabel)    offsetTopLabel.textContent    = rightTxt;
                if (offsetFrontLabel)  offsetFrontLabel.textContent  = frontTxt;
                if (offsetBackLabel)   offsetBackLabel.textContent   = backTxt;
            };
            if (partPreviewDeleteBtn) {
                partPreviewDeleteBtn.disabled = !selectedPartId || !parts[selectedPartId];
            }
            if (!selectedPartId || !parts[selectedPartId]) {
                partNameInput.value    = '';
                partTypeInput.value    = '';
                partSectionInput.value = '';
                partSizeInput.value    = '';
                partOffsetFrontInput.value = 0;
                if (edgeFrontInput) edgeFrontInput.checked = false;
                if (edgeBackInput)  edgeBackInput.checked  = false;
                if (edgeLeftInput)  edgeLeftInput.checked  = false;
                if (edgeRightInput) edgeRightInput.checked = false;
                if (offsetFrontInput) offsetFrontInput.value = 0;
                if (offsetBackInput)  offsetBackInput.value  = 0;
                if (offsetBottomInput)offsetBottomInput.value= 0;
                if (offsetTopInput)   offsetTopInput.value   = 0;
                if (partDrillingInput) partDrillingInput.value = '';
                if (partEmptyState) partEmptyState.style.display = 'block';
                syncEdgeLabels(null);
                refreshPartPreview();
                return;
            }
            const p = parts[selectedPartId];
            partNameInput.value    = p.name || '';
            partTypeInput.value    = p.type || '';
            partSectionInput.value = p.sectionId != null ? String(p.sectionId) : '';
            partSizeInput.value    = formatPartDims(p) + ' мм';
            const typeLower = (p.type || '').toLowerCase();
            const isDrawerFacade = (typeLower === 'drawer_facade');
            const isDrawerEdgePanelFlag = isDrawerEdgePanel(p);
            const drawerPart = resolveDrawerValueFromExtra(p && p.extra, 'drawerPart');
            const isDrawerBottomPanel = drawerPart === 'bottom';
            const isDoorPanel = (typeLower === 'door');
            const isTopPanel = (typeLower === 'top');
            const isBottomPanel = (typeLower === 'bottom');

            // ЛДСП фасадында есік кромкасы барлық қырда болсын
            if ((p.type || '').toLowerCase() === 'door' && facadeMaterial && facadeMaterial.value === 'ldsp') {
                p.edge = { front: true, back: true, left: true, right: true };
                rebuildEdgeHighlightForPart(p);
                applyEdgeHighlightVisibility();
            }

            partOffsetFrontInput.value = p.frontOffset || 0;
            if (edgeFrontInput) edgeFrontInput.checked = !!(p.edge && p.edge.front);
            if (edgeBackInput)  edgeBackInput.checked  = !!(p.edge && p.edge.back);
            if (edgeLeftInput)  edgeLeftInput.checked  = !!(p.edge && p.edge.left);
            if (edgeRightInput) edgeRightInput.checked = !!(p.edge && p.edge.right);
            const offs = p.offsets || { front:0, back:0, bottom:0, top:0, left:0, right:0 };
            const bottomVal = offs.bottom || 0;
            const topVal = offs.top || 0;
            const leftVal = offs.left || 0;
            const rightVal = offs.right || 0;
            const useDrawerFacadeMode = isDrawerFacade || isDrawerEdgePanelFlag || isDoorPanel;
            const useLeftRightFromBottomTop = useDrawerFacadeMode || isTopPanel || isBottomPanel || isDrawerBottomPanel;
            if (offsetFrontInput) offsetFrontInput.value = useDrawerFacadeMode ? bottomVal : (offs.front || 0);
            if (offsetBackInput)  offsetBackInput.value  = useDrawerFacadeMode ? topVal : (offs.back || 0);
            if (offsetBottomInput)offsetBottomInput.value= useLeftRightFromBottomTop ? leftVal : bottomVal;
            if (offsetTopInput)   offsetTopInput.value   = useLeftRightFromBottomTop ? rightVal : topVal;
            if (partDrillingInput) partDrillingInput.value = p.drilling || '';
            if (partEmptyState) partEmptyState.style.display = 'none';
            syncEdgeLabels(p);
            applyPartOffsets(p);
            rebuildEdgeHighlightForPart(p);
            applyEdgeHighlightVisibility();
            refreshPartPreview();
        }

        function selectPart(partId) {
            if (!parts[partId]) return;

            if (selectedPartBoxHelper) {
                scene.remove(selectedPartBoxHelper);
                selectedPartBoxHelper.geometry.dispose();
                selectedPartBoxHelper.material.dispose();
                selectedPartBoxHelper = null;
            }

            selectedPartId = partId;
            const mesh = parts[partId].mesh;
            if (mesh) {
                selectedPartBoxHelper = new THREE.BoxHelper(mesh, 0x4fa3ff);
                scene.add(selectedPartBoxHelper);
            }

            const secId = parts[partId].sectionId;
            if (secId) {
                const secExists = sections.some(s => s.id === secId);
                if (secExists) {
                    selectedSectionId = secId;
                    updateSelectedSectionHelper();
                    rebuildSectionSelect();
                    rebuildShelvesUI();
                }
            }

            // Панельді сыртқы settings файл ашады
            if (window.QDApp && typeof window.QDApp.activatePanel === 'function') {
                window.QDApp.activatePanel('part');
            } else {
                const btn = document.querySelector('.tool-tab[data-panel="part"]');
                const panel = document.getElementById('panel-part');
                if (btn) {
                    document.querySelectorAll('.tool-tab').forEach(b => {
                        b.classList.toggle('active', b === btn);
                    });
                }
                if (panel) {
                    document.querySelectorAll('.tool-panel').forEach(p => {
                        p.classList.toggle('active', p === panel);
                    });
                }
            }

            updatePartUI();
            syncStructureSelection();
            updateSectionFaceHighlight();
        }

        function purgePartsByType(typesToRemove) {
            const typeSet = new Set(typesToRemove || []);
            if (!typeSet.size) return;

            // Remove helpers for selected part if it gets deleted
            if (selectedPartId && parts[selectedPartId] && typeSet.has((parts[selectedPartId].type || '').toLowerCase())) {
                if (selectedPartBoxHelper) {
                    scene.remove(selectedPartBoxHelper);
                    selectedPartBoxHelper.geometry.dispose();
                    selectedPartBoxHelper.material.dispose();
                    selectedPartBoxHelper = null;
                }
                selectedPartId = null;
            }

            const removeMeshRefs = new Set();
            Object.keys(parts).forEach(pid => {
                const p = parts[pid];
                if (p && typeSet.has((p.type || '').toLowerCase())) {
                    disposeEdgeHighlight(p);
                    if (p.mesh) removeMeshRefs.add(p.mesh);
                    delete parts[pid];
                }
            });

            allMeshes = allMeshes.filter(m => !removeMeshRefs.has(m));
            allEdges  = allEdges.filter(e => !removeMeshRefs.has(e.__parentMesh));

            updatePartUI();
        }

        function clearSelectedPartSelection() {
            if (selectedPartBoxHelper) {
                scene.remove(selectedPartBoxHelper);
                selectedPartBoxHelper.geometry.dispose();
                selectedPartBoxHelper.material.dispose();
                selectedPartBoxHelper = null;
            }
            selectedPartId = null;
            updateSectionFaceHighlight();
        }

        function removeShelfHeightFromData(part) {
            if (!part) return false;
            const secId = part.sectionId;
            if (secId == null) return false;
            const height = part.extra ? Number(part.extra.shelfHeight) : NaN;
            if (!isFinite(height)) return false;
            const list = sectionShelves[secId] || [];
            const tol = 0.0001;
            const idx = list.findIndex(v => Math.abs((v || 0) - height) < tol);
            if (idx === -1) return false;
            list.splice(idx, 1);
            sectionShelves[secId] = list;
            return true;
        }

        function removeObjectFromScene(root) {
            if (!root) return { meshes: new Set(), edges: new Set() };
            const meshes = new Set();
            const edges = new Set();
            root.traverse(obj => {
                if (obj.isMesh) meshes.add(obj);
                if (obj.type === 'LineSegments') edges.add(obj);
            });
            if (root.parent) {
                root.parent.remove(root);
            }
            root.traverse(obj => {
                if (obj.geometry) obj.geometry.dispose();
                disposeMat(obj.material);
            });
            return { meshes, edges };
        }

        function deletePart(partId) {
            const part = parts[partId];
            if (!part) return;
            const typeLower = (part.type || '').toLowerCase();
            disposeEdgeHighlight(part);
            clearSelectedPartSelection();
            if (typeLower === 'shelf') {
                const removedFromData = removeShelfHeightFromData(part);
                delete parts[partId];
                if (removedFromData) {
                    syncShelves();
                    updatePartUI();
                    return;
                }
                // fallthrough to normal deletion if shelf data stayed the same
            }

            let root = null;
            if (part.mesh && part.mesh.userData && part.mesh.userData.hinge) {
                root = part.mesh.userData.hinge;
            } else if (part.mesh) {
                root = part.mesh.parent || part.mesh;
            }

            if (root) {
                const { meshes, edges } = removeObjectFromScene(root);
                if (meshes.size) {
                    allMeshes = allMeshes.filter(m => !meshes.has(m));
                }
                if (edges.size) {
                    allEdges = allEdges.filter(e => !edges.has(e));
                }
            }

            delete parts[partId];
            selectedPartId = null;
            rebuildStructureList();
            updatePartUI();
            updateSectionFaceHighlight();
        }

	        // СОСТОЯНИЕ – Capture/Apply (Undo/Redo, Save/Load үшін)
        function captureState() {
            const activeSnapshot =
                (activeCabinetId != null && cabinetSpawned)
                    ? captureCabinetSnapshot()
                    : null;
            const insertSideGaps = readInsertSideGaps();
            const state = {
                W: parseFloat(widthInput.value)  || 0,
	                H: parseFloat(heightInput.value) || 0,
	                D: parseFloat(depthInput.value)  || 0,
                wallMaterial: null,
                wallAngle: 0,
                wallColor: null,
                wallWidth: 0,
                wallHeight: 0,
                wallEnabled: false,
	                walls: [],
	                selectedWallId: null,
	                newWalls: newWalls.map(w => ({ ...w })),
	                wallSections: (function(){
	                    const out = {};
	                    Object.keys(wallSections).forEach(k => {
	                        out[k] = wallSections[k].map(s => ({...s}));
	                    });
	                    return out;
	                })(),
                corpusMaterial: corpusMaterial.value,
                corpusThickness: parseFloat(corpusThickness.value) || 16,
                facadeMaterial: facadeMaterial.value,
                facadeThickness: parseFloat(facadeThickness.value) || 18,
                facadeType: facadeType.value,
                plinthHeight: parseFloat(plinthHeightInput.value) || 0,
                doorGlobalOpen: doorGlobalOpen,
                wallGap: readWallGap(),
                backMaterial: backMaterial.value,
                bottomMount: bottomMountInput ? bottomMountInput.value : null,
                drawerFacadeGap: readDrawerFacadeGap(),
                drawerFrontOffset: readDrawerFrontOffset(),
                drawerFacadeMaterial: drawerFacadeMaterial ? drawerFacadeMaterial.value : null,
                drawerBodyHeight: readDrawerBodyHeight(),
                drawerRunnerThk: readDrawerRunnerThk(),
                drawerStackGap: readDrawerStackGap(),
                insertGapLeft: insertSideGaps.left,
                insertGapRight: insertSideGaps.right,
                drawerRunnerType: drawerRunnerTypeSelect ? drawerRunnerTypeSelect.value : null,
                pipeColor: pipeColorInput ? pipeColorInput.value : null,
                corpusColor: corpusColorInput ? corpusColorInput.value : null,
                facadeColor: facadeColorInput ? facadeColorInput.value : null,
                facadeStyle: facadeStyle ? facadeStyle.value : null,
                innerW: innerW,
                innerH: innerH,
                sections: sections.map(s => ({id:s.id, x:s.x, y:s.y, w:s.w, h:s.h})),
                sectionShelves: (function(){
                    const out = {};
                    Object.keys(sectionShelves).forEach(k => {
                        out[k] = sectionShelves[k].slice();
                    });
                    return out;
                })(),
                sectionShelfOffsets: { ...sectionShelfOffsets },
                shelfInserts: cloneShelfInserts(shelfInserts),
                cabinetWallId: cabinetWallId,
                cabinetSectionId: cabinetSectionId,
                selectedSectionId: selectedSectionId,
                selectedShelfSubId: selectedShelfSubId,
                facadesHidden: facadesHidden,
                viewMode: currentViewMode,
                dimensionsVisible: dimensionsVisible,
                infoPanelVisible: infoPanelVisible,
                doorAnimEnabled: doorAnimEnabled,
                doorStates: readDoorStatesFromGroup(doorsGroup),
                edgeHighlightEnabled: edgeHighlightEnabled,
                cabinetSpawned: cabinetSpawned,
                cabinetBaseOffset: { ...cabinetBaseOffset },
                cabinetRotationY: cabinetRotationY,
                falshPanels: falshPanels.map(p => ({ ...p })),
                nextFalshId: nextFalshId,
                falshLeftSideEnabled: falshLeftSideEnabled,
                falshRightSideEnabled: falshRightSideEnabled,
                falshLeftSideSize: falshLeftSideSize,
                falshRightSideSize: falshRightSideSize,
	                activeCabinetId: activeCabinetId,
	                cabinets: cabinets.map(c => ({
	                    id: c.id,
	                    wallId: c.wallId,
	                    sectionId: c.sectionId,
	                    baseOffset: { ...(c.baseOffset || { x: 0, y: 0, z: 0 }) },
	                    rotationY: c.rotationY || 0,
	                    hidden: !!c.hidden,
	                    state: (activeSnapshot && c.id === activeCabinetId) ? activeSnapshot : (c.state || null)
	                }))
	            };
	            return state;
	        }

        // Тек шкафқа тән стейт (қабырға тізімін қоспаймыз)
        function captureCabinetSnapshot() {
            const insertSideGaps = readInsertSideGaps();
            const state = {
                W: parseFloat(widthInput.value)  || 0,
                H: parseFloat(heightInput.value) || 0,
                D: parseFloat(depthInput.value)  || 0,
                corpusMaterial: corpusMaterial.value,
                corpusThickness: parseFloat(corpusThickness.value) || 16,
                facadeMaterial: facadeMaterial.value,
                facadeThickness: parseFloat(facadeThickness.value) || 18,
                facadeType: facadeType.value,
                plinthHeight: parseFloat(plinthHeightInput.value) || 0,
                backMaterial: backMaterial.value,
                bottomMount: bottomMountInput ? bottomMountInput.value : null,
                corpusColor: corpusColorInput ? corpusColorInput.value : null,
                facadeColor: facadeColorInput ? facadeColorInput.value : null,
                facadeStyle: facadeStyle ? facadeStyle.value : null,
                doorStates: readDoorStatesFromGroup(doorsGroup),
                drawerFacadeGap: readDrawerFacadeGap(),
                drawerFrontOffset: readDrawerFrontOffset(),
                drawerBodyHeight: readDrawerBodyHeight(),
                drawerRunnerThk: readDrawerRunnerThk(),
                drawerStackGap: readDrawerStackGap(),
                insertGapLeft: insertSideGaps.left,
                insertGapRight: insertSideGaps.right,
                drawerRunnerType: drawerRunnerTypeSelect ? drawerRunnerTypeSelect.value : null,
                pipeColor: pipeColorInput ? pipeColorInput.value : null,
                sections: sections.map(s => ({id:s.id, x:s.x, y:s.y, w:s.w, h:s.h})),
                sectionShelves: (function(){
                    const out = {};
                    Object.keys(sectionShelves).forEach(k => {
                        out[k] = sectionShelves[k].slice();
                    });
                    return out;
                })(),
                sectionShelfOffsets: { ...sectionShelfOffsets },
                shelfInserts: cloneShelfInserts(shelfInserts),
                selectedSectionId: selectedSectionId,
                selectedShelfSubId: selectedShelfSubId,
                facadesHidden: facadesHidden,
                edgeHighlightEnabled: edgeHighlightEnabled,
                cabinetSpawned: cabinetSpawned,
                innerW: innerW,
                innerH: innerH,
                falshPanels: falshPanels.map(p => ({ ...p })),
                nextFalshId: nextFalshId,
                falshLeftSideEnabled: falshLeftSideEnabled,
                falshRightSideEnabled: falshRightSideEnabled,
                falshLeftSideSize: falshLeftSideSize,
                falshRightSideSize: falshRightSideSize
            };
            return state;
        }

        function applyState(state) {
            if (!state) return;

            // Алдымен ескі шкаф группаларын тазалаймыз (жаңа стейтті таза қолдану үшін)
            getAllCabinetGroups().forEach(({ group }) => disposeGroup(group));
            cabinetGroup = null;
            cabinets = [];
            activeCabinetId = state.activeCabinetId || null;

            widthInput.value  = (state.W || state.W === 0) ? state.W : widthInput.value;
            heightInput.value = (state.H || state.H === 0) ? state.H : heightInput.value;
            depthInput.value  = (state.D || state.D === 0) ? state.D : depthInput.value;
            const hasCabList = Array.isArray(state.cabinets) && state.cabinets.length > 0;
            const targetActiveId = state.activeCabinetId || (hasCabList ? state.cabinets[0].id : null);
            wallEnabled = false;
            walls = [];
            selectedWallId = null;
            nextWallId = 1;
            newWalls = (state.newWalls || []).map(w => ({...w}));
            wallSections = {};
            const srcWallSections = state.wallSections || {};
            Object.keys(srcWallSections).forEach(k => {
                wallSections[k] = srcWallSections[k].map(s => ({...s}));
            });
            cabinetWallId      = hasCabList ? null : (state.cabinetWallId || null);
            cabinetSectionId   = hasCabList ? null : (state.cabinetSectionId || null);
            cabinetBaseOffset  = state.cabinetBaseOffset || { x: 0, y: 0, z: 0 };
            cabinetRotationY   = state.cabinetRotationY || 0;
            cabinetSpawned     = hasCabList ? false : !!state.cabinetSpawned;
            pendingDoorStates  = Array.isArray(state.doorStates) ? state.doorStates.slice() : null;
            rebuildWallsUI();
            rebuildNewWallList();
            rebuildNewWalls();
            rebuildCabinetIcons();

            if (state.corpusMaterial)  corpusMaterial.value  = state.corpusMaterial;
            if (state.corpusThickness) corpusThickness.value = state.corpusThickness;
            if (state.facadeMaterial)  facadeMaterial.value  = state.facadeMaterial;
            if (state.facadeThickness) facadeThickness.value = state.facadeThickness;
            if (state.facadeType)      facadeType.value      = state.facadeType;
            if (state.plinthHeight !== undefined) plinthHeightInput.value = state.plinthHeight;
            if (state.wallGap !== undefined && wallGapInput) wallGapInput.value = state.wallGap;
            readWallGap();
            if (state.backMaterial)    backMaterial.value    = state.backMaterial;
            if (state.bottomMount && bottomMountInput) bottomMountInput.value = state.bottomMount;

            if (state.corpusColor && corpusColorInput) corpusColorInput.value = state.corpusColor;
            if (state.facadeColor && facadeColorInput) facadeColorInput.value = state.facadeColor;
            if (state.facadeStyle && facadeStyle)      facadeStyle.value      = state.facadeStyle;
            if (pipeColorInput && state.pipeColor)     pipeColorInput.value  = state.pipeColor;
            if (drawerRunnerTypeSelect && state.drawerRunnerType) drawerRunnerTypeSelect.value = state.drawerRunnerType;
            if (state.falshLeftSideSize && falshLeftSideSizeInput) {
                falshLeftSideSizeInput.value = state.falshLeftSideSize;
                falshLeftSideSize = state.falshLeftSideSize;
            }
            if (state.falshRightSideSize && falshRightSideSizeInput) {
                falshRightSideSizeInput.value = state.falshRightSideSize;
                falshRightSideSize = state.falshRightSideSize;
            }
            if (drawerFacadeGapInput) {
                if (state.drawerFacadeGap !== undefined && state.drawerFacadeGap !== null) {
                    let g = parseFloat(state.drawerFacadeGap);
                    if (!isFinite(g) || g < 0) g = 3;
                    drawerFacadeGapInput.value = g;
                } else if (!drawerFacadeGapInput.value) {
                    drawerFacadeGapInput.value = 3;
                }
            }
            if (drawerBodyHeightInput) {
                if (state.drawerBodyHeight !== undefined && state.drawerBodyHeight !== null) {
                    let g = parseFloat(state.drawerBodyHeight);
                    if (!isFinite(g) || g < 40) g = 120;
                    drawerBodyHeightInput.value = g;
                } else if (!drawerBodyHeightInput.value) {
                    drawerBodyHeightInput.value = 120;
                }
            }
            if (drawerFrontOffsetInput) {
                if (state.drawerFrontOffset !== undefined && state.drawerFrontOffset !== null) {
                    let g = parseFloat(state.drawerFrontOffset);
                    if (!isFinite(g) || g < 0) g = 16;
                    drawerFrontOffsetInput.value = g;
                } else if (!drawerFrontOffsetInput.value) {
                    drawerFrontOffsetInput.value = 16;
                }
            }
            if (drawerFacadeMaterial && state.drawerFacadeMaterial) {
                drawerFacadeMaterial.value = state.drawerFacadeMaterial;
            }
            if (drawerRunnerThkInput) {
                if (state.drawerRunnerThk !== undefined && state.drawerRunnerThk !== null) {
                    let g = parseFloat(state.drawerRunnerThk);
                    if (!isFinite(g) || g < 0) g = 13;
                    drawerRunnerThkInput.value = g;
                } else if (!drawerRunnerThkInput.value) {
                    drawerRunnerThkInput.value = 13;
                }
            }
            if (drawerStackGapInput) {
                if (state.drawerStackGap !== undefined && state.drawerStackGap !== null) {
                    let g = parseFloat(state.drawerStackGap);
                    if (!isFinite(g) || g < 0) g = 0;
                    drawerStackGapInput.value = g;
                } else if (!drawerStackGapInput.value) {
                    drawerStackGapInput.value = 0;
                }
            }
            if (insertGapLeftInput) {
                if (state.insertGapLeft !== undefined && state.insertGapLeft !== null) {
                    let g = parseFloat(state.insertGapLeft);
                    if (!isFinite(g) || g < 0) g = 50;
                    insertGapLeftInput.value = g;
                } else if (!insertGapLeftInput.value) {
                    insertGapLeftInput.value = 50;
                }
            }
            if (insertGapRightInput) {
                if (state.insertGapRight !== undefined && state.insertGapRight !== null) {
                    let g = parseFloat(state.insertGapRight);
                    if (!isFinite(g) || g < 0) g = 50;
                    insertGapRightInput.value = g;
                } else if (!insertGapRightInput.value) {
                    insertGapRightInput.value = 50;
                }
            }

            facadesHidden      = !!state.facadesHidden;
            edgeHighlightEnabled = !!state.edgeHighlightEnabled;
            currentViewMode    = (state.viewMode !== undefined) ? state.viewMode : currentViewMode;
            dimensionsVisible  = (state.dimensionsVisible !== undefined) ? !!state.dimensionsVisible : true;
            infoPanelVisible   = (state.infoPanelVisible !== undefined) ? !!state.infoPanelVisible : false;
            doorAnimEnabled    = !!state.doorAnimEnabled;
            falshLeftSideEnabled  = !!state.falshLeftSideEnabled;
            falshRightSideEnabled = !!state.falshRightSideEnabled;
            if (falshLeftSideCheckbox) falshLeftSideCheckbox.checked   = falshLeftSideEnabled;
            if (falshRightSideCheckbox) falshRightSideCheckbox.checked = falshRightSideEnabled;
            if (falshLeftSideSizeInput && state.falshLeftSideSize) {
                falshLeftSideSizeInput.value = state.falshLeftSideSize;
                falshLeftSideSize = state.falshLeftSideSize;
            }
            if (falshRightSideSizeInput && state.falshRightSideSize) {
                falshRightSideSizeInput.value = state.falshRightSideSize;
                falshRightSideSize = state.falshRightSideSize;
            }
            falshPanels        = (state.falshPanels || []).map(p => ({ ...p }));
            nextFalshId        = Math.max(
                1,
                state.nextFalshId || 1,
                falshPanels.reduce((m, p) => Math.max(m, p.id || 0), 0) + 1
            );

            if (hasCabList) {
                cabinets = [];
                activeCabinetId = null;
                state.cabinets.forEach(cabData => {
                    if (!cabData || cabData.id == null) return;
                    const rec = {
                        id: cabData.id,
                        wallId: cabData.wallId || null,
                        sectionId: cabData.sectionId || null,
                        baseOffset: { ...(cabData.baseOffset || { x: 0, y: 0, z: 0 }) },
                        rotationY: cabData.rotationY || 0,
                        hidden: !!cabData.hidden,
                        state: cabData.state || null,
                        group: null
                    };
                    cabinets.push(rec);
                    activeCabinetId   = rec.id;
                    cabinetWallId     = rec.wallId;
                    cabinetSectionId  = rec.sectionId;
                    cabinetBaseOffset = rec.baseOffset;
                    cabinetRotationY  = rec.rotationY || 0;
                    cabinetSpawned    = true;
                    applyCabinetState(rec.state || {});
                    rec.state = captureCabinetSnapshot();
                    rec.group = cabinetGroup;
                    if (rec.group) rec.group.visible = !rec.hidden;
                });
                refreshNextSectionIdGlobal();

                if (targetActiveId && cabinets.some(c => c.id === targetActiveId)) {
                    setActiveCabinet(targetActiveId);
                } else if (cabinets[0]) {
                    setActiveCabinet(cabinets[0].id);
                }

                applyActiveCabinetVisibility();
                rebuildWalls();
                setViewMode(currentViewMode);
                applyEdgeHighlightVisibility();
                rebuildInsertsUI();
                updateSelectedShelfSubHelper();
                rebuildDrawerSubList();
                syncDrawerActiveRow();
                syncDimensionsVisibility();
                syncInfoVisibility();
                rebuildCabinetIcons();
                rebuildFalshList();
                if (animToggleBtn)   animToggleBtn.classList.toggle('active', doorAnimEnabled);
                return;
            }

            sections = (state.sections || []).map(s => ({
                id: s.id, x: s.x, y: s.y, w: s.w, h: s.h
            }));
            refreshNextSectionIdGlobal();

            sectionShelves = {};
            const srcShelves = state.sectionShelves || {};
            Object.keys(srcShelves).forEach(k => {
                sectionShelves[k] = srcShelves[k].slice();
            });
            sanitizeSectionShelves();

            // Полкалар алдынан отступ (секцияға байланған) – стейттен оқимыз
            sectionShelfOffsets = { ...(state.sectionShelfOffsets || {}) };
            shelfInserts = cloneShelfInserts(state.shelfInserts || {});
            selectedShelfSubId = state.selectedShelfSubId || null;
            sanitizeShelfInserts(getShelfSubSections());

            selectedSectionId  = state.selectedSectionId || (sections[0] && sections[0].id) || null;

            innerW = state.innerW || 0;
            innerH = state.innerH || 0;

            const W = state.W || 1000;
            const H = state.H || 2200;
            const D = state.D || 600;

            if (!hasCabList && cabinetSpawned && !activeCabinetId) {
                activeCabinetId = state.activeCabinetId || Date.now();
            }

            if (cabinetSpawned && cabinetWallId && cabinetSectionId) {
                updateCabinetFromSection(false);
            } else {
                cabinetSpawned = false;
            }
            if (cabinetSpawned && !cabinets.length) {
                const cabId = activeCabinetId || Date.now();
                activeCabinetId = cabId;
                cabinets.push({
                    id: cabId,
                    wallId: cabinetWallId,
                    sectionId: cabinetSectionId,
                    baseOffset: { ...cabinetBaseOffset },
                    rotationY: cabinetRotationY,
                    hidden: false,
                    state: captureCabinetSnapshot(),
                    group: cabinetGroup
                });
                applyActiveCabinetVisibility();
                rebuildCabinetIcons();
            }

            rebuildWalls();

            syncFacadesVisibilityAll();
            setViewMode(currentViewMode);
            applyEdgeHighlightVisibility();
            rebuildInsertsUI();
            updateSelectedShelfSubHelper();
            rebuildDrawerSubList();
            syncDrawerActiveRow();
            syncDimensionsVisibility();
            syncInfoVisibility();
            rebuildFalshList();
            if (animToggleBtn)   animToggleBtn.classList.toggle('active', doorAnimEnabled);
            // doorGlobalOpen removed (toggle all button deleted)
            hasUnsavedChanges = true;
        }

        // Тек шкаф күйін қолдану (қабырғаларды қозғамау үшін)
        function applyCabinetState(state) {
            if (!state) return;
            widthInput.value  = (state.W || state.W === 0) ? state.W : widthInput.value;
            heightInput.value = (state.H || state.H === 0) ? state.H : heightInput.value;
            depthInput.value  = (state.D || state.D === 0) ? state.D : depthInput.value;

            if (state.corpusMaterial)  corpusMaterial.value  = state.corpusMaterial;
            if (state.corpusThickness) corpusThickness.value = state.corpusThickness;
            if (state.facadeMaterial)  facadeMaterial.value  = state.facadeMaterial;
            if (state.facadeThickness) facadeThickness.value = state.facadeThickness;
            if (state.facadeType)      facadeType.value      = state.facadeType;
            if (state.plinthHeight !== undefined) plinthHeightInput.value = state.plinthHeight;
            if (state.backMaterial)    backMaterial.value    = state.backMaterial;
            if (state.bottomMount && bottomMountInput) bottomMountInput.value = state.bottomMount;
            if (state.corpusColor && corpusColorInput) corpusColorInput.value = state.corpusColor;
            if (state.facadeColor && facadeColorInput) facadeColorInput.value = state.facadeColor;
            if (state.facadeStyle && facadeStyle)      facadeStyle.value      = state.facadeStyle;
            if (pipeColorInput && state.pipeColor)     pipeColorInput.value  = state.pipeColor;
            if (drawerRunnerTypeSelect && state.drawerRunnerType) drawerRunnerTypeSelect.value = state.drawerRunnerType;
            falshPanels = (state.falshPanels || []).map(p => ({ ...p }));
            nextFalshId = Math.max(
                1,
                state.nextFalshId || 1,
                falshPanels.reduce((m, p) => Math.max(m, p.id || 0), 0) + 1
            );
            falshLeftSideEnabled  = !!state.falshLeftSideEnabled;
            falshRightSideEnabled = !!state.falshRightSideEnabled;
            falshLeftSideSize     = Number.isFinite(state.falshLeftSideSize) ? state.falshLeftSideSize : falshLeftSideSize;
            falshRightSideSize    = Number.isFinite(state.falshRightSideSize) ? state.falshRightSideSize : falshRightSideSize;
            if (falshLeftSideCheckbox) falshLeftSideCheckbox.checked   = falshLeftSideEnabled;
            if (falshRightSideCheckbox) falshRightSideCheckbox.checked = falshRightSideEnabled;
            if (falshLeftSideSizeInput && state.falshLeftSideSize) {
                falshLeftSideSizeInput.value = state.falshLeftSideSize;
            }
            if (falshRightSideSizeInput && state.falshRightSideSize) {
                falshRightSideSizeInput.value = state.falshRightSideSize;
            }
            if (drawerFacadeGapInput) {
                if (state.drawerFacadeGap !== undefined && state.drawerFacadeGap !== null) {
                    let g = parseFloat(state.drawerFacadeGap);
                    if (!isFinite(g) || g < 0) g = 3;
                    drawerFacadeGapInput.value = g;
                } else if (!drawerFacadeGapInput.value) {
                    drawerFacadeGapInput.value = 3;
                }
            }
            if (drawerBodyHeightInput) {
                if (state.drawerBodyHeight !== undefined && state.drawerBodyHeight !== null) {
                    let g = parseFloat(state.drawerBodyHeight);
                    if (!isFinite(g) || g < 40) g = 120;
                    drawerBodyHeightInput.value = g;
                } else if (!drawerBodyHeightInput.value) {
                    drawerBodyHeightInput.value = 120;
                }
            }
            if (drawerRunnerThkInput) {
                if (state.drawerRunnerThk !== undefined && state.drawerRunnerThk !== null) {
                    let g = parseFloat(state.drawerRunnerThk);
                    if (!isFinite(g) || g < 0) g = 13;
                    drawerRunnerThkInput.value = g;
                } else if (!drawerRunnerThkInput.value) {
                    drawerRunnerThkInput.value = 13;
                }
            }
            if (drawerStackGapInput) {
                if (state.drawerStackGap !== undefined && state.drawerStackGap !== null) {
                    let g = parseFloat(state.drawerStackGap);
                    if (!isFinite(g) || g < 0) g = 0;
                    drawerStackGapInput.value = g;
                } else if (!drawerStackGapInput.value) {
                    drawerStackGapInput.value = 0;
                }
            }

            sections = (state.sections || []).map(s => ({
                id: s.id, x: s.x, y: s.y, w: s.w, h: s.h
            }));
            nextSectionId = sections.reduce((m,s)=>Math.max(m,s.id), 0) + 1;

            sectionShelves = {};
            const srcShelves = state.sectionShelves || {};
            Object.keys(srcShelves).forEach(k => {
                sectionShelves[k] = srcShelves[k].slice();
            });
            sanitizeSectionShelves();
            sectionShelfOffsets = { ...(state.sectionShelfOffsets || {}) };
            shelfInserts = cloneShelfInserts(state.shelfInserts || {});
            selectedShelfSubId = state.selectedShelfSubId || null;
            sanitizeShelfInserts(getShelfSubSections());

            selectedSectionId  = state.selectedSectionId || (sections[0] && sections[0].id) || null;
            facadesHidden      = !!state.facadesHidden;
            edgeHighlightEnabled = !!state.edgeHighlightEnabled;
            cabinetSpawned     = !!state.cabinetSpawned;
            innerW = state.innerW || innerW;
            innerH = state.innerH || innerH;
            pendingDoorStates = Array.isArray(state.doorStates) ? state.doorStates.slice() : null;

            const W = state.W || parseFloat(widthInput.value) || 1000;
            const H = state.H || parseFloat(heightInput.value) || 2200;
            const D = state.D || parseFloat(depthInput.value) || 600;

            cabinetGroup = null;
            createCabinet(W, H, D, true);
            rebuildInsertsUI();
            updateSelectedShelfSubHelper();
            rebuildDrawerSubList();
            syncDrawerActiveRow();
            rebuildFalshList();
        }

        let undoCurrentState = null;

        function isPlainObject(val) {
            return !!val && typeof val === 'object' && !Array.isArray(val);
        }

        function deepEqual(a, b) {
            if (a === b) return true;
            if (!Object.is(typeof a, typeof b)) return false;
            if (a == null || b == null) return false;

            if (Array.isArray(a)) {
                if (!Array.isArray(b)) return false;
                if (a.length !== b.length) return false;
                for (let i = 0; i < a.length; i++) {
                    if (!deepEqual(a[i], b[i])) return false;
                }
                return true;
            }

            if (isPlainObject(a)) {
                if (!isPlainObject(b)) return false;
                const aKeys = Object.keys(a);
                const bKeys = Object.keys(b);
                if (aKeys.length !== bKeys.length) return false;
                for (const k of aKeys) {
                    if (!(k in b)) return false;
                    if (!deepEqual(a[k], b[k])) return false;
                }
                return true;
            }

            return Object.is(a, b);
        }

        function isArrayOfIdObjects(arr) {
            if (!Array.isArray(arr)) return false;
            if (!arr.length) return true;
            return arr.every(it => isPlainObject(it) && it.id != null);
        }

        function diffArrayById(beforeArr, afterArr, path, ops) {
            const beforeById = new Map();
            const afterById = new Map();
            const beforeOrder = [];
            const afterOrder = [];

            beforeArr.forEach(it => {
                const id = String(it.id);
                beforeById.set(id, it);
                beforeOrder.push(id);
            });
            afterArr.forEach(it => {
                const id = String(it.id);
                afterById.set(id, it);
                afterOrder.push(id);
            });

            const allIds = new Set([...beforeOrder, ...afterOrder]);
            for (const id of allIds) {
                const b = beforeById.get(id);
                const a = afterById.get(id);
                if (b === undefined || a === undefined) {
                    ops.push({ type: 'arr_item', path, id, before: b, after: a });
                    continue;
                }
                if (!deepEqual(b, a)) {
                    ops.push({ type: 'arr_item', path, id, before: b, after: a });
                }
            }

            if (!deepEqual(beforeOrder, afterOrder)) {
                ops.push({ type: 'arr_order', path, before: beforeOrder, after: afterOrder });
            }
        }

        function diffAny(beforeVal, afterVal, path, ops) {
            if (deepEqual(beforeVal, afterVal)) return;

            if (Array.isArray(beforeVal) && Array.isArray(afterVal)) {
                if (isArrayOfIdObjects(beforeVal) && isArrayOfIdObjects(afterVal)) {
                    diffArrayById(beforeVal, afterVal, path, ops);
                    return;
                }
                ops.push({ type: 'set', path, before: beforeVal, after: afterVal });
                return;
            }

            if (isPlainObject(beforeVal) && isPlainObject(afterVal)) {
                const keys = new Set([...Object.keys(beforeVal), ...Object.keys(afterVal)]);
                for (const key of keys) {
                    const hasBefore = Object.prototype.hasOwnProperty.call(beforeVal, key);
                    const hasAfter = Object.prototype.hasOwnProperty.call(afterVal, key);
                    if (!hasAfter) {
                        ops.push({ type: 'set', path: path.concat(key), before: beforeVal[key], after: undefined });
                        continue;
                    }
                    if (!hasBefore) {
                        ops.push({ type: 'set', path: path.concat(key), before: undefined, after: afterVal[key] });
                        continue;
                    }
                    diffAny(beforeVal[key], afterVal[key], path.concat(key), ops);
                }
                return;
            }

            ops.push({ type: 'set', path, before: beforeVal, after: afterVal });
        }

        function diffStates(beforeState, afterState) {
            const ops = [];
            diffAny(beforeState, afterState, [], ops);
            return ops;
        }

        function getAtPath(root, path) {
            let cur = root;
            for (const key of path) {
                if (cur == null) return undefined;
                cur = cur[key];
            }
            return cur;
        }

        function setAtPath(root, path, value) {
            if (!path.length) return;
            let cur = root;
            for (let i = 0; i < path.length - 1; i++) {
                const key = path[i];
                if (!isPlainObject(cur[key]) && !Array.isArray(cur[key])) {
                    const nextKey = path[i + 1];
                    cur[key] = (typeof nextKey === 'number') ? [] : {};
                }
                cur = cur[key];
            }
            cur[path[path.length - 1]] = value;
        }

        function deleteAtPath(root, path) {
            if (!path.length) return;
            let cur = root;
            for (let i = 0; i < path.length - 1; i++) {
                const key = path[i];
                if (cur == null) return;
                cur = cur[key];
            }
            if (cur == null) return;
            delete cur[path[path.length - 1]];
        }

        function applyOpsToState(state, ops, useAfter) {
            ops.forEach(op => {
                const val = useAfter ? op.after : op.before;

                if (op.type === 'set') {
                    if (val === undefined) deleteAtPath(state, op.path);
                    else setAtPath(state, op.path, val);
                    return;
                }

                if (op.type === 'arr_item') {
                    const arr = getAtPath(state, op.path);
                    if (!Array.isArray(arr)) return;
                    const idStr = String(op.id);
                    const idx = arr.findIndex(it => it && it.id != null && String(it.id) === idStr);
                    if (val === undefined) {
                        if (idx !== -1) arr.splice(idx, 1);
                        return;
                    }
                    if (idx !== -1) arr[idx] = val;
                    else arr.push(val);
                    return;
                }

                if (op.type === 'arr_order') {
                    const arr = getAtPath(state, op.path);
                    if (!Array.isArray(arr)) return;
                    const order = Array.isArray(val) ? val.map(String) : [];
                    const byId = new Map();
                    arr.forEach(it => {
                        if (it && it.id != null) byId.set(String(it.id), it);
                    });
                    const reordered = [];
                    order.forEach(id => {
                        const key = String(id);
                        if (byId.has(key)) {
                            reordered.push(byId.get(key));
                            byId.delete(key);
                        }
                    });
                    byId.forEach(v => reordered.push(v));
                    arr.length = 0;
                    reordered.forEach(v => arr.push(v));
                }
            });
            return state;
        }

        function resetUndoHistory(markDirty = false) {
            undoStack = [];
            redoStack = [];
            undoCurrentState = captureState();
            if (markDirty) hasUnsavedChanges = true;
            rebuildStructureList();
        }

        function runUndoable(fn, markDirty = true) {
            if (typeof fn !== 'function') return;
            const before = captureState();
            fn();
            const after = captureState();
            const ops = diffStates(before, after);
            if (!ops.length) {
                undoCurrentState = after;
                return;
            }
            undoStack.push({ ops });
            if (undoStack.length > 50) undoStack.shift();
            redoStack = [];
            undoCurrentState = after;
            if (markDirty) hasUnsavedChanges = true;
            rebuildStructureList();
        }

        function undo() {
            if (!undoStack.length) return;
            const entry = undoStack.pop();
            if (!undoCurrentState) undoCurrentState = captureState();
            undoCurrentState = applyOpsToState(undoCurrentState, entry.ops, false);
            redoStack.push(entry);
            applyState(undoCurrentState);
            undoCurrentState = captureState();
        }

        function redo() {
            if (!redoStack.length) return;
            const entry = redoStack.pop();
            if (!undoCurrentState) undoCurrentState = captureState();
            undoCurrentState = applyOpsToState(undoCurrentState, entry.ops, true);
            undoStack.push(entry);
            applyState(undoCurrentState);
            undoCurrentState = captureState();
        }

        // Секция ені өзгерту
        function resizeSectionWidth(sectionId, newWidth) {
            if (!sections.length) return;
            const minW = 100;

            const sorted = sections.slice().sort((a,b)=>a.x - b.x);
            const idx = sorted.findIndex(s => s.id === sectionId);
            if (idx === -1) return;

            const sec = sorted[idx];
            const delta = newWidth - sec.w;

            let neighborIndex = -1;
            if (idx < sorted.length - 1) {
                neighborIndex = idx + 1;
            } else if (idx > 0) {
                neighborIndex = idx - 1;
            } else {
                sec.w = newWidth;
                sec.x = 0;
                sections = sorted.map(s => ({...s}));
                createCabinet(currentW, currentH, currentD, true);
                setViewMode(currentViewMode);
                return;
            }

            const neigh = sorted[neighborIndex];
            if (neigh.w - delta < minW) {
                return;
            }

            sec.w = newWidth;
            if (neighborIndex > idx) {
                neigh.x = sec.x + sec.w;
            } else {
                sec.x = neigh.x + neigh.w - sec.w;
            }
            neigh.w -= delta;

            sorted[0].x = 0;
            for (let i = 1; i < sorted.length; i++) {
                sorted[i].x = sorted[i-1].x + sorted[i-1].w;
            }

            sections = sorted.map(s => ({...s}));
            createCabinet(currentW, currentH, currentD, true);
            setViewMode(currentViewMode);
        }


        // Секцияны өшіру
        function deleteSection(sectionId) {
            if (!sections.length) return;
            const sorted = sections.slice().sort((a, b) => a.x - b.x);
            const idx = sorted.findIndex(s => s.id === sectionId);
            if (idx === -1) return;

            const removed = sorted[idx];

            // Қай көршіге қосамыз – алдымен сол жақ, болмаса оң жақ
            let neighborIndex;
            if (idx > 0) {
                neighborIndex = idx - 1;
            } else {
                neighborIndex = idx + 1;
            }

            const neighbor = sorted[neighborIndex];
            neighbor.w += removed.w;

            // Өшірілген секцияның полкаларын да тазалаймыз
            delete sectionShelves[removed.id];

            // Тізімнен алып тастау
            sorted.splice(idx, 1);

            // x координаттарын қайта есептеу
            sorted[0].x = 0;
            for (let i = 1; i < sorted.length; i++) {
                sorted[i].x = sorted[i - 1].x + sorted[i - 1].w;
            }

            sections = sorted.map(s => ({ ...s }));

            // Таңдалған секцияны жаңарту
            if (selectedSectionId === sectionId) {
                selectedSectionId = neighbor.id;
                selectedShelfSubId = null;
            }

            // Қайта салу
            createCabinet(currentW, currentH, currentD, true);
            setViewMode(currentViewMode);
        }

        // Секцияны pattern бойынша бөлу
        function splitSectionByPattern(selectedId, pattern) {
            if (!sections.length) return;
            const partsArr = pattern.split('/').map(v => parseFloat(v)).filter(n => n > 0);
            if (!partsArr.length) return;

            const idx = sections.findIndex(s => s.id === selectedId);
            if (idx === -1) return;

            const sec = sections[idx];
            const total = partsArr.reduce((a,b)=>a+b, 0);
            let curX = sec.x;
            const newList = [];

            for (let i = 0; i < partsArr.length; i++) {
                const w = sec.w * partsArr[i] / total;
                const ns = {
                    id: (i === 0 ? sec.id : nextSectionId++),
                    x: curX,
                    y: sec.y,
                    w: w,
                    h: sec.h
                };
                newList.push(ns);
                curX += w;
            }

            sections.splice(idx, 1, ...newList);
            delete sectionShelves[sec.id];
            selectedShelfSubId = null;

            selectedSectionId = newList[0].id;
            createCabinet(currentW, currentH, currentD, true);
            setViewMode(currentViewMode);
        }

        // Вертикаль стойкалар
        function rebuildDividers(bodyMatColor) {
            if (!cabinetGroup) return;

            if (dividersGroup) {
                if (bodyCore) bodyCore.remove(dividersGroup);
                else cabinetGroup.remove(dividersGroup);
                dividersGroup.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
            }
            dividersGroup = new THREE.Group();

            const innerParams = computeInnerParams();
            const depthInside = innerParams.depthInside;
            const geom = new THREE.BoxGeometry(globalThickness, innerH, depthInside);

            const sorted = sections.slice().sort((a,b)=>a.x - b.x);

            // Фасад түріне қарай стойка позициясы
            const facadeTypeEl  = document.getElementById('facadeType');
            const facadeTypeVal = facadeTypeEl ? facadeTypeEl.value : 'vkladnoy';

            const useFacadeCenters =
                facadeTypeVal === 'nakladnoy' &&
                Array.isArray(facadeDividerCenters) &&
                facadeDividerCenters.length >= Math.max(0, sorted.length - 1);

            for (let i = 1; i < sorted.length; i++) {
                const boundaryX = sorted[i].x;

                const divider = solidWithEdges(geom.clone(), bodyMatColor, {
                    type: 'divider',
                    name: 'Стойка ' + i,
                    sectionId: null,
                    width: globalThickness,
                    height: innerH,
                    depth: depthInside
                });

                // Divider-дің жергілікті X позициясы:
                // - cabinetGroup өзінің осіне W/2 ығысқан, сондықтан мұнда қосымша offset қоспау керек.
                // - boundaryX ішкі ен (0..innerW) бойынша өлшенеді, сондықтан оны -innerW/2-ге қатысты қоямыз.
                let xWorld;
                if (useFacadeCenters) {
                    // Накладной фасад: стойка екі фасад арасындағы зазордың ортасына қойылады (локал координата)
                    xWorld = facadeDividerCenters[i - 1];
                } else {
                    // Қалған жағдай: ескі логика – секция шекарасы бойынша
                    xWorld = boundaryX - innerW / 2;
                }

                const yWorld = plinthHeight + globalThickness + innerH/2;
                divider.position.set(xWorld, yWorld, innerParams.centerZ);
                dividersGroup.add(divider);
            }

            (bodyCore || cabinetGroup).add(dividersGroup);
        }

        // Кабинетті салу
        function createCabinet(W, H, D, preserveLayout) {
            refreshNextSectionIdGlobal();
            cabinetSpawned = true;
            let oldSections = null;
            let oldShelves  = null;
            let oldShelfOffsets = null;
            let prevDoorStates = pendingDoorStates || null;
            pendingDoorStates = null;
            // Таңдалған бөлшек ескі шкафтан тасымалданбасын, UI босайтамыз
            clearSelectedPartSelection();

            if (preserveLayout && sections.length && innerW > 0 && innerH > 0) {
                oldSections = sections.map(s => ({...s}));
                oldShelves  = {};
                Object.keys(sectionShelves).forEach(id => {
                    oldShelves[id] = sectionShelves[id].slice();
                });
                oldShelfOffsets = { ...sectionShelfOffsets };
                prevInnerW = innerW;
                prevInnerH = innerH;
                if (!prevDoorStates && doorsGroup && doorsGroup.children) {
                    prevDoorStates = doorsGroup.children.map(h => !!(h.userData && h.userData.open));
                }
            } else {
                prevInnerW = 0;
                prevInnerH = 0;
            }

            if (cabinetGroup) {
                scene.remove(cabinetGroup);
                cabinetGroup.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
            }
            cabinetGroup          = new THREE.Group();
            innerVolumeMesh       = null;
            doorsGroup            = null;
            plinthGroup           = null;
            shelvesGroup          = null;
            insertsGroup          = null;
            dividersGroup         = null;
            falshGroup            = null;
            allMeshes             = [];
            allEdges              = [];
            parts                 = {};
            nextPartId            = 1;
            selectedShelfSubHelper = null;
            if (selectedPartBoxHelper) {
                scene.remove(selectedPartBoxHelper);
                selectedPartBoxHelper = null;
            }

            const totalW = W;
            const { left: falshLeft, right: falshRight, top: falshTop } = getFalshExtents();
            const bodyShiftX = (falshLeft - falshRight) / 2;
            const bodyW = Math.max(200, totalW - falshLeft - falshRight);
            bodyCore = new THREE.Group();
            bodyCore.position.x = bodyShiftX;

            currentW = totalW; currentH = H; currentD = D;
            globalDepth     = D;
            const facadeTypeEl  = document.getElementById('facadeType');
            const facadeTypeVal = facadeTypeEl ? facadeTypeEl.value : 'vkladnoy';

            const corpusMatVal  = corpusMaterial.value;
            const corpusColor   = getCorpusColor(corpusMatVal);
            globalThickness     = parseFloat(corpusThickness.value) || 16;
            const parsedGap = parseFloat(wallGapInput ? wallGapInput.value : '');
            wallGap = Number.isFinite(parsedGap) ? parsedGap : 10;

            const facadeMatVal  = facadeMaterial.value;
            const facadeColor   = getFacadeColor(facadeMatVal);
            const facadeThick   = parseFloat(facadeThickness.value) || 18;
            // facadeTypeVal already defined above

            const parsedPlinth = parseFloat(plinthHeightInput.value);
            plinthHeight = Number.isFinite(parsedPlinth) && parsedPlinth >= 0 ? parsedPlinth : 100;
            const backMaterialVal = backMaterial.value;
            const thickness = globalThickness;

            const bodyMatColor  = corpusColor;
            const carcassHeight = Math.max(50, H - plinthHeight - falshTop);

            // ===== ЦОКОЛЬ + НОЖКАЛАР =====
            plinthGroup = new THREE.Group();
            const hasPlinth = plinthHeight > 0;

            const legRadius = 20;
            const legColor  = 0x444444;
            const legGeo    = hasPlinth ? new THREE.CylinderGeometry(legRadius, legRadius, plinthHeight, 16) : null;

            function addLeg(x, z, name) {
                if (!hasPlinth || !legGeo) return;
                const legGroup = solidWithEdges(legGeo.clone(), legColor, {
                    type: 'leg',
                    name: name,
                    width: legRadius * 2,
                    height: plinthHeight,
                    depth: legRadius * 2
                });
                legGroup.position.set(x, plinthHeight / 2, z);
                plinthGroup.add(legGroup);
            }

            const legZoneWidth = Math.max(100, bodyW - 160);
            const segments = Math.max(1, Math.ceil(legZoneWidth / 600));
            const legsPerRow = segments + 1;
            if (hasPlinth) {
                for (let i = 0; i < legsPerRow; i++) {
                    const t = (legsPerRow === 1) ? 0.5 : (i / (legsPerRow - 1));
                    const x = -legZoneWidth / 2 + t * legZoneWidth;
                    addLeg(x,  D / 2 - 80, 'Ножка алдыңғы ' + (i + 1));
                    addLeg(x, -D / 2 + 80, 'Ножка артқы ' + (i + 1));
                }
            }

            // Алдыңғы цоколь панелі:
            // - қалыңдығы фасад қалыңдығымен бірдей
            // - алдынан 20 мм ішке кіреді
            const plinthBoardH = plinthHeight;
            // Дно түрі: вкладной болса, цоколь алдыңғы панелі екі боковинаның ішкі жағына дейін ғана (W - 2*thickness)
            // Накладной болса, толық ені W болып қалады
            const bottomMountPlinth = bottomMountInput ? (bottomMountInput.value || 'vkladnoy') : 'vkladnoy';
            const plinthBoardW = (bottomMountPlinth === 'vkladnoy') ? (bodyW - 2*thickness) : bodyW;
            // Вкладной дно болса, цоколь материалы корпус түсі/қалыңдығына сай болсын
            const plinthBoardT = (bottomMountPlinth === 'vkladnoy') ? thickness : facadeThick;
            const plinthMatColor = (bottomMountPlinth === 'vkladnoy') ? bodyMatColor : facadeColor;
            const frontOffset  = 20;

            const plinthBoardGeo = new THREE.BoxGeometry(plinthBoardW, plinthBoardH, plinthBoardT);
            const plinthEdge = { front:true, back:false, left:false, right:false };
            const plinthBoard = solidWithEdges(plinthBoardGeo, plinthMatColor, {
                type: 'plinth',
                name: 'Цоколь алдыңғы',
                width: plinthBoardW,
                height: plinthBoardH,
                depth: plinthBoardT,
                edge: plinthEdge
            });

            const plinthZ = D / 2 - frontOffset - plinthBoardT / 2;
            plinthBoard.position.set(0, plinthBoardH / 2, plinthZ);
            if (hasPlinth) {
                plinthGroup.add(plinthBoard);
            }

            if (hasPlinth) {
                bodyCore.add(plinthGroup);
            }

            // Корпус бүйірлері
            const bottomMountSide = bottomMountInput ? (bottomMountInput.value || 'vkladnoy') : 'vkladnoy';
            const sideStartsOnBottom = (bottomMountSide === 'nakladnoy');
            // Вкладной дно: бүйірлер плinth-тен төмен түсіп, цокольмен бір деңгейде тұрсын (0-ден басталады)
            // Накладной дно: бүйірлер дноның үстіне отырсын, қиылыспасын
            const sideStartY      = sideStartsOnBottom ? (plinthHeight + thickness) : 0;
            const sideHeight      = sideStartsOnBottom ? (carcassHeight - thickness) : (carcassHeight + plinthHeight);
            const sideCenterY     = sideStartY + sideHeight/2;

            const geomSide = new THREE.BoxGeometry(thickness, sideHeight, D);
            const left = solidWithEdges(geomSide, bodyMatColor, {
                type: 'side',
                name: 'Сол жақ бүйір',
                width: thickness,
                height: sideHeight,
                depth: D,
                mountType: bottomMountSide
            });
            left.position.set(-bodyW/2 + thickness/2, sideCenterY, 0);
            bodyCore.add(left);

            const right = solidWithEdges(geomSide.clone(), bodyMatColor, {
                type: 'side',
                name: 'Оң жақ бүйір',
                width: thickness,
                height: sideHeight,
                depth: D,
                mountType: bottomMountSide
            });
            right.position.set(bodyW/2 - thickness/2, sideCenterY, 0);
            bodyCore.add(right);

            // Төменгі дно
            const bottomMount = bottomMountInput ? (bottomMountInput.value || 'vkladnoy') : 'vkladnoy';
            const bottomWidth = (bottomMount === 'nakladnoy') ? bodyW : (bodyW - 2*thickness);

            const geomBottom = new THREE.BoxGeometry(bottomWidth, thickness, D);
            const bottom = solidWithEdges(geomBottom, bodyMatColor, {
                type: 'bottom',
                name: 'Асты',
                width: bottomWidth,
                height: thickness,
                depth: D,
                mountType: bottomMount
            });
            bottom.position.set(0, plinthHeight + thickness/2, 0);
            bodyCore.add(bottom);

            // Жоғарғы
            const geomTop = new THREE.BoxGeometry(bodyW - 2*thickness, thickness, D);
            const top = solidWithEdges(geomTop, bodyMatColor, {
                type: 'top',
                name: 'Төбесі',
                width: bodyW - 2*thickness,
                height: thickness,
                depth: D
            });
            top.position.set(0, plinthHeight + carcassHeight - thickness/2, 0);
            bodyCore.add(top);

            // Артқы қабырға (накладной)
            let backThick;
            let backWidth;
            let backHeight;
            let backZ;
            let backColorLocal;

            if (backMaterialVal === 'hdf') {
                backThick      = 4;
                backColorLocal = 0xf0f0f0;
            } else {
                backThick      = thickness;
                backColorLocal = bodyMatColor;
            }

            backWidth  = bodyW;
            backHeight = carcassHeight;
            backZ      = -D/2 - backThick / 2;

            // Координат басы: сол жақ артқы бұрышты (0,0) ету үшін ығыстыру
            cabinetOffsetX = totalW / 2;
            cabinetOffsetZ = D / 2 + backThick;
            const baseX = cabinetBaseOffset.x || 0;
            const baseY = cabinetBaseOffset.y || 0;
            const baseZ = cabinetBaseOffset.z || 0;
            cabinetGroup.position.set(cabinetOffsetX + baseX, baseY, cabinetOffsetZ + baseZ);
            cabinetGroup.rotation.y = cabinetRotationY || 0;

            const geomBack = new THREE.BoxGeometry(backWidth, backHeight, backThick);
            const backMesh = solidWithEdges(geomBack, backColorLocal, {
                type: 'back',
                name: (backMaterialVal === 'hdf' ? 'Артқы қабырға (ХДФ накладной)' : 'Артқы қабырға (ЛДСП накладной)'),
                width: backWidth,
                height: backHeight,
                depth: backThick,
                materialType: backMaterialVal,
                mountType: 'nakladnoy'
            });
            backMesh.position.set(0, plinthHeight + carcassHeight/2, backZ);
            bodyCore.add(backMesh);

            // Ішкі кеңістік
            innerW = bodyW - 2*thickness;
            innerH = carcassHeight - 2*thickness;

            if (oldSections && prevInnerW > 0 && prevInnerH > 0) {
                const sx = innerW / prevInnerW;
                const sy = innerH / prevInnerH;
                let maxId = 0;
                sections = oldSections.map(s => {
                    const ns = {
                        id: s.id,
                        x: s.x * sx,
                        y: s.y * sy,
                        w: s.w * sx,
                        h: s.h * sy
                    };
                    if (ns.id > maxId) maxId = ns.id;
                    return ns;
                });
                nextSectionId = maxId + 1;

                sectionShelves = {};
                if (oldShelves) {
                    Object.keys(oldShelves).forEach(id => {
                        const arr = oldShelves[id].map(h => h * sy);
                        sectionShelves[id] = arr;
                    });
                }
                sectionShelfOffsets = {};
                if (oldShelfOffsets) {
                    // Тереңдік өзгерсе, отступты жаңа ішкі тереңдікке сай қысқартамыз
                    const innerParamsNew = computeInnerParams();
                    const maxOffset = Math.max(0, innerParamsNew.depthInside - 10);
                    Object.keys(oldShelfOffsets).forEach(id => {
                        const v = Math.min(Math.max(0, oldShelfOffsets[id]), maxOffset);
                        sectionShelfOffsets[id] = v;
                    });
                }
                if (selectedSectionId) {
                    const exists = sections.some(s => s.id === selectedSectionId);
                    if (!exists && sections.length) {
                        selectedSectionId = sections[0].id;
                    }
                }
            } else {
                sections = [{
                    id: nextSectionId++,
                    x: 0,
                    y: 0,
                    w: innerW,
                    h: innerH
                }];
                selectedSectionId = sections[0].id;
                sectionShelves = {};
            }

            const innerParams = computeInnerParams();

            const innerGeo = new THREE.BoxGeometry(innerW, innerH, innerParams.depthInside);
            const innerMat = new THREE.MeshBasicMaterial({visible: false});
            innerVolumeMesh = new THREE.Mesh(innerGeo, innerMat);
            innerVolumeMesh.position.set(0, plinthHeight + thickness + innerH/2, innerParams.centerZ);
            bodyCore.add(innerVolumeMesh);

            // ===== ФАСАДТАР (pattern бойынша: 1 – 1 есік, 2 – 2 есік және т.б.) =====
            doorsGroup = new THREE.Group();
            doorsGroup.userData.isDoorsGroup = true;
            doorsGroup.userData.splitPattern = splitPatternInput ? splitPatternInput.value : '';

            const doorT        = facadeThick;
            const isVkladnoy   = (facadeTypeVal === 'vkladnoy');
            const edgeGap      = isVkladnoy ? 3 : 1.5; // шеткі зазор
            const betweenGap   = 3;                   // фасадтар арасы 3 мм

            // Pattern оқу: мысалы "2/1", "1/2", "1/1/1"
            let patternArray = [];
            if (splitPatternInput && splitPatternInput.value) {
                patternArray = splitPatternInput.value
                    .split('/')
                    .map(function (v) {
                        const n = parseInt(v.trim(), 10);
                        return (isNaN(n) || n <= 0) ? 1 : n;
                    })
                    .filter(function (n) { return n > 0; });
            }
            const sortedSections = sections.slice().sort((a, b) => a.x - b.x);
            const nSections      = sortedSections.length;

            if (!patternArray.length) {
                patternArray = new Array(nSections).fill(1);
            }

            // Биіктік (Y)
            let doorH, openingCenterY;
            if (isVkladnoy) {
                const gapTopBot    = 3;
                doorH              = Math.max(10, innerH - 2 * gapTopBot);
                const openingBottomY = plinthHeight + thickness + gapTopBot;
                openingCenterY     = openingBottomY + doorH / 2;
            } else {
                const gapTopBot    = edgeGap; // 1.5
                const carcH        = carcassHeight;
                doorH              = Math.max(10, carcH - 2 * gapTopBot);
                const openingBottomY = plinthHeight + gapTopBot;
                openingCenterY     = openingBottomY + doorH / 2;
            }

            // Тереңдік (Z)
            let doorZCenter;
            if (isVkladnoy) {
                doorZCenter = D / 2 - doorT / 2 - 1;
            } else {
                doorZCenter = D / 2 + doorT / 2 + 1; // шкаф фронтынан 1 мм алға шығарамыз
            }

            const facadeStyleVal = (typeof facadeStyle !== 'undefined' && facadeStyle && facadeStyle.value)
                ? facadeStyle.value
                : 'modern';

            // Фасадтың стиліне қарай (модерн / рамка / рефленный) есік геометриясын салатын функция
            // "Рамкамен" стилі – Shaker Slim сияқты: сыртында жұқа рамка, ортасы 3 мм төменірек панель
            
function buildDoorWithStyle(doorW, doorH, doorT, color, partInfo) {
                // Егер стиль көрсетілмесе немесе "модерн" болса – классикалық тегіс есік
                if (!facadeStyleVal || facadeStyleVal === 'modern') {
                    const geomDoor  = new THREE.BoxGeometry(doorW, doorH, doorT);
                    return solidWithEdges(geomDoor, color, partInfo);
                }

                // ---------------- SHAKER SLIM (рамкамен) ----------------
                // Ортасы рамкадан 5 мм артқа кетеді, рамка біртұтас контур (45°-пен қосылған сияқты)
                if (facadeStyleVal === 'frame') {
                    const group = new THREE.Group();

                    // Рамка ені – қолмен енгізілсе, соны қолданамыз, әйтпесе есік өлшеміне байланысты (30–80 мм)
                    let frameW = 0;
                    if (typeof facadeFrameWidthInput !== 'undefined' && facadeFrameWidthInput && facadeFrameWidthInput.value !== '') {
                        frameW = parseFloat(facadeFrameWidthInput.value) || 0;
                    }
                    if (!frameW || frameW <= 0) {
                        frameW = Math.min(doorW, doorH) * 0.08;
                    }
                    frameW = Math.max(30, Math.min(80, frameW));

                    // Панель рамкадан 5 мм ішкері
                    const insetZ  = 5;
                    const panelT  = Math.max(doorT - insetZ, 2);
                    const panelW  = Math.max(10, doorW - 2 * frameW);
                    const panelH  = Math.max(10, doorH - 2 * frameW);

                    // Орталық панель – BoxGeometry, артқы жағы рамкамен бірдей, алдыңғы жағы 5 мм төмен
                    const panelGeom  = new THREE.BoxGeometry(panelW, panelH, panelT);
                    const panelGroup = solidWithEdges(panelGeom, color, partInfo);
                    const zPanel     = -doorT / 2 + panelT / 2; // артқы беті -doorT/2 деңгейінде
                    panelGroup.position.set(0, 0, zPanel);
                    group.add(panelGroup);

                    // Біртұтас рамка – сыртқы және ішкі контурдан ExtrudeGeometry арқылы
                    const outerHalfW = doorW / 2;
                    const outerHalfH = doorH / 2;
                    const innerHalfW = panelW / 2;
                    const innerHalfH = panelH / 2;

                    const shape = new THREE.Shape();
                    shape.moveTo(-outerHalfW, -outerHalfH);
                    shape.lineTo( outerHalfW, -outerHalfH);
                    shape.lineTo( outerHalfW,  outerHalfH);
                    shape.lineTo(-outerHalfW,  outerHalfH);
                    shape.lineTo(-outerHalfW, -outerHalfH);

                    const hole = new THREE.Path();
                    hole.moveTo(-innerHalfW, -innerHalfH);
                    hole.lineTo( innerHalfW, -innerHalfH);
                    hole.lineTo( innerHalfW,  innerHalfH);
                    hole.lineTo(-innerHalfW,  innerHalfH);
                    hole.lineTo(-innerHalfW, -innerHalfH);
                    shape.holes.push(hole);

                    const extrudeSettings = {
                        depth: doorT,
                        bevelEnabled: false,
                        steps: 1
                    };
                    const frameGeom = new THREE.ExtrudeGeometry(shape, extrudeSettings);
                    // Ортаңғы жазықтыққа орталау
                    frameGeom.translate(0, 0, -doorT / 2);

                    // Егер материал шыны рамка болса, рамка қара, ортасы көк мөлдір
                    const isGlassFrame = partInfo && partInfo.materialType === 'glass_frame';
                    const frameColor   = isGlassFrame ? 0x444444 : color;
                    const panelColor   = isGlassFrame ? 0x6db7ff : color;

                    const frameMat  = new THREE.MeshPhongMaterial({ color: frameColor, shininess: 20 });
                    const frameMesh = new THREE.Mesh(frameGeom, frameMat);
                    frameMesh.castShadow = true;
                    frameMesh.receiveShadow = true;
                    frameMesh.userData.baseColor = frameColor;
                    if (typeof allMeshes !== 'undefined') {
                        allMeshes.push(frameMesh);
                    }

                    // Эскиз режимінде рамка жақсы көрінуі үшін edge қосамыз
                    const edgesGeo = new THREE.EdgesGeometry(frameGeom);
                    const edgesMat = new THREE.LineBasicMaterial({ color: 0x000000 });
                    const edges    = new THREE.LineSegments(edgesGeo, edgesMat);
                    frameMesh.add(edges);
                    if (typeof allEdges !== 'undefined') {
                        allEdges.push(edges);
                    }

                    // Панель материалын шыны етеміз
                    panelGroup.traverse(obj => {
                        if (!obj.isMesh) return;
                        obj.material = new THREE.MeshStandardMaterial({
                            color: panelColor,
                            metalness: isGlassFrame ? 0.0 : 0.2,
                            roughness: isGlassFrame ? 0.1 : 0.7,
                            transparent: isGlassFrame,
                            opacity: isGlassFrame ? 0.35 : 1.0
                        });
                        obj.userData.baseColor = panelColor;
                        if (isGlassFrame) obj.userData.isGlass = true;
                    });

                    group.add(frameMesh);
                    return group;
                }

                // ---------------- РЕФЛЕННЫЙ ----------------
                if (facadeStyleVal === 'refl') {
                    const geomDoor  = new THREE.BoxGeometry(doorW, doorH, doorT);
                    const doorGroup = solidWithEdges(geomDoor, color, partInfo);

                    let baseMesh = null;
                    doorGroup.traverse(obj => {
                        if (obj.isMesh && !baseMesh) baseMesh = obj;
                    });

                    const baseMat = baseMesh
                        ? baseMesh.material
                        : new THREE.MeshPhongMaterial({ color: color });

                    const insetX = Math.min(doorW * 0.10, 80);
                    const insetY = Math.min(doorH * 0.10, 80);

                    const areaW  = Math.max(80, doorW - insetX * 2);
                    const areaH  = Math.max(80, doorH - insetY * 2);

                    const stripeCount = 7;
                    const gapRatio    = 0.7;
                    const unit        = areaW / (stripeCount + (stripeCount - 1) * gapRatio);
                    const stripeW     = unit;
                    const gapW        = unit * gapRatio;

                    const depth   = 3;
                    const stripeT = Math.max(doorT - depth, 2);
                    const zStripe = -doorT / 2 + stripeT / 2; // артқы беті бірдей

                    let x = -areaW / 2 + stripeW / 2;
                    for (let i = 0; i < stripeCount; i++) {
                        const geom = new THREE.BoxGeometry(stripeW, areaH, stripeT);
                        const mat  = baseMat.clone();
                        mat.color.offsetHSL(0, 0, -0.08);

                        const mesh = new THREE.Mesh(geom, mat);
                        mesh.castShadow = true;
                        mesh.receiveShadow = true;
                        mesh.position.set(x, 0, zStripe);

                        const eGeo = new THREE.EdgesGeometry(geom);
                        const eMat = new THREE.LineBasicMaterial({ color: 0x000000 });
                        const e    = new THREE.LineSegments(eGeo, eMat);
                        mesh.add(e);
                        if (typeof allEdges !== 'undefined') {
                            allEdges.push(e);
                        }

                        doorGroup.add(mesh);
                        x += stripeW + gapW;
                    }

                    return doorGroup;
                }

                // Белгісіз стильдер үшін – жай тегіс есік
                const geomDoor  = new THREE.BoxGeometry(doorW, doorH, doorT);
                return solidWithEdges(geomDoor, color, partInfo);
            }
            if (isVkladnoy) {
                // ВКЛАДНОЙ: innerW бойынша, шеттері 3 мм, аралары 3 мм.
                const innerLeftWorld = -innerW / 2;

                sortedSections.forEach((sec, secIndex) => {
                    const slots = patternArray[secIndex] || 1; // осы секциядағы есік саны

                    const isFirst = (secIndex === 0);
                    const isLast  = (secIndex === nSections - 1);

                    const gLeft  = isFirst ? edgeGap : betweenGap / 2;
                    const gRight = isLast  ? edgeGap : betweenGap / 2;

                    const secInnerLeftWorld = innerLeftWorld + sec.x;
                    const baseX             = secInnerLeftWorld + gLeft;
                    const availWidth        = Math.max(10, sec.w - gLeft - gRight);

                    const totalInternalGap  = betweenGap * Math.max(0, slots - 1);
                    const doorW             = Math.max(
                        10,
                        (availWidth - totalInternalGap) / slots
                    );

                    for (let j = 0; j < slots; j++) {
                        const leftX = baseX + j * (doorW + betweenGap);

                        const doorGroup = buildDoorWithStyle(doorW, doorH, doorT, facadeColor, {
                            type: 'door',
                            name: 'Есік секция ' + sec.id + ' (' + (j + 1) + '/' + slots + ')',
                            width: doorW,
                            height: doorH,
                            depth: doorT,
                            sectionId: sec.id,
                            materialType: facadeMatVal
                        });

                        let doorMesh = null;
                        doorGroup.traverse(obj => {
                            if (obj.isMesh) doorMesh = obj;
                        });

                        const hinge = new THREE.Group();
                        // hinge сол жақ қырымен қойылады
                        doorGroup.position.set(doorW / 2, 0, 0);
                        hinge.add(doorGroup);

                        const hingeX = leftX;

                        hinge.position.set(hingeX, openingCenterY, doorZCenter);
                        hinge.userData.isDoorHinge = true;
                        hinge.userData.isDoor = true;
                        hinge.userData.open        = false;
                        hinge.userData.doorWidth   = doorW;
                        hinge.userData.doorGroup   = doorGroup;
                        hinge.userData.sign        = (slots === 1) ? -1 : (j === 0 ? -1 : +1); // 1 есік – солға, 2 – сол/оң

                        if (doorMesh) {
                            doorMesh.userData.isDoor = true;
                            doorMesh.userData.hinge  = hinge;
                        }

                        doorGroup.traverse(obj => {
                            if (!obj.isMesh) return;
                            obj.userData.isDoor = true;
                            obj.userData.hinge  = hinge;
                        });

                        doorsGroup.add(hinge);
                    }
                });
            } else {
                // НАКЛАДНОЙ: сыртқы W,H бойынша, pattern-ге қарай есіктер саны
                const facadeOuterW     = bodyW;
                const outerLeftWorld   = -facadeOuterW / 2;
                const totalInnerWidth  = innerW || 1;
                const totalFacadeWidth =
                    facadeOuterW - 2 * edgeGap - (nSections > 1 ? (nSections - 1) * betweenGap : 0);

                facadeDividerCenters = [];

                let cursor = outerLeftWorld + edgeGap;

                sortedSections.forEach((sec, secIndex) => {
                    const slots = patternArray[secIndex] || 1;

                    const ratio             = sec.w / totalInnerWidth;
                    const sectionAvailWidth = totalFacadeWidth * ratio;

                    const totalInternalGap  = betweenGap * Math.max(0, slots - 1);
                    const doorW             = Math.max(
                        10,
                        (sectionAvailWidth - totalInternalGap) / slots
                    );

                    for (let j = 0; j < slots; j++) {
                        const doorGroup = buildDoorWithStyle(doorW, doorH, doorT, facadeColor, {
                            type: 'door',
                            name: 'Есік секция ' + sec.id + ' (' + (j + 1) + '/' + slots + ')',
                            width: doorW,
                            height: doorH,
                            depth: doorT,
                            sectionId: sec.id,
                            materialType: facadeMatVal
                        });

                        let doorMesh = null;
                        doorGroup.traverse(obj => {
                            if (obj.isMesh) doorMesh = obj;
                        });

                        const hinge = new THREE.Group();
                        doorGroup.position.set(doorW / 2, 0, 0);
                        hinge.add(doorGroup);

                        const hingeX = cursor;

                        hinge.position.set(hingeX, openingCenterY, doorZCenter);
                        hinge.userData.isDoorHinge = true;
                        hinge.userData.isDoor = true;
                        hinge.userData.open        = false;
                        hinge.userData.doorWidth   = doorW;
                        hinge.userData.doorGroup   = doorGroup;
                        hinge.userData.sign        = (slots === 1) ? -1 : (j === 0 ? -1 : +1);

                        if (doorMesh) {
                            doorMesh.userData.isDoor = true;
                            doorMesh.userData.hinge  = hinge;
                        }

                        doorGroup.traverse(obj => {
                            if (!obj.isMesh) return;
                            obj.userData.isDoor = true;
                            obj.userData.hinge  = hinge;
                        });

                        doorsGroup.add(hinge);

                        cursor += doorW;
                        if (j < slots - 1) {
                            cursor += betweenGap; // секция ішіндегі есіктер арасындағы зазор
                        }
                    }

                    if (secIndex < nSections - 1) {
                        const gapCenter = cursor + betweenGap / 2;
                        facadeDividerCenters.push(gapCenter);

                        cursor += betweenGap; // секциялар арасындағы зазор
                    }
                });
            }

            bodyCore.add(doorsGroup);
            cabinetGroup.userData.doorsGroup = doorsGroup;
            doorsGroup.visible = !facadesHidden;
            // Бұрынғы есік ашық/жабық күйін қалпына келтіреміз
            if (prevDoorStates && Array.isArray(prevDoorStates)) {
                doorsGroup.children.forEach((hinge, idx) => {
                    const wantOpen = !!prevDoorStates[idx];
                    const sign = hinge.userData && hinge.userData.sign ? hinge.userData.sign : -1;
                    hinge.userData.open = wantOpen;
                    hinge.rotation.y = wantOpen ? sign * (Math.PI / 2) : 0;
                });
            }

            cabinetGroup.add(bodyCore);

            // Стойкалар
            rebuildDividers(bodyMatColor);

            // Полкалар
            rebuildShelvesGroup();
            rebuildFalshGroup();

            rebuildSectionSelect();
            updateSelectedSectionHelper();
            updateDimensionsBox();
            rebuildInsertsUI();
            rebuildDrawerSubList();

            // Осы cabinetId-мен бұрын сценада қалған group болса – тазалау
            disposeCabinetGroupsById(activeCabinetId);
            cabinetGroup.userData = cabinetGroup.userData || {};
            cabinetGroup.userData.cabinetId = activeCabinetId;

            scene.add(cabinetGroup);

            // Актив шкаф жазбасын жаңа group-пен синхрондап қоямыз
            const activeIdx = cabinets.findIndex(c => c.id === activeCabinetId);
            if (activeIdx !== -1) {
                cabinets[activeIdx].group = cabinetGroup;
            }

            rebuildDimensionHelpers();
            rebuildStructureList();

            controls.target.set(cabinetOffsetX + (cabinetBaseOffset.x || 0), plinthHeight + H/2 + (cabinetBaseOffset.y || 0), cabinetOffsetZ + (cabinetBaseOffset.z || 0));
            controls.update();

            setViewMode(currentViewMode);
            updatePartUI();
        }

        // Canvas size
        function resizeRenderer() {
            const w = wrap.clientWidth;
            const h = wrap.clientHeight;
            if (w <= 0 || h <= 0) return;
            renderer.setSize(w, h);

            const aspect = w / h;

            // Перспективалық камераға арналған аспект
            if (perspCamera) {
                perspCamera.aspect = aspect;
                perspCamera.updateProjectionMatrix();
            }

            // Орфографиялық камераға арналған frustum
            if (orthoCamera) {
                const maxSize = Math.max(currentW || 0, currentH || 0, currentD || 0, 1200);
                const orthoSize = maxSize * 0.7;
                orthoCamera.left   = -orthoSize * aspect;
                orthoCamera.right  =  orthoSize * aspect;
                orthoCamera.top    =  orthoSize;
                orthoCamera.bottom = -orthoSize;
                orthoCamera.near   = 1;
                orthoCamera.far    = 10000;
                orthoCamera.updateProjectionMatrix();
            }
        }
        window.addEventListener('resize', resizeRenderer);

        // Реалтайм: өлшем өзгергенде қайта сызу
        function updateSectionFromCabinet(W, H, opts) {
            if (!cabinetSpawned || !cabinetWallId || !cabinetSectionId) return;
            const wall = newWalls.find(w => w.id === cabinetWallId);
            if (!wall) return;
            const sections = ensureWallSections(wall);
            const idx = sections.findIndex(s => s.id === cabinetSectionId);
            if (idx === -1) return;
            sections[idx] = { ...sections[idx], w: W, h: H };
            if (!opts || opts.redraw !== false) {
                rebuildWallSectionList();
                rebuildNewWalls();
            }
        }

        function updateCabinetFromSection(preserveLayout) {
            if (!cabinetSpawned || !cabinetWallId || !cabinetSectionId) return;
            const wall = newWalls.find(w => w.id === cabinetWallId);
            if (!wall) return;
            const sections = ensureWallSections(wall);
            let sec = sections.find(s => s.id === cabinetSectionId);
            if (!sec && sections.length) {
                cabinetSectionId = sections[0].id;
                sec = sections[0];
            }
            if (!sec) return;

            const W = sec.w || parseFloat(widthInput.value) || 1000;
            const H = sec.h || parseFloat(heightInput.value) || 2200;
            const D = parseFloat(depthInput.value) || 600;

            readWallGap();
            const placement = computeCabinetPlacement(wall, sec, W, D);
            cabinetBaseOffset = placement.base;
            cabinetRotationY = placement.rotationY;

            widthInput.value = Math.round(W);
            heightInput.value = Math.round(H);
            createCabinet(W, H, D, preserveLayout);
            rebuildNewWalls();
            rebuildWallSectionList();
            applyActiveCabinetVisibility();
            syncActiveCabinetRecord();
        }

        function rebuildWithCurrentSize(preserveLayout) {
            if (!cabinetSpawned) return;
            const W = parseFloat(widthInput.value)  || 1000;
            const H = parseFloat(heightInput.value) || 2200;
            const D = parseFloat(depthInput.value)  || 600;
            readWallGap();
            if (cabinetWallId && cabinetSectionId) {
                const wall = newWalls.find(w => w.id === cabinetWallId);
                const sections = wall ? ensureWallSections(wall) : [];
                const sec = sections.find(s => s.id === cabinetSectionId);
                if (wall && sec) {
                    const placement = computeCabinetPlacement(wall, sec, W, D);
                    cabinetBaseOffset = placement.base;
                    cabinetRotationY = placement.rotationY;
                }
            }
            updateSectionFromCabinet(W, H, { redraw: false });
            createCabinet(W, H, D, preserveLayout);
            rebuildNewWalls();
            rebuildWalls();
            setViewMode(currentViewMode);
            applyActiveCabinetVisibility();
            syncActiveCabinetRecord();
        }

        function findDrawerGroupFromObject(obj) {
            let o = obj;
            while (o) {
                if (o.userData && o.userData.isDrawerGroup) return o;
                o = o.parent;
            }
            return null;
        }

        function toggleDrawerSlide(group) {
            if (!group || !group.userData || !group.userData.isDrawerGroup) return;
            const opened = !!group.userData.open;
            const from = group.position.z;
            const offset = group.userData.openOffset || 250;
            const closedZ = group.userData.closedZ || group.position.z;
            const to = opened ? closedZ : closedZ + offset;
            group.userData.open = !opened;
            group.userData.closedZ = closedZ;
            drawerAnimations = drawerAnimations.filter(a => a.group !== group);
            drawerAnimations.push({
                group,
                from,
                to,
                start: performance.now ? performance.now() : Date.now(),
                duration: 350
            });
            if (drawerSound) {
                try {
                    drawerSound.currentTime = 0;
                    const p = drawerSound.play();
                    if (p && typeof p.catch === 'function') p.catch(()=>{});
                } catch (e) {}
            }
        }

        // 3D-дан таңдау
        renderer.domElement.addEventListener('click', (event) => {
            const rect = renderer.domElement.getBoundingClientRect();
            mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            raycaster.setFromCamera(mouse, activeCamera);

            // Алдымен: егер анимация қосулы болса, есікті тікелей басу арқылы ашу/жабу
            if (doorAnimEnabled && !facadesHidden) {
                const doorGroups = getAllDoorGroups();
                const doorMeshes = doorGroups.flatMap(g => g ? g.children : []);
                const doorIntersects = raycaster.intersectObjects(doorMeshes, true);
                if (doorIntersects.length) {
                    const hit = doorIntersects[0].object;
                    let doorMesh = hit;
                    // Есіктің нақты mesh-іне дейін көтерілеміз
                    while (doorMesh && !doorMesh.userData.isDoor && doorMesh.parent) {
                        doorMesh = doorMesh.parent;
                    }
                    if (doorMesh && doorMesh.userData && doorMesh.userData.hinge) {
                        animateDoorHinge(doorMesh.userData.hinge);
                        return; // есікті басқан болсақ, ары қарай өңдемейміз
                    }
                }
            }

            // Стена секциясындағы плюс – шкафты құру
            if (wallSectionPlusSprites.length) {
                const plusHits = raycaster.intersectObjects(wallSectionPlusSprites, true);
                if (plusHits.length) {
                    const hit = plusHits[0].object;
                    const data = hit.userData || {};
                    if (data.isWallSectionPlus && data.wallId) {
                        spawnCabinetForSection(data.wallId, data.sectionId);
                        return;
                    }
                }
            }

            if (selectionMode === 'cabinet') {
                const groups = getAllCabinetGroups().map(c => c.group).filter(Boolean);
                const intersects = raycaster.intersectObjects(groups, true);
                if (intersects.length) {
                    const hit = intersects[0].object;
                    let targetGroup = hit;
                    const set = new Set(groups);
                    while (targetGroup && targetGroup.parent && !set.has(targetGroup)) {
                        targetGroup = targetGroup.parent;
                    }
                    const rec = getAllCabinetGroups().find(c => c.group === targetGroup);
                    if (rec && rec.cabinet) {
                        setActiveCabinet(rec.cabinet.id);
                        rebuildStructureList();
                        rebuildSectionSelect();
                        rebuildShelvesUI();
                        rebuildDimensionHelpers();
                    }
                }
                return;
            }

            if (selectionMode === 'part') {
                // Қай шкафқа тиіп тұрғанын анықтап, қажет болса сол шкафты активтейміз
                const allCabGroups = getAllCabinetGroups();
                const cabGroupsOnly = allCabGroups.map(c => c.group).filter(Boolean);
                const cabHits = raycaster.intersectObjects(cabGroupsOnly, true);
                if (cabHits.length) {
                    let root = cabHits[0].object;
                    const groupSet = new Set(cabGroupsOnly);
                    while (root && root.parent && !groupSet.has(root)) {
                        root = root.parent;
                    }
                    const rec = allCabGroups.find(c => c.group === root);
                    if (rec && rec.cabinet && rec.cabinet.id !== activeCabinetId) {
                        setActiveCabinet(rec.cabinet.id);
                    }
                }

                const findMeshWithPart = (hits) => {
                    for (const h of hits || []) {
                        let o = h.object;
                        // Edges → parent mesh
                        if (o.type === 'LineSegments' && o.__parentMesh) {
                            o = o.__parentMesh;
                        }
                        while (o && !o.userData.partId && o.parent) {
                            o = o.parent;
                        }
                        if (o && o.userData.partId && parts[o.userData.partId]) {
                            const p = parts[o.userData.partId];
                            if (facadesHidden && p.type === 'door') continue;
                            if (p.extra && p.extra.hidden) continue;
                            return o;
                        }
                    }
                    return null;
                };

                const activeGroupEntry = getAllCabinetGroups().find(c => c.cabinet && c.cabinet.id === activeCabinetId);
                const activeGroup = activeGroupEntry ? activeGroupEntry.group : cabinetGroup;
                const allHits = activeGroup ? raycaster.intersectObject(activeGroup, true) : [];
                let mesh = null;
                if (insertsGroup) {
                    const insertHits = raycaster.intersectObject(insertsGroup, true);
                    mesh = findMeshWithPart(insertHits);
                }
                if (!mesh) {
                    mesh = findMeshWithPart(allHits);
                }

                if (!mesh) return;
                const pid  = mesh.userData.partId;
                if (pid && parts[pid]) {
                    const p = parts[pid];

                    // Анимация режимінде ящикті басқанда алдыға жылжиды
                    if (doorAnimEnabled) {
                        const dg = findDrawerGroupFromObject(mesh);
                        if (dg) {
                            toggleDrawerSlide(dg);
                        }
                    }

                    // Анимация режимінде есікті тек қозғап, бөлшек таңдалмайды
                    if (p.type === 'door' && mesh.userData.hinge && doorAnimEnabled) {
                        animateDoorHinge(mesh.userData.hinge);
                        return;
                    }

                    selectPart(pid);

                    const extra = p.extra || {};
                    if (extra.type === 'shelf' && extra.sectionId && extra.shelfHeight != null) {
                        selectedSectionId = extra.sectionId;
                        rebuildSectionSelect();
                        rebuildShelvesUI();
                        const opts = shelfSelect ? shelfSelect.options : [];
                        for (let i=0; i<opts.length; i++) {
                            if (parseFloat(opts[i].value) === extra.shelfHeight) {
                                shelfSelect.selectedIndex = i;
                                if (editShelfHeightInput) editShelfHeightInput.value = extra.shelfHeight;
                                break;
                            }
                        }
                    }
                }
                return;
            }

            if (selectionMode === 'section') {
                // Алдымен: қай шкафқа тигенін анықтап, сол шкафты активтейміз
                const cabHits = raycaster.intersectObjects(
                    getAllCabinetGroups().map(c => c.group).filter(Boolean),
                    true
                );
                if (cabHits.length) {
                    const hitObj = cabHits[0].object;
                    let rootGroup = hitObj;
                    const groupSet = new Set(getAllCabinetGroups().map(c => c.group).filter(Boolean));
                    while (rootGroup && rootGroup.parent && !groupSet.has(rootGroup)) {
                        rootGroup = rootGroup.parent;
                    }
                    const rec = getAllCabinetGroups().find(c => c.group === rootGroup);
                    if (rec && rec.cabinet && rec.cabinet.id !== activeCabinetId) {
                        setActiveCabinet(rec.cabinet.id);
                    }
                }

                // Анимация қосулы болса, секция режимінде де ящикті бірден ашамыз
                if (doorAnimEnabled && insertsGroup) {
                    const hitInserts = raycaster.intersectObject(insertsGroup, true);
                    if (hitInserts.length) {
                        const dg = findDrawerGroupFromObject(hitInserts[0].object);
                        if (dg) {
                            toggleDrawerSlide(dg);
                            return;
                        }
                    }
                }
            }

            // selectionMode === 'section'
            if (!innerVolumeMesh || !sections.length) return;
            const intersects = raycaster.intersectObject(innerVolumeMesh, false);
            if (!intersects.length) return;

            const pWorld = intersects[0].point.clone();
            const p = pWorld.clone();
            innerVolumeMesh.worldToLocal(p);
            const sx = p.x + innerW / 2;
            const sy = p.y + innerH / 2;

            let found = null;
            for (const sec of sections) {
                if (
                    sx >= sec.x && sx <= sec.x + sec.w &&
                    sy >= sec.y && sy <= sec.y + sec.h
                ) {
                    found = sec;
                    break;
                }
            }
            if (!found) return;

            selectedSectionId = found.id;
            rebuildSectionSelect();
            updateSelectedSectionHelper();
            rebuildShelvesUI();
            setViewMode(currentViewMode);
        });

        // Hover кезінде есікке жақындағанда қол курсоры шығу
        renderer.domElement.addEventListener('mousemove', (event) => {
            const rect = renderer.domElement.getBoundingClientRect();
            mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            raycaster.setFromCamera(mouse, activeCamera);

            let cursor = '';
            if (doorAnimEnabled && !facadesHidden) {
                const doorGroups = getAllDoorGroups();
                const doorMeshes = doorGroups.flatMap(g => g ? g.children : []);
                const doorIntersects = raycaster.intersectObjects(doorMeshes, true);
                if (doorIntersects.length) {
                    const hit = doorIntersects[0].object;
                    let doorMesh = hit;
                    while (doorMesh && !doorMesh.userData.isDoor && doorMesh.parent) {
                        doorMesh = doorMesh.parent;
                    }
                    if (doorMesh && doorMesh.userData && doorMesh.userData.hinge) {
                        cursor = 'pointer';
                    }
                }
                if (!cursor && insertsGroup) {
                    const insertHits = raycaster.intersectObject(insertsGroup, true);
                    if (insertHits.length) {
                        const dg = findDrawerGroupFromObject(insertHits[0].object);
                        if (dg) cursor = 'pointer';
                    }
                }
            }
            renderer.domElement.style.cursor = cursor || '';
        });
// SAVE / LOAD (JSON)
        if (saveProjectBtn) {
            saveProjectBtn.addEventListener('click', () => {
                try {
                    const state = captureState();
                    const blob = new Blob(
                        [JSON.stringify(state, null, 2)],
                        {type:'application/json'}
                    );
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    const dateStr = new Date().toISOString().slice(0,19).replace(/[:T]/g,'-');
                    a.href = url;
                    a.download = 'qdesign_shkaf_' + dateStr + '.json';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                    hasUnsavedChanges = false;
                } catch (e) {
                    showError('Сақтау қатесі: ' + e.message);
                }
            });
        }

        if (loadProjectBtn && loadProjectInput) {
            loadProjectBtn.addEventListener('click', () => {
                loadProjectInput.click();
            });
            loadProjectInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
	                reader.onload = function(ev) {
	                    try {
	                        const data = JSON.parse(ev.target.result);
	                        applyState(data);
	                        resetUndoHistory(false);
	                        hasUnsavedChanges = false;
	                    } catch (err) {
	                        showError('Файлды оқу қатесі: ' + err.message);
	                    }
	                };
                reader.readAsText(file);
                loadProjectInput.value = '';
            });
        }

        // Алғашқы старт
        function init() {
            resizeRenderer();
            cabinetSpawned = false;
            cabinets = [];
            activeCabinetId = null;
            falshPanels = [];
            nextFalshId = 1;
            falshLeftSideEnabled = false;
            falshRightSideEnabled = false;
            falshLeftSideSize = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
            falshRightSideSize = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
            if (falshLeftSideCheckbox) falshLeftSideCheckbox.checked = false;
            if (falshRightSideCheckbox) falshRightSideCheckbox.checked = false;
            if (falshLeftSideSizeInput) falshLeftSideSizeInput.value = Math.round(falshLeftSideSize);
            if (falshRightSideSizeInput) falshRightSideSizeInput.value = Math.round(falshRightSideSize);
            bodyCore = null;
            walls = [];
            wallEnabled = false;
            selectedWallId = null;
	            rebuildNewWallList();
	            rebuildNewWalls();
	            setViewMode(currentViewMode);
	            resetUndoHistory(false);
	            hasUnsavedChanges = false;
	            rebuildCabinetList();
	            rebuildCabinetIcons();
	            rebuildFalshList();
	        }
        window.addEventListener('load', init);

        // Парақтан шығу/жаңарту алдында растау попапы
        window.addEventListener('beforeunload', (e) => {
            if (!hasUnsavedChanges) return;
            e.preventDefault();
            e.returnValue = '';
        });

        function animate() {
            requestAnimationFrame(animate);
            const now = performance.now ? performance.now() : Date.now();

            // Есіктер үшін плавная анимация (open/close)
            if (doorAnimations && doorAnimations.length) {
                for (let i = doorAnimations.length - 1; i >= 0; i--) {
                    const anim = doorAnimations[i];
                    const tRaw = (now - anim.start) / anim.duration;
                    const t    = Math.max(0, Math.min(1, tRaw));

                    // easeInOutQuad
                    const k = (t < 0.5)
                        ? 2 * t * t
                        : -1 + (4 - 2 * t) * t;

                    if (anim.hinge && anim.hinge.rotation) {
                        const angle = anim.from + (anim.to - anim.from) * k;
                        anim.hinge.rotation.y = angle;
                    }

                    if (t >= 1) {
                        doorAnimations.splice(i, 1);
                    }
                }
            }
            // Ящиктерді сырғыту анимациясы
            if (drawerAnimations && drawerAnimations.length) {
                for (let i = drawerAnimations.length - 1; i >= 0; i--) {
                    const anim = drawerAnimations[i];
                    const tRaw = (now - anim.start) / anim.duration;
                    const t    = Math.max(0, Math.min(1, tRaw));

                    const k = (t < 0.5)
                        ? 2 * t * t
                        : -1 + (4 - 2 * t) * t;

                    if (anim.group && anim.group.position) {
                        const posZ = anim.from + (anim.to - anim.from) * k;
                        anim.group.position.z = posZ;
                    }
                    if (t >= 1) {
                        drawerAnimations.splice(i, 1);
                    }
                }
            }

            animateSectionHighlight(now);

            renderer.render(scene, activeCamera);
            updateDimensionLabelAngles();
        }
        animate();


        // =========================
        // Сол жақтағы вид иконкалары (Алды / Жаны / Үсті / Изометрия)
        // =========================

        function setAxisView(type) {
            currentAxisView = type || 'iso';
            let targetX = cabinetOffsetX;
            let targetY = plinthHeight + (currentH || 0) * 0.5;
            let targetZ = cabinetOffsetZ;
            let sizeVec = new THREE.Vector3(currentW || 0, currentH || 0, currentD || 0);

            const activeGroup = cabinets.find(c => c.id === activeCabinetId)?.group || cabinetGroup;
            if (activeGroup) {
                const box = new THREE.Box3().setFromObject(activeGroup);
                if (box.isBox3 && box.isEmpty() === false) {
                    const center = new THREE.Vector3();
                    const size = new THREE.Vector3();
                    box.getCenter(center);
                    box.getSize(size);
                    targetX = center.x;
                    targetY = center.y;
                    targetZ = center.z;
                    sizeVec = size;
                }
            }

            // Шкаф габаритіне қарай дистанция есептейміз
            const maxSize = Math.max(sizeVec.x || 0, sizeVec.y || 0, sizeVec.z || 0, 1200);
            const centerY = targetY;

            // Экран аспектісі бойынша орфо камера көлемі
            const aspect = (renderer.domElement.clientWidth || 800) / (renderer.domElement.clientHeight || 600);
            const orthoSize = maxSize * 0.7;

            // Орто камераның frustum-ы
            orthoCamera.left   = -orthoSize * aspect;
            orthoCamera.right  =  orthoSize * aspect;
            orthoCamera.top    =  orthoSize;
            orthoCamera.bottom = -orthoSize;
            orthoCamera.near   = 1;
            orthoCamera.far    = 10000;
            orthoCamera.updateProjectionMatrix();

            if (type === 'front') {
                // Алды вид – Z осі бойымен қарап тұрған параллель проекция
                orthoCamera.position.set(targetX, centerY, maxSize * 2.0 + targetZ);
                orthoCamera.lookAt(targetX, centerY, targetZ);
                activeCamera = orthoCamera;
                controls.object = activeCamera;
                controls.enableRotate = false;
            } else if (type === 'side') {
                // Жаны вид – X осі бойымен
                orthoCamera.position.set(maxSize * 2.0 + targetX, centerY, targetZ);
                orthoCamera.lookAt(targetX, centerY, targetZ);
                activeCamera = orthoCamera;
                controls.object = activeCamera;
                controls.enableRotate = false;
            } else if (type === 'top') {
                // Үсті вид – Y осі бойымен
                orthoCamera.position.set(targetX, maxSize * 2.0 + centerY, targetZ);
                orthoCamera.lookAt(targetX, centerY, targetZ);
                activeCamera = orthoCamera;
                controls.object = activeCamera;
                controls.enableRotate = false;
            } else if (type === 'iso') {
                // Изометрия – перспективалық камера
                const isoDist = maxSize * 1.8;
                perspCamera.position.set(isoDist + targetX, isoDist * 0.7 + centerY, isoDist + targetZ);
                perspCamera.lookAt(targetX, centerY, targetZ);
                activeCamera = perspCamera;
                controls.object = activeCamera;
                controls.enableRotate = true;
            }

            controls.target.set(targetX, centerY, targetZ);
            controls.update();
            updateDimensionLabelAngles();
            updateWallDecorations();
        } if (viewToolbar) {
            viewToolbar.addEventListener('click', function (e) {
                const btn = e.target.closest('button');
                if (!btn || !btn.dataset.cam) return;
                setAxisView(btn.dataset.cam);
            });
        }

        if (structureBtn) {
            structureBtn.addEventListener('click', () => {
                structureVisible = !structureVisible;
                if (structureVisible) rebuildStructureList();
                syncStructureVisibility();
            });
            syncStructureVisibility();
        } else {
            syncStructureVisibility();
        }

        if (cabinetDeleteBtn) {
            cabinetDeleteBtn.addEventListener('click', () => {
                if (!activeCabinetId) {
                    showError('Өшіру үшін алдымен шкафты таңдаңыз');
                    return;
                }
                const ok = window.confirm('Белгіленген шкафты өшіреміз бе?');
                if (!ok) return;
                removeCabinet(activeCabinetId);
                rebuildStructureList();
                rebuildCabinetIcons();
                syncStructureVisibility();
            });
        }

        if (cabinetHideBtn) {
            cabinetHideBtn.addEventListener('click', () => {
                if (!activeCabinetId) {
                    showError('Жасыру үшін алдымен шкафты таңдаңыз');
                    return;
                }
                const hidden = isCabinetHidden(activeCabinetId);
                setCabinetHidden(activeCabinetId, !hidden);
                syncCabinetVisibilityBtn();
            });
        }

        if (animToggleBtn) {
            animToggleBtn.addEventListener('click', () => {
                doorAnimEnabled = !doorAnimEnabled;
                animToggleBtn.classList.toggle('active', doorAnimEnabled);
                // Өшіргенде барлық есік жабылсын
                if (!doorAnimEnabled) {
                    const doorGroups = getAllDoorGroups();
                    doorGroups.forEach(g => {
                        if (!g || !g.children) return;
                        g.children.forEach(h => {
                            const hinge = h.userData && h.userData.hinge;
                            if (hinge && hinge.rotation) hinge.rotation.y = 0;
                        });
                    });
                }
                syncFacadesVisibilityAll();
                updateSelectedSectionHelper();
            });
        }

        // === QDApp: settings-ке арналған API ===
        window.QDApp = {
            // Core helpers
            showError,
            setViewMode,
            rebuildWithCurrentSize,
            rebuildSectionSelect,
            updateSelectedSectionHelper,
            rebuildShelvesUI,
            rebuildShelvesGroup,
            selectPart,
            applyEdgeHighlightVisibility,
            applyPartOffsets,
            rebuildEdgeHighlightForPart,
            refreshPartPreview,
	            deletePart,
	            captureState,
	            applyState,
	            runUndoable,
	            undo,
	            redo,
	            resetUndoHistory,

            // Секция логикасы
            resizeSectionWidth,
            splitSectionByPattern,
            deleteSection,

            // Стейт
            get sections() { return sections; },
            set sections(v) { sections = v; },
            sectionShelves,
            get selectedSectionId() { return selectedSectionId; },
            set selectedSectionId(v) { selectedSectionId = v; },

            get innerW() { return innerW; },
            get innerH() { return innerH; },

            get doorAnimEnabled() { return doorAnimEnabled; },
            set doorAnimEnabled(v) { doorAnimEnabled = v; },
            get doorGlobalOpen() { return doorGlobalOpen; },
            set doorGlobalOpen(v) { doorGlobalOpen = v; },

            get dimensionsVisible() { return dimensionsVisible; },
            set dimensionsVisible(v) {
                dimensionsVisible = v;
                syncDimensionsVisibility();
            },

            get infoPanelVisible() { return infoPanelVisible; },
            set infoPanelVisible(v) {
                infoPanelVisible = v;
                syncInfoVisibility();
            },

            get facadesHidden() { return facadesHidden; },
            set facadesHidden(v) {
                facadesHidden = v;
                syncFacadesVisibilityAll();
            },

            get selectionMode() { return selectionMode; },
            set selectionMode(v) {
                selectionMode = v;
                updateSelectedSectionHelper();
                updateSectionFaceHighlight();
            },

            get parts() { return parts; },
            get selectedPartId() { return selectedPartId; },
            set selectedPartId(v) {
                selectedPartId = v;
                updateSectionFaceHighlight();
            },

            get undoStack() { return undoStack; },
            get redoStack() { return redoStack; },

            // DOM – settings.js-ке ыңғайлы болсын деп
            widthInput,
            heightInput,
            depthInput,
            corpusMaterial,
            corpusThickness,
            corpusColorInput,
            wallGapInput,
            bottomMountInput,
            facadeMaterial,
            facadeThickness,
            facadeType,
            facadeColorInput,
            facadeStyle,
            facadeFrameWidthInput,
            plinthHeightInput,
            backMaterial,
            sectionSelect,
            splitPatternInput,
            splitSectionBtn,
            sectionWidthInput,
            shelfCountInput,
            autoShelvesBtn,
            shelfHeightInput,
            addShelfBtn,
            shelfSelect,
            editShelfHeightInput,
            updateShelfBtn,
            shelfGapInput,
            applyShelfGapBtn,
            insertShelfBetweenBtn,
            insertTypeSelect,
            addInsertBtn,
            insertList,
            drawerVariantSelect,
            drawerDepthSelect,
            drawerFacadeMaterial,
            drawerSubList,
            drawerFacadeGapInput,
            drawerFrontOffsetInput,
            drawerBodyHeightInput,
            drawerStackGapInput,
            drawerRunnerThkInput,
            insertGapLeftInput,
            insertGapRightInput,
            pipeColorInput,
            drawerRunnerTypeSelect,
            falshSideSelect,
            falshSizeInput,
            addFalshBtn,
            falshList,
            falshLeftSideCheckbox,
            falshRightSideCheckbox,
            falshLeftSideSizeInput,
            falshRightSideSizeInput,
            addWallFrontalBtn,
            addWallVerticalBtn,
            partNameInput,
            partTypeInput,
            partSectionInput,
            partSizeInput,
            partOffsetFrontInput,
            edgeFrontInput,
            edgeBackInput,
            edgeLeftInput,
            edgeRightInput,
            partDrillingInput,
            offsetFrontInput,
            offsetBackInput,
            offsetBottomInput,
            offsetTopInput,
            offsetFrontLabel,
            offsetBackLabel,
            offsetBottomLabel,
            offsetTopLabel,
            viewButtons,
            modeButtons,
            animToggleBtn,
            toggleDimsBtn,
            toggleFacadeBtn,
            toggleEdgeBtn,
            toggleInfoBtn,
            undoBtn,
            redoBtn,

            dimensionBox,
            wallAngleInput,
            wallColorInput,
            wallWidthInput,
            wallHeightInput,
            wallListContainer,
            rebuildWalls,
            disposeWall: disposeWallGroup,
            get wallEnabled() { return wallEnabled; },
            set wallEnabled(v) {
                wallEnabled = !!v;
                if (!wallEnabled) disposeWallGroup();
            },
            get walls() { return walls; },
            set walls(v) { walls = v || []; rebuildWallsUI(); },
            get selectedWallId() { return selectedWallId; },
            set selectedWallId(v) { selectedWallId = v; rebuildWallsUI(); },
            rebuildWallsUI,
            addWallFromForm,
            updateSelectedWallFromForm,
            activatePanel: null, // app-settings.js толтырады
            get edgeHighlightEnabled() { return edgeHighlightEnabled; },
            set edgeHighlightEnabled(v) { edgeHighlightEnabled = !!v; applyEdgeHighlightVisibility(); },
            rebuildEdgeHighlightForPart
        };

        updateInsertSettingsVisibility();
        applyEdgeHighlightVisibility();

    } catch (e) {
        showError('Қате: ' + e.message);
        console.error(e);
    }
})();
