// app.model.js (split from app.legacy.js)
	        // СОСТОЯНИЕ – Capture/Apply (Undo/Redo, Save/Load үшін)
        function captureState() {
            const activeSnapshot =
                (activeCabinetId != null && cabinetSpawned)
                    ? captureCabinetSnapshot()
                    : null;
            const insertSideGaps = readInsertSideGaps();
            const state = {
                W: parseFloat(widthInput.value)  || 0,
	                H: parseFloat(heightInput.value) || 0,
	                D: parseFloat(depthInput.value)  || 0,
                wallMaterial: null,
                wallAngle: 0,
                wallColor: null,
                wallWidth: 0,
                wallHeight: 0,
                wallEnabled: false,
	                walls: [],
	                selectedWallId: null,
	                newWalls: newWalls.map(w => ({ ...w })),
	                wallSections: (function(){
	                    const out = {};
	                    Object.keys(wallSections).forEach(k => {
	                        out[k] = wallSections[k].map(s => ({...s}));
	                    });
	                    return out;
	                })(),
                corpusMaterial: corpusMaterial.value,
                corpusThickness: parseFloat(corpusThickness.value) || 16,
                facadeMaterial: facadeMaterial.value,
                facadeThickness: parseFloat(facadeThickness.value) || 18,
                facadeType: facadeType.value,
                facadeMaterialName: facadeMaterialNameInput ? facadeMaterialNameInput.value : '',
                plinthMaterialName: plinthMaterialNameInput ? plinthMaterialNameInput.value : '',
                plinthHeight: parseFloat(plinthHeightInput.value) || 0,
                doorGlobalOpen: doorGlobalOpen,
                wallGap: readWallGap(),
                backMaterial: backMaterial.value,
                bottomMount: bottomMountInput ? bottomMountInput.value : null,
                drawerFacadeGap: readDrawerFacadeGap(),
                drawerFrontOffset: readDrawerFrontOffset(),
                drawerFacadeMaterial: drawerFacadeMaterial ? drawerFacadeMaterial.value : null,
                drawerFacadeMaterialName: drawerFacadeMaterialNameInput ? drawerFacadeMaterialNameInput.value : '',
                drawerBodyHeight: readDrawerBodyHeight(),
                drawerRunnerThk: readDrawerRunnerThk(),
                drawerDepthBrand: drawerDepthBrandSelect ? drawerDepthBrandSelect.value : null,
                drawerStackGap: readDrawerStackGap(),
                insertGapLeft: insertSideGaps.left,
                insertGapRight: insertSideGaps.right,
                drawerRunnerType: drawerRunnerTypeSelect ? drawerRunnerTypeSelect.value : null,
                pipeColor: pipeColorInput ? pipeColorInput.value : null,
                corpusColor: corpusColorInput ? corpusColorInput.value : null,
                facadeColor: facadeColorInput ? facadeColorInput.value : null,
                facadeStyle: facadeStyle ? facadeStyle.value : null,
                innerW: innerW,
                innerH: innerH,
                sections: sections.map(s => ({id:s.id, x:s.x, y:s.y, w:s.w, h:s.h})),
                sectionShelves: (function(){
                    const out = {};
                    Object.keys(sectionShelves).forEach(k => {
                        out[k] = sectionShelves[k].slice();
                    });
                    return out;
                })(),
                sectionShelfOffsets: { ...sectionShelfOffsets },
                shelfInserts: cloneShelfInserts(shelfInserts),
                cabinetWallId: cabinetWallId,
                cabinetSectionId: cabinetSectionId,
                selectedSectionId: selectedSectionId,
                selectedShelfSubId: selectedShelfSubId,
                facadesHidden: facadesHidden,
                viewMode: currentViewMode,
                dimensionsVisible: dimensionsVisible,
                infoPanelVisible: infoPanelVisible,
                doorAnimEnabled: doorAnimEnabled,
                doorStates: readDoorStatesFromGroup(doorsGroup),
                edgeHighlightEnabled: edgeHighlightEnabled,
                cabinetSpawned: cabinetSpawned,
                cabinetBaseOffset: { ...cabinetBaseOffset },
                cabinetRotationY: cabinetRotationY,
                falshPanels: falshPanels.map(p => ({ ...p })),
                nextFalshId: nextFalshId,
                falshLeftSideEnabled: falshLeftSideEnabled,
                falshRightSideEnabled: falshRightSideEnabled,
                falshTopSideEnabled: falshTopSideEnabled,
                falshLeftSideSize: falshLeftSideSize,
                falshRightSideSize: falshRightSideSize,
                falshTopSideSize: falshTopSideSize,
                falshLeftSideDepth: falshLeftSideDepth,
                falshRightSideDepth: falshRightSideDepth,
                falshTopSideDepth: falshTopSideDepth,
	                activeCabinetId: activeCabinetId,
	                cabinets: cabinets.map(c => ({
	                    id: c.id,
	                    wallId: c.wallId,
	                    sectionId: c.sectionId,
	                    baseOffset: { ...(c.baseOffset || { x: 0, y: 0, z: 0 }) },
	                    rotationY: c.rotationY || 0,
	                    hidden: !!c.hidden,
	                    state: (activeSnapshot && c.id === activeCabinetId) ? activeSnapshot : (c.state || null)
	                }))
	            };
	            return state;
	        }

        // Тек шкафқа тән стейт (қабырға тізімін қоспаймыз)
        function captureCabinetSnapshot() {
            const insertSideGaps = readInsertSideGaps();
            const state = {
                W: parseFloat(widthInput.value)  || 0,
                H: parseFloat(heightInput.value) || 0,
                D: parseFloat(depthInput.value)  || 0,
                corpusMaterial: corpusMaterial.value,
                corpusThickness: parseFloat(corpusThickness.value) || 16,
                facadeMaterial: facadeMaterial.value,
                facadeThickness: parseFloat(facadeThickness.value) || 18,
                facadeType: facadeType.value,
                facadeMaterialName: facadeMaterialNameInput ? facadeMaterialNameInput.value : '',
                plinthMaterialName: plinthMaterialNameInput ? plinthMaterialNameInput.value : '',
                facadeFrameWidth: (function(){
                    const v = parseFloat(facadeFrameWidthInput ? facadeFrameWidthInput.value : '');
                    return Number.isFinite(v) ? v : null;
                })(),
                plinthHeight: parseFloat(plinthHeightInput.value) || 0,
                backMaterial: backMaterial.value,
                bottomMount: bottomMountInput ? bottomMountInput.value : null,
                corpusColor: corpusColorInput ? corpusColorInput.value : null,
                facadeColor: facadeColorInput ? facadeColorInput.value : null,
                facadeStyle: facadeStyle ? facadeStyle.value : null,
                doorStates: readDoorStatesFromGroup(doorsGroup),
                drawerFacadeGap: readDrawerFacadeGap(),
                drawerFrontOffset: readDrawerFrontOffset(),
                drawerFacadeMaterial: drawerFacadeMaterial ? drawerFacadeMaterial.value : null,
                drawerFacadeMaterialName: drawerFacadeMaterialNameInput ? drawerFacadeMaterialNameInput.value : '',
                drawerBodyHeight: readDrawerBodyHeight(),
                drawerRunnerThk: readDrawerRunnerThk(),
                drawerDepthBrand: drawerDepthBrandSelect ? drawerDepthBrandSelect.value : null,
                drawerStackGap: readDrawerStackGap(),
                insertGapLeft: insertSideGaps.left,
                insertGapRight: insertSideGaps.right,
                drawerRunnerType: drawerRunnerTypeSelect ? drawerRunnerTypeSelect.value : null,
                pipeColor: pipeColorInput ? pipeColorInput.value : null,
                wallGap: readWallGap(),
                splitPattern: splitPatternInput ? splitPatternInput.value : null,
                sections: sections.map(s => ({id:s.id, x:s.x, y:s.y, w:s.w, h:s.h})),
                sectionShelves: (function(){
                    const out = {};
                    Object.keys(sectionShelves).forEach(k => {
                        out[k] = sectionShelves[k].slice();
                    });
                    return out;
                })(),
                sectionShelfOffsets: { ...sectionShelfOffsets },
                shelfInserts: cloneShelfInserts(shelfInserts),
                selectedSectionId: selectedSectionId,
                selectedShelfSubId: selectedShelfSubId,
                cabinetSpawned: cabinetSpawned,
                innerW: innerW,
                innerH: innerH,
                falshPanels: falshPanels.map(p => ({ ...p })),
                nextFalshId: nextFalshId,
                falshLeftSideEnabled: falshLeftSideEnabled,
                falshRightSideEnabled: falshRightSideEnabled,
                falshLeftSideSize: falshLeftSideSize,
                falshRightSideSize: falshRightSideSize,
                falshTopSideEnabled: falshTopSideEnabled,
                falshTopSideSize: falshTopSideSize,
                falshLeftSideDepth: falshLeftSideDepth,
                falshRightSideDepth: falshRightSideDepth,
                falshTopSideDepth: falshTopSideDepth
            };
            return state;
        }

        function applyState(state) {
            if (!state) return;

            // Алдымен ескі шкаф группаларын тазалаймыз (жаңа стейтті таза қолдану үшін)
            getAllCabinetGroups().forEach(({ group }) => disposeGroup(group));
            cabinetGroup = null;
            cabinets = [];
            activeCabinetId = state.activeCabinetId || null;

            widthInput.value  = (state.W || state.W === 0) ? state.W : widthInput.value;
            heightInput.value = (state.H || state.H === 0) ? state.H : heightInput.value;
            depthInput.value  = (state.D || state.D === 0) ? state.D : depthInput.value;
            const hasCabList = Array.isArray(state.cabinets) && state.cabinets.length > 0;
            const targetActiveId = state.activeCabinetId || (hasCabList ? state.cabinets[0].id : null);
            wallEnabled = false;
            walls = [];
            selectedWallId = null;
            nextWallId = 1;
            newWalls = (state.newWalls || []).map(w => ({...w}));
            wallSections = {};
            const srcWallSections = state.wallSections || {};
            Object.keys(srcWallSections).forEach(k => {
                wallSections[k] = srcWallSections[k].map(s => ({...s}));
            });
            cabinetWallId      = hasCabList ? null : (state.cabinetWallId || null);
            cabinetSectionId   = hasCabList ? null : (state.cabinetSectionId || null);
            cabinetBaseOffset  = state.cabinetBaseOffset || { x: 0, y: 0, z: 0 };
            cabinetRotationY   = state.cabinetRotationY || 0;
            cabinetSpawned     = hasCabList ? false : !!state.cabinetSpawned;
            pendingDoorStates  = Array.isArray(state.doorStates) ? state.doorStates.slice() : null;
            rebuildWallsUI();
            rebuildNewWallList();
            rebuildNewWalls();
            rebuildCabinetIcons();

            if (state.corpusMaterial)  corpusMaterial.value  = state.corpusMaterial;
            if (state.corpusThickness) corpusThickness.value = state.corpusThickness;
            if (state.facadeMaterial)  facadeMaterial.value  = state.facadeMaterial;
            if (state.facadeThickness) facadeThickness.value = state.facadeThickness;
            if (state.facadeType)      facadeType.value      = state.facadeType;
            if (facadeMaterialNameInput) {
                if (state.facadeMaterialName !== undefined && state.facadeMaterialName !== null) {
                    facadeMaterialNameInput.value = state.facadeMaterialName;
                } else if (!facadeMaterialNameInput.value.trim()) {
                    facadeMaterialNameInput.value = 'Белый';
                }
            }
            if (plinthMaterialNameInput) {
                if (state.plinthMaterialName !== undefined && state.plinthMaterialName !== null) {
                    plinthMaterialNameInput.value = state.plinthMaterialName;
                } else if (!plinthMaterialNameInput.value.trim()) {
                    plinthMaterialNameInput.value = 'Белый';
                }
            }
            if (state.plinthHeight !== undefined) plinthHeightInput.value = state.plinthHeight;
            if (state.wallGap !== undefined && wallGapInput) wallGapInput.value = state.wallGap;
            readWallGap();
            if (state.backMaterial)    backMaterial.value    = state.backMaterial;
            if (state.bottomMount && bottomMountInput) bottomMountInput.value = state.bottomMount;

            if (state.corpusColor && corpusColorInput) corpusColorInput.value = state.corpusColor;
            if (state.facadeColor && facadeColorInput) facadeColorInput.value = state.facadeColor;
            if (state.facadeStyle && facadeStyle)      facadeStyle.value      = state.facadeStyle;
            if (pipeColorInput && state.pipeColor)     pipeColorInput.value  = state.pipeColor;
            if (drawerRunnerTypeSelect && state.drawerRunnerType) drawerRunnerTypeSelect.value = state.drawerRunnerType;
            if (drawerDepthBrandSelect) {
                if (state.drawerDepthBrand !== undefined && state.drawerDepthBrand !== null) {
                    drawerDepthBrandSelect.value = state.drawerDepthBrand;
                }
            }
            if (drawerFacadeMaterialNameInput) {
                if (state.drawerFacadeMaterialName !== undefined && state.drawerFacadeMaterialName !== null) {
                    drawerFacadeMaterialNameInput.value = state.drawerFacadeMaterialName;
                } else if (!drawerFacadeMaterialNameInput.value.trim()) {
                    drawerFacadeMaterialNameInput.value = 'Белый';
                }
            }
            if (state.falshLeftSideSize && falshLeftSideSizeInput) {
                falshLeftSideSizeInput.value = state.falshLeftSideSize;
                falshLeftSideSize = state.falshLeftSideSize;
            }
            if (state.falshRightSideSize && falshRightSideSizeInput) {
                falshRightSideSizeInput.value = state.falshRightSideSize;
                falshRightSideSize = state.falshRightSideSize;
            }
            if (drawerFacadeGapInput) {
                if (state.drawerFacadeGap !== undefined && state.drawerFacadeGap !== null) {
                    let g = parseFloat(state.drawerFacadeGap);
                    if (!isFinite(g) || g < 0) g = 3;
                    drawerFacadeGapInput.value = g;
                } else if (!drawerFacadeGapInput.value) {
                    drawerFacadeGapInput.value = 3;
                }
            }
            if (drawerBodyHeightInput) {
                if (state.drawerBodyHeight !== undefined && state.drawerBodyHeight !== null) {
                    let g = parseFloat(state.drawerBodyHeight);
                    if (!isFinite(g) || g < 40) g = 120;
                    drawerBodyHeightInput.value = g;
                } else if (!drawerBodyHeightInput.value) {
                    drawerBodyHeightInput.value = 120;
                }
            }
            if (drawerFrontOffsetInput) {
                if (state.drawerFrontOffset !== undefined && state.drawerFrontOffset !== null) {
                    let g = parseFloat(state.drawerFrontOffset);
                    if (!isFinite(g) || g < 0) g = 16;
                    drawerFrontOffsetInput.value = g;
                } else if (!drawerFrontOffsetInput.value) {
                    drawerFrontOffsetInput.value = 16;
                }
            }
            if (drawerFacadeMaterial && state.drawerFacadeMaterial) {
                drawerFacadeMaterial.value = state.drawerFacadeMaterial;
            }
            if (drawerRunnerThkInput) {
                if (state.drawerRunnerThk !== undefined && state.drawerRunnerThk !== null) {
                    let g = parseFloat(state.drawerRunnerThk);
                    if (!isFinite(g) || g < 0) g = 13;
                    drawerRunnerThkInput.value = g;
                } else if (!drawerRunnerThkInput.value) {
                    drawerRunnerThkInput.value = 13;
                }
            }
            if (drawerStackGapInput) {
                if (state.drawerStackGap !== undefined && state.drawerStackGap !== null) {
                    let g = parseFloat(state.drawerStackGap);
                    if (!isFinite(g) || g < 0) g = 0;
                    drawerStackGapInput.value = g;
                } else if (!drawerStackGapInput.value) {
                    drawerStackGapInput.value = 0;
                }
            }
            if (insertGapLeftInput) {
                if (state.insertGapLeft !== undefined && state.insertGapLeft !== null) {
                    let g = parseFloat(state.insertGapLeft);
                    if (!isFinite(g) || g < 0) g = 50;
                    insertGapLeftInput.value = g;
                } else if (!insertGapLeftInput.value) {
                    insertGapLeftInput.value = 50;
                }
            }
            if (insertGapRightInput) {
                if (state.insertGapRight !== undefined && state.insertGapRight !== null) {
                    let g = parseFloat(state.insertGapRight);
                    if (!isFinite(g) || g < 0) g = 50;
                    insertGapRightInput.value = g;
                } else if (!insertGapRightInput.value) {
                    insertGapRightInput.value = 50;
                }
            }
            if (insertGapLeftInput) {
                if (state.insertGapLeft !== undefined && state.insertGapLeft !== null) {
                    let g = parseFloat(state.insertGapLeft);
                    if (!isFinite(g) || g < 0) g = 50;
                    insertGapLeftInput.value = g;
                } else if (!insertGapLeftInput.value) {
                    insertGapLeftInput.value = 50;
                }
            }
            if (insertGapRightInput) {
                if (state.insertGapRight !== undefined && state.insertGapRight !== null) {
                    let g = parseFloat(state.insertGapRight);
                    if (!isFinite(g) || g < 0) g = 50;
                    insertGapRightInput.value = g;
                } else if (!insertGapRightInput.value) {
                    insertGapRightInput.value = 50;
                }
            }

            facadesHidden      = !!state.facadesHidden;
            edgeHighlightEnabled = !!state.edgeHighlightEnabled;
            currentViewMode    = (state.viewMode !== undefined) ? state.viewMode : currentViewMode;
            dimensionsVisible  = (state.dimensionsVisible !== undefined) ? !!state.dimensionsVisible : true;
            infoPanelVisible   = (state.infoPanelVisible !== undefined) ? !!state.infoPanelVisible : false;
            doorAnimEnabled    = !!state.doorAnimEnabled;
            falshLeftSideEnabled  = !!state.falshLeftSideEnabled;
            falshRightSideEnabled = !!state.falshRightSideEnabled;
            falshTopSideEnabled   = !!state.falshTopSideEnabled;
            falshLeftSideDepth  = Number.isFinite(state.falshLeftSideDepth) ? state.falshLeftSideDepth : null;
            falshRightSideDepth = Number.isFinite(state.falshRightSideDepth) ? state.falshRightSideDepth : null;
            falshTopSideDepth   = Number.isFinite(state.falshTopSideDepth) ? state.falshTopSideDepth : null;
            if (falshLeftSideCheckbox) falshLeftSideCheckbox.checked   = falshLeftSideEnabled;
            if (falshRightSideCheckbox) falshRightSideCheckbox.checked = falshRightSideEnabled;
            if (falshTopSideCheckbox) falshTopSideCheckbox.checked = falshTopSideEnabled;
            if (falshLeftSideSizeInput && state.falshLeftSideSize) {
                falshLeftSideSizeInput.value = state.falshLeftSideSize;
                falshLeftSideSize = state.falshLeftSideSize;
            }
            if (falshRightSideSizeInput && state.falshRightSideSize) {
                falshRightSideSizeInput.value = state.falshRightSideSize;
                falshRightSideSize = state.falshRightSideSize;
            }
            if (falshTopSideSizeInput && state.falshTopSideSize) {
                falshTopSideSizeInput.value = state.falshTopSideSize;
                falshTopSideSize = state.falshTopSideSize;
            }
            falshPanels        = (state.falshPanels || []).map(p => ({ ...p }));
            nextFalshId        = Math.max(
                1,
                state.nextFalshId || 1,
                falshPanels.reduce((m, p) => Math.max(m, p.id || 0), 0) + 1
            );

            if (hasCabList) {
                cabinets = [];
                activeCabinetId = null;
                const usedCabinetIds = new Set();
                const cabinetIdKey = (id) => `${typeof id}:${String(id)}`;
                const allocateCabinetId = (preferredId) => {
                    if (preferredId == null) return null;
                    const preferredKey = cabinetIdKey(preferredId);
                    if (!usedCabinetIds.has(preferredKey)) {
                        usedCabinetIds.add(preferredKey);
                        return preferredId;
                    }
                    // Backward-compatible: ескі проектте cabinet.id қайталанып қалса,
                    // біреуін жаңа уникал ID-ға ауыстырамыз (басқа шкафтар өзгермесін).
                    let newId = Date.now();
                    while (usedCabinetIds.has(cabinetIdKey(newId))) newId++;
                    usedCabinetIds.add(cabinetIdKey(newId));
                    return newId;
                };
                state.cabinets.forEach(cabData => {
                    if (!cabData || cabData.id == null) return;
                    const resolvedId = allocateCabinetId(cabData.id);
                    if (resolvedId == null) return;
                    const rec = {
                        id: resolvedId,
                        wallId: cabData.wallId || null,
                        sectionId: cabData.sectionId || null,
                        baseOffset: { ...(cabData.baseOffset || { x: 0, y: 0, z: 0 }) },
                        rotationY: cabData.rotationY || 0,
                        hidden: !!cabData.hidden,
                        state: cabData.state || null,
                        group: null
                    };
                    cabinets.push(rec);
                    activeCabinetId   = rec.id;
                    cabinetWallId     = rec.wallId;
                    cabinetSectionId  = rec.sectionId;
                    cabinetBaseOffset = rec.baseOffset;
                    cabinetRotationY  = rec.rotationY || 0;
                    cabinetSpawned    = true;
                    applyCabinetState(rec.state || {});
                    rec.state = captureCabinetSnapshot();
                    rec.group = cabinetGroup;
                    if (rec.group) rec.group.visible = !rec.hidden;
                });
                refreshNextSectionIdGlobal();

                if (targetActiveId && cabinets.some(c => c.id === targetActiveId)) {
                    setActiveCabinet(targetActiveId);
                } else if (cabinets[0]) {
                    setActiveCabinet(cabinets[0].id);
                }

                applyActiveCabinetVisibility();
                rebuildWalls();
                setViewMode(currentViewMode);
                applyEdgeHighlightVisibility();
                rebuildInsertsUI();
                updateSelectedShelfSubHelper();
                rebuildDrawerSubList();
                syncDrawerActiveRow();
                syncDimensionsVisibility();
                syncInfoVisibility();
                rebuildCabinetIcons();
                rebuildFalshList();
                if (animToggleBtn)   animToggleBtn.classList.toggle('active', doorAnimEnabled);
                return;
            }

            sections = (state.sections || []).map(s => ({
                id: s.id, x: s.x, y: s.y, w: s.w, h: s.h
            }));
            refreshNextSectionIdGlobal();

            sectionShelves = {};
            const srcShelves = state.sectionShelves || {};
            Object.keys(srcShelves).forEach(k => {
                sectionShelves[k] = srcShelves[k].slice();
            });
            sanitizeSectionShelves();

            // Полкалар алдынан отступ (секцияға байланған) – стейттен оқимыз
            sectionShelfOffsets = { ...(state.sectionShelfOffsets || {}) };
            shelfInserts = cloneShelfInserts(state.shelfInserts || {});
            selectedShelfSubId = state.selectedShelfSubId || null;
            sanitizeShelfInserts(getShelfSubSections());

            selectedSectionId  = state.selectedSectionId || (sections[0] && sections[0].id) || null;

            innerW = state.innerW || 0;
            innerH = state.innerH || 0;

            const W = state.W || 1000;
            const H = state.H || 2200;
            const D = state.D || 600;

            if (!hasCabList && cabinetSpawned && !activeCabinetId) {
                activeCabinetId = state.activeCabinetId || Date.now();
            }

            if (cabinetSpawned && cabinetWallId && cabinetSectionId) {
                // Стена/секция күйі өзгерсе де шкафтың ішкі құрылымы (секциялар/полкалар) жоғалмасын
                updateCabinetFromSection(true);
            } else {
                cabinetSpawned = false;
            }
            if (cabinetSpawned && !cabinets.length) {
                const cabId = activeCabinetId || Date.now();
                activeCabinetId = cabId;
                cabinets.push({
                    id: cabId,
                    wallId: cabinetWallId,
                    sectionId: cabinetSectionId,
                    baseOffset: { ...cabinetBaseOffset },
                    rotationY: cabinetRotationY,
                    hidden: false,
                    state: captureCabinetSnapshot(),
                    group: cabinetGroup
                });
                applyActiveCabinetVisibility();
                rebuildCabinetIcons();
            }

            rebuildWalls();

            syncFacadesVisibilityAll();
            setViewMode(currentViewMode);
            applyEdgeHighlightVisibility();
            rebuildInsertsUI();
            updateSelectedShelfSubHelper();
            rebuildDrawerSubList();
            syncDrawerActiveRow();
            syncDimensionsVisibility();
            syncInfoVisibility();
            rebuildFalshList();
            if (animToggleBtn)   animToggleBtn.classList.toggle('active', doorAnimEnabled);
            // doorGlobalOpen removed (toggle all button deleted)
            hasUnsavedChanges = true;
        }

        // Тек шкаф күйін қолдану (қабырғаларды қозғамау үшін)
        function applyCabinetState(state) {
            if (!state) return;
            widthInput.value  = (state.W || state.W === 0) ? state.W : widthInput.value;
            heightInput.value = (state.H || state.H === 0) ? state.H : heightInput.value;
            depthInput.value  = (state.D || state.D === 0) ? state.D : depthInput.value;

            if (state.corpusMaterial)  corpusMaterial.value  = state.corpusMaterial;
            if (state.corpusThickness) corpusThickness.value = state.corpusThickness;
            if (state.facadeMaterial)  facadeMaterial.value  = state.facadeMaterial;
            if (state.facadeThickness) facadeThickness.value = state.facadeThickness;
            if (state.facadeType)      facadeType.value      = state.facadeType;
            if (facadeMaterialNameInput) {
                if (state.facadeMaterialName !== undefined && state.facadeMaterialName !== null) {
                    facadeMaterialNameInput.value = state.facadeMaterialName;
                } else if (!facadeMaterialNameInput.value.trim()) {
                    facadeMaterialNameInput.value = 'Белый';
                }
            }
            if (plinthMaterialNameInput) {
                if (state.plinthMaterialName !== undefined && state.plinthMaterialName !== null) {
                    plinthMaterialNameInput.value = state.plinthMaterialName;
                } else if (!plinthMaterialNameInput.value.trim()) {
                    plinthMaterialNameInput.value = 'Белый';
                }
            }
            if (facadeFrameWidthInput && state.facadeFrameWidth !== undefined && state.facadeFrameWidth !== null) {
                facadeFrameWidthInput.value = state.facadeFrameWidth;
            }
            if (state.plinthHeight !== undefined) plinthHeightInput.value = state.plinthHeight;
            if (state.backMaterial)    backMaterial.value    = state.backMaterial;
            if (state.bottomMount && bottomMountInput) bottomMountInput.value = state.bottomMount;
            if (state.corpusColor && corpusColorInput) corpusColorInput.value = state.corpusColor;
            if (state.facadeColor && facadeColorInput) facadeColorInput.value = state.facadeColor;
            if (state.facadeStyle && facadeStyle)      facadeStyle.value      = state.facadeStyle;
            if (pipeColorInput && state.pipeColor)     pipeColorInput.value  = state.pipeColor;
            if (drawerRunnerTypeSelect && state.drawerRunnerType) drawerRunnerTypeSelect.value = state.drawerRunnerType;
            if (drawerFacadeMaterial && state.drawerFacadeMaterial !== undefined && state.drawerFacadeMaterial !== null) {
                drawerFacadeMaterial.value = state.drawerFacadeMaterial;
            }
            if (drawerFacadeMaterialNameInput) {
                if (state.drawerFacadeMaterialName !== undefined && state.drawerFacadeMaterialName !== null) {
                    drawerFacadeMaterialNameInput.value = state.drawerFacadeMaterialName;
                } else if (!drawerFacadeMaterialNameInput.value.trim()) {
                    drawerFacadeMaterialNameInput.value = 'Белый';
                }
            }
            if (wallGapInput && state.wallGap !== undefined && state.wallGap !== null) {
                wallGapInput.value = state.wallGap;
                readWallGap();
            }
            falshPanels = (state.falshPanels || []).map(p => ({ ...p }));
            nextFalshId = Math.max(
                1,
                state.nextFalshId || 1,
                falshPanels.reduce((m, p) => Math.max(m, p.id || 0), 0) + 1
            );
            if (splitPatternInput && state.splitPattern !== undefined && state.splitPattern !== null) {
                splitPatternInput.value = state.splitPattern;
            }
            falshLeftSideEnabled  = !!state.falshLeftSideEnabled;
            falshRightSideEnabled = !!state.falshRightSideEnabled;
            falshTopSideEnabled   = !!state.falshTopSideEnabled;
            falshLeftSideDepth  = Number.isFinite(state.falshLeftSideDepth) ? state.falshLeftSideDepth : null;
            falshRightSideDepth = Number.isFinite(state.falshRightSideDepth) ? state.falshRightSideDepth : null;
            falshTopSideDepth   = Number.isFinite(state.falshTopSideDepth) ? state.falshTopSideDepth : null;
            falshLeftSideSize     = Number.isFinite(state.falshLeftSideSize) ? state.falshLeftSideSize : falshLeftSideSize;
            falshRightSideSize    = Number.isFinite(state.falshRightSideSize) ? state.falshRightSideSize : falshRightSideSize;
            falshTopSideSize      = Number.isFinite(state.falshTopSideSize) ? state.falshTopSideSize : falshTopSideSize;
            if (falshLeftSideCheckbox) falshLeftSideCheckbox.checked   = falshLeftSideEnabled;
            if (falshRightSideCheckbox) falshRightSideCheckbox.checked = falshRightSideEnabled;
            if (falshTopSideCheckbox) falshTopSideCheckbox.checked = falshTopSideEnabled;
            if (falshLeftSideSizeInput && state.falshLeftSideSize) {
                falshLeftSideSizeInput.value = state.falshLeftSideSize;
            }
            if (falshRightSideSizeInput && state.falshRightSideSize) {
                falshRightSideSizeInput.value = state.falshRightSideSize;
            }
            if (falshTopSideSizeInput && state.falshTopSideSize) {
                falshTopSideSizeInput.value = state.falshTopSideSize;
            }
            if (drawerFacadeGapInput) {
                if (state.drawerFacadeGap !== undefined && state.drawerFacadeGap !== null) {
                    let g = parseFloat(state.drawerFacadeGap);
                    if (!isFinite(g) || g < 0) g = 3;
                    drawerFacadeGapInput.value = g;
                } else if (!drawerFacadeGapInput.value) {
                    drawerFacadeGapInput.value = 3;
                }
            }
            if (drawerBodyHeightInput) {
                if (state.drawerBodyHeight !== undefined && state.drawerBodyHeight !== null) {
                    let g = parseFloat(state.drawerBodyHeight);
                    if (!isFinite(g) || g < 40) g = 120;
                    drawerBodyHeightInput.value = g;
                } else if (!drawerBodyHeightInput.value) {
                    drawerBodyHeightInput.value = 120;
                }
            }
            if (drawerRunnerThkInput) {
                if (state.drawerRunnerThk !== undefined && state.drawerRunnerThk !== null) {
                    let g = parseFloat(state.drawerRunnerThk);
                    if (!isFinite(g) || g < 0) g = 13;
                    drawerRunnerThkInput.value = g;
                } else if (!drawerRunnerThkInput.value) {
                    drawerRunnerThkInput.value = 13;
                }
            }
            if (drawerStackGapInput) {
                if (state.drawerStackGap !== undefined && state.drawerStackGap !== null) {
                    let g = parseFloat(state.drawerStackGap);
                    if (!isFinite(g) || g < 0) g = 0;
                    drawerStackGapInput.value = g;
                } else if (!drawerStackGapInput.value) {
                    drawerStackGapInput.value = 0;
                }
            }

            sections = (state.sections || []).map(s => ({
                id: s.id, x: s.x, y: s.y, w: s.w, h: s.h
            }));
            nextSectionId = sections.reduce((m,s)=>Math.max(m,s.id), 0) + 1;

            sectionShelves = {};
            const srcShelves = state.sectionShelves || {};
            Object.keys(srcShelves).forEach(k => {
                sectionShelves[k] = srcShelves[k].slice();
            });
            sanitizeSectionShelves();
            sectionShelfOffsets = { ...(state.sectionShelfOffsets || {}) };
            shelfInserts = cloneShelfInserts(state.shelfInserts || {});
            selectedShelfSubId = state.selectedShelfSubId || null;
            sanitizeShelfInserts(getShelfSubSections());

            selectedSectionId  = state.selectedSectionId || (sections[0] && sections[0].id) || null;
            cabinetSpawned     = !!state.cabinetSpawned;
            innerW = state.innerW || innerW;
            innerH = state.innerH || innerH;
            pendingDoorStates = Array.isArray(state.doorStates) ? state.doorStates.slice() : null;

            const W = state.W || parseFloat(widthInput.value) || 1000;
            const H = state.H || parseFloat(heightInput.value) || 2200;
            const D = state.D || parseFloat(depthInput.value) || 600;

            cabinetGroup = null;
            createCabinet(W, H, D, true);
            rebuildInsertsUI();
            updateSelectedShelfSubHelper();
            rebuildDrawerSubList();
            syncDrawerActiveRow();
            rebuildFalshList();
        }

        let undoCurrentState = null;

        function isPlainObject(val) {
            return !!val && typeof val === 'object' && !Array.isArray(val);
        }

        function deepEqual(a, b) {
            if (a === b) return true;
            if (!Object.is(typeof a, typeof b)) return false;
            if (a == null || b == null) return false;

            if (Array.isArray(a)) {
                if (!Array.isArray(b)) return false;
                if (a.length !== b.length) return false;
                for (let i = 0; i < a.length; i++) {
                    if (!deepEqual(a[i], b[i])) return false;
                }
                return true;
            }

            if (isPlainObject(a)) {
                if (!isPlainObject(b)) return false;
                const aKeys = Object.keys(a);
                const bKeys = Object.keys(b);
                if (aKeys.length !== bKeys.length) return false;
                for (const k of aKeys) {
                    if (!(k in b)) return false;
                    if (!deepEqual(a[k], b[k])) return false;
                }
                return true;
            }

            return Object.is(a, b);
        }

        function isArrayOfIdObjects(arr) {
            if (!Array.isArray(arr)) return false;
            if (!arr.length) return true;
            return arr.every(it => isPlainObject(it) && it.id != null);
        }

        function diffArrayById(beforeArr, afterArr, path, ops) {
            const beforeById = new Map();
            const afterById = new Map();
            const beforeOrder = [];
            const afterOrder = [];

            beforeArr.forEach(it => {
                const id = String(it.id);
                beforeById.set(id, it);
                beforeOrder.push(id);
            });
            afterArr.forEach(it => {
                const id = String(it.id);
                afterById.set(id, it);
                afterOrder.push(id);
            });

            const allIds = new Set([...beforeOrder, ...afterOrder]);
            for (const id of allIds) {
                const b = beforeById.get(id);
                const a = afterById.get(id);
                if (b === undefined || a === undefined) {
                    ops.push({ type: 'arr_item', path, id, before: b, after: a });
                    continue;
                }
                if (!deepEqual(b, a)) {
                    ops.push({ type: 'arr_item', path, id, before: b, after: a });
                }
            }

            if (!deepEqual(beforeOrder, afterOrder)) {
                ops.push({ type: 'arr_order', path, before: beforeOrder, after: afterOrder });
            }
        }

        function diffAny(beforeVal, afterVal, path, ops) {
            if (deepEqual(beforeVal, afterVal)) return;

            if (Array.isArray(beforeVal) && Array.isArray(afterVal)) {
                if (isArrayOfIdObjects(beforeVal) && isArrayOfIdObjects(afterVal)) {
                    diffArrayById(beforeVal, afterVal, path, ops);
                    return;
                }
                ops.push({ type: 'set', path, before: beforeVal, after: afterVal });
                return;
            }

            if (isPlainObject(beforeVal) && isPlainObject(afterVal)) {
                const keys = new Set([...Object.keys(beforeVal), ...Object.keys(afterVal)]);
                for (const key of keys) {
                    const hasBefore = Object.prototype.hasOwnProperty.call(beforeVal, key);
                    const hasAfter = Object.prototype.hasOwnProperty.call(afterVal, key);
                    if (!hasAfter) {
                        ops.push({ type: 'set', path: path.concat(key), before: beforeVal[key], after: undefined });
                        continue;
                    }
                    if (!hasBefore) {
                        ops.push({ type: 'set', path: path.concat(key), before: undefined, after: afterVal[key] });
                        continue;
                    }
                    diffAny(beforeVal[key], afterVal[key], path.concat(key), ops);
                }
                return;
            }

            ops.push({ type: 'set', path, before: beforeVal, after: afterVal });
        }

        function diffStates(beforeState, afterState) {
            const ops = [];
            diffAny(beforeState, afterState, [], ops);
            return ops;
        }

        function getAtPath(root, path) {
            let cur = root;
            for (const key of path) {
                if (cur == null) return undefined;
                cur = cur[key];
            }
            return cur;
        }

        function setAtPath(root, path, value) {
            if (!path.length) return;
            let cur = root;
            for (let i = 0; i < path.length - 1; i++) {
                const key = path[i];
                if (!isPlainObject(cur[key]) && !Array.isArray(cur[key])) {
                    const nextKey = path[i + 1];
                    cur[key] = (typeof nextKey === 'number') ? [] : {};
                }
                cur = cur[key];
            }
            cur[path[path.length - 1]] = value;
        }

        function deleteAtPath(root, path) {
            if (!path.length) return;
            let cur = root;
            for (let i = 0; i < path.length - 1; i++) {
                const key = path[i];
                if (cur == null) return;
                cur = cur[key];
            }
            if (cur == null) return;
            delete cur[path[path.length - 1]];
        }

        function applyOpsToState(state, ops, useAfter) {
            ops.forEach(op => {
                const val = useAfter ? op.after : op.before;

                if (op.type === 'set') {
                    if (val === undefined) deleteAtPath(state, op.path);
                    else setAtPath(state, op.path, val);
                    return;
                }

                if (op.type === 'arr_item') {
                    const arr = getAtPath(state, op.path);
                    if (!Array.isArray(arr)) return;
                    const idStr = String(op.id);
                    const idx = arr.findIndex(it => it && it.id != null && String(it.id) === idStr);
                    if (val === undefined) {
                        if (idx !== -1) arr.splice(idx, 1);
                        return;
                    }
                    if (idx !== -1) arr[idx] = val;
                    else arr.push(val);
                    return;
                }

                if (op.type === 'arr_order') {
                    const arr = getAtPath(state, op.path);
                    if (!Array.isArray(arr)) return;
                    const order = Array.isArray(val) ? val.map(String) : [];
                    const byId = new Map();
                    arr.forEach(it => {
                        if (it && it.id != null) byId.set(String(it.id), it);
                    });
                    const reordered = [];
                    order.forEach(id => {
                        const key = String(id);
                        if (byId.has(key)) {
                            reordered.push(byId.get(key));
                            byId.delete(key);
                        }
                    });
                    byId.forEach(v => reordered.push(v));
                    arr.length = 0;
                    reordered.forEach(v => arr.push(v));
                }
            });
            return state;
        }

        function resetUndoHistory(markDirty = false) {
            undoStack = [];
            redoStack = [];
            undoCurrentState = captureState();
            if (markDirty) hasUnsavedChanges = true;
            rebuildStructureList();
        }

        function runUndoable(fn, markDirty = true) {
            if (typeof fn !== 'function') return;
            const before = captureState();
            fn();
            const after = captureState();
            const ops = diffStates(before, after);
            if (!ops.length) {
                undoCurrentState = after;
                return;
            }
            undoStack.push({ ops });
            if (undoStack.length > 50) undoStack.shift();
            redoStack = [];
            undoCurrentState = after;
            if (markDirty) hasUnsavedChanges = true;
            rebuildStructureList();
        }

        function undo() {
            if (!undoStack.length) return;
            const entry = undoStack.pop();
            if (!undoCurrentState) undoCurrentState = captureState();
            undoCurrentState = applyOpsToState(undoCurrentState, entry.ops, false);
            redoStack.push(entry);
            applyState(undoCurrentState);
            undoCurrentState = captureState();
        }

        function redo() {
            if (!redoStack.length) return;
            const entry = redoStack.pop();
            if (!undoCurrentState) undoCurrentState = captureState();
            undoCurrentState = applyOpsToState(undoCurrentState, entry.ops, true);
            undoStack.push(entry);
            applyState(undoCurrentState);
            undoCurrentState = captureState();
        }

        // Секция ені өзгерту
        function resizeSectionWidth(sectionId, newWidth) {
            if (!sections.length) return;
            const minW = 100;

            const sorted = sections.slice().sort((a,b)=>a.x - b.x);
            const idx = sorted.findIndex(s => s.id === sectionId);
            if (idx === -1) return;

            const sec = sorted[idx];
            const delta = newWidth - sec.w;

            let neighborIndex = -1;
            if (idx < sorted.length - 1) {
                neighborIndex = idx + 1;
            } else if (idx > 0) {
                neighborIndex = idx - 1;
            } else {
                sec.w = newWidth;
                sec.x = 0;
                sections = sorted.map(s => ({...s}));
                createCabinet(currentW, currentH, currentD, true);
                setViewMode(currentViewMode);
                return;
            }

            const neigh = sorted[neighborIndex];
            if (neigh.w - delta < minW) {
                return;
            }

            sec.w = newWidth;
            if (neighborIndex > idx) {
                neigh.x = sec.x + sec.w;
            } else {
                sec.x = neigh.x + neigh.w - sec.w;
            }
            neigh.w -= delta;

            sorted[0].x = 0;
            for (let i = 1; i < sorted.length; i++) {
                sorted[i].x = sorted[i-1].x + sorted[i-1].w;
            }

            sections = sorted.map(s => ({...s}));
            createCabinet(currentW, currentH, currentD, true);
            setViewMode(currentViewMode);
        }


        // Секцияны өшіру
        function deleteSection(sectionId) {
            if (!sections.length) return;
            const sorted = sections.slice().sort((a, b) => a.x - b.x);
            const idx = sorted.findIndex(s => s.id === sectionId);
            if (idx === -1) return;

            const removed = sorted[idx];

            // Қай көршіге қосамыз – алдымен сол жақ, болмаса оң жақ
            let neighborIndex;
            if (idx > 0) {
                neighborIndex = idx - 1;
            } else {
                neighborIndex = idx + 1;
            }

            const neighbor = sorted[neighborIndex];
            neighbor.w += removed.w;

            // Өшірілген секцияның полкаларын да тазалаймыз
            delete sectionShelves[removed.id];

            // Тізімнен алып тастау
            sorted.splice(idx, 1);

            // x координаттарын қайта есептеу
            sorted[0].x = 0;
            for (let i = 1; i < sorted.length; i++) {
                sorted[i].x = sorted[i - 1].x + sorted[i - 1].w;
            }

            sections = sorted.map(s => ({ ...s }));

            // Таңдалған секцияны жаңарту
            if (selectedSectionId === sectionId) {
                selectedSectionId = neighbor.id;
                selectedShelfSubId = null;
            }

            // Қайта салу
            createCabinet(currentW, currentH, currentD, true);
            setViewMode(currentViewMode);
        }

        // Секцияны pattern бойынша бөлу
        function splitSectionByPattern(selectedId, pattern) {
            if (!sections.length) return;
            const partsArr = pattern.split('/').map(v => parseFloat(v)).filter(n => n > 0);
            if (!partsArr.length) return;

            const idx = sections.findIndex(s => s.id === selectedId);
            if (idx === -1) return;

            const sec = sections[idx];
            const total = partsArr.reduce((a,b)=>a+b, 0);
            let curX = sec.x;
            const newList = [];

            for (let i = 0; i < partsArr.length; i++) {
                const w = sec.w * partsArr[i] / total;
                const ns = {
                    id: (i === 0 ? sec.id : nextSectionId++),
                    x: curX,
                    y: sec.y,
                    w: w,
                    h: sec.h
                };
                newList.push(ns);
                curX += w;
            }

            sections.splice(idx, 1, ...newList);
            delete sectionShelves[sec.id];
            selectedShelfSubId = null;

            selectedSectionId = newList[0].id;
            createCabinet(currentW, currentH, currentD, true);
            setViewMode(currentViewMode);
        }

        // Вертикаль стойкалар
        function rebuildDividers(bodyMatColor) {
            if (!cabinetGroup) return;

            if (dividersGroup) {
                if (bodyCore) bodyCore.remove(dividersGroup);
                else cabinetGroup.remove(dividersGroup);
                dividersGroup.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
            }
            dividersGroup = new THREE.Group();

            const innerParams = computeInnerParams();
            const depthInside = innerParams.depthInside;
            const geom = new THREE.BoxGeometry(globalThickness, innerH, depthInside);

            const sorted = sections.slice().sort((a,b)=>a.x - b.x);

            // Фасад түріне қарай стойка позициясы
            const facadeTypeEl  = document.getElementById('facadeType');
            const facadeTypeVal = facadeTypeEl ? facadeTypeEl.value : 'vkladnoy';

            const useFacadeCenters =
                facadeTypeVal === 'nakladnoy' &&
                Array.isArray(facadeDividerCenters) &&
                facadeDividerCenters.length >= Math.max(0, sorted.length - 1);

            for (let i = 1; i < sorted.length; i++) {
                const boundaryX = sorted[i].x;

                const divider = solidWithEdges(geom.clone(), bodyMatColor, {
                    type: 'divider',
                    name: 'Стойка ' + i,
                    sectionId: null,
                    width: globalThickness,
                    height: innerH,
                    depth: depthInside
                });

                // Divider-дің жергілікті X позициясы:
                // - cabinetGroup өзінің осіне W/2 ығысқан, сондықтан мұнда қосымша offset қоспау керек.
                // - boundaryX ішкі ен (0..innerW) бойынша өлшенеді, сондықтан оны -innerW/2-ге қатысты қоямыз.
                let xWorld;
                if (useFacadeCenters) {
                    // Накладной фасад: стойка екі фасад арасындағы зазордың ортасына қойылады (локал координата)
                    xWorld = facadeDividerCenters[i - 1];
                } else {
                    // Қалған жағдай: ескі логика – секция шекарасы бойынша
                    xWorld = boundaryX - innerW / 2;
                }

                const yWorld = plinthHeight + globalThickness + innerH/2;
                divider.position.set(xWorld, yWorld, innerParams.centerZ);
                dividersGroup.add(divider);
            }

            (bodyCore || cabinetGroup).add(dividersGroup);
        }

        // Кабинетті салу
        function createCabinet(W, H, D, preserveLayout) {
            refreshNextSectionIdGlobal();
            cabinetSpawned = true;
            let oldSections = null;
            let oldShelves  = null;
            let oldShelfOffsets = null;
            let prevDoorStates = pendingDoorStates || null;
            pendingDoorStates = null;
            // Таңдалған бөлшек ескі шкафтан тасымалданбасын, UI босайтамыз
            clearSelectedPartSelection();

            if (preserveLayout && sections.length && innerW > 0 && innerH > 0) {
                oldSections = sections.map(s => ({...s}));
                oldShelves  = {};
                Object.keys(sectionShelves).forEach(id => {
                    oldShelves[id] = sectionShelves[id].slice();
                });
                oldShelfOffsets = { ...sectionShelfOffsets };
                prevInnerW = innerW;
                prevInnerH = innerH;
                if (!prevDoorStates && doorsGroup && doorsGroup.children) {
                    prevDoorStates = doorsGroup.children.map(h => !!(h.userData && h.userData.open));
                }
            } else {
                prevInnerW = 0;
                prevInnerH = 0;
            }

            if (cabinetGroup) {
                scene.remove(cabinetGroup);
                cabinetGroup.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
            }
            cabinetGroup          = new THREE.Group();
            innerVolumeMesh       = null;
            doorsGroup            = null;
            plinthGroup           = null;
            shelvesGroup          = null;
            insertsGroup          = null;
            dividersGroup         = null;
            falshGroup            = null;
            allMeshes             = [];
            allEdges              = [];
            parts                 = {};
            nextPartId            = 1;
            selectedShelfSubHelper = null;
            if (selectedPartBoxHelper) {
                scene.remove(selectedPartBoxHelper);
                selectedPartBoxHelper.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
                selectedPartBoxHelper = null;
            }

            const totalW = W;
            const { left: falshLeft, right: falshRight, top: falshTop } = getFalshExtents();
            const bodyShiftX = (falshLeft - falshRight) / 2;
            const bodyW = Math.max(200, totalW - falshLeft - falshRight);
            bodyCore = new THREE.Group();
            bodyCore.position.x = bodyShiftX;

            currentW = totalW; currentH = H; currentD = D;
            globalDepth     = D;
            const facadeTypeEl  = document.getElementById('facadeType');
            const facadeTypeVal = facadeTypeEl ? facadeTypeEl.value : 'vkladnoy';

            const corpusMatVal  = corpusMaterial.value;
            const corpusColor   = getCorpusColor(corpusMatVal);
            globalThickness     = parseFloat(corpusThickness.value) || 16;
            const parsedGap = parseFloat(wallGapInput ? wallGapInput.value : '');
            wallGap = Number.isFinite(parsedGap) ? parsedGap : 10;

            const facadeMatVal  = facadeMaterial.value;
            const facadeColor   = getFacadeColor(facadeMatVal);
            const facadeThick   = parseFloat(facadeThickness.value) || 18;
            // facadeTypeVal already defined above

            const parsedPlinth = parseFloat(plinthHeightInput.value);
            plinthHeight = Number.isFinite(parsedPlinth) && parsedPlinth >= 0 ? parsedPlinth : 100;
            const backMaterialVal = backMaterial.value;
            const thickness = globalThickness;

            const bodyMatColor  = corpusColor;
            const carcassHeight = Math.max(50, H - plinthHeight - falshTop);

            // ===== ЦОКОЛЬ + НОЖКАЛАР =====
            plinthGroup = new THREE.Group();
            const hasPlinth = plinthHeight > 0;

            const legRadius = 20;
            const legColor  = 0x444444;
            const legGeo    = hasPlinth ? new THREE.CylinderGeometry(legRadius, legRadius, plinthHeight, 16) : null;

            function addLeg(x, z, name) {
                if (!hasPlinth || !legGeo) return;
                const legGroup = solidWithEdges(legGeo.clone(), legColor, {
                    type: 'leg',
                    name: name,
                    width: legRadius * 2,
                    height: plinthHeight,
                    depth: legRadius * 2
                });
                legGroup.position.set(x, plinthHeight / 2, z);
                plinthGroup.add(legGroup);
            }

            const legZoneWidth = Math.max(100, bodyW - 160);
            const segments = Math.max(1, Math.ceil(legZoneWidth / 600));
            const legsPerRow = segments + 1;
            if (hasPlinth) {
                for (let i = 0; i < legsPerRow; i++) {
                    const t = (legsPerRow === 1) ? 0.5 : (i / (legsPerRow - 1));
                    const x = -legZoneWidth / 2 + t * legZoneWidth;
                    addLeg(x,  D / 2 - 80, 'Ножка алдыңғы ' + (i + 1));
                    addLeg(x, -D / 2 + 80, 'Ножка артқы ' + (i + 1));
                }
            }

            // Алдыңғы цоколь панелі:
            // - қалыңдығы фасад қалыңдығымен бірдей
            // - алдынан 20 мм ішке кіреді
            const plinthBoardH = plinthHeight;
            // Дно түрі: вкладной болса, цоколь алдыңғы панелі екі боковинаның ішкі жағына дейін ғана (W - 2*thickness)
            // Накладной болса, толық ені W болып қалады
            const bottomMountPlinth = bottomMountInput ? (bottomMountInput.value || 'vkladnoy') : 'vkladnoy';
            const plinthBoardW = (bottomMountPlinth === 'vkladnoy') ? (bodyW - 2*thickness) : bodyW;
            // Вкладной дно болса, цоколь материалы корпус түсі/қалыңдығына сай болсын
            const plinthBoardT = (bottomMountPlinth === 'vkladnoy') ? thickness : facadeThick;
            const plinthMatColor = (bottomMountPlinth === 'vkladnoy') ? bodyMatColor : facadeColor;
            const frontOffset  = 20;

            const plinthBoardGeo = new THREE.BoxGeometry(plinthBoardW, plinthBoardH, plinthBoardT);
            const plinthEdge = { front:true, back:false, left:false, right:false };
            const plinthBoard = solidWithEdges(plinthBoardGeo, plinthMatColor, {
                type: 'plinth',
                name: 'Цоколь алдыңғы',
                width: plinthBoardW,
                height: plinthBoardH,
                depth: plinthBoardT,
                edge: plinthEdge
            });

            const plinthZ = D / 2 - frontOffset - plinthBoardT / 2;
            plinthBoard.position.set(0, plinthBoardH / 2, plinthZ);
            if (hasPlinth) {
                plinthGroup.add(plinthBoard);
            }

            if (hasPlinth) {
                bodyCore.add(plinthGroup);
            }

            // Корпус бүйірлері
            const bottomMountSide = bottomMountInput ? (bottomMountInput.value || 'vkladnoy') : 'vkladnoy';
            const sideStartsOnBottom = (bottomMountSide === 'nakladnoy');
            // Вкладной дно: бүйірлер плinth-тен төмен түсіп, цокольмен бір деңгейде тұрсын (0-ден басталады)
            // Накладной дно: бүйірлер дноның үстіне отырсын, қиылыспасын
            const sideStartY      = sideStartsOnBottom ? (plinthHeight + thickness) : 0;
            const sideHeight      = sideStartsOnBottom ? (carcassHeight - thickness) : (carcassHeight + plinthHeight);
            const sideCenterY     = sideStartY + sideHeight/2;

            const geomSide = new THREE.BoxGeometry(thickness, sideHeight, D);
            const left = solidWithEdges(geomSide, bodyMatColor, {
                type: 'side',
                name: 'Сол жақ бүйір',
                width: thickness,
                height: sideHeight,
                depth: D,
                mountType: bottomMountSide
            });
            left.position.set(-bodyW/2 + thickness/2, sideCenterY, 0);
            bodyCore.add(left);

            const right = solidWithEdges(geomSide.clone(), bodyMatColor, {
                type: 'side',
                name: 'Оң жақ бүйір',
                width: thickness,
                height: sideHeight,
                depth: D,
                mountType: bottomMountSide
            });
            right.position.set(bodyW/2 - thickness/2, sideCenterY, 0);
            bodyCore.add(right);

            // Төменгі дно
            const bottomMount = bottomMountInput ? (bottomMountInput.value || 'vkladnoy') : 'vkladnoy';
            const bottomWidth = (bottomMount === 'nakladnoy') ? bodyW : (bodyW - 2*thickness);

            const geomBottom = new THREE.BoxGeometry(bottomWidth, thickness, D);
            const bottom = solidWithEdges(geomBottom, bodyMatColor, {
                type: 'bottom',
                name: 'Асты',
                width: bottomWidth,
                height: thickness,
                depth: D,
                mountType: bottomMount
            });
            bottom.position.set(0, plinthHeight + thickness/2, 0);
            bodyCore.add(bottom);

            // Жоғарғы
            const geomTop = new THREE.BoxGeometry(bodyW - 2*thickness, thickness, D);
            const top = solidWithEdges(geomTop, bodyMatColor, {
                type: 'top',
                name: 'Төбесі',
                width: bodyW - 2*thickness,
                height: thickness,
                depth: D
            });
            top.position.set(0, plinthHeight + carcassHeight - thickness/2, 0);
            bodyCore.add(top);

            // Артқы қабырға (накладной)
            let backThick;
            let backWidth;
            let backHeight;
            let backZ;
            let backColorLocal;

            if (backMaterialVal === 'hdf') {
                backThick      = 4;
                backColorLocal = 0xf0f0f0;
            } else {
                backThick      = thickness;
                backColorLocal = bodyMatColor;
            }

            backWidth  = bodyW;
            backHeight = carcassHeight;
            backZ      = -D/2 - backThick / 2;

            // Координат басы: сол жақ артқы бұрышты (0,0) ету үшін ығыстыру
            cabinetOffsetX = totalW / 2;
            cabinetOffsetZ = D / 2 + backThick;
            const baseX = cabinetBaseOffset.x || 0;
            const baseY = cabinetBaseOffset.y || 0;
            const baseZ = cabinetBaseOffset.z || 0;
            cabinetGroup.position.set(cabinetOffsetX + baseX, baseY, cabinetOffsetZ + baseZ);
            cabinetGroup.rotation.y = cabinetRotationY || 0;

            const geomBack = new THREE.BoxGeometry(backWidth, backHeight, backThick);
            const backMesh = solidWithEdges(geomBack, backColorLocal, {
                type: 'back',
                name: (backMaterialVal === 'hdf' ? 'Артқы қабырға (ХДФ накладной)' : 'Артқы қабырға (ЛДСП накладной)'),
                width: backWidth,
                height: backHeight,
                depth: backThick,
                materialType: backMaterialVal,
                mountType: 'nakladnoy'
            });
            backMesh.position.set(0, plinthHeight + carcassHeight/2, backZ);
            bodyCore.add(backMesh);

            // Ішкі кеңістік
            innerW = bodyW - 2*thickness;
            innerH = carcassHeight - 2*thickness;

            if (oldSections && prevInnerW > 0 && prevInnerH > 0) {
                const sx = innerW / prevInnerW;
                const sy = innerH / prevInnerH;
                let maxId = 0;
                sections = oldSections.map(s => {
                    const ns = {
                        id: s.id,
                        x: s.x * sx,
                        y: s.y * sy,
                        w: s.w * sx,
                        h: s.h * sy
                    };
                    if (ns.id > maxId) maxId = ns.id;
                    return ns;
                });
                nextSectionId = maxId + 1;

                sectionShelves = {};
                if (oldShelves) {
                    Object.keys(oldShelves).forEach(id => {
                        const arr = oldShelves[id].map(h => h * sy);
                        sectionShelves[id] = arr;
                    });
                }
                sectionShelfOffsets = {};
                if (oldShelfOffsets) {
                    // Тереңдік өзгерсе, отступты жаңа ішкі тереңдікке сай қысқартамыз
                    const innerParamsNew = computeInnerParams();
                    const maxOffset = Math.max(0, innerParamsNew.depthInside - 10);
                    Object.keys(oldShelfOffsets).forEach(id => {
                        const v = Math.min(Math.max(0, oldShelfOffsets[id]), maxOffset);
                        sectionShelfOffsets[id] = v;
                    });
                }
                if (selectedSectionId) {
                    const exists = sections.some(s => s.id === selectedSectionId);
                    if (!exists && sections.length) {
                        selectedSectionId = sections[0].id;
                    }
                }
            } else {
                sections = [{
                    id: nextSectionId++,
                    x: 0,
                    y: 0,
                    w: innerW,
                    h: innerH
                }];
                selectedSectionId = sections[0].id;
                sectionShelves = {};
            }

            const innerParams = computeInnerParams();

            const innerGeo = new THREE.BoxGeometry(innerW, innerH, innerParams.depthInside);
            const innerMat = new THREE.MeshBasicMaterial({visible: false});
            innerVolumeMesh = new THREE.Mesh(innerGeo, innerMat);
            innerVolumeMesh.position.set(0, plinthHeight + thickness + innerH/2, innerParams.centerZ);
            bodyCore.add(innerVolumeMesh);

            // ===== ФАСАДТАР (pattern бойынша: 1 – 1 есік, 2 – 2 есік және т.б.) =====
            doorsGroup = new THREE.Group();
            doorsGroup.userData.isDoorsGroup = true;
            doorsGroup.userData.splitPattern = splitPatternInput ? splitPatternInput.value : '';

            const doorT        = facadeThick;
            const isVkladnoy   = (facadeTypeVal === 'vkladnoy');
            const edgeGap      = isVkladnoy ? 3 : 1.5; // шеткі зазор
            const betweenGap   = 3;                   // фасадтар арасы 3 мм

            // Pattern оқу: мысалы "2/1", "1/2", "1/1/1"
            let patternArray = [];
            if (splitPatternInput && splitPatternInput.value) {
                patternArray = splitPatternInput.value
                    .split('/')
                    .map(function (v) {
                        const n = parseInt(v.trim(), 10);
                        return (isNaN(n) || n <= 0) ? 1 : n;
                    })
                    .filter(function (n) { return n > 0; });
            }
            const sortedSections = sections.slice().sort((a, b) => a.x - b.x);
            const nSections      = sortedSections.length;

            if (!patternArray.length) {
                patternArray = new Array(nSections).fill(1);
            }

            // Биіктік (Y)
            let doorH, openingCenterY;
            if (isVkladnoy) {
                const gapTopBot    = 3;
                doorH              = Math.max(10, innerH - 2 * gapTopBot);
                const openingBottomY = plinthHeight + thickness + gapTopBot;
                openingCenterY     = openingBottomY + doorH / 2;
            } else {
                const gapTopBot    = edgeGap; // 1.5
                const carcH        = carcassHeight;
                doorH              = Math.max(10, carcH - 2 * gapTopBot);
                const openingBottomY = plinthHeight + gapTopBot;
                openingCenterY     = openingBottomY + doorH / 2;
            }

            // Тереңдік (Z)
            let doorZCenter;
            if (isVkladnoy) {
                doorZCenter = D / 2 - doorT / 2 - 1;
            } else {
                doorZCenter = D / 2 + doorT / 2 + 1; // шкаф фронтынан 1 мм алға шығарамыз
            }

            const facadeStyleVal = (typeof facadeStyle !== 'undefined' && facadeStyle && facadeStyle.value)
                ? facadeStyle.value
                : 'modern';

            // Фасадтың стиліне қарай (модерн / рамка / рефленный) есік геометриясын салатын функция
            // "Рамкамен" стилі – Shaker Slim сияқты: сыртында жұқа рамка, ортасы 3 мм төменірек панель
            
function buildDoorWithStyle(doorW, doorH, doorT, color, partInfo) {
                // Егер стиль көрсетілмесе немесе "модерн" болса – классикалық тегіс есік
                if (!facadeStyleVal || facadeStyleVal === 'modern') {
                    const geomDoor  = new THREE.BoxGeometry(doorW, doorH, doorT);
                    return solidWithEdges(geomDoor, color, partInfo);
                }

                // ---------------- SHAKER SLIM (рамкамен) ----------------
                // Ортасы рамкадан 5 мм артқа кетеді, рамка біртұтас контур (45°-пен қосылған сияқты)
                if (facadeStyleVal === 'frame') {
                    const group = new THREE.Group();

                    // Рамка ені – қолмен енгізілсе, соны қолданамыз, әйтпесе есік өлшеміне байланысты (30–80 мм)
                    let frameW = 0;
                    if (typeof facadeFrameWidthInput !== 'undefined' && facadeFrameWidthInput && facadeFrameWidthInput.value !== '') {
                        frameW = parseFloat(facadeFrameWidthInput.value) || 0;
                    }
                    if (!frameW || frameW <= 0) {
                        frameW = Math.min(doorW, doorH) * 0.08;
                    }
                    frameW = Math.max(30, Math.min(80, frameW));

                    // Панель рамкадан 5 мм ішкері
                    const insetZ  = 5;
                    const panelT  = Math.max(doorT - insetZ, 2);
                    const panelW  = Math.max(10, doorW - 2 * frameW);
                    const panelH  = Math.max(10, doorH - 2 * frameW);

                    // Орталық панель – BoxGeometry, артқы жағы рамкамен бірдей, алдыңғы жағы 5 мм төмен
                    const panelGeom  = new THREE.BoxGeometry(panelW, panelH, panelT);
                    const panelGroup = solidWithEdges(panelGeom, color, partInfo);
                    const zPanel     = -doorT / 2 + panelT / 2; // артқы беті -doorT/2 деңгейінде
                    panelGroup.position.set(0, 0, zPanel);
                    group.add(panelGroup);

                    // Біртұтас рамка – сыртқы және ішкі контурдан ExtrudeGeometry арқылы
                    const outerHalfW = doorW / 2;
                    const outerHalfH = doorH / 2;
                    const innerHalfW = panelW / 2;
                    const innerHalfH = panelH / 2;

                    const shape = new THREE.Shape();
                    shape.moveTo(-outerHalfW, -outerHalfH);
                    shape.lineTo( outerHalfW, -outerHalfH);
                    shape.lineTo( outerHalfW,  outerHalfH);
                    shape.lineTo(-outerHalfW,  outerHalfH);
                    shape.lineTo(-outerHalfW, -outerHalfH);

                    const hole = new THREE.Path();
                    hole.moveTo(-innerHalfW, -innerHalfH);
                    hole.lineTo( innerHalfW, -innerHalfH);
                    hole.lineTo( innerHalfW,  innerHalfH);
                    hole.lineTo(-innerHalfW,  innerHalfH);
                    hole.lineTo(-innerHalfW, -innerHalfH);
                    shape.holes.push(hole);

                    const extrudeSettings = {
                        depth: doorT,
                        bevelEnabled: false,
                        steps: 1
                    };
                    const frameGeom = new THREE.ExtrudeGeometry(shape, extrudeSettings);
                    // Ортаңғы жазықтыққа орталау
                    frameGeom.translate(0, 0, -doorT / 2);

                    // Егер материал шыны рамка болса, рамка қара, ортасы көк мөлдір
                    const isGlassFrame = partInfo && partInfo.materialType === 'glass_frame';
                    const frameColor   = isGlassFrame ? 0x444444 : color;
                    const panelColor   = isGlassFrame ? 0x6db7ff : color;

                    const frameMat  = new THREE.MeshPhongMaterial({ color: frameColor, shininess: 20 });
                    const frameMesh = new THREE.Mesh(frameGeom, frameMat);
                    frameMesh.castShadow = true;
                    frameMesh.receiveShadow = true;
                    frameMesh.userData.baseColor = frameColor;
                    if (typeof allMeshes !== 'undefined') {
                        allMeshes.push(frameMesh);
                    }

                    // Эскиз режимінде рамка жақсы көрінуі үшін edge қосамыз
                    const edgesGeo = new THREE.EdgesGeometry(frameGeom);
                    const edgesMat = new THREE.LineBasicMaterial({ color: 0x000000 });
                    const edges    = new THREE.LineSegments(edgesGeo, edgesMat);
                    frameMesh.add(edges);
                    if (typeof allEdges !== 'undefined') {
                        allEdges.push(edges);
                    }

                    // Панель материалын шыны етеміз
                    panelGroup.traverse(obj => {
                        if (!obj.isMesh) return;
                        obj.material = new THREE.MeshStandardMaterial({
                            color: panelColor,
                            metalness: isGlassFrame ? 0.0 : 0.2,
                            roughness: isGlassFrame ? 0.1 : 0.7,
                            transparent: isGlassFrame,
                            opacity: isGlassFrame ? 0.35 : 1.0
                        });
                        obj.userData.baseColor = panelColor;
                        if (isGlassFrame) obj.userData.isGlass = true;
                    });

                    group.add(frameMesh);
                    return group;
                }

                // ---------------- РЕФЛЕННЫЙ ----------------
                if (facadeStyleVal === 'refl') {
                    const geomDoor  = new THREE.BoxGeometry(doorW, doorH, doorT);
                    const doorGroup = solidWithEdges(geomDoor, color, partInfo);

                    let baseMesh = null;
                    doorGroup.traverse(obj => {
                        if (obj.isMesh && !baseMesh) baseMesh = obj;
                    });

                    const baseMat = baseMesh
                        ? baseMesh.material
                        : new THREE.MeshPhongMaterial({ color: color });

                    const insetX = Math.min(doorW * 0.10, 80);
                    const insetY = Math.min(doorH * 0.10, 80);

                    const areaW  = Math.max(80, doorW - insetX * 2);
                    const areaH  = Math.max(80, doorH - insetY * 2);

                    const stripeCount = 7;
                    const gapRatio    = 0.7;
                    const unit        = areaW / (stripeCount + (stripeCount - 1) * gapRatio);
                    const stripeW     = unit;
                    const gapW        = unit * gapRatio;

                    const depth   = 3;
                    const stripeT = Math.max(doorT - depth, 2);
                    const zStripe = -doorT / 2 + stripeT / 2; // артқы беті бірдей

                    let x = -areaW / 2 + stripeW / 2;
                    for (let i = 0; i < stripeCount; i++) {
                        const geom = new THREE.BoxGeometry(stripeW, areaH, stripeT);
                        const mat  = baseMat.clone();
                        mat.color.offsetHSL(0, 0, -0.08);

                        const mesh = new THREE.Mesh(geom, mat);
                        mesh.castShadow = true;
                        mesh.receiveShadow = true;
                        mesh.position.set(x, 0, zStripe);

                        const eGeo = new THREE.EdgesGeometry(geom);
                        const eMat = new THREE.LineBasicMaterial({ color: 0x000000 });
                        const e    = new THREE.LineSegments(eGeo, eMat);
                        mesh.add(e);
                        if (typeof allEdges !== 'undefined') {
                            allEdges.push(e);
                        }

                        doorGroup.add(mesh);
                        x += stripeW + gapW;
                    }

                    return doorGroup;
                }

                // Белгісіз стильдер үшін – жай тегіс есік
                const geomDoor  = new THREE.BoxGeometry(doorW, doorH, doorT);
                return solidWithEdges(geomDoor, color, partInfo);
            }
            if (isVkladnoy) {
                // ВКЛАДНОЙ: innerW бойынша, шеттері 3 мм, аралары 3 мм.
                const innerLeftWorld = -innerW / 2;

                sortedSections.forEach((sec, secIndex) => {
                    const slots = patternArray[secIndex] || 1; // осы секциядағы есік саны

                    const isFirst = (secIndex === 0);
                    const isLast  = (secIndex === nSections - 1);

                    const gLeft  = isFirst ? edgeGap : betweenGap / 2;
                    const gRight = isLast  ? edgeGap : betweenGap / 2;

                    const secInnerLeftWorld = innerLeftWorld + sec.x;
                    const baseX             = secInnerLeftWorld + gLeft;
                    const availWidth        = Math.max(10, sec.w - gLeft - gRight);

                    const totalInternalGap  = betweenGap * Math.max(0, slots - 1);
                    const doorW             = Math.max(
                        10,
                        (availWidth - totalInternalGap) / slots
                    );

                    for (let j = 0; j < slots; j++) {
                        const leftX = baseX + j * (doorW + betweenGap);

                        const doorGroup = buildDoorWithStyle(doorW, doorH, doorT, facadeColor, {
                            type: 'door',
                            name: 'Есік секция ' + sec.id + ' (' + (j + 1) + '/' + slots + ')',
                            width: doorW,
                            height: doorH,
                            depth: doorT,
                            sectionId: sec.id,
                            materialType: facadeMatVal
                        });

                        let doorMesh = null;
                        doorGroup.traverse(obj => {
                            if (obj.isMesh) doorMesh = obj;
                        });

                        const hinge = new THREE.Group();
                        // hinge сол жақ қырымен қойылады
                        doorGroup.position.set(doorW / 2, 0, 0);
                        hinge.add(doorGroup);

                        const hingeX = leftX;

                        hinge.position.set(hingeX, openingCenterY, doorZCenter);
                        hinge.userData.isDoorHinge = true;
                        hinge.userData.isDoor = true;
                        hinge.userData.open        = false;
                        hinge.userData.doorWidth   = doorW;
                        hinge.userData.doorGroup   = doorGroup;
                        hinge.userData.sign        = (slots === 1) ? -1 : (j === 0 ? -1 : +1); // 1 есік – солға, 2 – сол/оң

                        if (doorMesh) {
                            doorMesh.userData.isDoor = true;
                            doorMesh.userData.hinge  = hinge;
                        }

                        doorGroup.traverse(obj => {
                            if (!obj.isMesh) return;
                            obj.userData.isDoor = true;
                            obj.userData.hinge  = hinge;
                        });

                        doorsGroup.add(hinge);
                    }
                });
            } else {
                // НАКЛАДНОЙ: сыртқы W,H бойынша, pattern-ге қарай есіктер саны
                const facadeOuterW     = bodyW;
                const outerLeftWorld   = -facadeOuterW / 2;
                const totalInnerWidth  = innerW || 1;
                const totalFacadeWidth =
                    facadeOuterW - 2 * edgeGap - (nSections > 1 ? (nSections - 1) * betweenGap : 0);

                facadeDividerCenters = [];

                let cursor = outerLeftWorld + edgeGap;

                sortedSections.forEach((sec, secIndex) => {
                    const slots = patternArray[secIndex] || 1;

                    const ratio             = sec.w / totalInnerWidth;
                    const sectionAvailWidth = totalFacadeWidth * ratio;

                    const totalInternalGap  = betweenGap * Math.max(0, slots - 1);
                    const doorW             = Math.max(
                        10,
                        (sectionAvailWidth - totalInternalGap) / slots
                    );

                    for (let j = 0; j < slots; j++) {
                        const doorGroup = buildDoorWithStyle(doorW, doorH, doorT, facadeColor, {
                            type: 'door',
                            name: 'Есік секция ' + sec.id + ' (' + (j + 1) + '/' + slots + ')',
                            width: doorW,
                            height: doorH,
                            depth: doorT,
                            sectionId: sec.id,
                            materialType: facadeMatVal
                        });

                        let doorMesh = null;
                        doorGroup.traverse(obj => {
                            if (obj.isMesh) doorMesh = obj;
                        });

                        const hinge = new THREE.Group();
                        doorGroup.position.set(doorW / 2, 0, 0);
                        hinge.add(doorGroup);

                        const hingeX = cursor;

                        hinge.position.set(hingeX, openingCenterY, doorZCenter);
                        hinge.userData.isDoorHinge = true;
                        hinge.userData.isDoor = true;
                        hinge.userData.open        = false;
                        hinge.userData.doorWidth   = doorW;
                        hinge.userData.doorGroup   = doorGroup;
                        hinge.userData.sign        = (slots === 1) ? -1 : (j === 0 ? -1 : +1);

                        if (doorMesh) {
                            doorMesh.userData.isDoor = true;
                            doorMesh.userData.hinge  = hinge;
                        }

                        doorGroup.traverse(obj => {
                            if (!obj.isMesh) return;
                            obj.userData.isDoor = true;
                            obj.userData.hinge  = hinge;
                        });

                        doorsGroup.add(hinge);

                        cursor += doorW;
                        if (j < slots - 1) {
                            cursor += betweenGap; // секция ішіндегі есіктер арасындағы зазор
                        }
                    }

                    if (secIndex < nSections - 1) {
                        const gapCenter = cursor + betweenGap / 2;
                        facadeDividerCenters.push(gapCenter);

                        cursor += betweenGap; // секциялар арасындағы зазор
                    }
                });
            }

            bodyCore.add(doorsGroup);
            cabinetGroup.userData.doorsGroup = doorsGroup;
            doorsGroup.visible = !facadesHidden;
            // Бұрынғы есік ашық/жабық күйін қалпына келтіреміз
            if (prevDoorStates && Array.isArray(prevDoorStates)) {
                doorsGroup.children.forEach((hinge, idx) => {
                    const wantOpen = !!prevDoorStates[idx];
                    const sign = hinge.userData && hinge.userData.sign ? hinge.userData.sign : -1;
                    hinge.userData.open = wantOpen;
                    hinge.rotation.y = wantOpen ? sign * (Math.PI / 2) : 0;
                });
            }

            cabinetGroup.add(bodyCore);

            // Стойкалар
            rebuildDividers(bodyMatColor);

            // Полкалар
            rebuildShelvesGroup();
            rebuildFalshGroup();

            rebuildSectionSelect();
            updateSelectedSectionHelper();
            updateDimensionsBox();
            rebuildInsertsUI();
            rebuildDrawerSubList();

            // Осы cabinetId-мен бұрын сценада қалған group болса – тазалау
            disposeCabinetGroupsById(activeCabinetId);
            cabinetGroup.userData = cabinetGroup.userData || {};
            cabinetGroup.userData.cabinetId = activeCabinetId;

            scene.add(cabinetGroup);

            // Актив шкаф жазбасын жаңа group-пен синхрондап қоямыз
            const activeIdx = cabinets.findIndex(c => c.id === activeCabinetId);
            if (activeIdx !== -1) {
                cabinets[activeIdx].group = cabinetGroup;
            }

            rebuildDimensionHelpers();
            rebuildStructureList();

            controls.target.set(cabinetOffsetX + (cabinetBaseOffset.x || 0), plinthHeight + H/2 + (cabinetBaseOffset.y || 0), cabinetOffsetZ + (cabinetBaseOffset.z || 0));
            controls.update();

            setViewMode(currentViewMode);
            updatePartUI();
        }

        // Canvas size
        function resizeRenderer() {
            const w = wrap.clientWidth;
            const h = wrap.clientHeight;
            if (w <= 0 || h <= 0) return;
            renderer.setSize(w, h);

            const aspect = w / h;

            // Перспективалық камераға арналған аспект
            if (perspCamera) {
                perspCamera.aspect = aspect;
                perspCamera.updateProjectionMatrix();
            }

            // Орфографиялық камераға арналған frustum
            if (orthoCamera) {
                const maxSize = Math.max(currentW || 0, currentH || 0, currentD || 0, 1200);
                const orthoSize = maxSize * 0.7;
                orthoCamera.left   = -orthoSize * aspect;
                orthoCamera.right  =  orthoSize * aspect;
                orthoCamera.top    =  orthoSize;
                orthoCamera.bottom = -orthoSize;
                orthoCamera.near   = CAMERA_NEAR_MIN;
                orthoCamera.far    = CAMERA_FAR_MIN;
                orthoCamera.updateProjectionMatrix();
            }
            updateCameraClipping();
        }
        window.addEventListener('resize', resizeRenderer);

        // Реалтайм: өлшем өзгергенде қайта сызу
        function updateSectionFromCabinet(W, H, opts) {
            if (!cabinetSpawned || !cabinetWallId || !cabinetSectionId) return;
            const wall = newWalls.find(w => w.id === cabinetWallId);
            if (!wall) return;
            const sections = ensureWallSections(wall);
            const idx = sections.findIndex(s => s.id === cabinetSectionId);
            if (idx === -1) return;
            sections[idx] = { ...sections[idx], w: W, h: H };
            if (!opts || opts.redraw !== false) {
                rebuildWallSectionList();
                rebuildNewWalls();
            }
        }

        function updateCabinetFromSection(preserveLayout) {
            if (!cabinetSpawned || !cabinetWallId || !cabinetSectionId) return;
            const wall = newWalls.find(w => w.id === cabinetWallId);
            if (!wall) return;
            const sections = ensureWallSections(wall);
            let sec = sections.find(s => s.id === cabinetSectionId);
            if (!sec && sections.length) {
                cabinetSectionId = sections[0].id;
                sec = sections[0];
            }
            if (!sec) return;

            const W = sec.w || parseFloat(widthInput.value) || 1000;
            const H = sec.h || parseFloat(heightInput.value) || 2200;
            const D = parseFloat(depthInput.value) || 600;

            readWallGap();
            const placement = computeCabinetPlacement(wall, sec, W, D);
            cabinetBaseOffset = placement.base;
            cabinetRotationY = placement.rotationY;

            widthInput.value = Math.round(W);
            heightInput.value = Math.round(H);
            createCabinet(W, H, D, preserveLayout);
            rebuildNewWalls();
            rebuildWallSectionList();
            applyActiveCabinetVisibility();
            syncActiveCabinetRecord();
        }

        function rebuildWithCurrentSize(preserveLayout) {
            if (!cabinetSpawned) return;
            const W = parseFloat(widthInput.value)  || 1000;
            const H = parseFloat(heightInput.value) || 2200;
            const D = parseFloat(depthInput.value)  || 600;
            readWallGap();
            if (cabinetWallId && cabinetSectionId) {
                const wall = newWalls.find(w => w.id === cabinetWallId);
                const sections = wall ? ensureWallSections(wall) : [];
                const sec = sections.find(s => s.id === cabinetSectionId);
                if (wall && sec) {
                    const placement = computeCabinetPlacement(wall, sec, W, D);
                    cabinetBaseOffset = placement.base;
                    cabinetRotationY = placement.rotationY;
                }
            }
            updateSectionFromCabinet(W, H, { redraw: false });
            createCabinet(W, H, D, preserveLayout);
            rebuildNewWalls();
            rebuildWalls();
            setViewMode(currentViewMode);
            applyActiveCabinetVisibility();
            syncActiveCabinetRecord();
        }

        function findDrawerGroupFromObject(obj) {
            let o = obj;
            while (o) {
                if (o.userData && o.userData.isDrawerGroup) return o;
                o = o.parent;
            }
            return null;
        }

        function toggleDrawerSlide(group) {
            if (!group || !group.userData || !group.userData.isDrawerGroup) return;
            const opened = !!group.userData.open;
            const from = group.position.z;
            const offset = group.userData.openOffset || 250;
            const closedZ = group.userData.closedZ || group.position.z;
            const to = opened ? closedZ : closedZ + offset;
            group.userData.open = !opened;
            group.userData.closedZ = closedZ;
            drawerAnimations = drawerAnimations.filter(a => a.group !== group);
            drawerAnimations.push({
                group,
                from,
                to,
                start: performance.now ? performance.now() : Date.now(),
                duration: 350
            });
            if (drawerSound) {
                try {
                    drawerSound.currentTime = 0;
                    const p = drawerSound.play();
                    if (p && typeof p.catch === 'function') p.catch(()=>{});
                } catch (e) {}
            }
        }

        // 3D-дан таңдау
        renderer.domElement.addEventListener('click', (event) => {
            const rect = renderer.domElement.getBoundingClientRect();
            mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            raycaster.setFromCamera(mouse, activeCamera);

            // Алдымен: егер анимация қосулы болса, есікті тікелей басу арқылы ашу/жабу
            if (doorAnimEnabled && !facadesHidden) {
                const doorGroups = getAllDoorGroups();
                const doorMeshes = doorGroups.flatMap(g => g ? g.children : []);
                const doorIntersects = raycaster.intersectObjects(doorMeshes, true);
                if (doorIntersects.length) {
                    const hit = doorIntersects[0].object;
                    let doorMesh = hit;
                    // Есіктің нақты mesh-іне дейін көтерілеміз
                    while (doorMesh && !doorMesh.userData.isDoor && doorMesh.parent) {
                        doorMesh = doorMesh.parent;
                    }
                    if (doorMesh && doorMesh.userData && doorMesh.userData.hinge) {
                        animateDoorHinge(doorMesh.userData.hinge);
                        return; // есікті басқан болсақ, ары қарай өңдемейміз
                    }
                }
            }

            // Стена секциясындағы плюс – шкафты құру
            if (wallSectionPlusSprites.length) {
                const plusHits = raycaster.intersectObjects(wallSectionPlusSprites, true);
                if (plusHits.length) {
                    const hit = plusHits[0].object;
                    const data = hit.userData || {};
                    if (data.isWallSectionPlus && data.wallId) {
                        spawnCabinetForSection(data.wallId, data.sectionId);
                        return;
                    }
                }
            }

            if (selectionMode === 'cabinet') {
                const groups = getAllCabinetGroups().map(c => c.group).filter(Boolean);
                const intersects = raycaster.intersectObjects(groups, true);
                if (intersects.length) {
                    const hit = intersects[0].object;
                    let targetGroup = hit;
                    const set = new Set(groups);
                    while (targetGroup && targetGroup.parent && !set.has(targetGroup)) {
                        targetGroup = targetGroup.parent;
                    }
                    const rec = getAllCabinetGroups().find(c => c.group === targetGroup);
                    if (rec && rec.cabinet) {
                        setActiveCabinet(rec.cabinet.id);
                        rebuildStructureList();
                        rebuildSectionSelect();
                        rebuildShelvesUI();
                        rebuildDimensionHelpers();
                    }
                }
                return;
            }

            if (selectionMode === 'part') {
                // Қай шкафқа тиіп тұрғанын анықтап, қажет болса сол шкафты активтейміз
                const allCabGroups = getAllCabinetGroups();
                const cabGroupsOnly = allCabGroups.map(c => c.group).filter(Boolean);
                const cabHits = raycaster.intersectObjects(cabGroupsOnly, true);
                if (cabHits.length) {
                    let root = cabHits[0].object;
                    const groupSet = new Set(cabGroupsOnly);
                    while (root && root.parent && !groupSet.has(root)) {
                        root = root.parent;
                    }
                    const rec = allCabGroups.find(c => c.group === root);
                    if (rec && rec.cabinet && rec.cabinet.id !== activeCabinetId) {
                        setActiveCabinet(rec.cabinet.id);
                    }
                }

                const findMeshWithPart = (hits) => {
                    for (const h of hits || []) {
                        let o = h.object;
                        // Edges → parent mesh
                        if (o.type === 'LineSegments' && o.__parentMesh) {
                            o = o.__parentMesh;
                        }
                        while (o && !o.userData.partId && o.parent) {
                            o = o.parent;
                        }
                        if (o && o.userData.partId && parts[o.userData.partId]) {
                            const p = parts[o.userData.partId];
                            if (facadesHidden && p.type === 'door') continue;
                            if (p.extra && p.extra.hidden) continue;
                            return o;
                        }
                    }
                    return null;
                };

                const activeGroupEntry = getAllCabinetGroups().find(c => c.cabinet && c.cabinet.id === activeCabinetId);
                const activeGroup = activeGroupEntry ? activeGroupEntry.group : cabinetGroup;
                const allHits = activeGroup ? raycaster.intersectObject(activeGroup, true) : [];
                let mesh = null;
                if (insertsGroup) {
                    const insertHits = raycaster.intersectObject(insertsGroup, true);
                    mesh = findMeshWithPart(insertHits);
                }
                if (!mesh) {
                    mesh = findMeshWithPart(allHits);
                }

                if (!mesh) return;
                const pid  = mesh.userData.partId;
                if (pid && parts[pid]) {
                    const p = parts[pid];

                    // Анимация режимінде ящикті басқанда алдыға жылжиды
                    if (doorAnimEnabled) {
                        const dg = findDrawerGroupFromObject(mesh);
                        if (dg) {
                            toggleDrawerSlide(dg);
                        }
                    }

                    // Анимация режимінде есікті тек қозғап, бөлшек таңдалмайды
                    if (p.type === 'door' && mesh.userData.hinge && doorAnimEnabled) {
                        animateDoorHinge(mesh.userData.hinge);
                        return;
                    }

                    updateSelectionSetFromEvent(String(pid), event);
                    selectPart(pid, { skipSelectionSetUpdate: true });

                    const extra = p.extra || {};
                    if (extra.type === 'shelf' && extra.sectionId && extra.shelfHeight != null) {
                        selectedSectionId = extra.sectionId;
                        rebuildSectionSelect();
                        rebuildShelvesUI();
                        const opts = shelfSelect ? shelfSelect.options : [];
                        for (let i=0; i<opts.length; i++) {
                            if (parseFloat(opts[i].value) === extra.shelfHeight) {
                                shelfSelect.selectedIndex = i;
                                if (editShelfHeightInput) editShelfHeightInput.value = extra.shelfHeight;
                                break;
                            }
                        }
                    }
                }
                return;
            }

            if (selectionMode === 'section') {
                // Алдымен: қай шкафқа тигенін анықтап, сол шкафты активтейміз
                const cabHits = raycaster.intersectObjects(
                    getAllCabinetGroups().map(c => c.group).filter(Boolean),
                    true
                );
                if (cabHits.length) {
                    const hitObj = cabHits[0].object;
                    let rootGroup = hitObj;
                    const groupSet = new Set(getAllCabinetGroups().map(c => c.group).filter(Boolean));
                    while (rootGroup && rootGroup.parent && !groupSet.has(rootGroup)) {
                        rootGroup = rootGroup.parent;
                    }
                    const rec = getAllCabinetGroups().find(c => c.group === rootGroup);
                    if (rec && rec.cabinet && rec.cabinet.id !== activeCabinetId) {
                        setActiveCabinet(rec.cabinet.id);
                    }
                }

                // Анимация қосулы болса, секция режимінде де ящикті бірден ашамыз
                if (doorAnimEnabled && insertsGroup) {
                    const hitInserts = raycaster.intersectObject(insertsGroup, true);
                    if (hitInserts.length) {
                        const dg = findDrawerGroupFromObject(hitInserts[0].object);
                        if (dg) {
                            toggleDrawerSlide(dg);
                            return;
                        }
                    }
                }
            }

            // selectionMode === 'section'
            if (!innerVolumeMesh || !sections.length) return;
            const intersects = raycaster.intersectObject(innerVolumeMesh, false);
            if (!intersects.length) return;

            const pWorld = intersects[0].point.clone();
            const p = pWorld.clone();
            innerVolumeMesh.worldToLocal(p);
            const sx = p.x + innerW / 2;
            const sy = p.y + innerH / 2;

            let found = null;
            for (const sec of sections) {
                if (
                    sx >= sec.x && sx <= sec.x + sec.w &&
                    sy >= sec.y && sy <= sec.y + sec.h
                ) {
                    found = sec;
                    break;
                }
            }
            if (!found) return;

            selectedSectionId = found.id;
            rebuildSectionSelect();
            updateSelectedSectionHelper();
            rebuildShelvesUI();
            setViewMode(currentViewMode);
        });

        // Hover кезінде есікке жақындағанда қол курсоры шығу
        renderer.domElement.addEventListener('mousemove', (event) => {
            const rect = renderer.domElement.getBoundingClientRect();
            mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

            raycaster.setFromCamera(mouse, activeCamera);

            let cursor = '';
            if (doorAnimEnabled && !facadesHidden) {
                const doorGroups = getAllDoorGroups();
                const doorMeshes = doorGroups.flatMap(g => g ? g.children : []);
                const doorIntersects = raycaster.intersectObjects(doorMeshes, true);
                if (doorIntersects.length) {
                    const hit = doorIntersects[0].object;
                    let doorMesh = hit;
                    while (doorMesh && !doorMesh.userData.isDoor && doorMesh.parent) {
                        doorMesh = doorMesh.parent;
                    }
                    if (doorMesh && doorMesh.userData && doorMesh.userData.hinge) {
                        cursor = 'pointer';
                    }
                }
                if (!cursor && insertsGroup) {
                    const insertHits = raycaster.intersectObject(insertsGroup, true);
                    if (insertHits.length) {
                        const dg = findDrawerGroupFromObject(insertHits[0].object);
                        if (dg) cursor = 'pointer';
                    }
                }
            }
            renderer.domElement.style.cursor = cursor || '';
        });
// SAVE / LOAD (JSON)
        if (saveProjectBtn) {
            saveProjectBtn.addEventListener('click', () => {
                try {
                    const state = captureState();
                    const blob = new Blob(
                        [JSON.stringify(state, null, 2)],
                        {type:'application/json'}
                    );
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    const dateStr = new Date().toISOString().slice(0,19).replace(/[:T]/g,'-');
                    a.href = url;
                    a.download = 'qdesign_shkaf_' + dateStr + '.json';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                    hasUnsavedChanges = false;
                } catch (e) {
                    showError('Сақтау қатесі: ' + e.message);
                }
            });
        }

        if (loadProjectBtn && loadProjectInput) {
            loadProjectBtn.addEventListener('click', () => {
                loadProjectInput.click();
            });
            loadProjectInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
	                reader.onload = function(ev) {
	                    try {
	                        const data = JSON.parse(ev.target.result);
	                        applyState(data);
	                        resetUndoHistory(false);
	                        hasUnsavedChanges = false;
	                    } catch (err) {
	                        showError('Файлды оқу қатесі: ' + err.message);
	                    }
	                };
                reader.readAsText(file);
                loadProjectInput.value = '';
            });
        }

        // Алғашқы старт
        function init() {
            resizeRenderer();
            cabinetSpawned = false;
            cabinets = [];
            activeCabinetId = null;
            falshPanels = [];
            nextFalshId = 1;
            falshLeftSideEnabled = false;
            falshRightSideEnabled = false;
            falshTopSideEnabled = false;
            falshLeftSideDepth = null;
            falshRightSideDepth = null;
            falshTopSideDepth = null;
            falshLeftSideSize = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
            falshRightSideSize = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
            falshTopSideSize = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
            if (falshLeftSideCheckbox) falshLeftSideCheckbox.checked = false;
            if (falshRightSideCheckbox) falshRightSideCheckbox.checked = false;
            if (falshTopSideCheckbox) falshTopSideCheckbox.checked = false;
            if (falshLeftSideSizeInput) falshLeftSideSizeInput.value = Math.round(falshLeftSideSize);
            if (falshRightSideSizeInput) falshRightSideSizeInput.value = Math.round(falshRightSideSize);
            if (falshTopSideSizeInput) falshTopSideSizeInput.value = Math.round(falshTopSideSize);
            bodyCore = null;
            walls = [];
            wallEnabled = false;
            selectedWallId = null;
	            rebuildNewWallList();
	            rebuildNewWalls();
	            setViewMode(currentViewMode);
	            resetUndoHistory(false);
	            hasUnsavedChanges = false;
	            rebuildCabinetList();
	            rebuildCabinetIcons();
	            rebuildFalshList();
	        }
        window.addEventListener('load', init);

        // Парақтан шығу/жаңарту алдында растау попапы
        window.addEventListener('beforeunload', (e) => {
            if (!hasUnsavedChanges) return;
            e.preventDefault();
            e.returnValue = '';
        });

        function animate() {
            requestAnimationFrame(animate);
            const now = performance.now ? performance.now() : Date.now();

            // Есіктер үшін плавная анимация (open/close)
            if (doorAnimations && doorAnimations.length) {
                for (let i = doorAnimations.length - 1; i >= 0; i--) {
                    const anim = doorAnimations[i];
                    const tRaw = (now - anim.start) / anim.duration;
                    const t    = Math.max(0, Math.min(1, tRaw));

                    // easeInOutQuad
                    const k = (t < 0.5)
                        ? 2 * t * t
                        : -1 + (4 - 2 * t) * t;

                    if (anim.hinge && anim.hinge.rotation) {
                        const angle = anim.from + (anim.to - anim.from) * k;
                        anim.hinge.rotation.y = angle;
                    }

                    if (t >= 1) {
                        doorAnimations.splice(i, 1);
                    }
                }
            }
            // Ящиктерді сырғыту анимациясы
            if (drawerAnimations && drawerAnimations.length) {
                for (let i = drawerAnimations.length - 1; i >= 0; i--) {
                    const anim = drawerAnimations[i];
                    const tRaw = (now - anim.start) / anim.duration;
                    const t    = Math.max(0, Math.min(1, tRaw));

                    const k = (t < 0.5)
                        ? 2 * t * t
                        : -1 + (4 - 2 * t) * t;

                    if (anim.group && anim.group.position) {
                        const posZ = anim.from + (anim.to - anim.from) * k;
                        anim.group.position.z = posZ;
                    }
                    if (t >= 1) {
                        drawerAnimations.splice(i, 1);
                    }
                }
            }

            animateSectionHighlight(now);
            animateWallHighlight(now);

            updateCameraClipping();
            renderer.render(scene, activeCamera);
            updateDimensionLabelAngles();
        }
        animate();


        // =========================
        // Сол жақтағы вид иконкалары (Алды / Жаны / Үсті / Изометрия)
        // =========================

        function setAxisView(type) {
            currentAxisView = type || 'iso';
            let targetX = cabinetOffsetX;
            let targetY = plinthHeight + (currentH || 0) * 0.5;
            let targetZ = cabinetOffsetZ;
            let sizeVec = new THREE.Vector3(currentW || 0, currentH || 0, currentD || 0);

            const activeGroup = cabinets.find(c => c.id === activeCabinetId)?.group || cabinetGroup;
            if (activeGroup) {
                const box = new THREE.Box3().setFromObject(activeGroup);
                if (box.isBox3 && box.isEmpty() === false) {
                    const center = new THREE.Vector3();
                    const size = new THREE.Vector3();
                    box.getCenter(center);
                    box.getSize(size);
                    targetX = center.x;
                    targetY = center.y;
                    targetZ = center.z;
                    sizeVec = size;
                }
            }

            // Шкаф габаритіне қарай дистанция есептейміз
            const maxSize = Math.max(sizeVec.x || 0, sizeVec.y || 0, sizeVec.z || 0, 1200);
            const centerY = targetY;

            // Экран аспектісі бойынша орфо камера көлемі
            const aspect = (renderer.domElement.clientWidth || 800) / (renderer.domElement.clientHeight || 600);
            const orthoSize = maxSize * 0.7;

            // Орто камераның frustum-ы
            orthoCamera.left   = -orthoSize * aspect;
            orthoCamera.right  =  orthoSize * aspect;
            orthoCamera.top    =  orthoSize;
            orthoCamera.bottom = -orthoSize;
            orthoCamera.near   = CAMERA_NEAR_MIN;
            orthoCamera.far    = CAMERA_FAR_MIN;
            orthoCamera.updateProjectionMatrix();

            if (type === 'front') {
                // Алды вид – Z осі бойымен қарап тұрған параллель проекция
                orthoCamera.position.set(targetX, centerY, maxSize * 2.0 + targetZ);
                orthoCamera.lookAt(targetX, centerY, targetZ);
                activeCamera = orthoCamera;
                controls.object = activeCamera;
                controls.enableRotate = false;
            } else if (type === 'side') {
                // Жаны вид – X осі бойымен
                orthoCamera.position.set(maxSize * 2.0 + targetX, centerY, targetZ);
                orthoCamera.lookAt(targetX, centerY, targetZ);
                activeCamera = orthoCamera;
                controls.object = activeCamera;
                controls.enableRotate = false;
            } else if (type === 'top') {
                // Үсті вид – Y осі бойымен
                orthoCamera.position.set(targetX, maxSize * 2.0 + centerY, targetZ);
                orthoCamera.lookAt(targetX, centerY, targetZ);
                activeCamera = orthoCamera;
                controls.object = activeCamera;
                controls.enableRotate = false;
            } else if (type === 'iso') {
                // Изометрия – перспективалық камера
                const isoDist = maxSize * 1.8;
                perspCamera.position.set(isoDist + targetX, isoDist * 0.7 + centerY, isoDist + targetZ);
                perspCamera.lookAt(targetX, centerY, targetZ);
                activeCamera = perspCamera;
                controls.object = activeCamera;
                controls.enableRotate = true;
            }

            controls.target.set(targetX, centerY, targetZ);
            controls.update();
            updateCameraClipping();
            updateDimensionLabelAngles();
            updateWallDecorations();
        } if (viewToolbar) {
            viewToolbar.addEventListener('click', function (e) {
                const btn = e.target.closest('button');
                if (!btn || !btn.dataset.cam) return;
                setAxisView(btn.dataset.cam);
            });
        }

        if (structureBtn) {
            structureBtn.addEventListener('click', () => {
                structureVisible = !structureVisible;
                if (structureVisible) rebuildStructureList();
                syncStructureVisibility();
            });
            syncStructureVisibility();
        } else {
            syncStructureVisibility();
        }

        if (cabinetDeleteBtn) {
            cabinetDeleteBtn.addEventListener('click', () => {
                if (!activeCabinetId) {
                    showError('Өшіру үшін алдымен шкафты таңдаңыз');
                    return;
                }
                const ok = window.confirm('Белгіленген шкафты өшіреміз бе?');
                if (!ok) return;
                removeCabinet(activeCabinetId);
                rebuildStructureList();
                rebuildCabinetIcons();
                syncStructureVisibility();
            });
        }

        if (cabinetHideBtn) {
            cabinetHideBtn.addEventListener('click', () => {
                if (!activeCabinetId) {
                    showError('Жасыру үшін алдымен шкафты таңдаңыз');
                    return;
                }
                const hidden = isCabinetHidden(activeCabinetId);
                setCabinetHidden(activeCabinetId, !hidden);
                syncCabinetVisibilityBtn();
            });
        }

        if (animToggleBtn) {
            animToggleBtn.addEventListener('click', () => {
                doorAnimEnabled = !doorAnimEnabled;
                animToggleBtn.classList.toggle('active', doorAnimEnabled);
                // Өшіргенде барлық есік жабылсын
                if (!doorAnimEnabled) {
                    const doorGroups = getAllDoorGroups();
                    doorGroups.forEach(g => {
                        if (!g || !g.children) return;
                        g.children.forEach(hinge => {
                            if (!hinge) return;
                            if (hinge.userData) hinge.userData.open = false;
                            if (hinge.rotation) hinge.rotation.y = 0;
                        });
                        syncDoorStatesToCabinetRecord(g);
                    });
                }
                syncFacadesVisibilityAll();
                updateSelectedSectionHelper();
            });
        }

        // === QDApp: settings-ке арналған API ===
        window.QDApp = {
            // Core helpers
            showError,
            setViewMode,
            rebuildWithCurrentSize,
            rebuildSectionSelect,
            updateSelectedSectionHelper,
            rebuildShelvesUI,
            rebuildShelvesGroup,
            rebuildStructureList,
            selectPart,
            applyEdgeHighlightVisibility,
            applyPartOffsets,
            rebuildEdgeHighlightForPart,
            refreshPartPreview,
	            deletePart,
	            captureState,
	            applyState,
	            runUndoable,
	            undo,
	            redo,
	            resetUndoHistory,

            // Секция логикасы
            resizeSectionWidth,
            splitSectionByPattern,
            deleteSection,

            // Стейт
            get sections() { return sections; },
            set sections(v) { sections = v; },
            sectionShelves,
            get selectedSectionId() { return selectedSectionId; },
            set selectedSectionId(v) { selectedSectionId = v; },

            get innerW() { return innerW; },
            get innerH() { return innerH; },

            get doorAnimEnabled() { return doorAnimEnabled; },
            set doorAnimEnabled(v) { doorAnimEnabled = v; },
            get doorGlobalOpen() { return doorGlobalOpen; },
            set doorGlobalOpen(v) { doorGlobalOpen = v; },

            get dimensionsVisible() { return dimensionsVisible; },
            set dimensionsVisible(v) {
                dimensionsVisible = v;
                syncDimensionsVisibility();
            },

            get infoPanelVisible() { return infoPanelVisible; },
            set infoPanelVisible(v) {
                infoPanelVisible = v;
                syncInfoVisibility();
            },

            get facadesHidden() { return facadesHidden; },
            set facadesHidden(v) {
                facadesHidden = v;
                syncFacadesVisibilityAll();
            },

            get selectionMode() { return selectionMode; },
            set selectionMode(v) {
                selectionMode = v;
                updateSelectedSectionHelper();
                updateSectionFaceHighlight();
            },

            get parts() { return parts; },
            get selectedPartId() { return selectedPartId; },
            set selectedPartId(v) {
                selectedPartId = v;
                updateSectionFaceHighlight();
            },

            get undoStack() { return undoStack; },
            get redoStack() { return redoStack; },

            // DOM – settings.js-ке ыңғайлы болсын деп
            widthInput,
            heightInput,
            depthInput,
            corpusMaterial,
            corpusThickness,
            corpusColorInput,
            wallGapInput,
            bottomMountInput,
            facadeMaterial,
            facadeThickness,
            facadeType,
            facadeColorInput,
            facadeStyle,
            facadeFrameWidthInput,
            plinthHeightInput,
            backMaterial,
            sectionSelect,
            splitPatternInput,
            splitSectionBtn,
            sectionWidthInput,
            shelfCountInput,
            autoShelvesBtn,
            shelfHeightInput,
            addShelfBtn,
            shelfSelect,
            editShelfHeightInput,
            updateShelfBtn,
            shelfGapInput,
            applyShelfGapBtn,
            insertShelfBetweenBtn,
            insertTypeSelect,
            addInsertBtn,
            insertList,
            drawerVariantSelect,
            drawerDepthSelect,
            drawerDepthBrandSelect,
            drawerFacadeMaterial,
            drawerSubList,
            drawerFacadeGapInput,
            drawerFrontOffsetInput,
            drawerBodyHeightInput,
            drawerStackGapInput,
            drawerRunnerThkInput,
            insertGapLeftInput,
            insertGapRightInput,
            pipeColorInput,
            drawerRunnerTypeSelect,
            falshSideSelect,
            falshSizeInput,
            addFalshBtn,
            falshList,
            falshLeftSideCheckbox,
            falshRightSideCheckbox,
            falshTopSideCheckbox,
            falshLeftSideSizeInput,
            falshRightSideSizeInput,
            falshTopSideSizeInput,
            addWallFrontalBtn,
            addWallVerticalBtn,
            partNameInput,
            partTypeInput,
            partSectionInput,
            partSizeInput,
            partOffsetFrontInput,
            edgeFrontInput,
            edgeBackInput,
            edgeLeftInput,
            edgeRightInput,
            partDrillingInput,
            offsetFrontInput,
            offsetBackInput,
            offsetBottomInput,
            offsetTopInput,
            offsetFrontLabel,
            offsetBackLabel,
            offsetBottomLabel,
            offsetTopLabel,
            viewButtons,
            modeButtons,
            animToggleBtn,
            toggleDimsBtn,
            toggleFacadeBtn,
            toggleEdgeBtn,
            toggleInfoBtn,
            undoBtn,
            redoBtn,

            dimensionBox,
            wallAngleInput,
            wallColorInput,
            wallWidthInput,
            wallHeightInput,
            wallListContainer,
            rebuildWalls,
            disposeWall: disposeWallGroup,
            get wallEnabled() { return wallEnabled; },
            set wallEnabled(v) {
                wallEnabled = !!v;
                if (!wallEnabled) disposeWallGroup();
            },
            get walls() { return walls; },
            set walls(v) { walls = v || []; rebuildWallsUI(); },
            get selectedWallId() { return selectedWallId; },
            set selectedWallId(v) { selectedWallId = v; rebuildWallsUI(); },
            rebuildWallsUI,
            addWallFromForm,
            updateSelectedWallFromForm,
            activatePanel: null, // app-settings.js толтырады
            get edgeHighlightEnabled() { return edgeHighlightEnabled; },
            set edgeHighlightEnabled(v) { edgeHighlightEnabled = !!v; applyEdgeHighlightVisibility(); },
            rebuildEdgeHighlightForPart
        };

        updateInsertSettingsVisibility();
        applyEdgeHighlightVisibility();

    } catch (e) {
        showError('Қате: ' + e.message);
        console.error(e);
    }
})();
