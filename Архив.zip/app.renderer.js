// app.renderer.js (split from app.legacy.js)
(function () {
    const errorBox     = document.getElementById('errorBox');
    const errorClose   = document.getElementById('errorClose');
    const errorText    = document.getElementById('errorText');
    const dimensionBox = document.getElementById('dimensionBox');

    function showError(msg) {
        if (!errorBox) return;
        if (errorText) errorText.textContent = msg;
        else errorBox.textContent = msg;
        errorBox.style.display = 'flex';
    }

    if (errorClose && errorBox) {
        errorClose.addEventListener('click', () => {
            errorBox.style.display = 'none';
        });
    }

    try {
        if (!window.THREE || !THREE.OrbitControls) {
            showError('THREE немесе OrbitControls жүктелген жоқ');
            return;
        }

        const wrap = document.getElementById('canvas-wrap');
        if (!wrap) {
            showError('#canvas-wrap табылмады');
            return;
        }

        // Renderer
        const renderer = new THREE.WebGLRenderer({antialias: true});
        renderer.setPixelRatio(window.devicePixelRatio || 1);
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        wrap.appendChild(renderer.domElement);

        // Scene + Camera
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0xf3f3f3);

        const CAMERA_NEAR_MIN = 1;
        const CAMERA_FAR_MIN  = 20000;

        // Негізгі перспективалық камера (Изометрия үшін)
        const perspCamera = new THREE.PerspectiveCamera(45, 1, CAMERA_NEAR_MIN, CAMERA_FAR_MIN);
        perspCamera.position.set(3800, 2600, 3800);

        // Орфографиялық камера (Алды / Жаны / Үсті – параллель вид)
        const aspectInit = (wrap.clientWidth || 800) / (wrap.clientHeight || 600);
        const orthoSizeInit = 3000;
        const orthoCamera = new THREE.OrthographicCamera(
            -orthoSizeInit * aspectInit,
            +orthoSizeInit * aspectInit,
            +orthoSizeInit,
            -orthoSizeInit,
            CAMERA_NEAR_MIN,
            CAMERA_FAR_MIN
        );
        orthoCamera.position.set(3800, 2600, 3800);
        orthoCamera.lookAt(0, 1200, 0);

        // Қолданылып жатқан актив камера
        let activeCamera = perspCamera;

        const controls = new THREE.OrbitControls(activeCamera, renderer.domElement);
        controls.target.set(0, 1200, 0);
        controls.update();

        let _lastPerspNear = perspCamera.near;
        let _lastPerspFar  = perspCamera.far;
        let _lastOrthoNear = orthoCamera.near;
        let _lastOrthoFar  = orthoCamera.far;

        function updateCameraClipping() {
            if (!controls || !perspCamera || !orthoCamera) return;

            const target = controls.target || new THREE.Vector3();
            const maxSize = Math.max(currentW || 0, currentH || 0, currentD || 0, 1200);

            function apply(cam, lastNear, lastFar) {
                const dist = cam.position.distanceTo(target);
                const near = Math.max(CAMERA_NEAR_MIN, dist / 1000);
                const far = Math.max(CAMERA_FAR_MIN, dist * 4, maxSize * 10);
                const changed = (Math.abs(lastNear - near) > 0.01) || (Math.abs(lastFar - far) > 1);
                if (changed) {
                    cam.near = near;
                    cam.far = far;
                    cam.updateProjectionMatrix();
                }
                return { near, far };
            }

            const perspRes = apply(perspCamera, _lastPerspNear, _lastPerspFar);
            _lastPerspNear = perspRes.near;
            _lastPerspFar  = perspRes.far;

            const orthoRes = apply(orthoCamera, _lastOrthoNear, _lastOrthoFar);
            _lastOrthoNear = orthoRes.near;
            _lastOrthoFar  = orthoRes.far;
        }

        // Lights
        scene.add(new THREE.AmbientLight(0xffffff, 0.4));
        const dirLight = new THREE.DirectionalLight(0xffffff, 1.15);
        dirLight.position.set(2000, 3000, 2000);
        dirLight.castShadow = true;
        dirLight.shadow.mapSize.width  = 4096;
        dirLight.shadow.mapSize.height = 4096;
        dirLight.shadow.bias = -0.0005;
        dirLight.shadow.normalBias = 0.02;
        scene.add(dirLight);

        // Floor
        const floorGeo = new THREE.PlaneGeometry(6000, 6000);
        const floorMat = new THREE.ShadowMaterial({ color: 0x000000, opacity: 0.25 });
        const floor = new THREE.Mesh(floorGeo, floorMat);
        floor.rotation.x = -Math.PI / 2;
        floor.position.y = 0;
        floor.receiveShadow = true;
        scene.add(floor);

        // Grid
        const grid = new THREE.GridHelper(5000, 50, 0xcccccc, 0xeeeeee);
        scene.add(grid);

        // Raycaster
        const raycaster = new THREE.Raycaster();
        const mouse     = new THREE.Vector2();

        let cabinetGroup           = null;
        let innerVolumeMesh        = null;
        let doorsGroup             = null;
        let plinthGroup            = null;
        let shelvesGroup           = null;
        let insertsGroup           = null;
        let dividersGroup          = null;
        let bodyCore               = null;
        let falshGroup             = null;
        let facadesHidden          = false;
        let allMeshes              = [];  // тек негізгі Mesh (Edges емес)
        let allEdges               = [];
        let currentViewMode        = 'sketch';

        // Секциялар (вертикаль)
        let sections               = [];  // {id,x,y,w,h}
        let nextSectionId          = 1;
        let innerW = 0;
        let innerH = 0;
        let prevInnerW = 0;
        let prevInnerH = 0;

        let globalThickness = 16;
        let globalDepth     = 600;
        let plinthHeight    = 100;
        let currentW = 0, currentH = 0, currentD = 0;
        let wallGap          = 10;
        let selectedSectionId      = null;
        let selectedSectionHelper  = null;
        let selectedShelfSubId     = null; // `${sectionId}:${idx}`
        let selectedShelfSubHelper = null;
        const subHighlightBaseColor   = new THREE.Color(0x4fa3ff);
        let sectionHighlightStart  = performance.now ? performance.now() : Date.now();
        const sectionHighlightBaseColor    = new THREE.Color(0xff77bb);
        const sectionHighlightBrightColor  = new THREE.Color(0xffa6d7);
        const sectionHighlightTempColor    = new THREE.Color();
        let sectionShelves         = {}; // sectionId => [heights]
        let sectionShelfOffsets    = {}; // sectionId => алдынан отступ (мм)
        let shelfInserts           = {}; // key `${sectionId}:${idx}` => [{ type, variant? }]
        let selectedInsertKey      = null; // `${sectionId}:${idx}#${insertIndex}`
        let facadeDividerCenters    = [];  // Накладной фасадта есік аралықтарының ортасы
        let shelfNameCounter        = 1;   // rebuild сайын полка атауларының уникальды санағы
        let cabinetOffsetX          = 0;   // сол жақ артқы бұрыштқыдан ығысқан (origin)
        let cabinetOffsetZ          = 0;
        const WALL_THICKNESS_DEFAULT = 1;
        let edgeHighlightEnabled    = false;
        let wallGroup               = null;
        let walls                   = [];
        let nextWallId              = 1;
        let selectedWallId          = null;
        let wallEnabled             = false;
        let currentAxisView         = 'iso';
        let wallPreviewInsertIndex  = null;
        let newWalls                = [];
        let newWallGroup            = null;
        let selectedNewWallId       = null;
        let wallSections            = {}; // wallId => [{id,parentId,x,y,w,h}]
        let selectedWallSectionId   = null;
        let selectedWallSectionHelper = null;
        let selectedWallHighlightHelper = null;
        let wallSectionHighlightStart = performance.now ? performance.now() : Date.now();
        const wallSectionHighlightBaseColor   = new THREE.Color(0x2bbf6a);
        const wallSectionHighlightBrightColor = new THREE.Color(0x66ff9c);
        const wallSectionHighlightTempColor   = new THREE.Color();
        let wallSectionPlusSprites  = [];
        let nextWallSectionId       = 1;

	        let falshPanels             = [];
	        let nextFalshId             = 1;
	        let falshLeftSideEnabled    = false;
	        let falshRightSideEnabled   = false;
	        let falshTopSideEnabled     = false;
	        let falshLeftSideSize       = null;
	        let falshRightSideSize      = null;
	        let falshTopSideSize        = null;
	        // Қосымша фальш панельдің тереңдігі (мм). null болса – автомат.
	        let falshLeftSideDepth      = null;
	        let falshRightSideDepth     = null;
	        let falshTopSideDepth       = null;

        let cabinetSpawned          = false;
        let cabinetBaseOffset       = { x: 0, y: 0, z: 0 };
        let cabinetRotationY        = 0;
        let cabinetWallId           = null;
        let cabinetSectionId        = null;
        let cabinets                = []; // [{id, wallId, sectionId, baseOffset, state, group}]
        let activeCabinetId         = null;
        const getAllCabinetGroups = () => {
            const arr = [];
            cabinets.forEach(c => {
                if (c.hidden) return;
                if (c.group) {
                    arr.push({ group: c.group, cabinet: c });
                }
            });
            const activeHidden = isCabinetHidden(activeCabinetId);
            const activeCab = cabinets.find(c => c.id === activeCabinetId);
            if (cabinetGroup && !activeHidden && !arr.some(x => x.group === cabinetGroup)) {
                arr.push({ group: cabinetGroup, cabinet: activeCab || null });
            }
            return arr;
        };

        function computeGlobalMaxSectionId() {
            let maxId = 0;
            const collect = (list) => {
                (list || []).forEach(s => {
                    const sid = parseFloat(s.id);
                    if (Number.isFinite(sid)) {
                        if (sid > maxId) maxId = sid;
                    }
                });
            };
            collect(sections);
            cabinets.forEach(c => {
                if (c && c.state && Array.isArray(c.state.sections)) {
                    collect(c.state.sections);
                }
            });
            return maxId;
        }

        function refreshNextSectionIdGlobal() {
            nextSectionId = computeGlobalMaxSectionId() + 1;
        }

        function isCabinetHidden(id) {
            if (!id) return false;
            const c = cabinets.find(x => x.id === id);
            return !!(c && c.hidden);
        }

        function setCabinetHidden(id, hidden) {
            const c = cabinets.find(x => x.id === id);
            if (!c) return;
            c.hidden = !!hidden;
            if (c.group) c.group.visible = !hidden;
            syncActiveCabinetRecord();
            rebuildDimensionHelpers();
        }

        function applyActiveCabinetVisibility() {
            getAllCabinetGroups().forEach(({ group, cabinet }) => {
                if (!group || !cabinet) return;
                const hidden = isCabinetHidden(cabinet.id);
                group.visible = !hidden; // белсенді емес шкафтар да көрінеді, егер жасырылмаған болса
                if (!group.parent) scene.add(group);
            });
            if (cabinetGroup && !cabinetGroup.parent) {
                const hidden = isCabinetHidden(activeCabinetId);
                cabinetGroup.visible = !hidden;
                scene.add(cabinetGroup);
            }
            syncCabinetVisibilityBtn();
        }

        function getActiveWallInfo() {
            if (!newWalls || !newWalls.length) return null;
            let wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) wall = newWalls[0];
            const w = wall.w || 0;
            const h = wall.h || 0;
            const x = wall.x || 0;
            const y = wall.y || 0;
            const z = wall.z || 0;
            const type = wall.type || 'frontal';
            return { w, h, x, y, z, type };
        }

        // Бөлшектер (part) инфо
        let parts          = {}; // partId => {...}
        let nextPartId     = 1;
        let selectedPartId = null;
        let selectedPartBoxHelper = null;
        const transientPartTypes = new Set(['shelf']);

        // Таңдау режимі: 'section' | 'part'
        let selectionMode = 'section';

        // Есіктер анимациясы
        let doorAnimEnabled = false;
        let doorGlobalOpen  = false; // deprecated toggle removed
        // Есіктер анимациясы – плавный open/close + звук
        let doorAnimations      = [];
        let drawerAnimations    = [];
        let doorSound           = null;
        let drawerSound         = null;
        let pendingDoorStates   = null; // createCabinet қолданар алдында state-тен берілетін есік күйі
        try {
            doorSound = new Audio('door-sound.mp3');
            doorSound.volume = 0.35;
        } catch (e) {
            doorSound = null;
        }
        try {
            drawerSound = new Audio('box.mp3');
            drawerSound.volume = 0.35;
        } catch (e) {
            drawerSound = null;
        }


        

        function getDoorOpenSignByIndex(patternStr, doorIndex, totalDoors) {
            patternStr = (patternStr || '').replace(/\s+/g, '');
            let sign = -1;

            // 1 / 1 → екі есік, екі жаққа (сол, оң)
            if (patternStr === '1/1') {
                sign = (doorIndex === 0 ? -1 : +1);
            }
            // 2 → бір секцияда 2 есік: сол жақ есік солға, оң жақ есік оңға
            else if (patternStr === '2') {
                sign = (doorIndex === 0 ? -1 : +1);
            }
            // 2 / 1 → алғашқы екі есік – екі жаққа, үшінші есік – оңға
            else if (patternStr === '2/1') {
                if (doorIndex === 0) sign = -1;
                else sign = +1;
            }
            // 1 / 2 → алғашқы есік солға, келесі екі есік – екі жаққа
            else if (patternStr === '1/2') {
                if (doorIndex === 0) sign = -1;
                else if (doorIndex === 1) sign = -1;
                else sign = +1;
            }
            // 1 / 1 / 1 → алғашқы есік солға, келесі екеуі – оңға
            else if (patternStr === '1/1/1') {
                if (doorIndex === 0) sign = -1;
                else sign = +1;
            }

            return sign;
        }

        function findDoorsGroupFromObject(obj) {
            let o = obj;
            while (o) {
                if (o.userData && o.userData.isDoorsGroup) return o;
                o = o.parent;
            }
            return null;
        }

        function findCabinetIdFromObject(obj) {
            let o = obj;
            while (o) {
                if (o.userData && o.userData.cabinetId != null) return o.userData.cabinetId;
                o = o.parent;
            }
            return null;
        }

        function syncDoorStatesToCabinetRecord(doorsGroup) {
            if (!doorsGroup) return;
            const cabId = findCabinetIdFromObject(doorsGroup);
            if (cabId == null) return;
            const rec = cabinets.find(c => c && c.id === cabId);
            if (!rec) return;
            if (!rec.state || typeof rec.state !== 'object') rec.state = {};
            rec.state.doorStates = readDoorStatesFromGroup(doorsGroup);
        }

        function animateDoorHinge(hinge) {
            if (!hinge) return;
            const ownerDoorsGroup = findDoorsGroupFromObject(hinge);
            if (!ownerDoorsGroup) return;

            // Есіктер тізімін солдан оңға қарай аламыз (нақты осы кабинеттің group-ынан)
            const hinges = [];
            ownerDoorsGroup.traverse(obj => {
                if (obj.userData && obj.userData.isDoorHinge) {
                    hinges.push(obj);
                }
            });
            hinges.sort((a, b) => a.position.x - b.position.x);

            const totalDoors = hinges.length || 1;
            let doorIndex = hinges.indexOf(hinge);
            if (doorIndex < 0) doorIndex = 0;

            const patternStr = (ownerDoorsGroup.userData && ownerDoorsGroup.userData.splitPattern)
                ? ownerDoorsGroup.userData.splitPattern
                : (splitPatternInput ? splitPatternInput.value : '');
            let rawSign = getDoorOpenSignByIndex(patternStr, doorIndex, totalDoors);
            if (!rawSign) rawSign = -1; // default – солға ашылатын

            // Бірінші рет ашылса – айналу осін дұрыстап қоямыз
            if (!hinge.userData.pivotPrepared) {
                const doorW     = hinge.userData.doorWidth;
                const doorGroup = hinge.userData.doorGroup;

                if (doorW && doorGroup) {
                    // Оң жаққа ашылатын есік → осі оң жақ қырына ауысады
                    if (rawSign > 0) {
                        hinge.position.x += doorW;
                        doorGroup.position.x = -doorW / 2;
                    } else {
                        // Сол жаққа ашылатын есік → осі сол жақ қырында қалады
                        doorGroup.position.x = doorW / 2;
                    }
                }
                hinge.userData.pivotPrepared = true;
            }

            // Есіктердің барлығы сыртқа (қолданушыға қарай) ашылуы үшін – бастапқы бағытты қолданамыз
            const sign = rawSign;

            const isOpen  = hinge.userData.open || false;
            const nowOpen = !isOpen;
            hinge.userData.open = nowOpen;

            const from = hinge.rotation.y || 0;
            const to   = nowOpen ? sign * (Math.PI / 2) : 0;
            const duration = 350; // мс – плавная анимация

            syncDoorStatesToCabinetRecord(ownerDoorsGroup);

            if (Array.isArray(doorAnimations)) {
                doorAnimations.push({
                    hinge: hinge,
                    from: from,
                    to: to,
                    start: performance.now(),
                    duration: duration
                });
            }

            if (doorSound) {
                try {
                    doorSound.currentTime = 0;
                    const p = doorSound.play();
                    if (p && typeof p.catch === 'function') {
                        p.catch(()=>{});
                    }
                } catch (e) {}
            }
        }

        function getSelectedInsertTypeForSettings() {
            if (selectedInsertKey) {
                const [subId, idxStr] = selectedInsertKey.split('#');
                const idx = parseInt(idxStr, 10);
                if (subId && Number.isInteger(idx)) {
                    const arr = shelfInserts[subId] || [];
                    if (arr[idx]) return arr[idx].type || null;
                }
            }
            return null;
        }

        function updateInsertSettingsVisibility() {
            const type = getSelectedInsertTypeForSettings() || (insertTypeSelect ? insertTypeSelect.value : null);
            const showDrawer = type === 'drawer';
            const showPipe   = type === 'pipe';
            const drawerElems = document.querySelectorAll('.drawer-settings');
            const pipeElems   = document.querySelectorAll('.pipe-settings');
            drawerElems.forEach(el => {
                if (!el) return;
                el.style.display = showDrawer ? '' : 'none';
            });
            pipeElems.forEach(el => {
                if (!el) return;
                el.style.display = showPipe ? '' : 'none';
            });
        }

        function getPipeColorHex() {
            if (!pipeColorInput || !pipeColorInput.value) return 0x111111;
            const v = pipeColorInput.value.trim();
            const normalized = v.startsWith('#') ? v.slice(1) : v;
            if (/^[0-9a-fA-F]{6}$/.test(normalized)) {
                return parseInt(normalized, 16);
            }
            return 0x111111;
        }

        function rebuildInsertsUI() {
            if (!insertList) return;
            insertList.innerHTML = '';

            const subsAll = getShelfSubSections();
            sanitizeShelfInserts(subsAll);
            const entries = [];
            const targetSubs = selectedShelfSubId
                ? subsAll.filter(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId)
                : subsAll;
            targetSubs.forEach(sub => {
                const key = `${sub.sectionId}:${sub.idx}`;
                const arr = shelfInserts[key] || [];
                arr.forEach((ins, i) => entries.push({ sub, ins, idxInSub: i }));
            });

            if (!entries.length) {
                insertList.textContent = 'Наполнение жоқ';
                selectedInsertKey = null;
                updateInsertSettingsVisibility();
                return;
            }

            // Таңдау жоғалса, бірінші элементті автоматты түрде таңдаймыз
            const hasSelection = selectedInsertKey && entries.some(e => `${e.sub.sectionId}:${e.sub.idx}#${e.idxInSub}` === selectedInsertKey);
            if (!hasSelection) {
                const first = entries[0];
                selectedInsertKey = `${first.sub.sectionId}:${first.sub.idx}#${first.idxInSub}`;
                selectedShelfSubId = `${first.sub.sectionId}:${first.sub.idx}`;
            }

            entries.forEach(({ sub, ins, idxInSub }) => {
                const key = `${sub.sectionId}:${sub.idx}`;
                const row = document.createElement('div');
                row.className = 'simple-list-item shelf-sub-row';
                row.dataset.subId = key;
                row.dataset.insertIdx = String(idxInSub);
                const thisKey = `${key}#${idxInSub}`;
                const isSelected = selectedInsertKey && selectedInsertKey === thisKey;
                if (isSelected) {
                    row.classList.add('active');
                }

                const name = document.createElement('div');
                name.className = 'meta';
                const drawerLabel = (ins.variant === 'tandembox')
                    ? 'Тандем бокс'
                    : (ins.variant === 'tandem')
                        ? 'Тандем'
                        : 'Телескопический';
                const labelShort = sub.sectionId + '.' + sub.idx;
                const pipeLabel = ins.type === 'pipe'
                    ? 'Труба #' + (idxInSub + 1)
                    : 'Ящик (' + drawerLabel + ')';
                name.textContent = labelShort + ' · ' + pipeLabel;

                const delBtn = document.createElement('button');
                delBtn.type = 'button';
                delBtn.innerHTML = '<i class="fa-solid fa-trash" aria-hidden="true"></i>';
                delBtn.className = 'danger-btn';

                row.appendChild(name);
                row.appendChild(delBtn);

                row.addEventListener('click', () => {
                    selectedShelfSubId = row.dataset.subId;
                    selectedInsertKey = `${row.dataset.subId}#${row.dataset.insertIdx}`;
                    syncDrawerDepthSelect(sub);
                    const activeRows = insertList.querySelectorAll('.shelf-sub-row.active');
                    activeRows.forEach(r => r.classList.remove('active'));
                    row.classList.add('active');
                    updateSelectedShelfSubHelper();
                    syncDrawerActiveRow();
                    updateInsertSettingsVisibility();
                });
                delBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const arr = Array.isArray(shelfInserts[key]) ? shelfInserts[key] : [];
                    arr.splice(idxInSub, 1);
                    shelfInserts[key] = arr;
                    if (selectedShelfSubId === key && arr.length === 0) selectedShelfSubId = null;
                    if (selectedInsertKey === `${key}#${idxInSub}`) selectedInsertKey = null;
                    rebuildInsertsUI();
                    rebuildInsertsGroup();
                });

                insertList.appendChild(row);
            });

            const activeEntry = entries.find(e => `${e.sub.sectionId}:${e.sub.idx}#${e.idxInSub}` === selectedInsertKey);
            if (activeEntry) {
                syncDrawerDepthSelect(activeEntry.sub);
            }

            rebuildDrawerSubList();
            updateInsertSettingsVisibility();
        }

// Өлшемдік кесінділер (стрелкасыз)
        let dimensionHelpersGroup = null;
        let dimensionsVisible     = true;
        let infoPanelVisible      = false;
        let structureVisible      = false;

        // Undo/Redo стек
        let undoStack = [];
        let redoStack = [];
        let hasUnsavedChanges = false;

        // Материал түстері
        function colorFromInputById(id, fallback) {
            const el = document.getElementById(id);
            if (!el || !el.value) return fallback;
            const hexStr = String(el.value).trim();
            if (!/^#?[0-9a-fA-F]{6}$/.test(hexStr)) return fallback;
            return parseInt(hexStr.replace('#', ''), 16);
        }

        function getCorpusColor(value) {
            let base = 0xf5f5f5;
            if (value === 'sonoma')   base = 0xd2b48c;
            if (value === 'graphite') base = 0x444444;
            return colorFromInputById('corpusColor', base);
        }

        function getFacadeColor(value) {
            let base = 0xffffff;
            if (value === 'beige') base = 0xf5e1c4;
            if (value === 'black') base = 0x111111;
            return colorFromInputById('facadeColor', base);
        }

        // === ІШКІ ТЕРЕҢДІК: ФАСАДҚА БАЙЛАНЫСТЫ ===
        // - Вкладной: фасад қалыңдығынан 2 мм ге ішке кіреді
        // - Накладной: корпуспен бірдей тереңдік
        function computeInnerParams() {
            const facadeTypeEl      = document.getElementById('facadeType');
            const facadeThicknessEl = document.getElementById('facadeThickness');

            const typeVal  = facadeTypeEl ? facadeTypeEl.value : 'vkladnoy';
            const thickVal = facadeThicknessEl ? (parseFloat(facadeThicknessEl.value) || 18) : 18;

            const backPlaneInside  = -globalDepth / 2;
            let frontPlaneInside = globalDepth / 2;

            let extraFront = 0;
            if (typeVal === 'vkladnoy') {
                extraFront = thickVal + 2;
            }
            frontPlaneInside -= extraFront;

            const depthInside = frontPlaneInside - backPlaneInside;
            const centerZ     = backPlaneInside + depthInside / 2;

            return {
                depthInside: depthInside,
                centerZ: centerZ
            };
        }

        function readWallGap() {
            const parsed = parseFloat(wallGapInput ? wallGapInput.value : '');
            wallGap = Number.isFinite(parsed) ? parsed : 10;
            return wallGap;
        }

        function readDrawerFacadeGap() {
            if (!drawerFacadeGapInput) return 3;
            let v = parseFloat(drawerFacadeGapInput.value);
            if (!isFinite(v) || v < 0) v = 3;
            drawerFacadeGapInput.value = v;
            return v;
        }

        function readDrawerStackGap() {
            if (!drawerStackGapInput) return 0;
            let v = parseFloat(drawerStackGapInput.value);
            if (!isFinite(v) || v < 0) v = 0;
            drawerStackGapInput.value = v;
            return v;
        }

        function readDrawerBodyHeight() {
            if (!drawerBodyHeightInput) return 120;
            let v = parseFloat(drawerBodyHeightInput.value);
            if (!isFinite(v) || v < 40) v = 120;
            drawerBodyHeightInput.value = v;
            return v;
        }

        function readDrawerFrontOffset() {
            if (!drawerFrontOffsetInput) return 0;
            let v = parseFloat(drawerFrontOffsetInput.value);
            if (!isFinite(v) || v < 0) v = 16;
            drawerFrontOffsetInput.value = v;
            return v;
        }

        function readDrawerRunnerThk() {
            if (!drawerRunnerThkInput) return 13;
            let v = parseFloat(drawerRunnerThkInput.value);
            if (!isFinite(v) || v < 0) v = 13;
            drawerRunnerThkInput.value = v;
            return v;
        }

        function readDrawerDepthBrand() {
            const el = document.getElementById('drawerDepthBrandSelect');
            if (!el) return 'standard';
            const val = el.value;
            return val ? val : 'standard';
        }

        function getDrawerDepthBrandOffset() {
            const brand = readDrawerDepthBrand();
            if (brand === 'blum' || brand === 'china') return 10;
            return 0;
        }

        function readInsertGapValue(input, fallback) {
            if (!input) return fallback;
            let v = parseFloat(input.value);
            if (!isFinite(v) || v < 0) v = fallback;
            input.value = v;
            return v;
        }

        function readInsertSideGaps() {
            return {
                left: readInsertGapValue(insertGapLeftInput, 50),
                right: readInsertGapValue(insertGapRightInput, 50)
            };
        }

        const drawerDepthPresets = [250,300,350,400,450,500,550];
        function pickDrawerDepthForSub(sub) {
            const innerParams = computeInnerParams();
            let depth = innerParams.depthInside;
            if (sub && sub.sectionId && sectionShelfOffsets[sub.sectionId] != null) {
                const off = sectionShelfOffsets[sub.sectionId] || 0;
                depth = Math.max(10, depth - off);
            }
            // Корпус тереңдігінен шамамен 50 мм резерв қалдырамыз (арқа/фасад/жабдық)
            const usable = Math.max(0, depth - 50);
            let best = drawerDepthPresets[0];
            let found = false;
            drawerDepthPresets.forEach(d => {
                if (d <= usable && d >= best) {
                    best = d;
                    found = true;
                }
            });
            if (!found) {
                // Егер бірде-бір preset сыймаса, ең кіші preset аламыз
                best = drawerDepthPresets[0];
            }
            return best;
        }

        function syncDrawerDepthSelect(sub) {
            if (!drawerDepthSelect) return;
            const auto = pickDrawerDepthForSub(sub || null);
            const key = sub ? `${sub.sectionId}:${sub.idx}` : selectedShelfSubId;
            let val = auto;
            if (key && shelfInserts[key]) {
                const arr = shelfInserts[key] || [];
                if (selectedInsertKey && selectedInsertKey.startsWith(key + '#')) {
                    const idxStr = selectedInsertKey.split('#')[1];
                    const idx = parseInt(idxStr, 10);
                    if (Number.isInteger(idx) && arr[idx] && arr[idx].type === 'drawer' && arr[idx].depth) {
                        val = arr[idx].depth;
                    }
                }
                if (!drawerDepthPresets.includes(val)) {
                    const firstDrawer = arr.find(it => it && it.type === 'drawer' && it.depth);
                    if (firstDrawer && drawerDepthPresets.includes(firstDrawer.depth)) {
                        val = firstDrawer.depth;
                    }
                }
            }
            if (!drawerDepthPresets.includes(val)) val = auto;
            drawerDepthSelect.value = val;
        }

        function disposeMat(m) {
            if (!m) return;
            if (Array.isArray(m)) {
                m.forEach(disposeMat);
                return;
            }
            if (m.dispose) m.dispose();
        }

        function disposeGroup(group) {
            if (!group) return;
            scene.remove(group);
            group.traverse(obj => {
                if (obj.geometry) obj.geometry.dispose();
                if (obj.material) obj.material.dispose();
            });
        }

        function disposeCabinetGroupsById(cabinetId) {
            if (!scene || cabinetId == null) return;
            scene.children
                .filter(obj => obj.userData && obj.userData.cabinetId === cabinetId)
                .forEach(disposeGroup);
        }

        // Mesh + edges + part helper
        function solidWithEdges(geometry, colorHex, partInfo) {
            const group = new THREE.Group();

            const isGlassDoor = partInfo && partInfo.type && String(partInfo.type).toLowerCase() === 'door' &&
                partInfo.materialType === 'glass';
            const mat = new THREE.MeshStandardMaterial({
                color: isGlassDoor ? 0x6db7ff : colorHex,
                metalness: isGlassDoor ? 0.0 : 0.2,
                roughness: isGlassDoor ? 0.1 : 0.7,
                transparent: isGlassDoor,
                opacity: isGlassDoor ? 0.35 : 1.0
            });
            const mesh = new THREE.Mesh(geometry, mat);
            mesh.castShadow = true;
            mesh.receiveShadow = true;
            mesh.userData.baseColor = isGlassDoor ? 0x6db7ff : colorHex;
            if (isGlassDoor) {
                mesh.userData.isGlass = true;
            }
            mesh.userData.partPickable = true;

            const pid = nextPartId++;
            mesh.userData.partId = pid;
            const params = geometry.parameters || {};
            const materialLabel = (partInfo && (partInfo.materialName || partInfo.material)) || '';
            parts[pid] = {
                id: pid,
                type: (partInfo && partInfo.type) || 'unknown',
                name: (partInfo && partInfo.name) || '',
                sectionId: (partInfo && partInfo.sectionId) || null,
                cabinetId: activeCabinetId || null,
                width: (partInfo && partInfo.width) || params.width || 0,
                height: (partInfo && partInfo.height) || params.height || 0,
                depth: (partInfo && partInfo.depth) || params.depth || 0,
                material: materialLabel,
                materialType: (partInfo && partInfo.materialType) || '',
                baseDims: {
                    width: (partInfo && partInfo.width) || params.width || 0,
                    height: (partInfo && partInfo.height) || params.height || 0,
                    depth: (partInfo && partInfo.depth) || params.depth || 0
                },
                meshBasePosition: mesh.position.clone(),
                offsets: { front:0, back:0, bottom:0, top:0, left:0, right:0 },
                frontOffset: 0,
                edge: (() => {
                    const requested = partInfo && partInfo.edge;
                    if (requested && typeof requested === 'object') {
                        return {
                            front: !!requested.front,
                            back:  !!requested.back,
                            left:  !!requested.left,
                            right: !!requested.right
                        };
                    }
                    const t = (partInfo && partInfo.type) ? partInfo.type.toLowerCase() : '';
                    const mountType = (partInfo && partInfo.mountType) ? String(partInfo.mountType).toLowerCase() : '';
                    const isNakladnoyBottom = (mountType === 'nakladnoy');
                    if (t === 'side') {
                        return { front:true, back:false, left:!isNakladnoyBottom, right:true };
                    }
                    if (t === 'top') {
                        return { front:true, back:false, left:false, right:false };
                    }
                    if (t === 'bottom') {
                        const sideEdge = isNakladnoyBottom;
                        return { front:true, back:false, left:sideEdge, right:sideEdge };
                    }
                    if (t === 'divider') {
                        return { front:true, back:false, left:false, right:false };
                    }
                    if (t === 'shelf') {
                        return { front:true, back:false, left:false, right:false };
                    }
                    if (t === 'plinth') {
                        return { front:true, back:false, left:false, right:false };
                    }
                    return { front:false, back:false, left:false, right:false };
                })(),
                drilling: '',
                extra: partInfo || {},
                mesh: mesh
            };

            group.add(mesh);

            const edgesGeo = new THREE.EdgesGeometry(geometry);
            const edgesMat = new THREE.LineBasicMaterial({
                color: 0x222222,
                linewidth: 1
            });
            const edges = new THREE.LineSegments(edgesGeo, edgesMat);
            mesh.add(edges); // attach to mesh so scaling/offsets keep outlines in sync

            allMeshes.push(mesh);
            edges.__parentMesh = mesh;
            allEdges.push(edges);

            rebuildEdgeHighlightForPart(parts[pid]);
            return group;
        }

        function disposeWallGroup() {
            if (!wallGroup) return;
            scene.remove(wallGroup);
            wallGroup.traverse(obj => {
                if (obj.geometry) obj.geometry.dispose();
                if (obj.material) {
                    if (obj.material.map && obj.material.map.dispose) obj.material.map.dispose();
                    obj.material.dispose();
                }
            });
            wallGroup = null;
        }

        function disposeNewWallGroup() {
            if (!newWallGroup) return;
            scene.remove(newWallGroup);
            newWallGroup.traverse(obj => {
                if (obj.geometry) obj.geometry.dispose();
                if (obj.material) {
                    if (obj.material.map && obj.material.map.dispose) obj.material.map.dispose();
                    obj.material.dispose();
                }
            });
            newWallGroup = null;
            selectedWallSectionHelper = null;
            selectedWallHighlightHelper = null;
            wallSectionPlusSprites = [];
        }

        function createWallLabelSprite(text) {
            // Кабинет өлшем лейбл стиліне жақындатамыз
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = 2048;
            canvas.height = 1024;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#000000';
            ctx.font = '150px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(text, canvas.width / 2, canvas.height / 2);

            const texture = new THREE.CanvasTexture(canvas);
            texture.minFilter = THREE.LinearFilter;
            texture.magFilter = THREE.LinearFilter;

            const material = new THREE.SpriteMaterial({
                map: texture,
                transparent: true,
                depthTest: false
            });
            const sprite = new THREE.Sprite(material);
            sprite.scale.set(600, 300, 1);
            return sprite;
        }

        function createWallPlusSprite() {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = 512;
            canvas.height = 512;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            // Тек "+" белгісі, фон/шеңберсіз
            ctx.fillStyle = '#000';
            ctx.font = '240px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('+', 256, 260);

            const texture = new THREE.CanvasTexture(canvas);
            texture.minFilter = THREE.LinearFilter;
            texture.magFilter = THREE.LinearFilter;

            const material = new THREE.SpriteMaterial({
                map: texture,
                transparent: true,
                depthTest: false
            });
            const sprite = new THREE.Sprite(material);
            sprite.scale.set(300, 300, 1);
            sprite.renderOrder = 1200;
            return sprite;
        }

        function createCabinetNumberSprite(text) {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = 1024;
            canvas.height = 512;
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            const radius = 40;
            const rectX = 40;
            const rectY = 40;
            const rectW = canvas.width - rectX * 2;
            const rectH = canvas.height - rectY * 2;
            ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
            ctx.beginPath();
            ctx.moveTo(rectX + radius, rectY);
            ctx.lineTo(rectX + rectW - radius, rectY);
            ctx.quadraticCurveTo(rectX + rectW, rectY, rectX + rectW, rectY + radius);
            ctx.lineTo(rectX + rectW, rectY + rectH - radius);
            ctx.quadraticCurveTo(rectX + rectW, rectY + rectH, rectX + rectW - radius, rectY + rectH);
            ctx.lineTo(rectX + radius, rectY + rectH);
            ctx.quadraticCurveTo(rectX, rectY + rectH, rectX, rectY + rectH - radius);
            ctx.lineTo(rectX, rectY + radius);
            ctx.quadraticCurveTo(rectX, rectY, rectX + radius, rectY);
            ctx.closePath();
            ctx.fill();

            ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
            ctx.font = 'bold 340px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(text, canvas.width / 2, canvas.height / 2 + 10);

            const texture = new THREE.CanvasTexture(canvas);
            texture.minFilter = THREE.LinearFilter;
            texture.magFilter = THREE.LinearFilter;

            const material = new THREE.SpriteMaterial({
                map: texture,
                transparent: true,
                depthTest: false
            });
            const sprite = new THREE.Sprite(material);
            sprite.scale.set(480, 240, 1);
            sprite.renderOrder = 1250;
            return sprite;
        }

        function applyWallViewMode() {
            if (!wallGroup) return;
            wallGroup.traverse(obj => {
                if (obj.isMesh && obj.material) {
                    const mat = obj.material;
                    if (currentViewMode === 'xray') {
                        mat.transparent = true;
                        mat.opacity = 0.25;
                        mat.depthWrite = false;
                        mat.depthTest = true;
                    } else if (currentViewMode === 'sketch') {
                        mat.transparent = true;
                        mat.opacity = 0.8;
                        mat.depthWrite = true;
                        mat.depthTest = true;
                    } else {
                        mat.transparent = false;
                        mat.opacity = 1;
                        mat.depthWrite = true;
                        mat.depthTest = true;
                    }
                }
            });
        }

        function updateWallDecorations() {
            if (!wallGroup) return;
            wallGroup.traverse(obj => {
                if (obj.userData && obj.userData.isWallEdges) {
                    obj.visible = (currentAxisView !== 'iso');
                }
            });
        }

        function ensureDefaultWalls() {
            walls = [];
            selectedWallId = null;
            wallEnabled = false;
        }

        function rebuildWallsUI() {
            return;
        }

        function fillWallForm(w) { return; }

        function getDefaultWallAngle(insertIndex) { return 0; }

        function addWallFromForm(insertIndex) { return; }

        function deleteWall(id) { return; }

        function updateSelectedWallFromForm() { return; }

        function rebuildWalls() {
            disposeWallGroup();
            wallGroup = null;
            drawWallSketch();
        }

        function getWallsWithPreview() {
            return [];
        }

        function computeWallSegmentsForSketch() {
            return { segments: [], bounds: null };
        }

        function resizeWallSketchCanvas() {
            if (!wallSketchCanvas || !wallSketchCtx) return;
            const rect = wallSketchCanvas.getBoundingClientRect();
            const dpr = window.devicePixelRatio || 1;
            wallSketchCanvas.width  = Math.max(1, Math.round(rect.width * dpr));
            wallSketchCanvas.height = Math.max(1, Math.round(rect.height * dpr));
            wallSketchCtx.setTransform(1, 0, 0, 1, 0, 0);
            wallSketchCtx.scale(dpr, dpr);
        }

        function drawWallSketch() {
            // Эскиз қажет емес – бос функция
            return;
        }

        function setWallPreview(insertIndex) { return; }
        function clearWallPreview() { return; }

        function applyViewModeToGroup(group, mode) {
            if (!group) return;
            const meshes = [];
            const edges  = [];
            group.traverse(obj => {
                if (obj.isMesh && obj.userData && obj.userData.baseColor !== undefined) {
                    meshes.push(obj);
                } else if (obj.type === 'LineSegments' && obj.__parentMesh) {
                    edges.push(obj);
                }
            });

            meshes.forEach(mesh => {
                const baseColor = mesh.userData.baseColor || 0xffffff;
                if (mesh.material) disposeMat(mesh.material);

                let newMat;
                if (mode === 'shadow') {
                    newMat = new THREE.MeshStandardMaterial({
                        color: baseColor,
                        metalness: 0.2,
                        roughness: 0.7
                    });
                    newMat.transparent = false;
                } else if (mode === 'xray') {
                    newMat = new THREE.MeshStandardMaterial({
                        color: baseColor,
                        metalness: 0.0,
                        roughness: 0.1
                    });
                    newMat.transparent = true;
                    newMat.opacity     = 0.25;
                } else { // sketch
                    newMat = new THREE.MeshLambertMaterial({
                        color: baseColor,
                        flatShading: true
                    });
                    newMat.transparent = true;
                    newMat.opacity = 0.8;
                }
                mesh.material = newMat;
            });

            edges.forEach(edge => {
                edge.visible = true;
                edge.material.color.set(
                    mode === 'shadow' ? 0x222222 : 0x000000
                );
            });
        }

        // View mode
        function setViewMode(mode) {
            currentViewMode = mode;

            if (mode === 'shadow') {
                renderer.shadowMap.enabled = true;
                dirLight.castShadow = true;
                floor.visible = true;
            } else if (mode === 'xray') {
                renderer.shadowMap.enabled = false;
                dirLight.castShadow = false;
                floor.visible = false;
            } else { // sketch
                renderer.shadowMap.enabled = false;
                dirLight.castShadow = false;
                floor.visible = false;
            }

            getAllCabinetGroups().forEach(({ group }) => applyViewModeToGroup(group, mode));
            applyWallViewMode();
            updateSectionEdgeHighlight();
            updateSectionFaceHighlight();
            syncFacadesVisibilityAll();
            syncShelfSubHelperVisibility();
            if (viewButtons && viewButtons.length) {
                viewButtons.forEach(btn => {
                    const m = btn.dataset.view;
                    btn.classList.toggle('active', m === mode);
                });
            }
        }

        // Өлшемдік кесінділер (сыртқы өлшемдер + ұштарында тік сызық, ортасында үлкен сан)
        function updateDimensionLabelAngles() {
            if (!dimensionHelpersGroup || !activeCamera || !renderer) return;
            const domW = (renderer.domElement && renderer.domElement.clientWidth) || 1;
            const domH = (renderer.domElement && renderer.domElement.clientHeight) || 1;
            dimensionHelpersGroup.traverse(obj => {
                if (!obj.isSprite) return;
                const ls = obj.userData && obj.userData.lineStart;
                const le = obj.userData && obj.userData.lineEnd;
                if (!ls || !le) return;
                const a = ls.clone().project(activeCamera);
                const b = le.clone().project(activeCamera);
                const ax = (a.x * 0.5 + 0.5) * domW;
                const ay = (-a.y * 0.5 + 0.5) * domH;
                const bx = (b.x * 0.5 + 0.5) * domW;
                const by = (-b.y * 0.5 + 0.5) * domH;
                let angle = Math.atan2(by - ay, bx - ax);
                if (angle > Math.PI / 2) angle -= Math.PI;
                if (angle < -Math.PI / 2) angle += Math.PI;
                if (obj.material) obj.material.rotation = angle;
            });
        }

        function rebuildDimensionHelpers() {
            if (dimensionHelpersGroup) {
                scene.remove(dimensionHelpersGroup);
                dimensionHelpersGroup.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
                dimensionHelpersGroup = null;
            }

            dimensionHelpersGroup = new THREE.Group();

            const isXray = (currentViewMode === 'xray');
            const colorCab = 0xff0000;
            const colorWall = 0x00aa00;

            function hexToCss(hex) {
                return '#' + hex.toString(16).padStart(6, '0');
            }

            function addLine(p1, p2, opts) {
                const color = opts && opts.color !== undefined ? opts.color : colorCab;
                const overlay = opts && opts.overlay;
                const depthTest = (opts && opts.depthTest !== undefined)
                    ? opts.depthTest
                    : (!isXray || !overlay);
                const geo = new THREE.BufferGeometry().setFromPoints([p1, p2]);
                const mat = new THREE.LineBasicMaterial({
                    color,
                    depthTest,
                    depthWrite: false
                });
                const line = new THREE.Line(geo, mat);
                line.renderOrder = overlay ? 1000 : (isXray ? 100 : 0);
                dimensionHelpersGroup.add(line);

                // Стрелка (конус) ұштары
                if (!opts || opts.noArrow !== true) {
                    const len = p1.distanceTo(p2);
                    const arrowH = Math.max(10, Math.min(40, len * 0.05));
                    const arrowR = arrowH * 0.35;
                    const coneGeo = new THREE.ConeGeometry(arrowR, arrowH, 8);
                    const coneMat = new THREE.MeshBasicMaterial({
                        color,
                        depthTest,
                        depthWrite: false
                    });
                    const dir = new THREE.Vector3().subVectors(p1, p2).normalize(); // іштен сыртқа қарай
                    const quat = new THREE.Quaternion().setFromUnitVectors(
                        new THREE.Vector3(0, 1, 0),
                        dir
                    );
                    const cone1 = new THREE.Mesh(coneGeo, coneMat);
                    cone1.quaternion.copy(quat);
                    cone1.position.copy(p1).add(dir.clone().negate().multiplyScalar(arrowH * 0.4));
                    cone1.renderOrder = line.renderOrder;
                    dimensionHelpersGroup.add(cone1);

                    const cone2 = new THREE.Mesh(coneGeo.clone(), coneMat.clone());
                    const quat2 = new THREE.Quaternion().setFromUnitVectors(
                        new THREE.Vector3(0, 1, 0),
                        dir.clone().negate()
                    );
                    cone2.quaternion.copy(quat2);
                    cone2.position.copy(p2).add(dir.clone().multiplyScalar(arrowH * 0.4));
                    cone2.renderOrder = line.renderOrder;
                    dimensionHelpersGroup.add(cone2);
                }
            }

            // Үлкен label (спрайт)
            function addLabel(text, position, lineStart, lineEnd, opts) {
                const overlay = opts && opts.overlay;
                const depthTestFlag = opts && opts.depthTest;
                const colorStr = (opts && opts.color) ? opts.color : '#000000';
                const canvas = document.createElement('canvas');
                const ctx    = canvas.getContext('2d');

                canvas.width  = 2048;
                canvas.height = 1024;

                ctx.clearRect(0, 0, canvas.width, canvas.height);

                ctx.fillStyle = colorStr;
                ctx.font = '150px Arial';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';

                ctx.fillText(text, canvas.width / 2, canvas.height / 2);

                const texture = new THREE.CanvasTexture(canvas);
                const mat = new THREE.SpriteMaterial({
                    map: texture,
                    transparent: true,
                    depthTest: (overlay ? !!depthTestFlag : !isXray),
                    depthWrite: false
                });
                const sprite = new THREE.Sprite(mat);
                sprite.renderOrder = overlay ? 1001 : (isXray ? 101 : 0);

                sprite.position.copy(position);
                sprite.scale.set(600, 300, 1);
                if (lineStart && lineEnd) {
                    sprite.userData.lineStart = lineStart.clone();
                    sprite.userData.lineEnd   = lineEnd.clone();
                }

                // Экранда өлшем мәтіні сызыққа параллель болсын
                if (lineStart && lineEnd && activeCamera) {
                    const a = lineStart.clone().project(activeCamera);
                    const b = lineEnd.clone().project(activeCamera);

                    const domW = (renderer && renderer.domElement && renderer.domElement.clientWidth)  || 1;
                    const domH = (renderer && renderer.domElement && renderer.domElement.clientHeight) || 1;

                    // NDC → экран координаттары (y төмен бағытта)
                    const ax = (a.x * 0.5 + 0.5) * domW;
                    const ay = (-a.y * 0.5 + 0.5) * domH;
                    const bx = (b.x * 0.5 + 0.5) * domW;
                    const by = (-b.y * 0.5 + 0.5) * domH;

                    // Keep text upright: clamp rotation to +/-90deg so labels (depth especially) are not upside down
                    let angle = Math.atan2(by - ay, bx - ax);
                    if (angle > Math.PI / 2) angle -= Math.PI;
                    if (angle < -Math.PI / 2) angle += Math.PI;
                    sprite.material.rotation = angle;
                }

                dimensionHelpersGroup.add(sprite);
            }

            const allCabGroups = getAllCabinetGroups();
            let any = false;
            allCabGroups.forEach((cab, idx) => {
            const g = cab.group || cabinetGroup;
            if (!g) return;
            // Фасад/есік жасырылған болса да габаритті дұрыс алу үшін уақытша көрсетеміз
            const restoreVisibility = [];
            if (g.userData && g.userData.doorsGroup) {
                const dg = g.userData.doorsGroup;
                restoreVisibility.push({ obj: dg, vis: dg.visible });
                dg.visible = true;
            }
            const box = new THREE.Box3().setFromObject(g);
            restoreVisibility.forEach(r => { if (r.obj) r.obj.visible = r.vis; });
            if (!isFinite(box.min.x) || !isFinite(box.max.x)) return;
            any = true;

                const size = new THREE.Vector3();
                box.getSize(size);
                const center = new THREE.Vector3();
                box.getCenter(center);
                const leftX   = box.min.x;
                const rightX  = box.max.x;
                const bottomY = box.min.y;
                const topY    = box.max.y;
                const backZ   = box.min.z;
                const frontZ  = box.max.z;

            const state = (cab.cabinet && cab.cabinet.state) || {};
            const totalWidth  = state.W || size.x;
            const totalHeight = state.H || size.y;
            const corpusThick = parseFloat(state.corpusThickness) || globalThickness || 16;
            const backMatVal  = state.backMaterial || 'hdf';
            const backThick   = (backMatVal === 'hdf') ? 4 : corpusThick;
            const facadeThick = parseFloat(state.facadeThickness) || 18;
            const facadeTypeVal = state.facadeType || 'nakladnoy';
            let totalDepth;
            if (state.D) {
                totalDepth = state.D + backThick;
                if (facadeTypeVal === 'nakladnoy') {
                    totalDepth += facadeThick;
                }
            } else {
                totalDepth = size.z;
            }

            const halfW = totalWidth / 2;
            const halfH = totalHeight / 2;
            const halfD = totalDepth / 2;

                const q = new THREE.Quaternion();
                g.getWorldQuaternion(q);
                const xAxis = new THREE.Vector3(1, 0, 0).applyQuaternion(q).normalize();
                const yAxis = new THREE.Vector3(0, 1, 0).applyQuaternion(q).normalize();
                const zAxis = new THREE.Vector3(0, 0, 1).applyQuaternion(q).normalize();
                const frontDir = new THREE.Vector3(0, 0, 1);
                const labelDistance = halfD + 10;
                const label = createCabinetNumberSprite(String(idx + 1));
                label.position.copy(center.clone().add(frontDir.clone().multiplyScalar(labelDistance)));
                dimensionHelpersGroup.add(label);

                const offset  = 150; // шкафтан тұрақты арақашықтық
                const tickLen = 50;

                // ЕНІ (кабинетке параллель)
                const widthPlaneOffset = yAxis.clone().multiplyScalar(halfH + offset)
                    .add(zAxis.clone().multiplyScalar(-halfD - offset));
                const w1 = center.clone().add(xAxis.clone().multiplyScalar(-halfW)).add(widthPlaneOffset);
                const w2 = center.clone().add(xAxis.clone().multiplyScalar(halfW)).add(widthPlaneOffset);

                addLine(w1, w2);
                addLine(
                    w1.clone(),
                    w1.clone().add(yAxis.clone().multiplyScalar(-tickLen)),
                    { color: colorCab }
                );
                addLine(
                    w2.clone(),
                    w2.clone().add(yAxis.clone().multiplyScalar(-tickLen)),
                    { color: colorCab }
                );

                const wMid = w1.clone().add(w2).multiplyScalar(0.5).add(yAxis.clone().multiplyScalar(40));
                addLabel(Math.round(totalWidth) + ' мм', wMid, w1, w2, { color: hexToCss(colorCab) });

                // БИІКТІК
                const heightPlaneOffset = xAxis.clone().multiplyScalar(halfW + offset)
                    .add(zAxis.clone().multiplyScalar(-halfD - offset));
                const h1 = center.clone().add(yAxis.clone().multiplyScalar(-halfH)).add(heightPlaneOffset);
                const h2 = center.clone().add(yAxis.clone().multiplyScalar(halfH)).add(heightPlaneOffset);

                addLine(h1, h2);
                addLine(
                    h1.clone(),
                    h1.clone().add(xAxis.clone().multiplyScalar(-tickLen)),
                    { color: colorCab }
                );
                addLine(
                    h2.clone(),
                    h2.clone().add(xAxis.clone().multiplyScalar(-tickLen)),
                    { color: colorCab }
                );

                const hMid = h1.clone().add(h2).multiplyScalar(0.5).add(xAxis.clone().multiplyScalar(60));
                addLabel(Math.round(totalHeight) + ' мм', hMid, h1, h2, { color: hexToCss(colorCab) });

                // ТЕРЕҢДІК
                const depthPlaneOffset = yAxis.clone().multiplyScalar(halfH + offset)
                    .add(xAxis.clone().multiplyScalar(-halfW));
                const d1 = center.clone().add(zAxis.clone().multiplyScalar(-halfD)).add(depthPlaneOffset);
                const d2 = center.clone().add(zAxis.clone().multiplyScalar(halfD)).add(depthPlaneOffset);

                addLine(d1, d2);
                addLine(
                    d1.clone(),
                    d1.clone().add(yAxis.clone().multiplyScalar(-tickLen)),
                    { color: colorCab }
                );
                addLine(
                    d2.clone(),
                    d2.clone().add(yAxis.clone().multiplyScalar(-tickLen)),
                    { color: colorCab }
                );

                const dMid = d1.clone().add(d2).multiplyScalar(0.5).add(yAxis.clone().multiplyScalar(40));
                addLabel(Math.round(totalDepth) + ' мм', dMid, d1, d2, { color: hexToCss(colorCab) });

                // Стенаның жалпы ұзындығы (жасыл, шкаф өлшемінен жоғары)
                const wallInfo = getActiveWallInfo();
                if (newWalls && newWalls.length) {
                    newWalls.forEach(wallInfo => {
                        if (!wallInfo || !wallInfo.w) return;
                        const offsetWall = offset + 200;
                        const wallTopY = (wallInfo.y || 0) + (wallInfo.h || 0);
                        const halfW = wallInfo.w / 2;
                        const isVertWall = (wallInfo.type === 'vertical');
                        const dir = isVertWall
                            ? new THREE.Vector3(0, 0, 1)   // ұзындығы Z бойымен
                            : new THREE.Vector3(1, 0, 0);  // ұзындығы X бойымен
                        const perp = isVertWall
                            ? new THREE.Vector3(-1, 0, 0)  // вертикаль стена – X арқылы ығысу
                            : new THREE.Vector3(0, 0, -1); // фронтал – Z арқылы ығысу
                        const base = new THREE.Vector3(
                            isVertWall
                                ? (wallInfo.x || 0)
                                : (wallInfo.x || 0) + halfW,
                            wallTopY + offsetWall,
                            isVertWall
                                ? (wallInfo.z || 0) + halfW
                                : (wallInfo.z || 0)
                        );
                        const offsetVec = perp.clone().multiplyScalar(offsetWall);
                        const w1w = base.clone().add(dir.clone().multiplyScalar(-halfW)).add(offsetVec);
                        const w2w = base.clone().add(dir.clone().multiplyScalar(halfW)).add(offsetVec);
                        addLine(w1w, w2w, { color: colorWall });
                        addLine(
                            w1w.clone(),
                            w1w.clone().add(new THREE.Vector3(0, -tickLen, 0)),
                            { color: colorWall }
                        );
                        addLine(
                            w2w.clone(),
                            w2w.clone().add(new THREE.Vector3(0, -tickLen, 0)),
                            { color: colorWall }
                        );
                        const midWall = w1w.clone().add(w2w).multiplyScalar(0.5).add(new THREE.Vector3(0, 40, 0));
                        addLabel(Math.round(wallInfo.w) + ' мм', midWall, w1w, w2w, { color: hexToCss(colorWall) });
                    });
                }

                if (selectedNewWallId) {
                    const wall = newWalls.find(w => w.id === selectedNewWallId);
                    if (wall) {
                        const sections = wallSections[wall.id] || [];
                        if (sections.length) {
                            const startX = wall.x || 0;
                            const startY = wall.y || 0;
                            const startZ = wall.z || 0;
                            const isVertWall = (wall.type === 'vertical');
                            sections.forEach(sec => {
                                const left = startX + (isVertWall ? 0 : sec.x);
                                const right = left + sec.w;
                                const bottom = startY + sec.y;
                                const top = bottom + sec.h;
                                const zPlane = isVertWall ? startZ : startZ;
                                const centerX = isVertWall ? startX : (left + right) / 2;
                                const centerY = (bottom + top) / 2;
                                const centerZ = isVertWall ? (startZ + sec.x + sec.w / 2) : zPlane;

                                const widthStart = isVertWall
                                    ? new THREE.Vector3(startX, centerY, startZ + sec.x)
                                    : new THREE.Vector3(left, centerY, zPlane);
                                const widthEnd = isVertWall
                                    ? new THREE.Vector3(startX, centerY, startZ + sec.x + sec.w)
                                    : new THREE.Vector3(right, centerY, zPlane);
                                const heightStart = new THREE.Vector3(centerX, bottom, centerZ);
                                const heightEnd = new THREE.Vector3(centerX, top, centerZ);

                                let labelText;
                                let lineStart;
                                let lineEnd;
                                if (sec.dir === 'horizontal') {
                                    labelText = Math.round(sec.h || 0) + ' мм';
                                    lineStart = heightStart;
                                    lineEnd = heightEnd;
                                } else if (sec.dir === 'grid') {
                                    labelText = `${Math.round(sec.w || 0)} × ${Math.round(sec.h || 0)} мм`;
                                    lineStart = widthStart;
                                    lineEnd = widthEnd;
                                } else {
                                    labelText = Math.round(sec.w || 0) + ' мм';
                                    lineStart = widthStart;
                                    lineEnd = widthEnd;
                                }

                                addLabel(
                                    labelText,
                                    new THREE.Vector3(centerX, centerY, centerZ),
                                    lineStart,
                                    lineEnd,
                                    { color: '#111111', overlay: true, depthTest: true }
                                );
                            });
                        }
                    }
                }

                // Тек актив шкаф үшін ішкі өлшемдер (полка аралығы)
                if (cab.id && activeCabinetId && cab.id === activeCabinetId && sections && sections.length && sectionShelves) {
                    const innerParamsShelves = computeInnerParams();
                    const depthInsideShelves = innerParamsShelves.depthInside;
                    const backInsideZ        = innerParamsShelves.centerZ - depthInsideShelves / 2 + cabinetOffsetZ + (cabinetBaseOffset.z || 0);

                    const shelfThickLocal = globalThickness;

                    const secSortedForShelves = sections.slice().sort((a, b) => a.x - b.x);

                    secSortedForShelves.forEach(sec => {
                        const list = sectionShelves[sec.id];
                        if (!list || !list.length) return;

                        // Алдынан отступ: фронтты қысқартып көрсетеміз
                        const secFrontOffset = sectionShelfOffsets[sec.id] || 0;
                        const shelfDepth     = Math.max(10, depthInsideShelves - secFrontOffset);
                        const shelfFrontZ    = backInsideZ + shelfDepth;
                        // Сәл ішке (front ішкі жазықтығының ішінде), overlay бәрібір көрінеді
                        const zShelvesDim    = shelfFrontZ - Math.min(20, shelfDepth * 0.1);

                        const heights = list.slice().sort((a, b) => a - b);
                        const augmented = [0, ...heights, sec.h]; // дно мен крышаны қосамыз
                        let subIdx = 1;

                        const secLeft  = -innerW / 2 + sec.x + cabinetOffsetX + (cabinetBaseOffset.x || 0);
                        const secRight = secLeft + sec.w;
                        const xMid     = (secLeft + secRight) / 2;

                        for (let i = 0; i < augmented.length - 1; i++) {
                            const h1 = augmented[i];
                            const h2 = augmented[i + 1];

                            const isBottom = (i === 0);
                            const isTop    = (i === augmented.length - 2);

                            let gap = h2 - h1;
                            if (!isBottom) gap -= shelfThickLocal; // төмендегі полка қалыңдығын алып тастаймыз
                            if (gap <= 0) continue;

                            const y1 = (cabinetBaseOffset.y || 0) + plinthHeight + globalThickness + (isBottom ? 0 : h1 + shelfThickLocal);
                            const y2 = (cabinetBaseOffset.y || 0) + plinthHeight + globalThickness + (isTop ? sec.h : h2);

                            const p1 = new THREE.Vector3(xMid, y1, zShelvesDim);
                            const p2 = new THREE.Vector3(xMid, y2, zShelvesDim);

                            const overlayDepthTest = (currentViewMode === 'xray')
                                ? false        // ренгенде әрқашан көрінсін (depth off)
                                : !facadesHidden; // қалған режимде фасад жабық болса жасырылады

                            // Негізгі тік сызық (фасад ашық болса depth off, жабық болса depth on)
                            addLine(p1, p2, { overlay: true, depthTest: overlayDepthTest, color: colorCab });

                            // Жоғарғы / төменгі "тычоктар"
                            addLine(
                                new THREE.Vector3(xMid - tickLen / 2, y1, zShelvesDim),
                                new THREE.Vector3(xMid + tickLen / 2, y1, zShelvesDim),
                                { overlay: true, depthTest: overlayDepthTest, color: colorCab }
                            );
                            addLine(
                                new THREE.Vector3(xMid - tickLen / 2, y2, zShelvesDim),
                                new THREE.Vector3(xMid + tickLen / 2, y2, zShelvesDim),
                                { overlay: true, depthTest: overlayDepthTest, color: colorCab }
                            );

                            // Екі полка арасындағы ара қашықтықты жазу
                            const mid = p1.clone().add(p2).multiplyScalar(0.5);
                            mid.x += 40;
                            const subName = 'Секция ' + sec.id + '.' + subIdx;
                            addLabel(subName + ' · ' + Math.round(gap) + ' мм', mid, p1, p2, { overlay: true, depthTest: overlayDepthTest, color: hexToCss(colorCab) });
                            subIdx++;
                        }
                    });
                }
            });

            if (!any) return;

            dimensionHelpersGroup.visible = dimensionsVisible;
            syncDimensionsVisibility();
            syncInfoVisibility();
            updateDimensionLabelAngles();
        }
