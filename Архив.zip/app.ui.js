// app.ui.js (split from app.legacy.js)
        // DOM элементтер
        const widthInput        = document.getElementById('widthInput');
        const heightInput       = document.getElementById('heightInput');
        const depthInput        = document.getElementById('depthInput');
        const wallGapInput      = document.getElementById('wallGapInput');
        const wallAngleInput    = null;
        const wallColorInput    = null;
        const wallWidthInput    = null;
        const wallHeightInput   = null;
        const wallListContainer = null;
        const wallSketchCanvas  = null;
        const wallSketchCtx     = null;
        const newWallTypeInput   = document.getElementById('newWallType'); // no longer used (select removed)
        const newWallWidthInput  = null;
        const newWallHeightInput = null;
        const newWallStartXInput = null;
        const newWallStartYInput = null;
        const newWallStartZInput = null;
        const addWallFrontalBtn  = document.getElementById('addWallFrontalBtn');
        const addWallVerticalBtn = document.getElementById('addWallVerticalBtn');
        const newWallList       = document.getElementById('newWallList');
        const wallSectionList   = document.getElementById('wallSectionList');
        const cabinetList       = document.getElementById('cabinetList');
        const splitVerticalCountInput = document.getElementById('splitVerticalCount');
        const splitHorizontalCountInput = document.getElementById('splitHorizontalCount');
        const splitVerticalIncrease = document.getElementById('splitVerticalIncrease');
        const splitVerticalDecrease = document.getElementById('splitVerticalDecrease');
        const splitHorizontalIncrease = document.getElementById('splitHorizontalIncrease');
        const splitHorizontalDecrease = document.getElementById('splitHorizontalDecrease');
        const materialNamePopup        = document.getElementById('materialNamePopup');
        const materialNamePopupBackdrop= document.getElementById('materialNamePopupBackdrop');
        const materialNamePopupInput   = document.getElementById('materialNamePopupInput');
        const materialNamePopupApply   = document.getElementById('materialNamePopupApply');
        const materialNamePopupClose   = document.getElementById('materialNamePopupClose');

        let selectedPartIds = new Set();
        let structureEntryOrder = [];
        let structureEntryIndexMap = new Map();
        let multiSelectAnchorId = null;
        const splitCounts = { vertical: 1, horizontal: 1 };

        const corpusMaterial    = document.getElementById('corpusMaterial');
        const corpusThickness   = document.getElementById('corpusThickness');
        const corpusColorInput  = document.getElementById('corpusColor');
        const bottomMountInput  = document.getElementById('bottomMount');
        const facadeMaterial    = document.getElementById('facadeMaterial');
        const facadeThickness   = document.getElementById('facadeThickness');
        const facadeType        = document.getElementById('facadeType');
        const facadeColorInput  = document.getElementById('facadeColor');
        const facadeStyle       = document.getElementById('facadeStyle');
        const facadeFrameWidthInput = document.getElementById('facadeFrameWidth');
        const facadeMaterialNameInput = document.getElementById('facadeMaterialName');
        const plinthHeightInput = document.getElementById('plinthHeight');
        const plinthMaterialNameInput = document.getElementById('plinthMaterialName');
        const backMaterial      = document.getElementById('backMaterial');
        const facadeStyleRow    = (function(){
            const el = document.getElementById('facadeStyle');
            return el ? el.closest('.fields-row') : null;
        })();
        const facadeFrameRow    = (function(){
            const el = document.getElementById('facadeFrameWidth');
            return el ? el.closest('.fields-row') : null;
        })();
        if (facadeMaterialNameInput && !facadeMaterialNameInput.value.trim()) {
            facadeMaterialNameInput.value = 'Белый';
        }
        if (plinthMaterialNameInput && !plinthMaterialNameInput.value.trim()) {
            plinthMaterialNameInput.value = 'Белый';
        }

        const sectionSelect       = document.getElementById('sectionSelect');
        const splitPatternInput   = document.getElementById('splitPattern');
        const splitSectionBtn     = document.getElementById('splitSectionBtn');
        const sectionWidthInput   = document.getElementById('sectionWidthInput');

        const shelfCountInput       = document.getElementById('shelfCountInput');
        const autoShelvesBtn        = document.getElementById('autoShelvesBtn');
        const shelfHeightInput      = document.getElementById('shelfHeightInput');
        const addShelfBtn           = document.getElementById('addShelfBtn');
        const shelfSelect           = document.getElementById('shelfSelect');
        const editShelfHeightInput  = document.getElementById('editShelfHeightInput');
        const updateShelfBtn        = document.getElementById('updateShelfBtn');
        const shelfGapInput         = document.getElementById('shelfGapInput');
        const applyShelfGapBtn      = document.getElementById('applyShelfGapBtn');
        const insertShelfBetweenBtn = document.getElementById('insertShelfBetweenBtn');
        const shelfOffsetInput      = document.getElementById('shelfOffsetInput');
        const shelfList             = document.getElementById('shelfList');
        const insertTypeSelect      = document.getElementById('insertTypeSelect');
        const addInsertBtn          = document.getElementById('addInsertBtn');
        const insertList            = document.getElementById('insertList');
        const drawerVariantSelect   = document.getElementById('drawerVariantSelect');
        const drawerDepthSelect     = document.getElementById('drawerDepthSelect');
        const drawerDepthBrandSelect= document.getElementById('drawerDepthBrandSelect');
        const drawerFacadeMaterial  = document.getElementById('drawerFacadeMaterial');
        const drawerFacadeMaterialNameInput = document.getElementById('drawerFacadeMaterialName');
        if (drawerFacadeMaterialNameInput && !drawerFacadeMaterialNameInput.value.trim()) {
            drawerFacadeMaterialNameInput.value = 'Белый';
        }
        const drawerSubList         = document.getElementById('drawerSubList');
        const drawerFacadeGapInput  = document.getElementById('drawerFacadeGap');
        const drawerFrontOffsetInput= document.getElementById('drawerFrontOffset');
        const drawerBodyHeightInput = document.getElementById('drawerBodyHeight');
        const drawerStackGapInput   = document.getElementById('drawerStackGap');
        const drawerRunnerThkInput  = document.getElementById('drawerRunnerThk');
        const insertGapLeftInput    = document.getElementById('insertGapLeft');
        const insertGapRightInput   = document.getElementById('insertGapRight');
        const pipeColorInput        = document.getElementById('pipeColor');
        const drawerRunnerTypeSelect= document.getElementById('drawerRunnerType');
        const falshSideSelect       = document.getElementById('falshSide');
        const falshSizeInput        = document.getElementById('falshSize');
        const addFalshBtn           = document.getElementById('addFalshBtn');
        const falshList             = document.getElementById('falshList');
        const falshListItems        = document.getElementById('falshListItems') || falshList;
        const falshLeftSideCheckbox = document.getElementById('falshLeftSide'); // legacy UI (may be null)
        const falshRightSideCheckbox= document.getElementById('falshRightSide'); // legacy UI (may be null)
        const falshLeftSideSizeInput  = document.getElementById('falshLeftSideSize'); // legacy UI (may be null)
        const falshRightSideSizeInput = document.getElementById('falshRightSideSize'); // legacy UI (may be null)
        const falshTopSideCheckbox    = document.getElementById('falshTopSide'); // legacy UI (may be null)
        const falshTopSideSizeInput   = document.getElementById('falshTopSideSize'); // legacy UI (may be null)
        const falshOverlaySideSelect  = document.getElementById('falshOverlaySide');
        const falshOverlaySizeInput   = document.getElementById('falshOverlaySize');
        const addFalshOverlayBtn      = document.getElementById('addFalshOverlayBtn');

        function ensureSelectedSubIdFromUI() {
            const activeRow = drawerSubList ? drawerSubList.querySelector('.shelf-sub-row.active') : null;
            if (activeRow && activeRow.dataset && activeRow.dataset.subId) {
                selectedShelfSubId = activeRow.dataset.subId;
                return;
            }
            const subs = getShelfSubSections();
            const scoped = subs.filter(s => s.sectionId === selectedSectionId);
            const pool = scoped.length ? scoped : subs;
            if (!selectedShelfSubId && pool.length) {
                selectedShelfSubId = `${pool[0].sectionId}:${pool[0].idx}`;
            }
        }
        function syncDrawerActiveRow() {
            if (!drawerSubList) return;
            const rows = drawerSubList.querySelectorAll('.shelf-sub-row');
            rows.forEach(r => {
                const isActive = selectedShelfSubId && r.dataset && r.dataset.subId === selectedShelfSubId;
                r.classList.toggle('active', !!isActive);
            });
        }

        function getFalshSizeForSide(side) {
            const raw = parseFloat(falshSizeInput ? falshSizeInput.value : '');
            if (isFinite(raw) && raw > 0) return raw;
            return side === 'top' ? 120 : 50;
        }

        function normalizePositiveNumber(raw, fallback) {
            const v = parseFloat(raw);
            if (Number.isFinite(v) && v > 0) return v;
            return fallback;
        }

        function getFalshOverlayThickness() {
            return parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
        }

        function getFalshOverlayAutoDepth() {
            const depthVal = (currentD || parseFloat(depthInput ? depthInput.value : '') || 0);
            const facadeThkVal = getFalshOverlayThickness();
            const facadeTypeVal = facadeType ? facadeType.value : 'vkladnoy';
            const facadeFrontZ = (facadeTypeVal === 'vkladnoy')
                ? (depthVal / 2 - 1)
                : (depthVal / 2 + facadeThkVal + 1);
            const zMin = -depthVal / 2;
            return Math.max(10, facadeFrontZ - zMin);
        }

        function getSideOverlayEnabled(side) {
            if (side === 'left') return !!falshLeftSideEnabled;
            if (side === 'right') return !!falshRightSideEnabled;
            return !!falshTopSideEnabled;
        }

        function setSideOverlayEnabled(side, enabled) {
            if (side === 'left') falshLeftSideEnabled = !!enabled;
            else if (side === 'right') falshRightSideEnabled = !!enabled;
            else falshTopSideEnabled = !!enabled;
        }

        function getSideOverlayDepth(side) {
            const autoDepth = getFalshOverlayAutoDepth();
            const raw = (side === 'left')
                ? falshLeftSideDepth
                : (side === 'right' ? falshRightSideDepth : falshTopSideDepth);
            const val = Number.isFinite(raw) && raw > 0 ? raw : autoDepth;
            return Math.max(10, Math.min(val, autoDepth));
        }

        function setSideOverlayDepth(side, depthVal) {
            const autoDepth = getFalshOverlayAutoDepth();
            const v = normalizePositiveNumber(depthVal, autoDepth);
            const clamped = Math.max(10, Math.min(v, autoDepth));
            // Егер autoDepth-қа тең болса – сақтамаймыз (null), автомат болып қала берсін
            const store = Math.abs(clamped - autoDepth) < 0.01 ? null : clamped;
            if (side === 'left') falshLeftSideDepth = store;
            else if (side === 'right') falshRightSideDepth = store;
            else falshTopSideDepth = store;
            return clamped;
        }

        function syncFalshOverlayControls(force) {
            if (!falshOverlaySideSelect || !falshOverlaySizeInput) return;
            if (!force && document.activeElement === falshOverlaySizeInput) return;
            const side = falshOverlaySideSelect.value || 'left';
            const v = getSideOverlayDepth(side);
            falshOverlaySizeInput.value = Math.round(v);
            falshOverlaySizeInput.min = '10';
            falshOverlaySizeInput.max = String(Math.round(getFalshOverlayAutoDepth()));
        }

        function readSideOverlaySize(side) {
            const input = side === 'left'
                ? falshLeftSideSizeInput
                : (side === 'right' ? falshRightSideSizeInput : falshTopSideSizeInput);
            const raw = parseFloat(input ? input.value : '');
            const fallback = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
            const stored = (side === 'left')
                ? falshLeftSideSize
                : (side === 'right' ? falshRightSideSize : falshTopSideSize);
            const val = Number.isFinite(raw) && raw > 0
                ? raw
                : (Number.isFinite(stored) && stored > 0 ? stored : fallback);
            if (input && (!input.value || raw <= 0 || !isFinite(raw))) {
                input.value = Math.round(val);
            }
            if (side === 'left') falshLeftSideSize = val;
            else if (side === 'right') falshRightSideSize = val;
            else falshTopSideSize = val;
            return val;
        }
        if (facadeMaterial && facadeThickness) {
            facadeMaterial.addEventListener('change', () => {
                const val = facadeMaterial.value;
                let thick = parseFloat(facadeThickness.value) || 18;
                if (val === 'ldsp') thick = 16;
                if (val === 'mdf') thick = 18;
                if (val === 'glass') thick = 4;
                if (val === 'glass_frame') thick = 20;
                facadeThickness.value = thick;
                rebuildWithCurrentSize(true);
                if (facadeStyleRow) {
                    facadeStyleRow.style.display = (val === 'mdf') ? 'flex' : 'none';
                }
                if (facadeFrameRow) {
                    const showFrame = (facadeStyle && facadeStyle.value === 'frame' && val === 'mdf');
                    facadeFrameRow.style.display = showFrame ? 'flex' : 'none';
                }
                if (facadeStyle) {
                    // ЛДСП/Стекло/Стекло рамка → модерн стиліне күштеп ауыстыру
                    if (val === 'ldsp' || val === 'glass') {
                        facadeStyle.value = 'modern';
                    } else if (val === 'glass_frame') {
                        facadeStyle.value = 'frame';
                        if (facadeFrameWidthInput) {
                            facadeFrameWidthInput.value = 20;
                        }
                    }
                }
                // Егер фасад материалы ЛДСП болса, есік кромкасы толық белсенді (Асты/Үсті/Сол/Оң)
                if (val === 'ldsp') {
                    Object.values(parts || {}).forEach(p => {
                        if ((p.type || '').toLowerCase() === 'door') {
                            p.edge = { front:true, back:true, left:true, right:true };
                            rebuildEdgeHighlightForPart(p);
                        }
                    });
                    applyEdgeHighlightVisibility();
                    updatePartUI();
                }
                rebuildStructureList();
                refreshPartPreview();
                updatePartUI();
            });
        }
        if (facadeMaterialNameInput) {
            facadeMaterialNameInput.addEventListener('input', () => {
                const trimmed = facadeMaterialNameInput.value.trim();
                const normalized = trimmed || 'Белый';
                facadeMaterialNameInput.value = normalized;
                if (plinthMaterialNameInput) {
                    plinthMaterialNameInput.value = normalized;
                }
                rebuildStructureList();
                refreshPartPreview();
                updatePartUI();
            });
        }
        if (drawerFacadeMaterialNameInput) {
            drawerFacadeMaterialNameInput.addEventListener('input', () => {
                rebuildStructureList();
                refreshPartPreview();
                updatePartUI();
            });
        }
        if (plinthMaterialNameInput) {
            plinthMaterialNameInput.addEventListener('input', () => {
                rebuildStructureList();
                refreshPartPreview();
                updatePartUI();
            });
        }
        if (facadeStyleRow && facadeMaterial) {
            facadeStyleRow.style.display = (facadeMaterial.value === 'mdf') ? 'flex' : 'none';
        }
        if (facadeFrameRow && facadeMaterial && facadeStyle) {
            facadeFrameRow.style.display = (facadeMaterial.value === 'mdf' && facadeStyle.value === 'frame') ? 'flex' : 'none';
            facadeStyle.addEventListener('change', () => {
                if (!facadeFrameRow) return;
                const show = (facadeMaterial.value === 'mdf' && facadeStyle.value === 'frame');
                facadeFrameRow.style.display = show ? 'flex' : 'none';
            });
        }

	        if (addFalshBtn) {
	            addFalshBtn.addEventListener('click', () => {
	                if (!cabinetSpawned) {
	                    showError('Алдымен шкафты құрыңыз');
	                    return;
	                }
	                const side = falshSideSelect ? falshSideSelect.value : 'left';
	                const size = getFalshSizeForSide(side);
	                runUndoable(() => {
	                    falshPanels.push({ id: nextFalshId++, side, size });
	                    rebuildFalshList();
	                    rebuildWithCurrentSize(true);
	                    syncActiveCabinetRecord();
	                    if (falshSizeInput) falshSizeInput.value = size;
	                });
	            });
	        }
	        if (falshOverlaySideSelect) {
	            falshOverlaySideSelect.addEventListener('change', () => {
	                syncFalshOverlayControls(true);
	            });
	        }
	        if (falshOverlaySizeInput) {
	            falshOverlaySizeInput.addEventListener('change', () => {
	                const side = falshOverlaySideSelect ? (falshOverlaySideSelect.value || 'left') : 'left';
	                const v = normalizePositiveNumber(falshOverlaySizeInput.value, getSideOverlayDepth(side));
	                falshOverlaySizeInput.value = Math.round(v);
	                if (cabinetSpawned && getSideOverlayEnabled(side)) {
	                    runUndoable(() => {
	                        setSideOverlayDepth(side, v);
	                        rebuildWithCurrentSize(true);
	                        syncActiveCabinetRecord();
	                    });
	                    rebuildFalshList();
	                } else {
	                    setSideOverlayDepth(side, v);
	                }
	            });
	        }
	        if (addFalshOverlayBtn) {
	            addFalshOverlayBtn.addEventListener('click', () => {
	                if (!cabinetSpawned) {
	                    showError('Алдымен шкафты құрыңыз');
	                    return;
	                }
	                const side = falshOverlaySideSelect ? (falshOverlaySideSelect.value || 'left') : 'left';
	                const v = normalizePositiveNumber(
	                    falshOverlaySizeInput ? falshOverlaySizeInput.value : null,
	                    getSideOverlayDepth(side)
	                );
	                runUndoable(() => {
	                    setSideOverlayEnabled(side, true);
	                    setSideOverlayDepth(side, v);
	                    rebuildWithCurrentSize(true);
	                    syncActiveCabinetRecord();
	                });
	                syncFalshOverlayControls(true);
	                rebuildFalshList();
	            });
	        }
	        syncFalshOverlayControls(true);
        if (falshSideSelect && falshSizeInput) {
            falshSideSelect.addEventListener('change', () => {
                const side = falshSideSelect.value || 'left';
                if (!falshSizeInput.value || parseFloat(falshSizeInput.value) <= 0) {
                    falshSizeInput.value = getFalshSizeForSide(side);
                }
                // Авто: Төбе таңдалса, биіктікті қайта есептеу
                if (side === 'top' && cabinetSpawned) {
                    rebuildWithCurrentSize(true);
                    syncActiveCabinetRecord();
                }
            });
        }
	        // Legacy UI events (checkboxes/size inputs) removed; use falshOverlaySide/falshOverlaySize instead.

        const viewButtons    = document.querySelectorAll('#canvas-toolbar [data-view]');
        const modeButtons    = document.querySelectorAll('#canvas-toolbar [data-mode]');
        const animToggleBtn  = document.getElementById('animToggleBtn');
        const viewToolbar    = document.getElementById('view-toolbar');

        const toggleDimsBtn  = document.getElementById('toggleDimsBtn');
        const toggleFacadeBtn= document.getElementById('toggleFacadeBtn');
        const toggleEdgeBtn  = document.getElementById('toggleEdgeBtn');
        const toggleInfoBtn  = document.getElementById('toggleInfoBtn');
        const structureBtn   = document.getElementById('structureBtn');
        const structureList  = document.getElementById('structureList');
        const cabinetIconList= document.getElementById('cabinetIconList');
        const cabinetDeleteBtn= document.getElementById('cabinetDeleteBtn');
        const cabinetHideBtn = document.getElementById('cabinetHideBtn');
        const undoBtn        = document.getElementById('undoBtn');
        const redoBtn        = document.getElementById('redoBtn');
        const saveProjectBtn = document.getElementById('saveProjectBtn');
        const loadProjectBtn = document.getElementById('loadProjectBtn');
        const loadProjectInput = document.getElementById('loadProjectInput');

        // Бөлшек UI
        const partNameInput       = document.getElementById('partName');
        const partTypeInput       = document.getElementById('partType');
        const partSectionInput    = document.getElementById('partSection');
        const partSizeInput       = document.getElementById('partSize');
        const partOffsetFrontInput= document.getElementById('partOffsetFront');
        const edgeFrontInput      = document.getElementById('edgeFront');
        const edgeBackInput       = document.getElementById('edgeBack');
        const edgeLeftInput       = document.getElementById('edgeLeft');
        const edgeRightInput      = document.getElementById('edgeRight');
        const edgeFrontLabel      = document.getElementById('edgeFrontLabel');
        const edgeBackLabel       = document.getElementById('edgeBackLabel');
        const edgeLeftLabel       = document.getElementById('edgeLeftLabel');
        const edgeRightLabel      = document.getElementById('edgeRightLabel');
        const offsetFrontInput    = document.getElementById('offsetFront');
        const offsetBackInput     = document.getElementById('offsetBack');
        const offsetBottomInput   = document.getElementById('offsetBottom');
        const offsetTopInput      = document.getElementById('offsetTop');
        const offsetFrontLabel    = document.getElementById('offsetFrontLabel');
        const offsetBackLabel     = document.getElementById('offsetBackLabel');
        const offsetBottomLabel   = document.getElementById('offsetBottomLabel');
        const offsetTopLabel      = document.getElementById('offsetTopLabel');
        const partDrillingInput   = document.getElementById('partDrilling');
        const partPreviewCanvas   = document.getElementById('partPreviewCanvas');
        const partPreviewCaption  = document.getElementById('partPreviewCaption');
        const partPreviewEmpty    = document.getElementById('partPreviewEmpty');
        const partPreviewName     = document.getElementById('partPreviewName');
        const partPreviewDeleteBtn= document.getElementById('partPreviewDeleteBtn');
        const partEmptyState      = document.getElementById('partEmptyState');
        const partPreviewCtx      = partPreviewCanvas ? partPreviewCanvas.getContext('2d') : null;
	        const handlePartDelete = () => {
	            if (!selectedPartId) return;
	            const ok = window.confirm('Таңдалған бөлшекті өшіру керек пе?');
	            if (!ok) return;
	            const pid = selectedPartId;
	            runUndoable(() => {
	                deletePart(pid);
	            });
	        };
        if (partPreviewDeleteBtn) {
            partPreviewDeleteBtn.addEventListener('click', handlePartDelete);
        }

        // Қабырға UI жоқ

        // ===== ЖАҢА СТЕНАЛАР (контур)
        function ensureWallSections(wall) {
            if (!wall) return [];
            if (!wallSections[wall.id]) {
                wallSections[wall.id] = [{
                    id: nextWallSectionId++,
                    parentId: null,
                    x: 0,
                    y: 0,
                    w: wall.w || 0,
                    h: wall.h || 0,
                    dir: 'base',
                    widthLocked: false,
                    heightLocked: false
                }];
                selectedWallSectionId = wallSections[wall.id][0].id;
            }
            wallSections[wall.id].forEach(sec => {
                const legacyLocked = !!sec.locked;
                sec.widthLocked = !!(sec.widthLocked || legacyLocked);
                sec.heightLocked = !!(sec.heightLocked || legacyLocked);
                delete sec.locked;
            });
            return wallSections[wall.id];
        }

        function hasCabinetInSection(wallId, sectionId) {
            return cabinets.some(c => c.wallId === wallId && c.sectionId === sectionId);
        }

        function getCabinetsByWallId(wallId) {
            return cabinets.filter(c => c.wallId === wallId);
        }

        // Белгілі бір стена/секцияға байланған барлық шкафтарды қайта құру
        function refreshCabinetsForSection(wallId, sectionId, preserveLayout) {
            const targets = cabinets.filter(c =>
                c.wallId === wallId &&
                (sectionId == null || c.sectionId === sectionId)
            );
            if (!targets.length) return;
            const prevActive = activeCabinetId;
            const prevSelectedWall = selectedNewWallId;
            const prevSelectedSection = selectedWallSectionId;

            targets.forEach(cab => {
                setActiveCabinet(cab.id);
                updateCabinetFromSection(preserveLayout);
            });

            if (prevActive && prevActive !== activeCabinetId) {
                setActiveCabinet(prevActive);
            } else if (!prevActive) {
                selectedNewWallId = prevSelectedWall;
                selectedWallSectionId = prevSelectedSection;
                rebuildWallSectionList();
                rebuildNewWalls();
            }
        }

        function sameSectionParent(a, b) {
            return (a && b && (a.parentId || null) === (b.parentId || null));
        }

        function redistributeWidthsForSiblings(sections, sec, desiredW, minSize) {
            if (!sec || sec.dir !== 'vertical' || sec.parentId == null) return false;
            const siblings = sections.filter(s => s.parentId === sec.parentId && !s.widthLocked);
            if (siblings.length < 2) return false;
            const totalPrev = siblings.reduce((sum, s) => sum + (s._prevW || s.w || 0), 0);
            const otherCount = siblings.length - 1;
            const maxForChanged = totalPrev - minSize * otherCount;
            const newW = Math.min(Math.max(desiredW, minSize), maxForChanged);
            const others = siblings.filter(s => s !== sec);
            const totalOthersPrev = others.reduce((sum, s) => sum + (s._prevW || s.w || 0), 0);
            const remaining = totalPrev - newW;
            sec.w = newW;
            if (remaining < minSize * others.length) return false;
            others.forEach(o => {
                const ratio = totalOthersPrev > 0 ? ((o._prevW || o.w || 0) / totalOthersPrev) : (1 / others.length);
                o.w = Math.max(minSize, remaining * ratio);
            });
            const totalAfter = siblings.reduce((sum, s) => sum + (s.w || 0), 0);
            let diff = totalPrev - totalAfter;
            if (Math.abs(diff) > 0.001) {
                others[0].w += diff;
            }
            const sorted = siblings.slice().sort((a, b) => (a._prevX || a.x || 0) - (b._prevX || b.x || 0));
            let cursor = Math.min(...sorted.map(s => s._prevX || s.x || 0));
            sorted.forEach(s => {
                s.x = cursor;
                cursor += s.w || 0;
            });
            return true;
        }

        function redistributeHeightsForSiblings(sections, sec, desiredH, minSize) {
            if (!sec || sec.dir !== 'horizontal' || sec.parentId == null) return false;
            const siblings = sections.filter(s => s.parentId === sec.parentId && !s.heightLocked);
            if (siblings.length < 2) return false;
            const totalPrev = siblings.reduce((sum, s) => sum + (s._prevH || s.h || 0), 0);
            const otherCount = siblings.length - 1;
            const maxForChanged = totalPrev - minSize * otherCount;
            const newH = Math.min(Math.max(desiredH, minSize), maxForChanged);
            const others = siblings.filter(s => s !== sec);
            const totalOthersPrev = others.reduce((sum, s) => sum + (s._prevH || s.h || 0), 0);
            const remaining = totalPrev - newH;
            sec.h = newH;
            if (remaining < minSize * others.length) return false;
            others.forEach(o => {
                const ratio = totalOthersPrev > 0 ? ((o._prevH || o.h || 0) / totalOthersPrev) : (1 / others.length);
                o.h = Math.max(minSize, remaining * ratio);
            });
            const totalAfter = siblings.reduce((sum, s) => sum + (s.h || 0), 0);
            let diff = totalPrev - totalAfter;
            if (Math.abs(diff) > 0.001) {
                others[0].h += diff;
            }
            const sorted = siblings.slice().sort((a, b) => (a._prevY || a.y || 0) - (b._prevY || b.y || 0));
            let cursor = Math.min(...sorted.map(s => s._prevY || s.y || 0));
            sorted.forEach(s => {
                s.y = cursor;
                cursor += s.h || 0;
            });
            return true;
        }

        function alignHorizontalGroupWidth(sections, sec) {
            if (!sec || sec.dir !== 'horizontal' || sec.parentId == null) return false;
            const group = sections.filter(s => s.parentId === sec.parentId && s.dir === 'horizontal' && !s.widthLocked);
            if (group.length < 2) return false;
            group.forEach(s => {
                s.w = sec.w;
            });
            return true;
        }

        function adjustHorizontalColumnNeighborWidth(sections, sec, minSize) {
            if (!sec || sec.parentId == null) return false;
            const prevW = (sec._prevW != null) ? sec._prevW : sec.w;
            const prevX = (sec._prevX != null) ? sec._prevX : (sec.x || 0);
            const delta = (sec.w || 0) - prevW;
            const eps = 0.001;
            if (Math.abs(delta) < eps) {
                sec.w = prevW;
                sec.x = prevX;
                return false;
            }
            const overlapY = (s) => {
                const top = Math.max(s.y || 0, sec.y || 0);
                const bottom = Math.min((s.y || 0) + (s.h || 0), (sec.y || 0) + (sec.h || 0));
                return bottom > top + eps;
            };
            const prevRight = prevX + prevW;
            const prevLeft = prevX;
            const rightNeighbors = sections.filter(s =>
                overlapY(s) &&
                !s.widthLocked &&
                Math.abs((s.x || 0) - prevRight) < eps
            );
            const leftNeighbors = sections.filter(s =>
                overlapY(s) &&
                !s.widthLocked &&
                Math.abs(((s.x || 0) + (s.w || 0)) - prevLeft) < eps
            );
            let neighbors = rightNeighbors;
            let neighborSide = 'right';
            if (!neighbors.length) {
                neighbors = leftNeighbors;
                neighborSide = 'left';
            }
            if (!neighbors.length) {
                sec.w = prevW;
                sec.x = prevX;
                return false;
            }

            const neighborChange = -delta;
            if (neighborChange < 0) {
                const minNeighborPrev = Math.min(...neighbors.map(n => (n._prevW != null) ? n._prevW : (n.w || 0)));
                if (minNeighborPrev + neighborChange < minSize) {
                    sec.w = prevW;
                    sec.x = prevX;
                    return false;
                }
            }

            neighbors.forEach(n => {
                const prevNeighborW = (n._prevW != null) ? n._prevW : (n.w || 0);
                const desired = prevNeighborW + neighborChange;
                n.w = Math.max(minSize, desired);
            });

            if (neighborSide === 'right') {
                const boundary = (sec.x || prevX) + (sec.w || 0);
                neighbors.forEach(n => {
                    n.x = boundary;
                });
            } else {
                const boundary = Math.max(...neighbors.map(n => (n.x || 0) + (n.w || 0)));
                sec.x = boundary;
            }
            return true;
        }

        function reflowHorizontalSiblingPositions(sections, sec) {
            if (!sec || sec.parentId == null) return;
            const siblings = sections.filter(s => s.parentId === sec.parentId && s.dir === 'vertical');
            if (!siblings.length) return;
            const start = Math.min(...siblings.map(s => s.x || 0));
            const sorted = siblings.slice().sort((a, b) => (a.x || 0) - (b.x || 0));
            let cursor = start;
            sorted.forEach(s => {
                s.x = cursor;
                cursor += (s.w || 0);
            });
        }

        function reflowVerticalSiblingPositions(sections, sec) {
            if (!sec || sec.parentId == null) return;
            const siblings = sections.filter(s => s.parentId === sec.parentId && s.dir === 'horizontal');
            if (!siblings.length) return;
            const start = Math.min(...siblings.map(s => s.y || 0));
            const sorted = siblings.slice().sort((a, b) => (a.y || 0) - (b.y || 0));
            let cursor = start;
            sorted.forEach(s => {
                s.y = cursor;
                cursor += (s.h || 0);
            });
        }

        function alignVerticalGroupHeight(sections, sec) {
            if (!sec || sec.dir !== 'vertical' || sec.parentId == null) return false;
            const group = sections.filter(s => s.parentId === sec.parentId && s.dir === 'vertical' && !s.heightLocked);
            if (group.length < 2) return false;
            group.forEach(s => {
                s.h = sec.h;
            });
            return true;
        }

        function adjustVerticalRowNeighborHeight(sections, sec, minSize) {
            if (!sec || sec.parentId == null) return false;
            const prevH = (sec._prevH != null) ? sec._prevH : sec.h;
            const prevY = (sec._prevY != null) ? sec._prevY : (sec.y || 0);
            const delta = (sec.h || 0) - prevH;
            const eps = 0.001;
            if (Math.abs(delta) < eps) {
                sec.h = prevH;
                sec.y = prevY;
                return false;
            }
            const overlapX = (s) => {
                const left = Math.max(s.x || 0, sec.x || 0);
                const right = Math.min((s.x || 0) + (s.w || 0), (sec.x || 0) + (sec.w || 0));
                return right > left + eps;
            };
            const prevTop = prevY + prevH;
            const prevBottom = prevY;
            const topNeighbors = sections.filter(s =>
                overlapX(s) &&
                !s.heightLocked &&
                Math.abs((s.y || 0) - prevTop) < eps
            );
            const bottomNeighbors = sections.filter(s =>
                overlapX(s) &&
                !s.heightLocked &&
                Math.abs(((s.y || 0) + (s.h || 0)) - prevBottom) < eps
            );
            let neighbors = topNeighbors;
            let neighborSide = 'top';
            if (!neighbors.length) {
                neighbors = bottomNeighbors;
                neighborSide = 'bottom';
            }
            if (!neighbors.length) {
                sec.h = prevH;
                sec.y = prevY;
                return false;
            }

            const neighborChange = -delta;
            if (neighborChange < 0) {
                const minNeighborPrev = Math.min(...neighbors.map(n => (n._prevH != null) ? n._prevH : (n.h || 0)));
                if (minNeighborPrev + neighborChange < minSize) {
                    sec.h = prevH;
                    sec.y = prevY;
                    return false;
                }
            }

            neighbors.forEach(n => {
                const prevNeighborH = (n._prevH != null) ? n._prevH : (n.h || 0);
                const desired = prevNeighborH + neighborChange;
                n.h = Math.max(minSize, desired);
            });

            if (neighborSide === 'top') {
                const boundary = (sec.y || prevY) + (sec.h || 0);
                neighbors.forEach(n => {
                    n.y = boundary;
                });
            } else {
                const boundary = Math.max(...neighbors.map(n => (n.y || 0) + (n.h || 0)));
                sec.y = boundary;
            }
            return true;
        }

        function clampSectionToWall(sec, wall, minSize) {
            if (!sec || !wall) return;
            const maxW = Math.max(minSize, wall.w || 0);
            const maxH = Math.max(minSize, wall.h || 0);
            sec.x = Math.max(0, Math.min(sec.x || 0, maxW - minSize));
            sec.y = Math.max(0, Math.min(sec.y || 0, maxH - minSize));
            sec.w = Math.max(minSize, Math.min(sec.w || minSize, maxW - sec.x));
            sec.h = Math.max(minSize, Math.min(sec.h || minSize, maxH - sec.y));
        }

        function clampSectionsToWall(wall, sections, minSize) {
            if (!wall || !sections) return;
            sections.forEach(sec => clampSectionToWall(sec, wall, minSize));
        }

        function saveActiveCabinetState() {
            if (!activeCabinetId) return;
            const idx = cabinets.findIndex(c => c.id === activeCabinetId);
            if (idx === -1) return;
            cabinets[idx].state      = captureCabinetSnapshot();
            cabinets[idx].baseOffset = { ...cabinetBaseOffset };
            cabinets[idx].wallId     = cabinetWallId;
            cabinets[idx].sectionId  = cabinetSectionId;
            cabinets[idx].rotationY  = cabinetRotationY;
            cabinets[idx].group      = cabinetGroup;
        }

        function setActiveCabinet(cabinetId) {
            saveActiveCabinetState();
            const cab = cabinets.find(c => c.id === cabinetId);
            if (!cab) return;

            // Backward-compatible: ескі стейтте splitPattern сақталмаған болуы мүмкін.
            // Онда соңғы салынған doorsGroup.userData.splitPattern мәнін пайдаланып, осы шкафқа бекітеміз.
            if (cab.state && typeof cab.state === 'object' && (cab.state.splitPattern === undefined || cab.state.splitPattern === null)) {
                const dg = cab.group && cab.group.userData ? cab.group.userData.doorsGroup : null;
                const sp = dg && dg.userData ? dg.userData.splitPattern : null;
                if (sp !== undefined && sp !== null) {
                    cab.state.splitPattern = sp;
                }
            }

            // Алдыңғы кабинеттің секция хелперін алып тастаймыз (басқа шкафтан қалмасын)
            if (selectedSectionHelper && selectedSectionHelper.parent) {
                selectedSectionHelper.parent.remove(selectedSectionHelper);
                selectedSectionHelper.geometry.dispose();
                disposeMat(selectedSectionHelper.material);
                selectedSectionHelper = null;
            }
            if (selectedShelfSubHelper && selectedShelfSubHelper.parent) {
                selectedShelfSubHelper.parent.remove(selectedShelfSubHelper);
                selectedShelfSubHelper.geometry.dispose();
                disposeMat(selectedShelfSubHelper.material);
                selectedShelfSubHelper = null;
            }

            // Ескі group-ты жоймаймыз, сол group-пен жұмыс істейміз (басқа шкафтарды жоғалтпау үшін)
            cabinetGroup = null; // жаңа актив үшін
            activeCabinetId = cabinetId;
            cabinetWallId   = cab.wallId;
            cabinetSectionId= cab.sectionId;
            cabinetBaseOffset = cab.baseOffset || { x: 0, y: 0, z: 0 };
            cabinetRotationY = cab.rotationY || 0;
            selectedNewWallId = cab.wallId;
            selectedWallSectionId = cab.sectionId;
            selectedShelfSubId = null;

            // Әрқашан стейттен қайта құрамыз — innerVolumeMesh, sections дұрыс жаңарады
            applyCabinetState(cab.state);
            const idx = cabinets.findIndex(c => c.id === cabinetId);
            if (idx !== -1) {
                cabinets[idx].group = cabinetGroup;
            }
            applyActiveCabinetVisibility();
            syncActiveCabinetRecord();
            rebuildSectionSelect();
            updateSelectedSectionHelper();
            rebuildShelvesUI();
            rebuildDimensionHelpers();
            rebuildCabinetList();
            rebuildCabinetIcons();
        }

	        function removeCabinet(cabinetId) {
	            const idx = cabinets.findIndex(c => c.id === cabinetId);
	            if (idx === -1) return;
	            runUndoable(() => {
	                const cab = cabinets[idx];
	                if (cab.group) {
	                    disposeGroup(cab.group);
	                    if (cabinetGroup === cab.group) {
	                        cabinetGroup = null;
	                    }
	                }
	                if (activeCabinetId === cabinetId && cabinetGroup && cabinetGroup !== cab.group) {
	                    disposeGroup(cabinetGroup);
	                    cabinetGroup = null;
	                }
	                // Сценада userData.cabinetId сәйкес келетін басқа group қалмасын
	                scene.children
	                    .filter(obj => obj.userData && obj.userData.cabinetId === cabinetId)
	                    .forEach(disposeGroup);

	                cabinets.splice(idx, 1);
	                if (activeCabinetId === cabinetId) {
	                    cabinetGroup = null;
	                    activeCabinetId = null;
	                    cabinetWallId = null;
	                    cabinetSectionId = null;
	                    cabinetSpawned = false;
	                    cabinetRotationY = 0;
	                }
	                if (cabinets.length) {
	                    // Тек белсенді group-ты жаңадан салу, басқа шкафтарды қозғамаймыз
	                    const lastId = cabinets[cabinets.length - 1].id;
	                    activeCabinetId = null;
	                    setActiveCabinet(lastId);
	                } else {
	                    // Ешқандай шкаф қалмаса – сценадан толық тазалаймыз
	                    disposeGroup(cabinetGroup);
	                    cabinetGroup = null;
	                    rebuildNewWalls();
	                    rebuildCabinetList();
	                }
	                rebuildCabinetList();
	                rebuildCabinetIcons();
	                rebuildDimensionHelpers();
	            });
	        }

        function syncActiveCabinetRecord() {
            if (!activeCabinetId) return;
            const idx = cabinets.findIndex(c => c.id === activeCabinetId);
            if (idx === -1) return;
            cabinets[idx].state = captureCabinetSnapshot();
            cabinets[idx].group = cabinetGroup;
            cabinets[idx].baseOffset = { ...cabinetBaseOffset };
            cabinets[idx].wallId = cabinetWallId;
            cabinets[idx].sectionId = cabinetSectionId;
            cabinets[idx].rotationY = cabinetRotationY;
            cabinets[idx].hidden = isCabinetHidden(cabinets[idx].id);
        }

        function rebuildWallSectionList() {
            if (!wallSectionList) return;
            wallSectionList.innerHTML = '';
            if (!selectedNewWallId) {
                wallSectionList.textContent = 'Стенаны таңдаңыз';
                return;
            }
            const sections = ensureWallSections(newWalls.find(w => w.id === selectedNewWallId));
            if (!sections.length) {
                wallSectionList.textContent = 'Секция жоқ';
                return;
            }
            sections.forEach(sec => {
                const row = document.createElement('div');
                row.className = 'simple-list-item wall-section-row';
                if (sec.id === selectedWallSectionId) row.classList.add('active');

                const info = document.createElement('div');
                info.className = 'meta';
                const dirLabel = (sec.dir === 'vertical')
                    ? 'В'
                    : (sec.dir === 'horizontal')
                        ? 'Г'
                        : 'B';
                info.textContent = `${dirLabel} · ID ${sec.id}`;

                const inputsWrap = document.createElement('div');
                inputsWrap.className = 'wall-section-inputs';

                const widthLocked = !!sec.widthLocked;
                const heightLocked = !!sec.heightLocked;
                sec.widthLocked = widthLocked;
                sec.heightLocked = heightLocked;

                const wInput = document.createElement('input');
                wInput.type = 'number';
                wInput.value = Math.round(sec.w || 0);
                wInput.step = '10';
                wInput.title = 'Ені (мм)';
                wInput.disabled = widthLocked;
                const hInput = document.createElement('input');
                hInput.type = 'number';
                hInput.value = Math.round(sec.h || 0);
                hInput.step = '10';
                hInput.title = 'Биіктігі (мм)';
                hInput.disabled = heightLocked;

                const lockWidthBtn = document.createElement('button');
                lockWidthBtn.type = 'button';
                lockWidthBtn.className = 'wall-section-lock-btn wall-section-lock-btn--width' + (widthLocked ? ' locked' : '');
                lockWidthBtn.title = widthLocked ? 'Ені құлыптан босату' : 'Ені құлыптау';
                lockWidthBtn.setAttribute('aria-label', lockWidthBtn.title);
                lockWidthBtn.innerHTML = `<i class="fa-solid ${widthLocked ? 'fa-lock' : 'fa-lock-open'}" aria-hidden="true"></i>`;
                lockWidthBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    sec.widthLocked = !sec.widthLocked;
                    rebuildWallSectionList();
                });

                const lockHeightBtn = document.createElement('button');
                lockHeightBtn.type = 'button';
                lockHeightBtn.className = 'wall-section-lock-btn wall-section-lock-btn--height' + (heightLocked ? ' locked' : '');
                lockHeightBtn.title = heightLocked ? 'Биіктігі құлыптан босату' : 'Биіктігі құлыптау';
                lockHeightBtn.setAttribute('aria-label', lockHeightBtn.title);
                lockHeightBtn.innerHTML = `<i class="fa-solid ${heightLocked ? 'fa-lock' : 'fa-lock-open'}" aria-hidden="true"></i>`;
                lockHeightBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    sec.heightLocked = !sec.heightLocked;
                    rebuildWallSectionList();
                });

                const widthBlock = document.createElement('div');
                widthBlock.className = 'wall-section-measure';
                widthBlock.appendChild(wInput);
                widthBlock.appendChild(lockWidthBtn);

                const heightBlock = document.createElement('div');
                heightBlock.className = 'wall-section-measure';
                heightBlock.appendChild(hInput);
                heightBlock.appendChild(lockHeightBtn);

                const delBtn = document.createElement('button');
                delBtn.type = 'button';
                delBtn.innerHTML = '<i class="fa-solid fa-trash" aria-hidden="true"></i>';
                delBtn.title = 'Секцияны өшіру';
                if (widthLocked || heightLocked) {
                    delBtn.disabled = true;
                    delBtn.classList.add('disabled');
                }

                wInput.addEventListener('change', (e) => {
                    const newW = parseFloat(e.target.value) || sec.w;
                    resizeWallSection(sec.id, { w: newW });
                });
                hInput.addEventListener('change', (e) => {
                    const newH = parseFloat(e.target.value) || sec.h;
                    resizeWallSection(sec.id, { h: newH });
                });
                [lockWidthBtn, lockHeightBtn, wInput, hInput, delBtn].forEach(inp => {
                    inp.addEventListener('mousedown', ev => ev.stopPropagation());
                    inp.addEventListener('click', ev => ev.stopPropagation());
                    inp.addEventListener('focus', ev => ev.stopPropagation());
                });
                delBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    deleteWallSection(sec.id);
                });

                inputsWrap.appendChild(widthBlock);
                inputsWrap.appendChild(heightBlock);
                inputsWrap.appendChild(delBtn);

                row.appendChild(info);
                row.appendChild(inputsWrap);

                row.addEventListener('click', () => {
                    selectedWallSectionId = sec.id;
                    rebuildWallSectionList();
                    rebuildNewWalls();
                });
                wallSectionList.appendChild(row);
            });
        }


        function rebuildCabinetList() {
            if (!cabinetList) return;
            cabinetList.style.display = 'none';
            cabinetList.innerHTML = '';
            // intentionally hidden as per latest requirement
        }

        function rebuildNewWallList() {
            if (!newWallList) return;
            newWallList.innerHTML = '';
            if (!newWalls.length) {
                newWallList.textContent = 'Стена жоқ';
                return;
            }
            newWalls.forEach((w, idx) => {
                const wallSectionsList = ensureWallSections(w);
                const row = document.createElement('div');
                row.className = 'simple-list-item wall-list-row';
                if (w.id === selectedNewWallId) row.classList.add('active');
                const header = document.createElement('div');
                header.className = 'wall-row-header';

                const title = document.createElement('div');
                const typeLabel = (w.type === 'vertical') ? 'V' : 'F';
                title.textContent = `${typeLabel} · ID ${idx + 1}`;
                header.appendChild(title);

                const whInputs = document.createElement('div');
                whInputs.className = 'wall-wh-inputs';
                const wInput = document.createElement('input');
                wInput.type = 'number';
                wInput.value = Math.round(w.w || 0);
                wInput.step = '10';
                wInput.title = 'Ені (мм)';
                wInput.placeholder = 'l';
                const hInput = document.createElement('input');
                hInput.type = 'number';
                hInput.value = Math.round(w.h || 0);
                hInput.step = '10';
                hInput.title = 'Биіктік (мм)';
                hInput.placeholder = 'h';
                whInputs.appendChild(wInput);
                whInputs.appendChild(hInput);
                header.appendChild(whInputs);

                const del = document.createElement('button');
                del.innerHTML = '<i class="fa-solid fa-trash" aria-hidden="true"></i>';
                del.title = 'Өшіру';
                del.style.marginLeft = 'auto';
                del.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const cabinetsOnWall = getCabinetsByWallId(w.id);
                    if (cabinetsOnWall.length) {
                        const msg = `Бұл стенаны өшірсеңіз, осы стенамен байланысқан ${cabinetsOnWall.length} шкаф та өшеді. Өшіруді растайсыз ба?`;
                        const ok = window.confirm(msg);
                        if (!ok) return;
                        const ids = cabinetsOnWall.map(c => c.id);
                        ids.forEach(removeCabinet);
                    }
                    newWalls = newWalls.filter(x => x.id !== w.id);
                    if (selectedNewWallId === w.id) selectedNewWallId = null;
                    delete wallSections[w.id];
                    selectedWallSectionId = null;
                    if (cabinetWallId === w.id) {
                        cabinetWallId = null;
                        cabinetSectionId = null;
                        cabinetSpawned = false;
                        cabinetBaseOffset = { x: 0, y: 0, z: 0 };
                        cabinetRotationY = 0;
                        if (cabinetGroup) {
                            scene.remove(cabinetGroup);
                            cabinetGroup = null;
                        }
                        cabinets.forEach(c => {
                            if (c.wallId === w.id && c.group) {
                                scene.remove(c.group);
                            }
                        });
                        cabinets = cabinets.filter(c => c.wallId !== w.id);
                        activeCabinetId = null;
                    }
                    rebuildNewWallList();
                    rebuildNewWalls();
                    rebuildCabinetList();
                    rebuildCabinetIcons();
                });
                header.appendChild(del);

                const posRow = document.createElement('div');
                posRow.className = 'wall-xyz-inputs';
                const xInput = document.createElement('input');
                xInput.type = 'number';
                xInput.value = Math.round(w.x || 0);
                xInput.step = '10';
                xInput.title = 'X (мм)';
                xInput.placeholder = 'x';
                const yInput = document.createElement('input');
                yInput.type = 'number';
                yInput.value = Math.round(w.y || 0);
                yInput.step = '10';
                yInput.title = 'Y (мм)';
                yInput.placeholder = 'y';
                const zInput = document.createElement('input');
                zInput.type = 'number';
                zInput.value = Math.round(w.z || 0);
                zInput.step = '10';
                zInput.title = 'Z (мм)';
                zInput.placeholder = 'z';
                posRow.appendChild(xInput);
                posRow.appendChild(yInput);
                posRow.appendChild(zInput);

                wInput.addEventListener('change', (e) => {
                    const newW = parseFloat(e.target.value) || w.w;
                    updateWallSizeById(w.id, { w: newW });
                });
                hInput.addEventListener('change', (e) => {
                    const newH = parseFloat(e.target.value) || w.h;
                    updateWallSizeById(w.id, { h: newH });
                });
                xInput.addEventListener('change', (e) => {
                    const nx = parseFloat(e.target.value);
                    updateWallSizeById(w.id, { x: isNaN(nx) ? w.x : nx });
                });
                yInput.addEventListener('change', (e) => {
                    const ny = parseFloat(e.target.value);
                    updateWallSizeById(w.id, { y: isNaN(ny) ? w.y : ny });
                });
                zInput.addEventListener('change', (e) => {
                    const nz = parseFloat(e.target.value);
                    updateWallSizeById(w.id, { z: isNaN(nz) ? w.z : nz });
                });

                [wInput, hInput, xInput, yInput, zInput].forEach(inp => {
                    inp.addEventListener('mousedown', e => e.stopPropagation());
                    inp.addEventListener('click', e => e.stopPropagation());
                    inp.addEventListener('focus', e => e.stopPropagation());
                });

                row.addEventListener('click', () => {
                    selectedNewWallId = w.id;
                    if (cabinetWallId === w.id && cabinetSectionId) {
                        selectedWallSectionId = cabinetSectionId;
                    }
                    ensureWallSections(w);
                    selectedWallSectionId = selectedWallSectionId || (wallSections[w.id] && wallSections[w.id][0] && wallSections[w.id][0].id) || null;
                    rebuildNewWallList();
                    rebuildWallSectionList();
                    rebuildNewWalls();
                    rebuildCabinetList();
                });

                const sectionDims = createWallSectionSizeSummary(w);
                row.appendChild(header);
                row.appendChild(posRow);
                row.appendChild(sectionDims);
                newWallList.appendChild(row);
            });

            rebuildWallSectionList();
        }

        function createWallSectionSizeSummary(wall) {
            const block = document.createElement('div');
            block.className = 'wall-section-size-summary';
            const width = Number.isFinite(wall.w) ? Math.round(wall.w) : 0;
            const height = Number.isFinite(wall.h) ? Math.round(wall.h) : 0;
            const vLine = document.createElement('div');
            vLine.textContent = 'В: ' + (width || '—');
            const gLine = document.createElement('div');
            gLine.textContent = 'Г: ' + (height || '—');
            block.appendChild(vLine);
            block.appendChild(gLine);
            return block;
        }

        const wallAxisPatterns = {};

        function createWallSectionSizeSummary(wall) {
            const block = document.createElement('div');
            block.className = 'wall-section-size-summary';
            block.appendChild(createAxisPatternBlock('В', wall, 'x', 'w'));
            block.appendChild(createAxisPatternBlock('Г', wall, 'y', 'h'));
            return block;
        }

        function createAxisPatternBlock(labelText, wall, axis, dimensionKey) {
            const block = document.createElement('div');
            block.className = 'wall-axis-pattern-block';

            const header = document.createElement('div');
            header.className = 'wall-axis-pattern-header';
            header.textContent = labelText + ': ' + formatAxisSizes(wall, axis, dimensionKey);
            block.appendChild(header);

            const pattern = document.createElement('input');
            pattern.type = 'text';
            pattern.className = 'wall-axis-pattern-input';
            pattern.placeholder = '500/500/500';
            pattern.title = `${labelText}: / бөлгіштер арқылы ендер енгізіңіз`;
            const stored = (wallAxisPatterns[wall.id] || {})[axis];
            if (stored && stored.text) pattern.value = stored.text;
            ['pointerdown', 'mousedown', 'click', 'focus'].forEach(evt => {
                pattern.addEventListener(evt, event => {
                    event.stopPropagation();
                });
            });
            pattern.addEventListener('keydown', (event) => {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    applyAxisSplitPattern(wall, axis, dimensionKey, pattern.value);
                }
            });
            block.appendChild(pattern);
            return block;
        }

        function formatAxisSizes(wall, axis, dimensionKey) {
            const entry = getAxisPatternEntry(wall, axis);
            if (entry && entry.text) {
                return entry.text;
            }
            const sizes = getSectionsSortedByAxis(wall, axis);
            if (!sizes.length) {
                const fallback = Number.isFinite(wall[dimensionKey]) ? Math.round(wall[dimensionKey]) : 0;
                return fallback ? `${fallback}` : '—';
            }
            return sizes.map(sec => Math.round(sec[dimensionKey] || 0)).join('/');
        }

        function getSectionsSortedByAxis(wall, axis) {
            const sections = ensureWallSections(wall);
            if (!sections || !sections.length) return [];
            return sections.slice().sort((a, b) => {
                if (axis === 'x') return (a.x || 0) - (b.x || 0);
                return (a.y || 0) - (b.y || 0);
            });
        }

        function applyAxisSplitPattern(wall, axis, dimensionKey, rawValue) {
            if (!wall || !rawValue) return;
            const sizes = parseAxisSplitValues(rawValue);
            if (!sizes.length) return;
            const total = sizes.reduce((sum, v) => sum + v, 0);
            if (total <= 0) return;
            const normalized = rawValue.trim();
            wallAxisPatterns[wall.id] = wallAxisPatterns[wall.id] || {};
            wallAxisPatterns[wall.id][axis] = { text: normalized, sizes };
            const wallIdx = newWalls.findIndex(w => w.id === wall.id);
            if (wallIdx === -1) return;
            const updatedWall = { ...newWalls[wallIdx] };
            if (dimensionKey === 'w') {
                updatedWall.w = total;
            } else {
                updatedWall.h = total;
            }
            newWalls[wallIdx] = updatedWall;

            rebuildSectionsFromPatterns(updatedWall);
        }

        function parseAxisSplitValues(rawValue) {
            return (rawValue || '')
                .split(/[\\/;]+/)
                .map(part => parseFloat(part.trim()))
                .filter(val => Number.isFinite(val) && val > 0)
                .map(val => Math.max(WALL_SECTION_MIN_SIZE, val));
        }

        function rebuildSectionsFromPatterns(wall) {
            if (!wall) return;
            const widths = getAxisPatternSizes(wall, 'x', 'w');
            const heights = getAxisPatternSizes(wall, 'y', 'h');
            if (!widths.length || !heights.length) return;

            const totalW = widths.reduce((sum, v) => sum + v, 0);
            const totalH = heights.reduce((sum, v) => sum + v, 0);
            if (totalW > 0) wall.w = totalW;
            if (totalH > 0) wall.h = totalH;

            const sections = [];
            let offsetY = 0;
            heights.forEach(height => {
                let offsetX = 0;
                widths.forEach(width => {
                    sections.push({
                        id: nextWallSectionId++,
                        parentId: null,
                        x: offsetX,
                        y: offsetY,
                        w: width,
                        h: height,
                        dir: 'grid',
                        widthLocked: false,
                        heightLocked: false
                    });
                    offsetX += width;
                });
                offsetY += height;
            });
            wallSections[wall.id] = sections;
            selectedWallSectionId = sections[0] ? sections[0].id : null;
            rebuildNewWallList();
            rebuildWallSectionList();
            rebuildNewWalls();
        }

        function getAxisPatternEntry(wall, axis) {
            if (!wall) return null;
            return wallAxisPatterns[wall.id] && wallAxisPatterns[wall.id][axis] || null;
        }

        function getAxisPatternSizes(wall, axis, dimensionKey) {
            const entry = getAxisPatternEntry(wall, axis);
            if (entry && entry.sizes && entry.sizes.length) {
                return entry.sizes;
            }
            const fallback = Number.isFinite(wall[dimensionKey]) ? wall[dimensionKey] : 0;
            if (fallback > 0) return [fallback];
            return [];
        }

        function rebuildNewWalls() {
            disposeNewWallGroup();
            if (!newWalls.length) return;
            newWallGroup = new THREE.Group();
            const lineMat = new THREE.LineBasicMaterial({ color: 0x00aa00, linewidth: 2, depthTest: true });
            const sectionMat = new THREE.LineBasicMaterial({ color: 0x0077ff, linewidth: 1, depthTest: true });
            wallSectionPlusSprites = [];
            selectedWallSectionHelper = null;
            selectedWallHighlightHelper = null;

            newWalls.forEach(w => {
                const isVert = (w.type === 'vertical');
                const sizeX = isVert ? 1 : (w.w || 1000);
                const sizeZ = isVert ? (w.w || 1000) : 1;
                const sizeY = w.h || 1000;
                const geo = new THREE.BoxGeometry(sizeX, sizeY, sizeZ);
                const edges = new THREE.EdgesGeometry(geo);
                const line = new THREE.LineSegments(edges, lineMat.clone());
                const startX = w.x || 0;
                const startY = w.y || 0;
                const startZ = w.z || 0;
                const centerX = startX + (isVert ? 0 : sizeX / 2);
                const centerZ = startZ + (isVert ? sizeZ / 2 : 0);
                line.position.set(centerX, startY + sizeY / 2, centerZ);
                newWallGroup.add(line);
                if (selectedNewWallId === w.id) {
                    const wallWidth = Number.isFinite(w.w) ? w.w : 0;
                    const wallHeight = Number.isFinite(w.h) ? w.h : 0;
                    if (wallWidth > 0 && wallHeight > 0) {
                        const highlightGeo = new THREE.PlaneGeometry(wallWidth, wallHeight);
                        const highlightMat = new THREE.MeshBasicMaterial({
                            color: wallSectionHighlightBaseColor.getHex(),
                            opacity: 0.25,
                            transparent: true,
                            depthWrite: false,
                            side: THREE.DoubleSide
                        });
                        const highlightPlane = new THREE.Mesh(highlightGeo, highlightMat);
                        const centerYPlane = startY + wallHeight / 2;
                        const offset = 0.1;
                        if (isVert) {
                            const centerZPlane = startZ + wallWidth / 2;
                            highlightPlane.position.set(startX, centerYPlane, centerZPlane);
                            highlightPlane.rotation.y = Math.PI / 2;
                            highlightPlane.position.x += offset;
                        } else {
                            const centerXPlane = startX + wallWidth / 2;
                            highlightPlane.position.set(centerXPlane, centerYPlane, startZ);
                            highlightPlane.position.z += offset;
                        }
                        highlightPlane.renderOrder = 1400;
                        selectedWallHighlightHelper = highlightPlane;
                        newWallGroup.add(highlightPlane);
                    }
                }

                // Секцияларды салу
                const sections = ensureWallSections(w);
                sections.forEach(sec => {
                    const left   = startX + (isVert ? 0 : sec.x);
                    const right  = left + sec.w;
                    const bottom = startY + sec.y;
                    const top    = bottom + sec.h;
                    const zPlane = isVert ? startZ : startZ;
                    const xPlane = isVert ? startX : null;

                    const pts = isVert
                        ? [
                            new THREE.Vector3(xPlane, bottom, startZ + sec.x),
                            new THREE.Vector3(xPlane, bottom, startZ + sec.x + sec.w),
                            new THREE.Vector3(xPlane, top,    startZ + sec.x + sec.w),
                            new THREE.Vector3(xPlane, top,    startZ + sec.x),
                            new THREE.Vector3(xPlane, bottom, startZ + sec.x)
                        ]
                        : [
                            new THREE.Vector3(left,  bottom, zPlane),
                            new THREE.Vector3(right, bottom, zPlane),
                            new THREE.Vector3(right, top,    zPlane),
                            new THREE.Vector3(left,  top,    zPlane),
                            new THREE.Vector3(left,  bottom, zPlane)
                        ];
                    const secGeo = new THREE.BufferGeometry().setFromPoints(pts);
                    const secLine = new THREE.Line(secGeo, sectionMat.clone());
                    secLine.userData.isWallSection = true;
                    newWallGroup.add(secLine);

                    const isSelectedSection = (selectedWallSectionId === sec.id) && (selectedNewWallId === w.id);
                    if (isSelectedSection) {
                        const planeGeo = new THREE.PlaneGeometry(
                            isVert ? sec.w : sec.w,
                            sec.h
                        );
                        const planeMat = new THREE.MeshBasicMaterial({
                            color: wallSectionHighlightBaseColor.getHex(),
                            opacity: 0.35,
                            transparent: true,
                            depthWrite: false,
                            side: THREE.DoubleSide
                        });
                        const plane = new THREE.Mesh(planeGeo, planeMat);

                        const centerX = isVert ? xPlane : (left + right) / 2;
                        const centerY = (bottom + top) / 2;
                        const centerZ = isVert ? (startZ + sec.x + sec.w / 2) : zPlane;
                        plane.position.set(centerX, centerY, centerZ);
                        if (isVert) {
                            plane.rotation.y = Math.PI / 2;
                        }
                        const offset = 0.1;
                        if (isVert) {
                            plane.position.x += (w.type === 'vertical') ? offset : 0;
                        } else {
                            plane.position.z += offset;
                        }
                        plane.renderOrder = 1500;

                        selectedWallSectionHelper = plane;
                        newWallGroup.add(plane);
                    }

                    // Плюс белгісі (егер осы секцияда шкаф байланбаған болса)
                    const isLinkedCabinet = hasCabinetInSection(w.id, sec.id);
                    if (!isLinkedCabinet) {
                        const plus = createWallPlusSprite();
                        const cX = isVert ? xPlane : (left + right) / 2;
                        const cZ = isVert ? (startZ + sec.x + sec.w / 2) : zPlane;
                        plus.position.set(cX, (bottom + top) / 2, cZ);
                        plus.userData.isWallSectionPlus = true;
                        plus.userData.wallId = w.id;
                        plus.userData.sectionId = sec.id;
                        wallSectionPlusSprites.push(plus);
                        newWallGroup.add(plus);
                    }
                });

            });

            scene.add(newWallGroup);
        }

        function addNewWall(typeOverride) {
            saveActiveCabinetState();
            const type = typeOverride || 'frontal';
            const wVal = 3000;
            const hVal = 3000;
            const xVal = 0;
            const yVal = 0;
            const zVal = 0;
            const id = Date.now() + Math.random();
            newWalls.push({ id, type, w: wVal, h: hVal, x: xVal, y: yVal, z: zVal });
            selectedNewWallId = id;
                wallSections[id] = [{
                    id: nextWallSectionId++,
                    parentId: null,
                    x: 0,
                    y: 0,
                    w: wVal,
                    h: hVal,
                    dir: 'base',
                    widthLocked: false,
                    heightLocked: false
                }];
            selectedWallSectionId = wallSections[id][0].id;
            if (!cabinetWallId) {
                cabinetWallId = id;
                cabinetSectionId = selectedWallSectionId;
            }
            if (newWallList) newWallList.scrollTop = newWallList.scrollHeight;
            rebuildNewWallList();
            rebuildNewWalls();
        }

        if (addWallFrontalBtn) {
            addWallFrontalBtn.addEventListener('click', () => addNewWall('frontal'));
        }
        if (addWallVerticalBtn) {
            addWallVerticalBtn.addEventListener('click', () => addNewWall('vertical'));
        }

        function updateWallSizeById(wallId, opts) {
            const idx = newWalls.findIndex(w => w.id === wallId);
            if (idx === -1) return;
            const wall = newWalls[idx];
            const newW = (opts && opts.w != null) ? opts.w : wall.w;
            const newH = (opts && opts.h != null) ? opts.h : wall.h;
            const newX = (opts && opts.x != null) ? opts.x : wall.x;
            const newY = (opts && opts.y != null) ? opts.y : wall.y;
            const newZ = (opts && opts.z != null) ? opts.z : wall.z;
            const prevW = (opts && opts.prevW) || wall.w || 1;
            const prevH = (opts && opts.prevH) || wall.h || 1;
            newWalls[idx] = { ...wall, w: newW, h: newH, x: newX, y: newY, z: newZ };
            if (wallSections[wallId] && wallSections[wallId].length) {
                const list = wallSections[wallId];
                const scaleW = newW / prevW;
                const scaleH = newH / prevH;
                wallSections[wallId] = list.map(sec => ({
                    ...sec,
                    x: sec.x * scaleW,
                    y: sec.y * scaleH,
                    w: sec.w * scaleW,
                    h: sec.h * scaleH
                }));
            }
            rebuildNewWallList();
            rebuildNewWalls();
            if (cabinetWallId === wallId) {
                updateCabinetFromSection(true);
            }
        }

        function applySelectedWallInputs() {
            if (!selectedNewWallId) return;
            const idx = newWalls.findIndex(x => x.id === selectedNewWallId);
            if (idx === -1) return;
            const type = newWalls[idx].type;
            const prevW = newWalls[idx].w || 1;
            const prevH = newWalls[idx].h || 1;
            updateWallSizeById(newWalls[idx].id, {
                w: newWalls[idx].w,
                h: newWalls[idx].h,
                x: newWalls[idx].x,
                y: newWalls[idx].y,
                z: newWalls[idx].z,
                prevW,
                prevH
            });
        }

        [newWallWidthInput, newWallHeightInput, newWallStartXInput, newWallStartYInput, newWallStartZInput].forEach(inp => {
            if (inp) {
                inp.addEventListener('input', applySelectedWallInputs);
                inp.addEventListener('change', applySelectedWallInputs);
            }
        });

        const WALL_SECTION_MIN_SIZE = 50;

        function getSplitCount(input, fallback = 2) {
            if (!input) return fallback;
            const parsed = parseInt(input.value, 10);
            if (isNaN(parsed)) return fallback;
            return Math.max(2, parsed);
        }

        function confirmAndClearWallCabinets(wallId) {
            const cabinetIds = getCabinetsByWallId(wallId).map(c => c.id);
            if (!cabinetIds.length) return true;
            const msg = 'Осы стенадағы барлық шкафты өшіріп, қайта бөліңіз бе?';
            if (!window.confirm(msg)) return false;
            cabinetIds.forEach(removeCabinet);
            return true;
        }

        function updateSplitCountInputs() {
            if (splitVerticalCountInput) {
                splitVerticalCountInput.value = splitCounts.vertical;
            }
            if (splitHorizontalCountInput) {
                splitHorizontalCountInput.value = splitCounts.horizontal;
            }
        }

        function handleSplitCountInput(input, direction) {
            if (!input) return;
            input.addEventListener('change', () => {
                const parsed = Math.max(1, parseInt(input.value, 10) || 1);
                splitCounts[direction] = parsed;
                input.value = splitCounts[direction];
            });
        }

        function adjustSplitCount(direction, delta) {
            if (!selectedNewWallId) return;
            const wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) return;
            const axisLength = direction === 'vertical' ? (wall.w || 0) : (wall.h || 0);
            if (!Number.isFinite(axisLength) || axisLength < WALL_SECTION_MIN_SIZE) return;
            const maxCount = Math.max(1, Math.floor(axisLength / WALL_SECTION_MIN_SIZE));
            const newValue = Math.max(1, Math.min(maxCount, splitCounts[direction] + delta));
            if (newValue === splitCounts[direction]) return;
            splitCounts[direction] = newValue;
            updateSplitCountInputs();
            applySplitCounts();
        }

        function applySplitCounts() {
            if (!selectedNewWallId) return;
            const wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) return;
            const vCount = Math.max(1, splitCounts.vertical);
            const hCount = Math.max(1, splitCounts.horizontal);
            const canVertical = Number.isFinite(wall.w) && wall.w >= vCount * WALL_SECTION_MIN_SIZE;
            const canHorizontal = Number.isFinite(wall.h) && wall.h >= hCount * WALL_SECTION_MIN_SIZE;
            if (vCount > 1 && hCount > 1 && canVertical && canHorizontal) {
                splitWallGrid(vCount, hCount);
            } else if (vCount > 1 && canVertical) {
                splitWallIntoLines('vertical', vCount);
            } else if (hCount > 1 && canHorizontal) {
                splitWallIntoLines('horizontal', hCount);
            } else {
                ensureWallSections(wall);
                const defaultSection = wallSections[wall.id] && wallSections[wall.id][0];
                selectedWallSectionId = defaultSection ? defaultSection.id : null;
                rebuildWallSectionList();
                rebuildNewWalls();
            }
        }

        function splitWallIntoLines(mode, splitCountOverride) {
            if (!selectedNewWallId) return;
            const wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) return;
            const splitCount = Math.max(2, splitCountOverride || (mode === 'vertical' ? getSplitCount(splitVerticalCountInput) : getSplitCount(splitHorizontalCountInput)));
            if (splitCount < 2) return;
            const minSize = WALL_SECTION_MIN_SIZE;
            const isVertical = (mode === 'vertical');
            const axisLength = isVertical ? wall.w : wall.h;
            if (!isFinite(axisLength) || axisLength < minSize * splitCount) return;
            if (!confirmAndClearWallCabinets(wall.id)) return;

            const sectionSize = axisLength / splitCount;
            const sections = [];
            for (let i = 0; i < splitCount; i++) {
                const size = (i === splitCount - 1)
                    ? Math.max(minSize, axisLength - sectionSize * (splitCount - 1))
                    : sectionSize;
                const sec = {
                    id: nextWallSectionId++,
                    parentId: null,
                    x: isVertical ? sectionSize * i : 0,
                    y: isVertical ? 0 : sectionSize * i,
                    w: isVertical ? size : (wall.w || 0),
                    h: isVertical ? (wall.h || 0) : size,
                    dir: isVertical ? 'vertical' : 'horizontal',
                    widthLocked: false,
                    heightLocked: false
                };
                sections.push(sec);
            }
            clampSectionsToWall(wall, sections, minSize);
            wallSections[wall.id] = sections;
            selectedWallSectionId = sections[0] ? sections[0].id : null;
            if (isVertical) {
                splitCounts.vertical = splitCount;
                splitCounts.horizontal = 1;
            } else {
                splitCounts.horizontal = splitCount;
                splitCounts.vertical = 1;
            }
            updateSplitCountInputs();
            rebuildWallSectionList();
            rebuildNewWalls();
        }

        function splitWallGrid(verticalCountOverride, horizontalCountOverride) {
            if (!selectedNewWallId) return;
            const wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) return;
            const verticalCount = Math.max(2, verticalCountOverride || getSplitCount(splitVerticalCountInput));
            const horizontalCount = Math.max(2, horizontalCountOverride || getSplitCount(splitHorizontalCountInput));
            const minSize = WALL_SECTION_MIN_SIZE;
            if (verticalCount < 2 || horizontalCount < 2) return;
            if (!isFinite(wall.w) || !isFinite(wall.h)) return;
            if (wall.w < minSize * verticalCount || wall.h < minSize * horizontalCount) return;
            if (!confirmAndClearWallCabinets(wall.id)) return;

            const sectionWidth = wall.w / verticalCount;
            const sectionHeight = wall.h / horizontalCount;
            const verticalBands = [];
            let xAcc = 0;
            for (let i = 0; i < verticalCount; i++) {
                const w = (i === verticalCount - 1)
                    ? Math.max(minSize, wall.w - sectionWidth * (verticalCount - 1))
                    : sectionWidth;
                verticalBands.push({ x: xAcc, w });
                xAcc += w;
            }
            const horizontalBands = [];
            let yAcc = 0;
            for (let i = 0; i < horizontalCount; i++) {
                const h = (i === horizontalCount - 1)
                    ? Math.max(minSize, wall.h - sectionHeight * (horizontalCount - 1))
                    : sectionHeight;
                horizontalBands.push({ y: yAcc, h });
                yAcc += h;
            }

            const sections = [];
            verticalBands.forEach(v => {
                horizontalBands.forEach(h => {
                    sections.push({
                        id: nextWallSectionId++,
                        parentId: null,
                        x: v.x,
                        y: h.y,
                        w: v.w,
                        h: h.h,
                        dir: 'grid',
                        widthLocked: false,
                        heightLocked: false
                    });
                });
            });
            clampSectionsToWall(wall, sections, minSize);
            wallSections[wall.id] = sections;
            selectedWallSectionId = sections[0] ? sections[0].id : null;
            splitCounts.vertical = verticalCount;
            splitCounts.horizontal = horizontalCount;
            updateSplitCountInputs();
            rebuildWallSectionList();
            rebuildNewWalls();
        }

        if (splitVerticalIncrease) {
            splitVerticalIncrease.addEventListener('click', () => adjustSplitCount('vertical', 1));
        }
        if (splitVerticalDecrease) {
            splitVerticalDecrease.addEventListener('click', () => adjustSplitCount('vertical', -1));
        }
        if (splitHorizontalIncrease) {
            splitHorizontalIncrease.addEventListener('click', () => adjustSplitCount('horizontal', 1));
        }
        if (splitHorizontalDecrease) {
            splitHorizontalDecrease.addEventListener('click', () => adjustSplitCount('horizontal', -1));
        }
        handleSplitCountInput(splitVerticalCountInput, 'vertical');
        handleSplitCountInput(splitHorizontalCountInput, 'horizontal');
        updateSplitCountInputs();

        // СЕКЦИЯ ӨЛШЕМІН ТІКЕЛЕЙ ӨЗГЕРТУ (list inputs)
        function resizeWallSection(sectionId, opts) {
            if (!selectedNewWallId) return;
            const wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) return;
            const sections = ensureWallSections(wall);
            const idx = sections.findIndex(s => s.id === sectionId);
            if (idx === -1) return;
            const sec = sections[idx];
            const newW = (opts && opts.w != null) ? opts.w : sec.w;
            const newH = (opts && opts.h != null) ? opts.h : sec.h;
            const minSize = 50;
            const eps = 0.001;
            // Capture previous sizes for balancing
            sections.forEach(s => {
                s._prevW = s.w;
                s._prevH = s.h;
                s._prevX = s.x;
                s._prevY = s.y;
            });

            // Width adjust (жалпы биіктік бірдей көрші керек)
            if (opts && opts.w != null && !sec.widthLocked) {
                let widthChanged = false;
                // Try sibling redistribution first (for vertical split siblings)
                const redisOk = redistributeWidthsForSiblings(sections, sec, newW, minSize);
                if (redisOk) {
                    widthChanged = true;
                } else {
                let neighbor = sections.find(s =>
                    !s.widthLocked &&
                    Math.abs(s.x - (sec.x + sec.w)) < eps &&
                    Math.abs(s.y - sec.y) < eps &&
                    Math.abs(s.h - sec.h) < eps &&
                    sameSectionParent(s, sec)
                );
                let neighborSide = 'right';
                if (!neighbor) {
                    neighbor = sections.find(s =>
                        !s.widthLocked &&
                        Math.abs((s.x + s.w) - sec.x) < eps &&
                        Math.abs(s.y - sec.y) < eps &&
                        Math.abs(s.h - sec.h) < eps &&
                        sameSectionParent(s, sec)
                    );
                    neighborSide = 'left';
                }
                if (neighbor) {
                    const delta = newW - sec.w;
                    const newNeighW = neighbor.w - delta;
                    if (newW >= minSize && newNeighW >= minSize) {
                        if (neighborSide === 'right') {
                            sec.w = newW;
                            neighbor.w = newNeighW;
                            neighbor.x = sec.x + sec.w;
                        } else {
                            neighbor.w = newNeighW;
                            sec.x = neighbor.x + neighbor.w;
                            sec.w = newW;
                        }
                        widthChanged = true;
                    }
                } else if (newW >= minSize) {
                    sec.w = newW;
                    widthChanged = true;
                }
                }
                if (widthChanged) {
                    if (sec.dir === 'horizontal' && sec.parentId != null) {
                        alignHorizontalGroupWidth(sections, sec);
                        adjustHorizontalColumnNeighborWidth(sections, sec, minSize);
                    }
                    reflowHorizontalSiblingPositions(sections, sec);
                    // already handled positioning inside redistribution or neighbor logic
                }
            }

            // Height adjust (жалпы ені бірдей көрші керек)
            if (opts && opts.h != null && !sec.heightLocked) {
                let heightChanged = false;
                // Баған бойынша (x/w бірдей) пропорциямен қайта бөлу: жалпы биіктікті сақтаймыз
                if (!heightChanged) {
                    const sameColumn = sections.filter(s =>
                        Math.abs((s.x || 0) - (sec.x || 0)) < eps &&
                        Math.abs((s.w || 0) - (sec.w || 0)) < eps
                    );
                    if (sameColumn.length > 1) {
                        const totalPrev = sameColumn.reduce((sum, s) => sum + (s._prevH || s.h || 0), 0);
                        const others = sameColumn.filter(s => s !== sec);
                        const totalOthersPrev = others.reduce((sum, s) => sum + (s._prevH || s.h || 0), 0);
                        const minForOthers = minSize * others.length;
                        const newHClamped = Math.min(Math.max(newH, minSize), totalPrev - minForOthers);
                        const remaining = totalPrev - newHClamped;
                        if (remaining >= minForOthers && totalOthersPrev > 0) {
                            sec.h = newHClamped;
                            others.forEach(o => {
                                const ratio = (o._prevH || o.h || 0) / totalOthersPrev;
                                o.h = Math.max(minSize, remaining * ratio);
                            });
                            const sortedCol = sameColumn.slice().sort((a, b) => (a._prevY || a.y || 0) - (b._prevY || b.y || 0));
                            let cursor = Math.min(...sortedCol.map(s => s._prevY || s.y || 0));
                            sortedCol.forEach(s => {
                                s.y = cursor;
                                cursor += s.h || 0;
                            });
                            heightChanged = true;
                        }
                    }
                }
                // Алдымен бауырлас (бір parent) горизонталь бөліктерге бағытталған логика:
                if (!heightChanged && sec.dir === 'horizontal' && sec.parentId != null) {
                    const siblings = sections.filter(s => s.parentId === sec.parentId && s.dir === sec.dir);
                    if (siblings.length > 1) {
                        const sorted = siblings.slice().sort((a, b) => (a._prevY || a.y || 0) - (b._prevY || b.y || 0));
                        const myIdx = sorted.indexOf(sec);
                        const neighbor = (myIdx < sorted.length - 1) ? sorted[myIdx + 1] : sorted[myIdx - 1];
                        if (neighbor) {
                            const others = siblings.filter(s => s !== sec && s !== neighbor);
                            const totalPrev = siblings.reduce((sum, s) => sum + (s._prevH || s.h || 0), 0);
                            const fixedSum = others.reduce((sum, s) => sum + (s._prevH || s.h || 0), 0);
                            const maxForSec = totalPrev - fixedSum - minSize;
                            const newHClamped = Math.min(Math.max(newH, minSize), maxForSec);
                            const newNeighborH = totalPrev - fixedSum - newHClamped;
                            if (newNeighborH >= minSize) {
                                sec.h = newHClamped;
                                neighbor.h = newNeighborH;
                                const startY = Math.min(...sorted.map(s => s._prevY || s.y || 0));
                                let cursor = startY;
                                sorted.forEach(s => {
                                    s.y = cursor;
                                    cursor += s.h || 0;
                                });
                                heightChanged = true;
                            }
                        }
                    }
                }
                if (!heightChanged) {
                    const redisHOk = redistributeHeightsForSiblings(sections, sec, newH, minSize);
                    if (redisHOk) {
                        heightChanged = true;
                    } else {
                    let neighbor = sections.find(s =>
                        !s.heightLocked &&
                        Math.abs(s.y - (sec.y + sec.h)) < eps &&
                        Math.abs(s.x - sec.x) < eps &&
                        Math.abs(s.w - sec.w) < eps &&
                        sameSectionParent(s, sec)
                    );
                    let neighborSide = 'top';
                    if (!neighbor) {
                        neighbor = sections.find(s =>
                            !s.heightLocked &&
                            Math.abs((s.y + s.h) - sec.y) < eps &&
                            Math.abs(s.x - sec.x) < eps &&
                            Math.abs(s.w - sec.w) < eps &&
                            sameSectionParent(s, sec)
                        );
                        neighborSide = 'bottom';
                    }
                    if (neighbor) {
                        const delta = newH - sec.h;
                        const newNeighH = neighbor.h - delta;
                        if (newH >= minSize && newNeighH >= minSize) {
                            if (neighborSide === 'top') {
                                sec.h = newH;
                                neighbor.h = newNeighH;
                                neighbor.y = sec.y + sec.h;
                            } else {
                                neighbor.h = newNeighH;
                                sec.y = neighbor.y + neighbor.h;
                                sec.h = newH;
                            }
                            heightChanged = true;
                        }
                    } else if (newH >= minSize) {
                        sec.h = newH;
                        heightChanged = true;
                    }
                    }
                }
                if (heightChanged) {
                    if (sec.dir === 'vertical' && sec.parentId != null) {
                        alignVerticalGroupHeight(sections, sec);
                        adjustVerticalRowNeighborHeight(sections, sec, minSize);
                    }
                    reflowVerticalSiblingPositions(sections, sec);
                    // already handled
                }
            }

            wallSections[wall.id] = sections;
            clampSectionsToWall(wall, wallSections[wall.id], minSize);
            rebuildWallSectionList();
            rebuildNewWalls();
            // Cleanup temp fields
            sections.forEach(s => {
                delete s._prevW;
                delete s._prevH;
                delete s._prevX;
                delete s._prevY;
            });
            refreshCabinetsForSection(wall.id, null, true);
        }

        function deleteWallSection(sectionId) {
            if (!selectedNewWallId) return;
            const wall = newWalls.find(w => w.id === selectedNewWallId);
            if (!wall) return;
            const sections = ensureWallSections(wall);
            if (sections.length <= 1) return;
            const idx = sections.findIndex(s => s.id === sectionId);
            if (idx === -1) return;
            const sec = sections[idx];
            if (sec.widthLocked || sec.heightLocked) return;
            const eps = 0.001;
            const overlap1D = (a1, a2, b1, b2) => Math.max(0, Math.min(a2, b2) - Math.max(a1, b1));

            let bestIndex = -1;
            let bestScore = -Infinity;
            let bestMergeType = null; // 'horizontal' (stack) немесе 'vertical' (side by side)

            sections.forEach((s, i) => {
                if (i === idx) return;
                const touchLeft  = Math.abs((sec.x + sec.w) - s.x) < eps;
                const touchRight = Math.abs((s.x + s.w) - sec.x) < eps;
                const touchBottom = Math.abs((sec.y + sec.h) - s.y) < eps;
                const touchTop    = Math.abs((s.y + s.h) - sec.y) < eps;

                // Бүйірден жанасу (x бойынша жанасады) => тік шекара, overlap Y қарастырамыз
                if (touchLeft || touchRight) {
                    const ov = overlap1D(sec.y, sec.y + sec.h, s.y, s.y + s.h);
                    if (ov > 0) {
                        const score = ov + (s.parentId === sec.parentId ? 10000 : 0);
                        if (score > bestScore) {
                            bestScore = score;
                            bestIndex = i;
                            bestMergeType = 'vertical';
                        }
                    }
                }

                // Жоғары/төмен жанасу (y бойынша жанасады) => overlap X қарастырамыз
                if (touchTop || touchBottom) {
                    const ov = overlap1D(sec.x, sec.x + sec.w, s.x, s.x + s.w);
                    if (ov > 0) {
                        const score = ov + (s.parentId === sec.parentId ? 10000 : 0);
                        if (score > bestScore) {
                            bestScore = score;
                            bestIndex = i;
                            bestMergeType = 'horizontal';
                        }
                    }
                }
            });

            if (bestIndex === -1) return;

            const neigh = sections[bestIndex];
            // Біріктіру: толық bounding-box
            const leftX = Math.min(sec.x, neigh.x);
            const rightX = Math.max(sec.x + sec.w, neigh.x + neigh.w);
            const bottomY = Math.min(sec.y, neigh.y);
            const topY = Math.max(sec.y + sec.h, neigh.y + neigh.h);

            neigh.x = leftX;
            neigh.y = bottomY;
            neigh.w = rightX - leftX;
            neigh.h = topY - bottomY;
            neigh.parentId = neigh.parentId != null ? neigh.parentId : sec.parentId;
            neigh.dir = neigh.dir || sec.dir || bestMergeType;
            neigh.widthLocked = neigh.widthLocked || sec.widthLocked;
            neigh.heightLocked = neigh.heightLocked || sec.heightLocked;

            sections.splice(idx, 1);
            wallSections[wall.id] = sections;
            clampSectionsToWall(wall, wallSections[wall.id], 50);
            // Осы секцияға байланған барлық шкафтарды жаңа секцияға көшіреміз
            cabinets.forEach(c => {
                if (c.wallId === wall.id && c.sectionId === sec.id) {
                    c.sectionId = neigh.id;
                    if (activeCabinetId === c.id) {
                        cabinetSectionId = neigh.id;
                    }
                }
            });
            if (selectedWallSectionId === sec.id) {
                selectedWallSectionId = neigh.id;
            }
            rebuildWallSectionList();
            rebuildNewWalls();
            if (cabinetWallId === wall.id) {
                refreshCabinetsForSection(wall.id, neigh.id, true);
            }
        }

        function computeCabinetPlacement(wall, sec, W, D) {
            const thicknessVal     = parseFloat(corpusThickness ? corpusThickness.value : '') || 16;
            const backMaterialVal  = backMaterial ? backMaterial.value : 'hdf';
            const backThickLocal   = (backMaterialVal === 'hdf') ? 4 : thicknessVal;
            const base = { x: 0, y: 0, z: 0 };
            let rotationYLocal = 0;
            base.y = (wall ? (wall.y || 0) : 0) + (sec ? (sec.y || 0) : 0);
            if (wall && wall.type === 'vertical') {
                rotationYLocal = Math.PI / 2;
                base.x = (wall.x || 0) + D / 2 + backThickLocal - W / 2 + wallGap;
                base.z = (wall.z || 0) + (sec ? (sec.x || 0) : 0) + W / 2 - (D / 2 + backThickLocal);
            } else {
                base.x = (wall ? (wall.x || 0) : 0) + (sec ? (sec.x || 0) : 0);
                base.z = (wall ? (wall.z || 0) : 0) + wallGap;
            }
            return { base, rotationY: rotationYLocal };
        }

	        function spawnCabinetForSection(wallId, sectionId) {
	            saveActiveCabinetState();
	            const prevActiveGroup = cabinetGroup; // keep previous cabinet visible
	            cabinetGroup = null;
	            const wall = newWalls.find(w => w.id === wallId);
	            if (!wall) return;
	            const sections = ensureWallSections(wall);
	            const sec = sections.find(s => s.id === sectionId) || sections[0];
	            if (!sec) return;
	            runUndoable(() => {
	                const W = sec.w || parseFloat(widthInput.value) || 1000;
	                const H = sec.h || parseFloat(heightInput.value) || 2200;
	                const D = parseFloat(depthInput.value) || 600;

	                readWallGap();
	                const placement = computeCabinetPlacement(wall, sec, W, D);
	                cabinetBaseOffset = placement.base;
	                cabinetRotationY = placement.rotationY;

	                widthInput.value = Math.round(W);
	                heightInput.value = Math.round(H);

	                cabinetWallId = wallId;
	                cabinetSectionId = sec.id;
	                cabinetSpawned = true;
	                shelfInserts = {};
	                selectedShelfSubId = null;
	                falshPanels = [];
	                nextFalshId = 1;
	                falshLeftSideEnabled = false;
	                falshRightSideEnabled = false;
	                falshTopSideEnabled = false;
	                falshLeftSideDepth = null;
	                falshRightSideDepth = null;
	                falshTopSideDepth = null;
	                falshLeftSideSize = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
	                falshRightSideSize = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
	                falshTopSideSize = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
	                if (falshLeftSideCheckbox) falshLeftSideCheckbox.checked = false;
	                if (falshRightSideCheckbox) falshRightSideCheckbox.checked = false;
	                if (falshTopSideCheckbox) falshTopSideCheckbox.checked = false;
	                if (falshLeftSideSizeInput) falshLeftSideSizeInput.value = Math.round(falshLeftSideSize);
	                if (falshRightSideSizeInput) falshRightSideSizeInput.value = Math.round(falshRightSideSize);
	                if (falshTopSideSizeInput) falshTopSideSizeInput.value = Math.round(falshTopSideSize);
	                syncFalshOverlayControls(true);
	                rebuildFalshList();
	                let newCabinetId = Date.now();
	                while (cabinets.some(c => c && c.id === newCabinetId)) newCabinetId++;
	                activeCabinetId = newCabinetId;
	                cabinetGroup = null; // алдыңғы шкафты өшірмеу үшін null қоямыз
	                createCabinet(W, H, D, false);
	                applyActiveCabinetVisibility();
	                updateSelectedSectionHelper();
	                selectedNewWallId = wallId;
	                selectedWallSectionId = sec.id;
	                cabinets.push({
	                    id: newCabinetId,
	                    wallId: wallId,
	                    sectionId: sec.id,
	                    baseOffset: { ...cabinetBaseOffset },
	                    rotationY: cabinetRotationY,
	                    hidden: false,
	                    state: captureCabinetSnapshot(),
	                    group: cabinetGroup
	                });
	                structureVisible = false;
	                syncStructureVisibility();
	                rebuildWallSectionList();
	                rebuildNewWalls();
	                rebuildCabinetList();
	                rebuildCabinetIcons();
	            });
	        }

        // Өлшем көрсету элементтерімен синхрондау
        function syncDimensionsVisibility() {
            if (!dimensionHelpersGroup) return;
            dimensionHelpersGroup.visible = dimensionsVisible;
            if (dimensionsVisible) {
                if (!scene.children.includes(dimensionHelpersGroup)) {
                    scene.add(dimensionHelpersGroup);
                }
            } else {
                scene.remove(dimensionHelpersGroup);
            }
            if (toggleDimsBtn) {
                toggleDimsBtn.classList.toggle('active', dimensionsVisible);
            }
        }

        function syncInfoVisibility() {
            if (dimensionBox) {
                dimensionBox.style.display = infoPanelVisible ? 'block' : 'none';
            }
            if (toggleInfoBtn) {
                toggleInfoBtn.classList.toggle('active', infoPanelVisible);
            }
        }

        function updateCabinetActionsVisibility() {
            const show = !!(structureVisible && cabinets.length && activeCabinetId);
            const display = show ? 'inline-flex' : 'none';
            if (cabinetHideBtn)  cabinetHideBtn.style.display  = display;
            if (cabinetDeleteBtn) cabinetDeleteBtn.style.display = display;
        }

        function syncStructureVisibility() {
            if (structureList) {
                structureList.style.display = structureVisible ? 'block' : 'none';
            }
            if (structureBtn) {
                structureBtn.classList.toggle('active', structureVisible);
            }
            updateCabinetActionsVisibility();
        }

        function syncCabinetVisibilityBtn() {
            if (!cabinetHideBtn) return;
            const hidden = isCabinetHidden(activeCabinetId);
            cabinetHideBtn.classList.toggle('active', hidden);
            cabinetHideBtn.title = hidden ? 'Шкафты көрсету' : 'Шкафты жасыру';
        }

        function setDoorsVisibilityOnGroup(group, visible) {
            if (!group) return;
            group.traverse(obj => {
                const ud = obj.userData || {};
                if (ud.isDoor || ud.isDoorHinge || ud.isDoorsGroup) {
                    obj.visible = visible;
                }
            });
        }

        function getAllDoorGroups() {
            const groups = [];
            if (doorsGroup) groups.push(doorsGroup);
            cabinets.forEach(c => {
                if (c.group && c.group.userData && c.group.userData.doorsGroup) {
                    const dg = c.group.userData.doorsGroup;
                    if (dg) groups.push(dg);
                }
            });
            return groups;
        }

        function readDoorStatesFromGroup(group) {
            const g = group || doorsGroup;
            if (!g || !g.children) return [];
            return g.children.map(h => !!(h.userData && h.userData.open));
        }

        function getFalshExtents() {
            const res = { left: 0, right: 0, top: 0 };
            falshPanels.forEach(fp => {
                const sz = Math.max(0, parseFloat(fp.size) || 0);
                if (fp.side === 'left') res.left = Math.max(res.left, sz);
                else if (fp.side === 'right') res.right = Math.max(res.right, sz);
                else if (fp.side === 'top') res.top = Math.max(res.top, sz);
            });
            const overlayThk = getFalshOverlayThickness();
            if (falshLeftSideEnabled)  res.left  = Math.max(res.left, overlayThk);
            if (falshRightSideEnabled) res.right = Math.max(res.right, overlayThk);
            if (falshTopSideEnabled)   res.top   = Math.max(res.top, overlayThk);
            return res;
        }

        function rebuildFalshGroup() {
            if (!cabinetGroup) return;
            if (falshGroup) {
                cabinetGroup.remove(falshGroup);
                falshGroup.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
                falshGroup = null;
            }
            const hasSideOverlay = falshLeftSideEnabled || falshRightSideEnabled || falshTopSideEnabled;
            if (!falshPanels.length && !hasSideOverlay) {
                rebuildStructureList();
                return;
            }

            const { left: falshLeft, right: falshRight, top: falshTop } = getFalshExtents();
            const bodyW = Math.max(200, (currentW || 0) - falshLeft - falshRight);
            const bodyShiftX = (falshLeft - falshRight) / 2;

            const facadeThickVal = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
            const facadeMatVal   = facadeMaterial ? facadeMaterial.value : 'ldsp';
            const color          = getFacadeColor(facadeMatVal);
            const carcassHeight  = Math.max(50, (currentH || 0) - plinthHeight - falshTop);
            const frontZ         = (currentD || 0) / 2 - facadeThickVal / 2;
            const totalW         = Math.max(10, currentW || (bodyW + falshLeft + falshRight));

            falshGroup = new THREE.Group();
            falshGroup.userData.isFalshGroup = true;

            falshPanels.forEach(fp => {
                const side = fp.side || 'left';
                const size = Math.max(10, parseFloat(fp.size) || (side === 'top' ? 120 : 50));
                let baseW = 0;
                let baseH = 0;
                let pos   = new THREE.Vector3();
                const baseInfo = {
                    type: 'falsh',
                    name: 'Фальш ' + (side === 'left' ? 'сол' : side === 'right' ? 'оң' : 'төбе') + ' (негізгі)',
                    sectionId: cabinetSectionId || null,
                    width: 0,  height: 0,
                    depth: facadeThickVal
                };

                if (side === 'top') {
                    baseW = totalW;
                    baseH = size;
                    pos.set(0, plinthHeight + carcassHeight + size / 2, frontZ);
                    baseInfo.width  = baseW;
                    baseInfo.height = baseH;
                } else {
                    baseW = size;
                    baseH = carcassHeight;
                    const x = side === 'left'
                        ? (bodyShiftX - bodyW / 2 - size / 2)
                        : (bodyShiftX + bodyW / 2 + size / 2);
                    pos.set(x, plinthHeight + carcassHeight / 2, frontZ);
                    baseInfo.width  = baseW;
                    baseInfo.height = baseH;
                }

                const geomBase = new THREE.BoxGeometry(baseW, baseH, facadeThickVal);
                const base = solidWithEdges(geomBase, color, baseInfo);
                base.position.copy(pos);
                base.userData.isFalshPanel = true;
                falshGroup.add(base);

                // Алдыңғы қаптама – фасад қалыңдығымен
                const frontInfo = {
                    ...baseInfo,
                    name: baseInfo.name.replace('(негізгі)', '(алдыңғы)')
                };
                const geomFront = new THREE.BoxGeometry(baseW, baseH, facadeThickVal);
                const frontPos = pos.clone();
                frontPos.z += facadeThickVal;
                const front = solidWithEdges(geomFront, color, frontInfo);
                front.position.copy(frontPos);
                front.userData.isFalshPanel = true;
                falshGroup.add(front);
            });

            const overlayThkVal = getFalshOverlayThickness();
            const overlayThkL  = falshLeftSideEnabled  ? overlayThkVal : 0;
            const overlayThkR  = falshRightSideEnabled ? overlayThkVal : 0;
            const overlayThkT  = falshTopSideEnabled   ? overlayThkVal : 0;
            const thickness    = globalThickness || 16;
            const depth        = currentD || 0;
            const facadeTypeEl  = document.getElementById('facadeType');
            const facadeTypeVal = facadeTypeEl ? facadeTypeEl.value : 'vkladnoy';
            const facadeFrontZ  = (facadeTypeVal === 'vkladnoy')
                ? (depth / 2 - 1)
                : (depth / 2 + (parseFloat(facadeThickness ? facadeThickness.value : '') || 18) + 1);
            const zMin          = -depth / 2;
            const overlayDepthAuto  = Math.max(10, facadeFrontZ - zMin);
            const bottomMountSide = bottomMountInput ? (bottomMountInput.value || 'vkladnoy') : 'vkladnoy';
            const sideStartsOnBottom = (bottomMountSide === 'nakladnoy');
            const sideStartY    = sideStartsOnBottom ? (plinthHeight + thickness) : 0;
            const sideHeight    = sideStartsOnBottom ? (carcassHeight - thickness) : (carcassHeight + plinthHeight);
            const sideCenterY   = sideStartY + sideHeight / 2;

            function clampOverlayDepth(v) {
                return Math.max(10, Math.min(v, overlayDepthAuto));
            }

            function addSideOverlay(side, overlayThk, overlayDepthVal) {
                if (!overlayThk) return;
                const depthUsed = clampOverlayDepth(overlayDepthVal);
                const geom = new THREE.BoxGeometry(overlayThk, sideHeight, depthUsed);
                const info = {
                    type: 'falsh',
                    name: 'Фальш панель ' + (side === 'left' ? 'сол' : 'оң') + ' (қосымша)',
                    sectionId: cabinetSectionId || null,
                    width: overlayThk,
                    height: sideHeight,
                    depth: depthUsed
                };
                const g = solidWithEdges(geom, color, info);
                const x = side === 'left'
                    ? (bodyShiftX - bodyW / 2 - overlayThk / 2)
                    : (bodyShiftX + bodyW / 2 + overlayThk / 2);
                // Алдыңғы шеті фасад жазықтығымен бірдей болсын
                g.position.set(x, sideCenterY, facadeFrontZ - depthUsed / 2);
                g.userData.isFalshPanel = true;
                falshGroup.add(g);
            }
            if (falshLeftSideEnabled)  addSideOverlay('left', overlayThkL, getSideOverlayDepth('left'));
            if (falshRightSideEnabled) addSideOverlay('right', overlayThkR, getSideOverlayDepth('right'));
            if (falshTopSideEnabled && overlayThkT) {
                const depthUsed = clampOverlayDepth(getSideOverlayDepth('top'));
                const geom = new THREE.BoxGeometry(totalW, overlayThkT, depthUsed);
                const info = {
                    type: 'falsh',
                    name: 'Фальш панель төбе (қосымша)',
                    sectionId: cabinetSectionId || null,
                    width: totalW,
                    height: overlayThkT,
                    depth: depthUsed
                };
                const g = solidWithEdges(geom, color, info);
                // Алдыңғы шеті фасад жазықтығымен бірдей болсын
                g.position.set(0, (currentH || 0) - overlayThkT / 2, facadeFrontZ - depthUsed / 2);
                g.userData.isFalshPanel = true;
                falshGroup.add(g);
            }

            falshGroup.visible = !facadesHidden;
            cabinetGroup.add(falshGroup);
            rebuildStructureList();
        }

        function rebuildFalshList() {
            if (!falshListItems) return;
            falshListItems.innerHTML = '';

            const hasBase = Array.isArray(falshPanels) && falshPanels.length > 0;
            const hasOverlay = !!(falshLeftSideEnabled || falshRightSideEnabled || falshTopSideEnabled);
            if (!hasBase && !hasOverlay) {
                falshListItems.textContent = 'Фальш панель жоқ';
                syncFalshOverlayControls(false);
                return;
            }

            function addRow(opts) {
                const o = opts || {};
                const row = document.createElement('div');
                row.className = 'simple-list-item';
                const label = document.createElement('div');
                label.className = 'meta';
                label.textContent = o.text || '';
                row.appendChild(label);

                const actions = document.createElement('div');
                actions.style.display = 'flex';
                actions.style.alignItems = 'center';
                actions.style.gap = '6px';

                if (typeof o.onSizeChange === 'function') {
                    const sizeInput = document.createElement('input');
                    sizeInput.type = 'number';
                    sizeInput.min = String(Number.isFinite(o.min) ? o.min : 1);
                    if (Number.isFinite(o.max)) {
                        sizeInput.max = String(Math.round(o.max));
                    }
                    sizeInput.step = '1';
                    sizeInput.value = String(Math.round(Number.isFinite(o.size) ? o.size : 0));
                    sizeInput.style.width = '90px';
                    sizeInput.style.maxWidth = '90px';
                    sizeInput.style.flex = '0 0 90px';

                    const stop = (e) => e.stopPropagation();
                    sizeInput.addEventListener('mousedown', stop);
                    sizeInput.addEventListener('click', stop);
                    sizeInput.addEventListener('focus', stop);

                    sizeInput.addEventListener('change', () => {
                        o.onSizeChange(sizeInput.value);
                    });

                    const mm = document.createElement('span');
                    mm.textContent = 'мм';
                    mm.style.fontSize = '12px';
                    mm.style.color = '#555';

                    actions.appendChild(sizeInput);
                    actions.appendChild(mm);
                }

                if (typeof o.onDelete === 'function') {
                    const delBtn = document.createElement('button');
                    delBtn.type = 'button';
                    delBtn.className = 'danger-btn';
                    delBtn.innerHTML = '<i class="fa-solid fa-trash" aria-hidden="true"></i>';
                    delBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        o.onDelete();
                    });
                    actions.appendChild(delBtn);
                }

                if (actions.childNodes.length) {
                    row.appendChild(actions);
                }
                falshListItems.appendChild(row);
            }

            if (hasBase) {
                falshPanels.forEach(fp => {
                    const sideLabel = fp.side === 'left' ? 'Сол'
                        : fp.side === 'right' ? 'Оң'
                        : 'Төбесі';
                    addRow({
                        text: `${sideLabel} ·`,
                        size: parseFloat(fp.size) || 0,
                        min: 10,
                        onSizeChange: (raw) => {
                            const v = normalizePositiveNumber(raw, parseFloat(fp.size) || getFalshSizeForSide(fp.side));
                            runUndoable(() => {
                                falshPanels = falshPanels.map(p => (p.id === fp.id ? { ...p, size: v } : p));
                                rebuildWithCurrentSize(true);
                                rebuildFalshList();
                                syncActiveCabinetRecord();
                            });
                        },
                        onDelete: () => {
                            runUndoable(() => {
                                falshPanels = falshPanels.filter(x => x.id !== fp.id);
                                rebuildWithCurrentSize(true);
                                rebuildFalshList();
                                syncActiveCabinetRecord();
                            });
                        }
                    });
                });
            }

            if (falshLeftSideEnabled) {
                addRow({
                    text: 'Сол жақ фальш панель ·',
                    size: getSideOverlayDepth('left') || 0,
                    min: 10,
                    max: getFalshOverlayAutoDepth(),
                    onSizeChange: (raw) => {
                        const v = normalizePositiveNumber(raw, getSideOverlayDepth('left'));
                        runUndoable(() => {
                            setSideOverlayDepth('left', v);
                            rebuildWithCurrentSize(true);
                            rebuildFalshList();
                            syncActiveCabinetRecord();
                        });
                    },
                    onDelete: () => {
                        runUndoable(() => {
                            setSideOverlayEnabled('left', false);
                            rebuildWithCurrentSize(true);
                            rebuildFalshList();
                            syncActiveCabinetRecord();
                        });
                    }
                });
            }
            if (falshRightSideEnabled) {
                addRow({
                    text: 'Оң жақ фальш панель ·',
                    size: getSideOverlayDepth('right') || 0,
                    min: 10,
                    max: getFalshOverlayAutoDepth(),
                    onSizeChange: (raw) => {
                        const v = normalizePositiveNumber(raw, getSideOverlayDepth('right'));
                        runUndoable(() => {
                            setSideOverlayDepth('right', v);
                            rebuildWithCurrentSize(true);
                            rebuildFalshList();
                            syncActiveCabinetRecord();
                        });
                    },
                    onDelete: () => {
                        runUndoable(() => {
                            setSideOverlayEnabled('right', false);
                            rebuildWithCurrentSize(true);
                            rebuildFalshList();
                            syncActiveCabinetRecord();
                        });
                    }
                });
            }
            if (falshTopSideEnabled) {
                addRow({
                    text: 'Қосымша төбе фальш панель ·',
                    size: getSideOverlayDepth('top') || 0,
                    min: 10,
                    max: getFalshOverlayAutoDepth(),
                    onSizeChange: (raw) => {
                        const v = normalizePositiveNumber(raw, getSideOverlayDepth('top'));
                        runUndoable(() => {
                            setSideOverlayDepth('top', v);
                            rebuildWithCurrentSize(true);
                            rebuildFalshList();
                            syncActiveCabinetRecord();
                        });
                    },
                    onDelete: () => {
                        runUndoable(() => {
                            setSideOverlayEnabled('top', false);
                            rebuildWithCurrentSize(true);
                            rebuildFalshList();
                            syncActiveCabinetRecord();
                        });
                    }
                });
            }

            syncFalshOverlayControls(false);
        }

        function syncFacadesVisibilityAll() {
            const visible = !facadesHidden;
            if (doorsGroup) doorsGroup.visible = visible;
            setDoorsVisibilityOnGroup(cabinetGroup, visible);
            cabinets.forEach(c => {
                if (c.group && c.group !== cabinetGroup) {
                    setDoorsVisibilityOnGroup(c.group, visible);
                }
            });
            const toggleFalsh = (group) => {
                if (!group) return;
                group.traverse(obj => {
                    if (obj.userData && obj.userData.isFalshPanel) {
                        obj.visible = visible;
                    }
                });
            };
            toggleFalsh(cabinetGroup);
            cabinets.forEach(c => toggleFalsh(c.group));
            if (toggleFacadeBtn) toggleFacadeBtn.classList.toggle('active', visible);
        }

        function rebuildCabinetIcons() {
            if (!cabinetIconList) return;
            cabinetIconList.innerHTML = '';
            if (!cabinets.length) {
                cabinetIconList.style.display = 'none';
                structureVisible = false;
                syncStructureVisibility();
                return;
            }

            cabinetIconList.style.display = 'flex';
            cabinets.forEach((c, idx) => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'cabinet-icon-btn';
                btn.textContent = String(idx + 1);
                btn.title = `Шкаф ${c.id}`;
                if (c.id === activeCabinetId) btn.classList.add('active');
                btn.addEventListener('click', () => {
                    if (activeCabinetId === c.id) {
                        structureVisible = !structureVisible;
                        syncStructureVisibility();
                        return;
                    }
                    setActiveCabinet(c.id);
                    structureVisible = true;
                    rebuildStructureList();
                    syncStructureVisibility();
                    rebuildCabinetIcons();
                });
                cabinetIconList.appendChild(btn);
            });
            syncStructureVisibility();
            updateCabinetActionsVisibility();
        }

        const structureCategoryDefinitions = {
            facade:       { title: 'Фасад материалы', subtitle: 'Материал аты', order: 1 },
            drawerFacade: { title: 'Фасад материалы (ящик)', subtitle: 'Материал аты (ящик)', order: 2 },
            corpus:       { title: 'Корпус материалы', subtitle: 'Материал аты', order: 3 },
            plinth:       { title: 'Цоколь', subtitle: 'Материал аты', order: 4 },
            other:        { title: 'Бөлшектер', subtitle: 'Материал аты', order: 99 }
        };

        function resolveStructureMaterialCategory(part) {
            if (!part) return structureCategoryDefinitions.other;
            const type = (part.type || '').toLowerCase();
            if (type === 'drawer_facade') return structureCategoryDefinitions.drawerFacade;
            if (type === 'door' || type === 'falsh') return structureCategoryDefinitions.facade;
            if (type === 'plinth') return structureCategoryDefinitions.plinth;
            if (['side','top','bottom','divider','shelf','back','drawer','drawer_panel','drawer_panel_front'].includes(type)) {
                return structureCategoryDefinitions.corpus;
            }
            return structureCategoryDefinitions.other;
        }

        function rebuildStructureList() {
            if (!structureList) return;
            const allowedTypes = ['side','top','bottom','divider','shelf','back','plinth','door','drawer','drawer_facade','drawer_panel','drawer_panel_front','falsh'];
            const arr = Object.values(parts || {}).filter(p => {
                const mat = (p.extra && (p.extra.materialType || p.extra.material)) || '';
                if (mat === 'hdf' || mat === 'mdf' || mat === 'ldsp') return true;
                const t = (p.type || '').toLowerCase();
                return allowedTypes.includes(t);
            });
            arr.sort((a, b) => {
                const secA = a.sectionId || 0;
                const secB = b.sectionId || 0;
                if (secA !== secB) return secA - secB;
                const typeA = a.type || '';
                const typeB = b.type || '';
                if (typeA !== typeB) return typeA.localeCompare(typeB);
                return (a.id || 0) - (b.id || 0);
            });

            structureList.innerHTML = '';
            if (!arr.length) {
                const empty = document.createElement('div');
                empty.className = 'structure-empty';
                empty.textContent = 'Бөлшектер жоқ';
                structureList.appendChild(empty);
                structureEntryOrder = [];
                structureEntryIndexMap = new Map();
                return;
            }

            const defaultMaterialLabel = 'Материал белгісіз';
            const entries = arr.map((p, idx) => {
                const cab = cabinets.find(c => c.id === p.cabinetId);
                const cabNum = cab ? cabinets.indexOf(cab) + 1 : 0;
                const prefix = String(cabNum).padStart(2, '0');
                const partNum = String(idx + 1).padStart(2, '0');
                const displayId = prefix + '.' + partNum;
                const dims = getDisplayDimsThicknessLast(p).map(v => Math.round(v || 0));
                const materialLabelRaw = getMaterialLabelForPart(p);
                const materialSuffix = materialLabelRaw ? ' · ' + materialLabelRaw : '';
                const metaText = '№ ' + displayId + ' · ' + dims.join(' × ') + ' мм' + materialSuffix;
                return {
                    part: p,
                    nameText: p.name || ('Бөлшек ' + displayId),
                    metaText,
                    materialLabel: materialLabelRaw || defaultMaterialLabel
                };
            });

            const groups = new Map();
            entries.forEach(entry => {
                const materialLabel = entry.materialLabel;
                const category = resolveStructureMaterialCategory(entry.part);
                const groupKey = category.title + '|' + materialLabel;
                if (!groups.has(groupKey)) {
                    groups.set(groupKey, {
                        key: groupKey,
                        category,
                        label: materialLabel,
                        entries: []
                    });
                }
                groups.get(groupKey).entries.push(entry);
            });

            const sortedGroups = Array.from(groups.values()).sort((a, b) => {
                if (a.category.order !== b.category.order) {
                    return a.category.order - b.category.order;
                }
                if (a.label !== b.label) {
                    return a.label.localeCompare(b.label);
                }
                return 0;
            });
            const entrySequence = [];
            const createRow = (entry) => {
                const row = document.createElement('div');
                row.className = 'structure-row';
                row.dataset.id = String(entry.part.id);

                const name = document.createElement('div');
                name.className = 'structure-name';
                name.textContent = entry.nameText;

                const meta = document.createElement('div');
                meta.className = 'structure-meta';
                meta.textContent = entry.metaText;

                const edgeFlags = getEdgeVisualFlags(entry.part);
                const edgeSquare = document.createElement('span');
                edgeSquare.className = 'edge-square';
                [
                    { cls: 'edge-top', on: !!edgeFlags.top },
                    { cls: 'edge-bottom', on: !!edgeFlags.bottom },
                    { cls: 'edge-left', on: !!edgeFlags.left },
                    { cls: 'edge-right', on: !!edgeFlags.right },
                ].forEach(seg => {
                    const s = document.createElement('span');
                    s.className = 'edge-square-seg ' + seg.cls + (seg.on ? ' active' : '');
                    edgeSquare.appendChild(s);
                });
                meta.appendChild(edgeSquare);

                row.appendChild(name);
                row.appendChild(meta);

                row.addEventListener('click', (event) => {
                    handleStructureRowClick(event, entry);
                });

                return row;
            };

            sortedGroups.forEach(group => {
                if (!group.entries.length) return;
                const groupEl = document.createElement('div');
                groupEl.className = 'structure-material-group';

                const header = document.createElement('div');
                header.className = 'structure-material-title';
                header.textContent = group.category.title;

                const subtitle = document.createElement('div');
                subtitle.className = 'structure-material-subtitle';
                subtitle.textContent = `${group.category.subtitle}: ${group.label}`;

                groupEl.appendChild(header);
                groupEl.appendChild(subtitle);
                group.entries.forEach(entry => {
                    entrySequence.push(entry);
                    groupEl.appendChild(createRow(entry));
                });
                structureList.appendChild(groupEl);
            });

            structureEntryOrder = entrySequence.slice();
            structureEntryIndexMap = new Map();
            structureEntryOrder.forEach((entry, idx) => {
                structureEntryIndexMap.set(String(entry.part.id), idx);
            });

            syncStructureSelection();
        }

        function updateSelectionSetFromEvent(targetId, event) {
            if (!targetId) return;
            const hasShiftSelection =
                event && event.shiftKey &&
                multiSelectAnchorId &&
                structureEntryIndexMap.has(multiSelectAnchorId) &&
                structureEntryIndexMap.has(targetId);
            if (hasShiftSelection) {
                const anchorIdx = structureEntryIndexMap.get(multiSelectAnchorId);
                const targetIdx = structureEntryIndexMap.get(targetId);
                const startIdx = Math.min(anchorIdx, targetIdx);
                const endIdx = Math.max(anchorIdx, targetIdx);
                const rangeIds = structureEntryOrder.slice(startIdx, endIdx + 1).map(e => String(e.part.id));
                selectedPartIds = new Set(rangeIds);
            } else if (event && (event.ctrlKey || event.metaKey)) {
                const nextSet = new Set(selectedPartIds);
                if (nextSet.has(targetId)) {
                    nextSet.delete(targetId);
                } else {
                    nextSet.add(targetId);
                }
                if (!nextSet.size) {
                    nextSet.add(targetId);
                }
                selectedPartIds = nextSet;
            } else {
                selectedPartIds = new Set([targetId]);
            }
            multiSelectAnchorId = targetId;
        }

        function isPartHidden(part) {
            return !!(part && part.extra && part.extra.hidden);
        }

        function setPartHidden(partId, hidden, opts = {}) {
            const part = parts[partId];
            if (!part) return;
            part.extra = part.extra || {};
            part.extra.hidden = hidden;
            if (part.mesh) {
                part.mesh.visible = !hidden;
            }
            if (!opts.skipEdgeRefresh && edgeHighlightEnabled) {
                applyEdgeHighlightVisibility();
            }
            if (!opts.skipSelectionRefresh) {
                rebuildSelectionHighlightHelpers();
            }
        }

        function showAllHiddenParts() {
            let changed = false;
            Object.values(parts || {}).forEach(p => {
                if (p.extra && p.extra.hidden) {
                    setPartHidden(p.id, false, { skipEdgeRefresh: true, skipSelectionRefresh: true });
                    changed = true;
                }
            });
            if (changed) {
                applyEdgeHighlightVisibility();
                rebuildSelectionHighlightHelpers();
                rebuildStructureList();
                updatePartUI();
            }
        }

        function toggleHiddenForSelection() {
            if (!selectedPartIds.size) return;
            const allHidden = Array.from(selectedPartIds).every(id => isPartHidden(parts[id]));
            selectedPartIds.forEach(id => {
                setPartHidden(id, !allHidden, { skipEdgeRefresh: true, skipSelectionRefresh: true });
            });
            applyEdgeHighlightVisibility();
            rebuildSelectionHighlightHelpers();
            rebuildStructureList();
            updatePartUI();
        }

        function handleStructureRowClick(event, entry) {
            const targetId = String(entry.part.id);
            updateSelectionSetFromEvent(targetId, event);
            selectedPartId = entry.part.id;
            selectPart(entry.part.id, { skipSelectionSetUpdate: true });
            structureVisible = true;
            syncStructureVisibility();
            if (isPartHidden(entry.part)) {
                setPartHidden(entry.part.id, false, { skipEdgeRefresh: true, skipSelectionRefresh: true });
                applyEdgeHighlightVisibility();
                rebuildSelectionHighlightHelpers();
                rebuildStructureList();
                updatePartUI();
            }
        }

        function syncStructureSelection() {
            if (!structureList) return;
            const rows = structureList.querySelectorAll('.structure-row');
            rows.forEach(r => {
                const id = r.dataset.id;
                const isActive = id === String(selectedPartId);
                r.classList.toggle('active', isActive);
                r.classList.toggle('multi-selected', selectedPartIds.has(id));
                const part = parts[id];
                r.classList.toggle('structure-row--hidden', isPartHidden(part));
            });
        }

        function applyMaterialNameToSelectedParts(name) {
            if (!name || !selectedPartIds.size) return;
            const value = name.trim();
            if (!value) return;
            selectedPartIds.forEach(id => {
                const part = parts[id];
                if (!part) return;
                part.materialName = value;
                part.material = value;
                part.extra = part.extra || {};
                part.extra.materialName = value;
            });
            rebuildStructureList();
            updatePartUI();
            rebuildSelectionHighlightHelpers();
        }

        function openMaterialNamePopup(value) {
            if (!materialNamePopup || !materialNamePopupInput) return;
            const initial = value || '';
            materialNamePopupInput.value = initial;
            materialNamePopup.classList.add('visible');
            setTimeout(() => {
                materialNamePopupInput.focus();
                materialNamePopupInput.select();
            }, 0);
        }

        function closeMaterialNamePopup() {
            if (!materialNamePopup) return;
            materialNamePopup.classList.remove('visible');
        }

        if (materialNamePopupBackdrop) {
            materialNamePopupBackdrop.addEventListener('click', closeMaterialNamePopup);
        }
        if (materialNamePopupClose) {
            materialNamePopupClose.addEventListener('click', closeMaterialNamePopup);
        }
        if (materialNamePopupApply && materialNamePopupInput) {
            materialNamePopupApply.addEventListener('click', () => {
                applyMaterialNameToSelectedParts(materialNamePopupInput.value);
                closeMaterialNamePopup();
            });
            materialNamePopupInput.addEventListener('keydown', (event) => {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    materialNamePopupApply.click();
                } else if (event.key === 'Escape') {
                    event.preventDefault();
                    closeMaterialNamePopup();
                }
            });
        }
        document.addEventListener('keydown', (event) => {
            const active = document.activeElement;
            if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA')) return;
            const key = (event.key || '').toLowerCase();
            if (key === 'h' || key === 'р') {
                if (event.shiftKey) {
                    showAllHiddenParts();
                } else {
                    toggleHiddenForSelection();
                }
                event.preventDefault();
                return;
            }
            if (key === 'm' || key === 'ь') {
                if (!selectedPartIds.size) return;
                const firstId = Array.from(selectedPartIds)[0];
                const part = parts[firstId];
                const current = part ? getMaterialLabelForPart(part) : '';
                openMaterialNamePopup(current);
                event.preventDefault();
            }
        });

        function getBaseEdgeColor() {
            return (currentViewMode === 'shadow') ? 0x222222 : 0x000000;
        }

        function updateSectionEdgeHighlight() {
            const baseColor = getBaseEdgeColor();
            const activeId = activeCabinetId;
            allEdges.forEach(edge => {
                const pid = edge.__parentMesh && edge.__parentMesh.userData && edge.__parentMesh.userData.partId;
                const partCabinetId = pid && parts[pid] ? parts[pid].cabinetId : activeCabinetId;
                const isActiveCabinet = (partCabinetId === activeId);
                const color = isActiveCabinet ? baseColor : 0x999999;
                edge.material.color.set(color);
            });
        }

        function updateSectionFaceHighlight() {
            const activeId = activeCabinetId;
            const isSelectedPartMode = (selectionMode === 'part');
            const highlightColor = 0x6bb8ff;
            allMeshes.forEach(mesh => {
                const mat = mesh.material;
                if (!mat) return;
                const pid = mesh.userData && mesh.userData.partId;
                const partCabinetId = pid && parts[pid] ? parts[pid].cabinetId : activeCabinetId;
                const isActiveCabinet = (partCabinetId === activeId);
                const base = mesh.userData.baseColor || 0xffffff;
                const dimColor = 0xd0d0d0;
                const isSelectedPart = isSelectedPartMode && pid && selectedPartIds.has(String(pid));
                const targetColor = isSelectedPart
                    ? highlightColor
                    : (isActiveCabinet ? base : dimColor);
                if (mat.color) {
                    mat.color.setHex(targetColor);
                }
                if (mat.emissive) {
                    const emissiveHex = isSelectedPart ? 0x4fa3ff : 0x000000;
                    mat.emissive.setHex(emissiveHex);
                    if ('emissiveIntensity' in mat) {
                        mat.emissiveIntensity = isSelectedPart ? 0.8 : 0;
                    }
                }
            });
        }

        function disposeMat(m) {
            if (!m) return;
            if (Array.isArray(m)) {
                m.forEach(x => disposeMat(x));
                return;
            }
            if (m.dispose) m.dispose();
        }

        function resetSectionHighlightBlink() {
            sectionHighlightStart = performance.now ? performance.now() : Date.now();
        }

        function resetWallSectionHighlightBlink() {
            wallSectionHighlightStart = performance.now ? performance.now() : Date.now();
        }

        function animateSectionHighlight(now) {
            if (!selectedSectionHelper) return;
            const mat = selectedSectionHelper.material;
            if (!mat || typeof mat.opacity !== 'number') return;

            // Жыпылықтауды алып тастадық: тұрақты мөлдірлік пен түс
            const opacity = 0.35;
            mat.opacity = opacity;
            if (mat.color) {
                mat.color.copy(sectionHighlightBaseColor);
            }
            mat.needsUpdate = true;
        }

        function animateWallHighlight(now) {
            if (!selectedWallHighlightHelper) return;
            const mat = selectedWallHighlightHelper.material;
            if (!mat || typeof mat.opacity !== 'number') return;

            const cycle = (Math.sin(now / 400) + 1) / 2;
            mat.opacity = 0.25 + 0.15 * cycle;
            if (mat.color) {
                wallSectionHighlightTempColor.copy(wallSectionHighlightBaseColor);
                wallSectionHighlightTempColor.lerp(wallSectionHighlightBrightColor, cycle);
                mat.color.copy(wallSectionHighlightTempColor);
            }
            mat.needsUpdate = true;
        }

        // Секция визуалды подсветка
        function updateSelectedSectionHelper() {
            if (!cabinetGroup) return;
            if (selectedSectionHelper) {
                if (bodyCore) bodyCore.remove(selectedSectionHelper);
                else cabinetGroup.remove(selectedSectionHelper);
                selectedSectionHelper.geometry.dispose();
                disposeMat(selectedSectionHelper.material);
                selectedSectionHelper = null;
            }
            if (selectedShelfSubHelper) {
                if (bodyCore) bodyCore.remove(selectedShelfSubHelper);
                else cabinetGroup.remove(selectedShelfSubHelper);
                selectedShelfSubHelper.geometry.dispose();
                disposeMat(selectedShelfSubHelper.material);
                selectedShelfSubHelper = null;
            }
            const sec = sections.find(s => s.id === selectedSectionId);
            if (!sec) {
                selectedShelfSubId = null;
                updateDimensionsBox();
                if (sectionWidthInput) sectionWidthInput.value = '';
                updateSectionEdgeHighlight();
                updateSectionFaceHighlight();
                return;
            }
            const hideHelpers = !!doorAnimEnabled || selectionMode === 'part';
            if (selectedShelfSubId) {
                const [secIdStr] = String(selectedShelfSubId).split(':');
                if (parseFloat(secIdStr) !== sec.id) {
                    selectedShelfSubId = null;
                }
            }

            const innerParams = computeInnerParams();
            const depthInside = innerParams.depthInside;

            const geo = new THREE.BoxGeometry(sec.w, sec.h, depthInside);
            const mat = new THREE.MeshBasicMaterial({
                color: sectionHighlightBaseColor.getHex(),
                opacity: 0.25,
                transparent: true,
                depthWrite: false,
                depthTest: true
            });
            if (!hideHelpers) {
                selectedSectionHelper = new THREE.Mesh(geo, mat);
                resetSectionHighlightBlink();

                const xWorld = sec.x + sec.w/2 - innerW/2;
                const yWorld = plinthHeight + globalThickness + sec.y + sec.h/2;
                selectedSectionHelper.position.set(xWorld, yWorld, innerParams.centerZ);

                (bodyCore || cabinetGroup).add(selectedSectionHelper);
            }
            if (sectionWidthInput) {
                sectionWidthInput.value = Math.round(sec.w);
            }
            updateDimensionsBox();
            updateSectionEdgeHighlight();
            updateSectionFaceHighlight();
            updateSelectedShelfSubHelper();
            rebuildInsertsUI();
            rebuildDrawerSubList();
        }

        function updateSelectedShelfSubHelper() {
            if (selectedShelfSubHelper && cabinetGroup) {
                if (bodyCore) bodyCore.remove(selectedShelfSubHelper);
                else cabinetGroup.remove(selectedShelfSubHelper);
                selectedShelfSubHelper.geometry.dispose();
                disposeMat(selectedShelfSubHelper.material);
                selectedShelfSubHelper = null;
            }
            if (!cabinetGroup) return;
            if (!selectedShelfSubId) return;

            const parts = String(selectedShelfSubId).split(':');
            const secId = parseFloat(parts[0]);
            const subIdx = parseInt(parts[1], 10);
            if (!isFinite(secId) || !isFinite(subIdx)) {
                selectedShelfSubId = null;
                return;
            }
            const sec = sections.find(s => s.id === secId);
            if (!sec) {
                selectedShelfSubId = null;
                return;
            }
            const sub = getShelfSubSections().find(s => s.sectionId === secId && s.idx === subIdx);
            if (!sub) {
                selectedShelfSubId = null;
                rebuildInsertsUI();
                return;
            }
            syncDrawerDepthSelect(sub);
            syncDrawerDepthSelect(sub);

            const innerParams = computeInnerParams();
            const depthInside = innerParams.depthInside;
            const frontOffset = sectionShelfOffsets[sec.id] || 0;
            const depth = Math.max(10, depthInside - frontOffset);
            const backInsideZ = innerParams.centerZ - depthInside / 2;
            const zWorld = backInsideZ + depth / 2;

            const region = getSectionShelfRegion(sec.id);
            const effectiveWidth = region ? region.width : sub.width;
            const xCenter = region ? region.center : (sec.x + sub.width / 2 - innerW / 2);

            const geo = new THREE.BoxGeometry(effectiveWidth, sub.height, depth);
            const mat = new THREE.MeshBasicMaterial({
                color: subHighlightBaseColor.getHex(),
                opacity: 0.32,
                transparent: true,
                depthWrite: false,
                depthTest: false
            });
            if (!doorAnimEnabled) {
                selectedShelfSubHelper = new THREE.Mesh(geo, mat);

                const xWorld = xCenter;
                const yWorld = plinthHeight + globalThickness + sec.y + sub.start + sub.height / 2;
                selectedShelfSubHelper.position.set(xWorld, yWorld, zWorld);

                (bodyCore || cabinetGroup).add(selectedShelfSubHelper);
            }
            rebuildInsertsUI();
            rebuildDrawerSubList();
            syncShelfSubHelperVisibility();
        }

        function syncShelfSubHelperVisibility() {
            if (selectedShelfSubHelper) {
                const allowByMode = (currentViewMode === 'xray' || currentViewMode === 'sketch');
                const allowBySelection = selectionMode !== 'part';
                selectedShelfSubHelper.visible = allowByMode && allowBySelection;
            }
        }

        // Секциялар тізімі (ID + ені + корзина)
        function rebuildSectionSelect() {
            if (!sectionSelect) return;

            const sorted = sections.slice().sort((a, b) => a.x - b.x);

            // Таңдалған секция коррект болсын
            if (sorted.length) {
                if (!selectedSectionId || !sorted.some(s => s.id === selectedSectionId)) {
                    selectedSectionId = sorted[0].id;
                }
            } else {
                selectedSectionId = null;
            }

            // Контейнерді тазалау
            sectionSelect.innerHTML = '';

            sorted.forEach(sec => {
                const row = document.createElement('div');
                row.className = 'section-row';
                row.dataset.id = String(sec.id);
                if (sec.id === selectedSectionId) {
                    row.classList.add('active');
                }

                const main = document.createElement('div');
                main.className = 'section-row-main';

                const idSpan = document.createElement('span');
                idSpan.className = 'section-row-id';
                idSpan.textContent = 'Секция ' + sec.id;

                const wSpan = document.createElement('span');
                wSpan.className = 'section-row-width';
                wSpan.textContent = Math.round(sec.w) + ' мм';

                main.appendChild(idSpan);
                main.appendChild(wSpan);

                const delBtn = document.createElement('button');
                delBtn.type = 'button';
                delBtn.className = 'section-row-delete';
                delBtn.title = 'Секцияны өшіру';
                delBtn.innerHTML = '<i class="fa-solid fa-trash" aria-hidden="true"></i>';

                // Корзина – секцияны өшіру
                const canDelete = (sorted.length > 1);
                if (!canDelete) {
                    delBtn.disabled = true;
                    delBtn.classList.add('disabled');
                }
                delBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    if (!canDelete) return;
                    deleteSection(sec.id);
                });

                // Қатарды басқанда – секцияны таңдау
                row.addEventListener('click', function () {
                    selectedSectionId = sec.id;
                    updateSelectedSectionHelper();
                    rebuildSectionSelect();
                    rebuildShelvesUI();
                });

                row.appendChild(main);
                row.appendChild(delBtn);
                sectionSelect.appendChild(row);
            });

            // Қосымша инфо үшін (бар болса)
            const currentSectionInfo = document.getElementById('currentSectionInfo');
            const widthInputEl = document.getElementById('sectionWidthInput');

            let sel = null;
            if (sorted.length) {
                sel = sorted.find(s => s.id === selectedSectionId) || sorted[0];
            }

            if (currentSectionInfo) {
                if (sel) {
                    currentSectionInfo.value =
                        'ID ' + sel.id + ' · ' + Math.round(sel.w) + ' мм';
                } else {
                    currentSectionInfo.value = '';
                }
            }

            if (shelfOffsetInput) {
                if (sel && sectionShelfOffsets[sel.id] !== undefined) {
                    shelfOffsetInput.value = sectionShelfOffsets[sel.id];
                } else if (sel) {
                    shelfOffsetInput.value = 0;
                }
            }

            if (widthInputEl) {
                widthInputEl.value = sel ? Math.round(sel.w) : '';
            }

            updateDimensionsBox();
        }

        function updateDimensionsBox() {
            if (!dimensionBox) return;
            const hotkeys = [
                { key: 'M', desc: 'Материалды өзгерту' },
                { key: 'H', desc: 'Бөлшекті жасыр/көрсет' },
                { key: 'Shift + H', desc: 'Барлық жасырын бөлшектерді көрсету' },
                { key: 'Ctrl/Cmd + Click', desc: 'Көп таңдауда бөліктерді қосу/алып тастау' }
            ];
            const html = '<div class="hotkey-list">' +
                '<div class="hotkey-list__title">Ақпаратты көрсету – ыстық пернелер:</div>' +
                hotkeys.map(item => `<div><strong>${item.key}</strong> · ${item.desc}</div>`).join('') +
                '</div>';
            dimensionBox.innerHTML = html;
            syncInfoVisibility();
        }

        // Полка тізімін тазалау (валид диапазон, дубльсіз)
        function sanitizeSectionShelves() {
            const tol = 0.001;
            const secMap = new Set(sections.map(s => s.id));
            Object.keys(sectionShelves).forEach(k => {
                if (!secMap.has(parseFloat(k))) delete sectionShelves[k];
            });
            sections.forEach(sec => {
                let arr = (sectionShelves[sec.id] || []).filter(h => isFinite(h));
                const filtered = [];
                arr.forEach(h => {
                    if (h <= 0 || h >= sec.h - 20) return;
                    if (filtered.some(v => Math.abs(v - h) < tol)) return;
                    filtered.push(h);
                });
                filtered.sort((a, b) => a - b);
                sectionShelves[sec.id] = filtered;
            });
        }

        // Полка аралық ішкі секциялар (виртуалды) – Секция 1.1, 1.2 ...
        function getShelfSubSections() {
            const res = [];
            const shelfThickLocal = globalThickness;
            const secSorted = sections.slice().sort((a, b) => a.x - b.x);

            secSorted.forEach(sec => {
                const list = (sectionShelves[sec.id] || []).slice().sort((a, b) => a - b);
                const hasShelves = list.length > 0;
                const augmented = hasShelves ? [0, ...list, sec.h] : [0, sec.h];

                let idx = 1;
                for (let i = 0; i < augmented.length - 1; i++) {
                    const isBottom = (i === 0);
                    const h1 = augmented[i];
                    const h2 = augmented[i + 1];

                    const start = isBottom ? h1 : h1 + shelfThickLocal;
                    const gap = h2 - start;
                    if (gap <= 0) continue;
                    const end = start + gap;

                    res.push({
                        sectionId: sec.id,
                        name: 'Секция ' + sec.id + '.' + idx,
                        idx,
                        start,
                        end,
                        height: gap,
                        width: sec.w
                    });
                    idx++;
                }
            });
            return res;
        }

        // Секциядағы полка нақты ені (сол/оң маржаларымен) және центрі
        function getSectionShelfRegion(sectionId) {
            const secSorted = sections.slice().sort((a, b) => a.x - b.x);
            const idx = secSorted.findIndex(s => s.id === sectionId);
            if (idx === -1) return null;

            const facadeTypeEl  = document.getElementById('facadeType');
            const facadeTypeVal = facadeTypeEl ? facadeTypeEl.value : 'vkladnoy';
            const useFacadeCenters =
                facadeTypeVal === 'nakladnoy' &&
                Array.isArray(facadeDividerCenters) &&
                facadeDividerCenters.length >= Math.max(0, secSorted.length - 1);

            const dividerWorld = [];
            for (let i = 1; i < secSorted.length; i++) {
                const boundaryX = secSorted[i].x;
                const xWorld = useFacadeCenters
                    ? facadeDividerCenters[i - 1]
                    : boundaryX - innerW / 2;
                dividerWorld.push(xWorld);
            }

            const tol = 0.0001;
            const clearance = 0.2;

            const sec = secSorted[idx];
            const leftBoundWorld  = (idx === 0) ? (-innerW / 2) : dividerWorld[idx - 1];
            const rightBoundWorld = (idx === secSorted.length - 1) ? (innerW / 2) : dividerWorld[idx];
            const atLeftWall  = Math.abs(leftBoundWorld + innerW / 2) < tol;
            const atRightWall = Math.abs(rightBoundWorld - innerW / 2) < tol;
            const leftMargin  = atLeftWall  ? 0 : (globalThickness / 2 + clearance);
            const rightMargin = atRightWall ? 0 : (globalThickness / 2 + clearance);
            const width = Math.max(10, (rightBoundWorld - rightMargin) - (leftBoundWorld + leftMargin));
            const center = leftBoundWorld + leftMargin + width / 2;
            return { width, center, left: leftBoundWorld + leftMargin, right: rightBoundWorld - rightMargin };
        }

        function sanitizeShelfInserts(subs) {
            const valid = new Set(subs.map(s => `${s.sectionId}:${s.idx}`));
            Object.keys(shelfInserts).forEach(k => {
                if (!valid.has(k)) delete shelfInserts[k];
            });
            Object.keys(shelfInserts).forEach(k => {
                let arr = shelfInserts[k];
                if (!Array.isArray(arr)) arr = arr ? [arr] : [];
                arr = arr
                    .filter(it => it && it.type)
                    .map(it => {
                        if (it.type === 'drawer' && !it.variant) return { ...it, variant: 'telescope' };
                        return it;
                    });
                shelfInserts[k] = arr;
            });
        }

        function cloneShelfInserts(src) {
            const out = {};
            if (!src) return out;
            Object.keys(src).forEach(key => {
                const arr = Array.isArray(src[key]) ? src[key] : (src[key] ? [src[key]] : []);
                out[key] = arr.map(item => item ? { ...item } : item);
            });
            return out;
        }

        function rebuildDrawerSubList() {
            if (!drawerSubList) return;
            drawerSubList.innerHTML = '';

            const subsAll = getShelfSubSections();
            sanitizeShelfInserts(subsAll);
            const filtered = selectedSectionId
                ? subsAll.filter(s => s.sectionId === selectedSectionId)
                : subsAll;

            if (!filtered.length) {
                drawerSubList.textContent = 'Полка аралығы жоқ';
                return;
            }

            if (!selectedShelfSubId || !filtered.some(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId)) {
                selectedShelfSubId = `${filtered[0].sectionId}:${filtered[0].idx}`;
            }

            filtered.forEach(sub => {
                const key = `${sub.sectionId}:${sub.idx}`;
                const row = document.createElement('div');
                row.className = 'simple-list-item shelf-sub-row';
                row.dataset.subId = key;
                if (selectedShelfSubId === key) {
                    row.classList.add('active');
                }

                const name = document.createElement('div');
                name.className = 'meta';
                const labelShort = sub.sectionId + '.' + sub.idx;
                name.textContent = labelShort;
                name.style.display = 'inline-flex';
                name.style.gap = '8px';
                name.style.alignItems = 'center';
                name.style.flex = '1';

                row.appendChild(name);

                row.addEventListener('click', () => {
                    selectedShelfSubId = key;
                    const active = drawerSubList.querySelectorAll('.shelf-sub-row.active');
                    active.forEach(r => r.classList.remove('active'));
                    row.classList.add('active');
                    rebuildShelvesUI();
                    updateSelectedShelfSubHelper();
                });

                drawerSubList.appendChild(row);
            });
            if (selectedShelfSubId) {
                const sub = filtered.find(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId);
                syncDrawerDepthSelect(sub || filtered[0]);
            }
            syncDrawerActiveRow();
        }

        // Полкалар UI
        function rebuildShelvesUI() {
            const listEl = shelfList;
            if (!listEl) return;

            listEl.innerHTML = '';
            if (!selectedSectionId) return;

            const sec = sections.find(s => s.id === selectedSectionId);
            if (!sec) return;

            sanitizeSectionShelves();
            const subsAll = getShelfSubSections();
            sanitizeShelfInserts(subsAll);
            const subsForSelected = subsAll.filter(s => s.sectionId === selectedSectionId);
            if (subsForSelected.length) {
                const firstKey = `${subsForSelected[0].sectionId}:${subsForSelected[0].idx}`;
                if (!selectedShelfSubId || !subsForSelected.some(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId)) {
                    selectedShelfSubId = firstKey;
                }
            } else {
                selectedShelfSubId = null;
            }

            const shelfThickLocal = globalThickness;

            const list = sectionShelves[selectedSectionId] || [];
            const sorted = list.slice().sort((a, b) => a - b);

            sorted.forEach((h, index) => {
                const row   = document.createElement('div');
                row.className = 'shelf-row';

                const label = document.createElement('span');
                label.className = 'shelf-label';
                label.textContent = 'Полка' + (index + 1);

                const input = document.createElement('input');
                input.type  = 'number';
                input.min   = '0';
                input.step  = '1';

                // Көрсетілетін мән – төмендегі полкадан (немесе еденнен) ара қашықтық
                let gapValue;
                if (index === 0) {
                    gapValue = h;
                } else {
                    gapValue = h - sorted[index - 1] - shelfThickLocal; // полка қалыңдығын шегереміз
                }
                if (!isFinite(gapValue) || gapValue < 0) gapValue = 0;
                input.value = Math.round(gapValue);

                input.className = 'shelf-height-input';

                const btnUpdate = document.createElement('button');
                btnUpdate.type = 'button';
                btnUpdate.textContent = 'өзгерту';

                const btnDelete = document.createElement('button');
                btnDelete.type = 'button';
                btnDelete.innerHTML = '<i class="fa-solid fa-trash" aria-hidden="true"></i>';
                btnDelete.className = 'danger-btn';

                row.appendChild(label);
                row.appendChild(input);
                row.appendChild(btnUpdate);
                row.appendChild(btnDelete);

                listEl.appendChild(row);

                const oldH = h;
                const shelfIndex = index;

                btnUpdate.addEventListener('click', function () {
                    const gap = parseFloat(input.value);
                    if (!isFinite(gap)) return;

                    if (gap <= 0) {
                        showError('Полка ара қашықтығы 0-ден үлкен болуы керек');
                        return;
                    }

                    let newAbs;
                    if (shelfIndex === 0) {
                        newAbs = gap;
                    } else {
                        newAbs = sorted[shelfIndex - 1] + shelfThickLocal + gap; // төменгі полка қалыңдығын қосамыз
                    }

                    if (newAbs <= 0 || newAbs >= sec.h - 20) {
                        showError('Полка биіктігі секция биіктігіне сай емес');
                        return;
                    }

                    const arr = sectionShelves[sec.id] || [];
                    const idx = arr.findIndex(v => Math.abs(v - oldH) < 0.0001);
                    if (idx === -1) return;

                    arr[idx] = newAbs;
                    arr.sort((a, b) => a - b);
                    sectionShelves[sec.id] = arr;
                    syncShelves();
                });

                btnDelete.addEventListener('click', function () {
                    const arr = sectionShelves[sec.id] || [];
                    const idx = arr.findIndex(v => Math.abs(v - oldH) < 0.0001);
                    if (idx === -1) return;

                    arr.splice(idx, 1);
                    sectionShelves[sec.id] = arr;
                    syncShelves();
                });
            });

            rebuildDrawerSubList();
        }

        // Полкаларды қайта салу
        function rebuildShelvesGroup() {
            if (!cabinetGroup) return;

            // Remove previous shelf parts references
            purgePartsByType(transientPartTypes);

            if (shelvesGroup) {
                if (bodyCore) bodyCore.remove(shelvesGroup);
                else cabinetGroup.remove(shelvesGroup);
                shelvesGroup.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
            }
            if (insertsGroup) {
                if (bodyCore) bodyCore.remove(insertsGroup);
                else cabinetGroup.remove(insertsGroup);
                insertsGroup.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
            }
            shelvesGroup = new THREE.Group();
            insertsGroup = new THREE.Group();

            sanitizeSectionShelves();
            shelfNameCounter = 1;

            const innerParams = computeInnerParams();
            const depthInside = innerParams.depthInside;
            const shelfThick  = globalThickness;
            const corpusMatVal  = corpusMaterial.value;
            const shelfColor    = getCorpusColor(corpusMatVal);

            const secSorted = sections.slice().sort((a,b)=>a.x - b.x);

            // Divider позициясы (шын мәнінде), фасад накладной болса facadeDividerCenters қолданамыз
            const facadeTypeEl  = document.getElementById('facadeType');
            const facadeTypeVal = facadeTypeEl ? facadeTypeEl.value : 'vkladnoy';
            const useFacadeCenters =
                facadeTypeVal === 'nakladnoy' &&
                Array.isArray(facadeDividerCenters) &&
                facadeDividerCenters.length >= Math.max(0, secSorted.length - 1);

            const dividerWorld = [];
            for (let i = 1; i < secSorted.length; i++) {
                const boundaryX = secSorted[i].x;
                const xWorld = useFacadeCenters
                    ? facadeDividerCenters[i - 1]
                    : boundaryX - innerW / 2;
                dividerWorld.push(xWorld);
            }

            secSorted.forEach((sec, idx) => {
                const list = sectionShelves[sec.id];
                if (!list || !list.length) return;

                const sorted = list.slice().sort((a,b) => a - b);
                sorted.forEach(h => {
                    if (h <= 0 || h >= sec.h - 20) return;

                    // dividerWorld координаттары cabinetGroup ішінде жергілікті жүйеде,
                    // сондықтан қабырғаларға қатысты -innerW/2 .. +innerW/2 диапазонын қолданамыз.
                    const leftBoundWorld  = (idx === 0) ? (-innerW / 2) : dividerWorld[idx - 1];
                    const rightBoundWorld = (idx === secSorted.length - 1) ? (innerW / 2) : dividerWorld[idx];
                    const tol = 0.0001;
                    const atLeftWall  = Math.abs(leftBoundWorld + innerW / 2) < tol;
                    const atRightWall = Math.abs(rightBoundWorld - innerW / 2) < tol;
                    const clearance = 0.2;
                    const leftMargin  = atLeftWall  ? 0 : (globalThickness / 2 + clearance);
                    const rightMargin = atRightWall ? 0 : (globalThickness / 2 + clearance);
                    const shelfW = Math.max(10, (rightBoundWorld - rightMargin) - (leftBoundWorld + leftMargin));

                    // Алдынан отступты ескеріп, полка тереңдігін қысқартамыз
                    let frontOffset = sectionShelfOffsets[sec.id] || 0;
                    if (frontOffset < 0) frontOffset = 0;
                    let shelfDepth = Math.max(10, depthInside - frontOffset);

                    const geo   = new THREE.BoxGeometry(shelfW, shelfThick, shelfDepth);
                    const shelf = solidWithEdges(geo, shelfColor, {
                        type: 'shelf',
                        name: 'Полка ' + (shelfNameCounter++),
                        sectionId: sec.id,
                        width: shelfW,
                        height: shelfThick,
                        depth: depthInside,
                        shelfHeight: h,
                        edge: { front: true, back: false, left: false, right: false }
                    });

                    const xWorld = leftBoundWorld + leftMargin + shelfW / 2;
                    const yWorld = plinthHeight + globalThickness + h + shelfThick/2;

                    // Тек алдынан ғана кішірейту: артқы жағы бір орында қалады
                    const backInsideZ = innerParams.centerZ - depthInside / 2;
                    const zWorld      = backInsideZ + shelfDepth / 2;

                    shelf.position.set(xWorld, yWorld, zWorld);
                    shelvesGroup.add(shelf);
                });
            });

            (bodyCore || cabinetGroup).add(shelvesGroup);
            rebuildInsertsGroup();
        }

        function rebuildInsertsGroup() {
            if (!cabinetGroup) return;
            // Барлық наполнение бөлшектерін тазартып, қайта құрамыз
            purgePartsByType(['pipe','flange','drawer','drawer_facade','runner']);
        if (insertsGroup) {
            if (bodyCore) bodyCore.remove(insertsGroup);
            else cabinetGroup.remove(insertsGroup);
            insertsGroup.traverse(obj => {
                if (obj.geometry) obj.geometry.dispose();
                if (obj.material) obj.material.dispose();
            });
        }
            insertsGroup = new THREE.Group();

            const subs = getShelfSubSections();
            sanitizeShelfInserts(subs);
            const innerParams = computeInnerParams();
            const depthInside = innerParams.depthInside;
            const frontOffsetGlobal = sectionShelfOffsets;
            const drawerFrontOffsetGlobal = readDrawerFrontOffset();
            const drawerDepthBrandOffset = getDrawerDepthBrandOffset();
            if (subs.length && (!selectedShelfSubId || !subs.some(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId))) {
                selectedShelfSubId = `${subs[0].sectionId}:${subs[0].idx}`;
            }

            subs.forEach(sub => {
                const key = `${sub.sectionId}:${sub.idx}`;
                const list = Array.isArray(shelfInserts[key]) ? shelfInserts[key] : [];
                if (!list.length) return;

                const sec = sections.find(s => s.id === sub.sectionId);
                if (!sec) return;
                syncDrawerDepthSelect(sub);
                let pipeCounter = 0;
                let drawerCounter = 0;
                const region = getSectionShelfRegion(sub.sectionId);
                const runnerType = drawerRunnerTypeSelect ? drawerRunnerTypeSelect.value : 'softclose';

                const frontOffset = frontOffsetGlobal[sec.id] || 0;
                const depth = Math.max(10, depthInside - frontOffset);
                const backInsideZ = innerParams.centerZ - depthInside / 2;
                const zWorld = backInsideZ + depth / 2;
                const baseWidth = region ? region.width : sub.width;
                const baseCenter = region ? region.center : (sec.x + sub.width / 2 - innerW / 2);
                const sideGaps = readInsertSideGaps();
                let leftGap = Math.max(0, sideGaps.left);
                let rightGap = Math.max(0, sideGaps.right);
                const maxTotalGap = Math.max(0, baseWidth - 10);
                const totalGap = leftGap + rightGap;
                if (totalGap > maxTotalGap) {
                    let overflow = totalGap - maxTotalGap;
                    if (rightGap >= overflow) {
                        rightGap -= overflow;
                    } else {
                        overflow -= rightGap;
                        rightGap = 0;
                        leftGap = Math.max(0, leftGap - overflow);
                    }
                }
                const drawerUsableWidth = Math.max(10, baseWidth - leftGap - rightGap);
                const pipeUsableWidth = Math.max(10, baseWidth);
                const drawerXCenter = baseCenter + (leftGap - rightGap) / 2;
                const pipeXCenter = baseCenter;
                const gapTopWorld = plinthHeight + globalThickness + sec.y + sub.start + sub.height;
                const gapCenterY  = plinthHeight + globalThickness + sec.y + sub.start + sub.height / 2;
                const gapBottomWorld = plinthHeight + globalThickness + sec.y + sub.start;
                const drawersInSub = list.filter(it => it.type === 'drawer').length;
                const drawerSpacing = readDrawerStackGap();
                const padBody = Math.max(0, readDrawerRunnerThk()); // корпусқа арналған маржа (направляющий қалыңдығы)
                const desiredDrawerH = readDrawerBodyHeight();
                const targetGap = readDrawerFacadeGap(); // фасадтар және үсті/асты саңылау
                const gapTarget = Math.max(targetGap, drawerSpacing);
                const minFacH = 20;
                const panelColor = getCorpusColor(corpusMaterial.value);
                // Вертикаль слот параметрлері: gapY (жоғары/төмен және аралық), facSlotH (фасад биіктігі)
                let gapY = gapTarget;
                let facSlotH;
                if (drawersInSub > 0) {
                    const maxGapAllowed = Math.max(0, (sub.height - minFacH * drawersInSub) / (drawersInSub + 1));
                    gapY = Math.min(gapY, maxGapAllowed);
                    facSlotH = (sub.height - gapY * (drawersInSub + 1)) / drawersInSub;
                    if (facSlotH < minFacH) {
                        gapY = Math.max(gapTarget, Math.max(0, (sub.height - minFacH * drawersInSub) / (drawersInSub + 1)));
                        facSlotH = (sub.height - gapY * (drawersInSub + 1)) / drawersInSub;
                    }
                    facSlotH = Math.max(minFacH, facSlotH);
                } else {
                    gapY = Math.min(gapY, Math.max(0, (sub.height - minFacH) / 2));
                    facSlotH = Math.max(minFacH, sub.height - 2 * gapY);
                }
                const stepY = facSlotH + gapY;
                // Үсті/асты қосымша маржа жоқ, gapY-ды тікелей қолданамыз
                const topMargin = 0;

                const bodyHeight = Math.max(30, Math.min(desiredDrawerH, facSlotH - 2 * padBody));
                if (drawersInSub > 0) {
                    const panelCenterY = gapBottomWorld + sub.height / 2;
                    const baseLeft = baseCenter - baseWidth / 2;
                    const baseRight = baseCenter + baseWidth / 2;
                    const ldspThickness = 16;
                    const gapDepth = depth;
                    const frontLenLeft = Math.max(1, leftGap);
                    const frontLenRight = Math.max(1, rightGap);
                    const frontPanelDepth = 16;
                    const leftSidePanelEnabled = leftGap >= 16;
                    const leftFrontPanelEnabled = leftGap > 16;
                    const facadeThkVal = parseFloat(facadeThickness ? facadeThickness.value : '') || 18;
                    const frontSurfaceZ = zWorld + depth / 2 - drawerFrontOffsetGlobal - frontOffset + facadeThkVal;
                    const backInsideZ = innerParams.centerZ - depthInside / 2;
                    const leftRightPanelDepth = Math.max(1, (frontSurfaceZ - frontPanelDepth) - backInsideZ);
                    if (leftSidePanelEnabled) {
                        const leftPanelDepth = leftRightPanelDepth;
                        const leftPanelGeo = new THREE.BoxGeometry(ldspThickness, sub.height, leftPanelDepth);
                        const leftPanel = solidWithEdges(leftPanelGeo, panelColor, {
                            type: 'drawer_panel',
                            name: 'Панель сол жақ',
                            sectionId: sub.sectionId,
                            width: ldspThickness,
                            height: sub.height,
                            depth: leftPanelDepth,
                            extra: { side: 'left', subId: key }
                        });
                        const leftPanelX = baseLeft + Math.max(ldspThickness / 2, leftGap - ldspThickness / 2);
                        const leftPanelFrontZ = frontSurfaceZ - frontPanelDepth;
                        leftPanel.position.set(leftPanelX, panelCenterY, backInsideZ + leftPanelDepth / 2);
                        insertsGroup.add(leftPanel);
                    }
                    if (rightGap > 0) {
                        const rightPanelDepth = leftRightPanelDepth;
                        const rightPanelGeo = new THREE.BoxGeometry(ldspThickness, sub.height, rightPanelDepth);
                        const rightPanel = solidWithEdges(rightPanelGeo, panelColor, {
                            type: 'drawer_panel',
                            name: 'Панель оң жақ',
                            sectionId: sub.sectionId,
                            width: ldspThickness,
                            height: sub.height,
                            depth: rightPanelDepth,
                            extra: { side: 'right', subId: key }
                        });
                        const rightPanelX = baseRight - Math.max(ldspThickness / 2, rightGap - ldspThickness / 2);
                        rightPanel.position.set(rightPanelX, panelCenterY, backInsideZ + rightPanelDepth / 2);
                        insertsGroup.add(rightPanel);
                    }
                    if (leftFrontPanelEnabled) {
                        const leftFrontGeo = new THREE.BoxGeometry(frontLenLeft, sub.height, frontPanelDepth);
                        const leftFrontPanel = solidWithEdges(leftFrontGeo, panelColor, {
                            type: 'drawer_panel',
                            name: 'Фронтальный панель (сол)',
                            sectionId: sub.sectionId,
                            width: frontLenLeft,
                            height: sub.height,
                            depth: frontPanelDepth,
                            edge: { front:true, back:true, left:true, right:true },
                            extra: { side: 'left-front', subId: key }
                        });
                        const leftFrontX = baseLeft + leftGap / 2;
                        leftFrontPanel.position.set(leftFrontX, panelCenterY, frontSurfaceZ - frontPanelDepth / 2);
                        insertsGroup.add(leftFrontPanel);
                    }
                    if (rightGap > 0) {
                        const rightFrontGeo = new THREE.BoxGeometry(frontLenRight, sub.height, frontPanelDepth);
                        const rightFrontPanel = solidWithEdges(rightFrontGeo, panelColor, {
                            type: 'drawer_panel',
                            name: 'Фронтальный панель (оң)',
                            sectionId: sub.sectionId,
                            width: frontLenRight,
                            height: sub.height,
                            depth: frontPanelDepth,
                            edge: { front:true, back:true, left:true, right:true },
                            extra: { side: 'right-front', subId: key }
                        });
                        const rightFrontX = baseRight - rightGap / 2;
                        rightFrontPanel.position.set(rightFrontX, panelCenterY, frontSurfaceZ - frontPanelDepth / 2);
                        insertsGroup.add(rightFrontPanel);
                    }
                }
                list.forEach(ins => {
                    if (ins.type === 'pipe') {
                        const r = 12.5; // диаметр 25 мм
                        const flangeT = 10;
                        const pipeColor = getPipeColorHex();
                        let lenMax = Math.max(0, pipeUsableWidth - 2 * flangeT - 4); // фланецтерді ескеріп, ішке сыюы керек
                        if (lenMax <= 0) return;
                        let len = Math.min(Math.max(30, pipeUsableWidth - 20), lenMax);
                        if (len < 15 && lenMax < 15) len = lenMax; // өте тар секцияда да сыртқа шықпау үшін
                        if (len <= 0) return;
                        const geo = new THREE.CylinderGeometry(r, r, len, 24);
                        geo.rotateZ(Math.PI / 2);
                        const pipe = solidWithEdges(geo, pipeColor, {
                            type: 'pipe',
                            name: 'Труба ' + (pipeCounter + 1),
                            sectionId: sub.sectionId,
                            width: len,
                            height: r * 2,
                            depth: r * 2,
                            extra: { insertType: 'pipe', subId: key }
                        });
                        const minY = plinthHeight + globalThickness + sec.y + sub.start + r;
                        const targetTop = gapTopWorld - 70;
                        const targetMid = gapCenterY - 70;
                        const pipeIndex = pipeCounter++;
                        const yTarget = (pipeIndex === 0) ? targetTop : targetMid;
                        const yPipe = Math.max(minY, yTarget);
                        pipe.position.set(pipeXCenter, yPipe, zWorld);
                        insertsGroup.add(pipe);

                        // Фланец-держательлер (диаметр 45, қалыңдығы 10 мм)
                        const flangeR = 22.5;
                        const flangeGeo = new THREE.CylinderGeometry(flangeR, flangeR, flangeT, 24);
                        flangeGeo.rotateZ(Math.PI / 2); // осьті X бойына бұрамыз
                        const flangeOffset = len / 2 + flangeT / 2;
                        const flangeLeft = solidWithEdges(flangeGeo, pipeColor, {
                            type: 'flange',
                            name: 'Фланец сол',
                            sectionId: sub.sectionId,
                            width: flangeT,
                            height: flangeR * 2,
                            depth: flangeR * 2,
                            extra: { insertType: 'pipe', subId: key }
                        });
                        flangeLeft.position.set(pipeXCenter - flangeOffset, yPipe, zWorld);
                        const flangeRight = solidWithEdges(flangeGeo.clone(), pipeColor, {
                            type: 'flange',
                            name: 'Фланец оң',
                            sectionId: sub.sectionId,
                            width: flangeT,
                            height: flangeR * 2,
                            depth: flangeR * 2,
                            extra: { insertType: 'pipe', subId: key }
                        });
                        flangeRight.position.set(pipeXCenter + flangeOffset, yPipe, zWorld);
                        insertsGroup.add(flangeLeft);
                        insertsGroup.add(flangeRight);
                    } else if (ins.type === 'drawer') {
                        // LDSP қорап + жеке фасад
                        const bodyT = globalThickness;
                        // Корпус ені: әр жақтан runner қалыңдығына тең бос орын
                        const outerW = Math.max(60, drawerUsableWidth - 2 * padBody);
                        const outerH = Math.max(10, Math.min(bodyHeight, facSlotH - 2));
                        const preferredDepth = ins.depth || pickDrawerDepthForSub(sub);
                        const effectivePreferredDepth = Math.max(10, preferredDepth - drawerDepthBrandOffset);
                        const bodyDepth = Math.max(120, Math.min(effectivePreferredDepth, depth));
                        const bodyColor = getCorpusColor(corpusMaterial.value);
                        const facadeThk = parseFloat(facadeThickness.value) || 18;
                        const drawerFacadeMatVal = drawerFacadeMaterial && drawerFacadeMaterial.value ? drawerFacadeMaterial.value : facadeMaterial.value;
                        const facadeColorLocal = getFacadeColor(drawerFacadeMatVal);
                        let facadeGap = targetGap;
                        const facBaseH = facSlotH;
                        const maxGap = Math.max(0, Math.min((drawerUsableWidth - 10) / 2, (facBaseH - 10) / 2));
                        facadeGap = Math.min(facadeGap, maxGap);

                        const groupBody = new THREE.Group();
                        // Боковиналар
                        const sideExtension = ins.variant === 'tandem' ? 11 : 0;
                        const sideHeight = outerH + sideExtension;
                        const sideYOffset = sideExtension / 2;
                        const sideGeo = new THREE.BoxGeometry(bodyT, sideHeight, bodyDepth);
                        const leftSide = solidWithEdges(sideGeo, bodyColor, {
                            type: 'drawer',
                            name: 'Ящик сол жақ',
                            sectionId: sub.sectionId,
                            width: bodyT,
                            height: sideHeight,
                            depth: bodyDepth,
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, drawerSide: 'left' },
                            edge: { front: false, back: true, left: true, right: true }
                        });
                        leftSide.position.set(-outerW / 2 + bodyT / 2, -sideYOffset, 0);
                        const rightSide = solidWithEdges(sideGeo.clone(), bodyColor, {
                            type: 'drawer',
                            name: 'Ящик оң жақ',
                            sectionId: sub.sectionId,
                            width: bodyT,
                            height: sideHeight,
                            depth: bodyDepth,
                            edge: { front: false, back: true, left: true, right: true },
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, drawerSide: 'right' }
                        });
                        rightSide.position.set(outerW / 2 - bodyT / 2, -sideYOffset, 0);
                        // Алдыңғы/артқы
                        const frontW = Math.max(10, outerW - 2 * bodyT);
                        const frontGeo = new THREE.BoxGeometry(frontW, outerH - bodyT, bodyT);
                        const front = solidWithEdges(frontGeo, bodyColor, {
                            type: 'drawer',
                            name: 'Ящик алды',
                            sectionId: sub.sectionId,
                            width: frontW,
                            height: outerH - bodyT,
                            depth: bodyT,
                            edge: { front: false, back: true, left: false, right: false },
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, drawerPart: 'front' }
                        });
                        front.position.set(0, bodyT / 2, bodyDepth / 2 - bodyT / 2);
                        const back = solidWithEdges(frontGeo.clone(), bodyColor, {
                            type: 'drawer',
                            name: 'Ящик арты',
                            sectionId: sub.sectionId,
                            width: frontW,
                            height: outerH - bodyT,
                            depth: bodyT,
                            edge: { front: false, back: true, left: false, right: false },
                            extra: {
                                insertType: 'drawer',
                                subId: key,
                                variant: ins.variant,
                                drawerPart: 'back'
                            }
                        });
                        back.position.set(0, bodyT / 2, -bodyDepth / 2 + bodyT / 2);
                        // Түбі
                        const bottomW = Math.max(10, outerW - 2 * bodyT);
                        const bottomD = Math.max(10, bodyDepth);
                        const bottomGeo = new THREE.BoxGeometry(bottomW, bodyT, bottomD);
                        const bottom = solidWithEdges(bottomGeo, bodyColor, {
                            type: 'drawer',
                            name: 'Ящик түбі',
                            sectionId: sub.sectionId,
                            width: bottomW,
                            height: bodyT,
                            depth: bottomD,
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, drawerPart: 'bottom' }
                        });
                        bottom.position.set(0, -outerH / 2 + bodyT / 2, 0);
                        [leftSide, rightSide, front, back, bottom].forEach(m => groupBody.add(m));

                        // Направляющие (визуализация)
                        const sanitizedRunnerThk = Math.max(1, readDrawerRunnerThk());
                        const runnerThk = ins.variant === 'tandem' ? 5 : sanitizedRunnerThk;
                        const runnerH = 30;
                        const runnerD = bodyDepth;
                        const runnerColor = 0x777777;
                        const runnerGeo = new THREE.BoxGeometry(runnerThk, runnerH, runnerD);
                        const leftRunner = solidWithEdges(runnerGeo, runnerColor, {
                            type: 'runner',
                            name: 'Направляющий сол',
                            sectionId: sub.sectionId,
                            width: runnerThk,
                            height: runnerH,
                            depth: runnerD,
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, runnerType }
                        });
                        leftRunner.position.set(-outerW / 2 - runnerThk / 2, 0, 0);
                        const rightRunner = solidWithEdges(runnerGeo.clone(), runnerColor, {
                            type: 'runner',
                            name: 'Направляющий оң',
                            sectionId: sub.sectionId,
                            width: runnerThk,
                            height: runnerH,
                            depth: runnerD,
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, runnerType }
                        });
                        rightRunner.position.set(outerW / 2 + runnerThk / 2, 0, 0);
                        groupBody.add(leftRunner);
                        groupBody.add(rightRunner);

                        // Фасад
                        const facW = Math.max(20, drawerUsableWidth - 2 * facadeGap);
                        // Фасад биіктігі слот биіктігіне тең – gapY арқылы бөлінеді (gapY == targetGap мүмкіндігінше)
                        const facH = Math.max(20, facBaseH);
                        const facGeo = new THREE.BoxGeometry(facW, facH, facadeThk);
                        const fac = solidWithEdges(facGeo, facadeColorLocal, {
                            type: 'drawer_facade',
                            name: 'Ящик фасад',
                            sectionId: sub.sectionId,
                            width: facW,
                            height: facH,
                            depth: facadeThk,
                            edge: { front: true, back: true, left: true, right: true },
                            extra: { insertType: 'drawer', subId: key, variant: ins.variant, facadeGap, facadeMaterial: drawerFacadeMatVal }
                        });
                        fac.position.set(0, 0, bodyDepth / 2 + facadeThk / 2);

                        const drawerGroup = new THREE.Group();
                        drawerGroup.add(groupBody);
                        drawerGroup.add(fac);

                        const slotStartY = gapBottomWorld + gapY;
                        const yDrawer = slotStartY + facSlotH / 2 + drawerCounter * stepY;
                        drawerCounter++;
                        // Фасадты алдынан оффсетке қарай артқа жылжытамыз
                        const frontOffset = readDrawerFrontOffset();
                        const bodyZ = zWorld + (depth / 2 - bodyDepth / 2) - frontOffset;
                        drawerGroup.position.set(drawerXCenter, yDrawer, bodyZ);
                        fac.position.z = bodyDepth / 2 + facadeThk / 2;
                        drawerGroup.userData.isDrawerGroup = true;
                        drawerGroup.userData.open = false;
                        drawerGroup.userData.closedZ = drawerGroup.position.z;
                        drawerGroup.userData.openOffset = bodyDepth;
                        drawerGroup.userData.sectionId = sub.sectionId;
                        drawerGroup.userData.drawerDepth = preferredDepth;
                        // Төмендегі mesh-тер drawerGroup ата-анасы арқылы анимация алады
                        insertsGroup.add(drawerGroup);
                    }
                });
            });

            (bodyCore || cabinetGroup).add(insertsGroup);
            rebuildStructureList();
            rebuildDrawerSubList();
        }

        // === ПОЛКАЛАРМЕН ЖҰМЫС ІСТЕЙТІН HELPERS ===

        function getSelectedSection() {
            if (!selectedSectionId) return null;
            return sections.find(s => s.id === selectedSectionId) || null;
        }

        function syncShelves() {
            rebuildShelvesGroup();
            rebuildShelvesUI();
            rebuildSectionSelect();
            updateDimensionsBox();
            rebuildDimensionHelpers();
            rebuildStructureList();
            updateSelectedShelfSubHelper();
            rebuildInsertsUI();
            rebuildDrawerSubList();
        }

        // Таңдалған секция үшін алдынан отступты UI-дан оқу
        function updateShelfFrontOffsetFromUI() {
            if (!shelfOffsetInput) return;

            const sec = getSelectedSection();
            if (!sec) {
                showError('Алдымен секцияны таңдаңыз');
                return;
            }

            let v = parseFloat(shelfOffsetInput.value);
            if (!isFinite(v) || v < 0) {
                v = 0;
            }

            const innerParams = computeInnerParams();
            const depthInside = innerParams.depthInside;
            const maxOffset   = Math.max(0, depthInside - 10);
            if (v > maxOffset) v = maxOffset;

            shelfOffsetInput.value = v;
            sectionShelfOffsets[sec.id] = v;

            rebuildShelvesGroup();
            rebuildDimensionHelpers();
            rebuildInsertsGroup();
        }


        // Қолмен бір полка қосу (биіктігі мм)
        function addShelfManual() {
            const sec = getSelectedSection();
            if (!sec) {
                showError('Алдымен секцияны таңдаңыз');
                return;
            }
            if (!shelfHeightInput) {
                showError('Полка биіктігі үшін input табылмады');
                return;
            }

            const h = parseFloat(shelfHeightInput.value);
            if (!isFinite(h)) {
                showError('Полка биіктігін (мм) дұрыс енгізіңіз');
                return;
            }

            // Секция ішіндегі диапазон: 0 ... sec.h
            if (h <= 0 || h >= sec.h - 20) {
                showError('Полка биіктігі секция ішінде болуы керек');
                return;
            }

            if (!sectionShelves[sec.id]) sectionShelves[sec.id] = [];
            sectionShelves[sec.id].push(h);
            sectionShelves[sec.id].sort((a, b) => a - b);

            syncShelves();
        }

        // Авто полкалар (саны бойынша тең бөлу)
        function autoPlaceShelves() {
            const sec = getSelectedSection();
            if (!sec) {
                showError('Алдымен секцияны таңдаңыз');
                return;
            }

            let count = 0;
            if (shelfCountInput) {
                count = parseInt(shelfCountInput.value, 10);
            }
            if (!isFinite(count) || count <= 0) {
                count = 3; // әдепкі 3 полка
            }

            const shelfT = globalThickness;
            const usable = sec.h - shelfT * count;
            if (usable <= 0) {
                showError('Секция биіктігі полка қоюға өте аз');
                return;
            }

            // Тең арақашықтық: gaps = count + 1
            const gaps = count + 1;
            const baseGap = Math.floor(usable / gaps);
            let remainder = Math.round(usable - baseGap * gaps); // бүтін мм үлестіреміз

            const arr = [];
            let pos = 0;
            for (let i = 0; i < count; i++) {
                const extra = remainder > 0 ? 1 : 0;
                if (remainder > 0) remainder -= 1;
                pos += baseGap + extra;
                arr.push(pos); // полканың түбі
                pos += shelfT; // келесі gap есептеу үшін полка қалыңдығын қосамыз
            }

            sectionShelves[sec.id] = arr;
            syncShelves();
        }

        // Таңдалған полканың биіктігін өзгерту
        function updateSelectedShelfHeight() {
            const sec = getSelectedSection();
            if (!sec) {
                showError('Алдымен секцияны таңдаңыз');
                return;
            }
            if (!shelfSelect || !editShelfHeightInput) return;
            if (shelfSelect.selectedIndex < 0) {
                showError('Алдымен тізімнен полканы таңдаңыз');
                return;
            }

            const oldH = parseFloat(shelfSelect.value);
            let newH = parseFloat(editShelfHeightInput.value);
            if (!isFinite(newH)) {
                showError('Жаңа биіктікті дұрыс енгізіңіз');
                return;
            }

            if (newH <= 0 || newH >= sec.h - 20) {
                showError('Полка биіктігі секция ішінде болуы керек');
                return;
            }

            const list = sectionShelves[sec.id] || [];
            const idx = list.findIndex(v => Math.abs(v - oldH) < 0.0001);
            if (idx === -1) {
                showError('Полканы табу мүмкін болмады');
                return;
            }
            list[idx] = newH;
            list.sort((a, b) => a - b);
            sectionShelves[sec.id] = list;

            syncShelves();
        }

        // Gap бойынша полкаларды қайта санау
        function applyShelfGap() {
            const sec = getSelectedSection();
            if (!sec) {
                showError('Алдымен секцияны таңдаңыз');
                return;
            }
            if (!shelfGapInput) return;

            let gap = parseFloat(shelfGapInput.value);
            if (!isFinite(gap) || gap <= 50) {
                gap = 300; // әдепкі 300 мм
            }

            const margin = 80;
            const usable = sec.h - margin * 2;
            if (usable <= gap) {
                showError('Секция биіктігі gap-тен кіші');
                return;
            }

            const list = [];
            let h = margin + gap;
            while (h < sec.h - margin - 20) {
                list.push(h);
                h += gap;
            }

            if (!list.length) {
                showError('Берілген gap бойынша полка қоюға орын жоқ');
                return;
            }

            sectionShelves[sec.id] = list;
            syncShelves();
        }

        // Екі полканың арасына қосымша полка қою
        function insertShelfBetween() {
            const sec = getSelectedSection();
            if (!sec) {
                showError('Алдымен секцияны таңдаңыз');
                return;
            }
            if (!shelfSelect) return;
            if (shelfSelect.selectedIndex <= 0) {
                showError('Кем дегенде екінші полканы таңдаңыз (аралық табылады)');
                return;
            }

            const list = (sectionShelves[sec.id] || []).slice().sort((a,b)=>a-b);
            const idx  = shelfSelect.selectedIndex;
            if (idx >= list.length) return;

            const h1 = list[idx - 1];
            const h2 = list[idx];
            const mid = (h1 + h2) / 2;

            if (!isFinite(mid) || mid <= 0 || mid >= sec.h - 20) {
                showError('Аралық дұрыс емес');
                return;
            }

            list.push(mid);
            list.sort((a,b)=>a-b);
            sectionShelves[sec.id] = list;

            syncShelves();
        }

	        // ПОЛКА КНОПКАЛАРЫНА EVENT LISTENER БАЙЛАУ
	        if (addShelfBtn) {
	            addShelfBtn.addEventListener('click', function () {
	                runUndoable(() => {
	                    addShelfManual();
	                });
	            });
	        }

	        if (autoShelvesBtn) {
	            autoShelvesBtn.addEventListener('click', function () {
	                runUndoable(() => {
	                    autoPlaceShelves();
	                });
	            });
	        }

	        if (updateShelfBtn) {
	            updateShelfBtn.addEventListener('click', function () {
	                runUndoable(() => {
	                    updateSelectedShelfHeight();
	                });
	            });
	        }

	        if (applyShelfGapBtn) {
	            applyShelfGapBtn.addEventListener('click', function () {
	                runUndoable(() => {
	                    applyShelfGap();
	                });
	            });
	        }

	        if (insertShelfBetweenBtn) {
	            insertShelfBetweenBtn.addEventListener('click', function () {
	                runUndoable(() => {
	                    insertShelfBetween();
	                });
	            });
	        }

        if (addInsertBtn) {
            addInsertBtn.addEventListener('click', function () {
                ensureSelectedSubIdFromUI();
                if (!selectedShelfSubId) {
                    showError('Алдымен полкалар арасындағы секцияны таңдаңыз');
                    return;
                }
                const type = insertTypeSelect ? insertTypeSelect.value : 'pipe';
                let variant = null;
	                if (type === 'drawer') {
	                    variant = drawerVariantSelect ? drawerVariantSelect.value : 'telescope';
	                    if (!variant) variant = 'telescope';
	                    syncDrawerDepthSelect(getShelfSubSections().find(s=>`${s.sectionId}:${s.idx}`===selectedShelfSubId));
	                }
	                if (!type) return;
	                runUndoable(() => {
	                    const arr = Array.isArray(shelfInserts[selectedShelfSubId]) ? shelfInserts[selectedShelfSubId] : [];
	                    let depth = null;
	                    if (type === 'drawer') {
	                        let dSel = drawerDepthSelect ? parseFloat(drawerDepthSelect.value) : NaN;
	                        if (!isFinite(dSel) || !drawerDepthPresets.includes(dSel)) {
	                            const sub = getShelfSubSections().find(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId);
	                            dSel = pickDrawerDepthForSub(sub);
	                        }
	                        depth = dSel;
	                    }
	                    const newIdx = arr.length;
	                    arr.push({ type, variant, depth });
	                    shelfInserts[selectedShelfSubId] = arr;
	                    selectedInsertKey = `${selectedShelfSubId}#${newIdx}`;
	                    rebuildInsertsUI();
	                    rebuildInsertsGroup();
	                    updateSelectedShelfSubHelper();
	                });
	            });
	        }
        if (insertTypeSelect) {
            insertTypeSelect.addEventListener('change', () => {
                updateInsertSettingsVisibility();
            });
        }

	        if (drawerBodyHeightInput) {
	            drawerBodyHeightInput.addEventListener('change', () => {
	                runUndoable(() => {
	                    readDrawerBodyHeight();
	                    rebuildInsertsGroup();
	                    rebuildInsertsUI();
	                });
	            });
	        }

        if (drawerStackGapInput) {
            drawerStackGapInput.addEventListener('change', () => {
                runUndoable(() => {
                    rebuildInsertsGroup();
                    rebuildInsertsUI();
                });
            });
        }
        if (drawerRunnerThkInput) {
            drawerRunnerThkInput.addEventListener('change', () => {
                runUndoable(() => {
                    rebuildInsertsGroup();
                    rebuildInsertsUI();
                });
            });
        }
        if (drawerVariantSelect) {
            drawerVariantSelect.addEventListener('change', () => {
                if (drawerVariantSelect.value === 'tandem' && drawerRunnerThkInput) {
                    drawerRunnerThkInput.value = 5;
                }
            });
        }
        if (drawerDepthBrandSelect) {
            drawerDepthBrandSelect.addEventListener('change', () => {
                runUndoable(() => {
                    rebuildInsertsGroup();
                    rebuildInsertsUI();
                });
            });
        }
        if (insertGapLeftInput) {
            insertGapLeftInput.addEventListener('change', () => {
                runUndoable(() => {
                    rebuildInsertsGroup();
                    rebuildInsertsUI();
                });
            });
        }
        if (insertGapRightInput) {
            insertGapRightInput.addEventListener('change', () => {
                runUndoable(() => {
                    rebuildInsertsGroup();
                    rebuildInsertsUI();
                });
            });
        }
	        if (drawerRunnerTypeSelect) {
	            drawerRunnerTypeSelect.addEventListener('change', () => {
	                runUndoable(() => {
	                    rebuildInsertsGroup();
	                    rebuildInsertsUI();
	                });
	            });
	        }
	        if (pipeColorInput) {
	            pipeColorInput.addEventListener('change', () => {
	                runUndoable(() => {
	                    rebuildInsertsGroup();
	                });
	            });
	        }
        if (drawerDepthSelect) {
            drawerDepthSelect.addEventListener('change', () => {
                if (!selectedShelfSubId) return;
                const sub = getShelfSubSections().find(s => `${s.sectionId}:${s.idx}` === selectedShelfSubId);
                const depthVal = parseFloat(drawerDepthSelect.value);
	                if (!isFinite(depthVal)) {
	                    syncDrawerDepthSelect(sub);
	                    return;
	                }
	                runUndoable(() => {
	                    const arr = Array.isArray(shelfInserts[selectedShelfSubId]) ? shelfInserts[selectedShelfSubId] : [];
	                    const updated = arr.map((it, idx) => {
	                        const isTarget = selectedInsertKey && selectedInsertKey === `${selectedShelfSubId}#${idx}`;
	                        if (it && it.type === 'drawer') {
	                            if (isTarget || !selectedInsertKey) {
	                                return { ...it, depth: depthVal };
	                            }
	                        }
	                        return it;
	                    });
	                    shelfInserts[selectedShelfSubId] = updated;
	                    rebuildInsertsUI();
	                    rebuildInsertsGroup();
	                    syncDrawerDepthSelect(sub);
	                });
	            });
	        }
	        if (drawerFrontOffsetInput) {
	            drawerFrontOffsetInput.addEventListener('change', () => {
	                runUndoable(() => {
	                    readDrawerFrontOffset();
	                    rebuildInsertsGroup();
	                });
	            });
	        }
        if (drawerFacadeMaterial) {
            drawerFacadeMaterial.addEventListener('change', () => {
                runUndoable(() => {
                    rebuildInsertsGroup();
                    rebuildStructureList();
                    refreshPartPreview();
                    updatePartUI();
                });
            });
        }

	        if (shelfOffsetInput) {
	            const commitShelfOffset = () => {
	                runUndoable(() => {
	                    updateShelfFrontOffsetFromUI();
	                });
	            };

            // Enter басқанда да бірден қолдану үшін
            shelfOffsetInput.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    commitShelfOffset();
                }
            });

            shelfOffsetInput.addEventListener('change', function () {
                commitShelfOffset();
            });
        }

        function resolveDrawerValueFromExtra(extra, key) {
            let target = extra;
            let depth = 0;
            while (target && typeof target === 'object' && depth < 8) {
                if (Object.prototype.hasOwnProperty.call(target, key)) {
                    return target[key];
                }
                target = target.extra;
                depth++;
            }
            return null;
        }

        function resolveDrawerSideFromExtra(extra) {
            return resolveDrawerValueFromExtra(extra, 'drawerSide');
        }

        function isDrawerEdgePanel(part) {
            if (!part) return false;
            const drawerPart = resolveDrawerValueFromExtra(part && part.extra, 'drawerPart');
            if (drawerPart === 'back' || drawerPart === 'front') {
                return true;
            }
            const typeLower = (part.type || '').toLowerCase();
            return typeLower === 'plinth';
        }

        function isVerticalPanelPart(part) {
            if (!part) return false;
            const typeLower = (part.type || '').toLowerCase();
            if (typeLower === 'side' || typeLower === 'divider') {
                return true;
            }
            if (typeLower === 'drawer') {
                const extra = part.extra || {};
                if (resolveDrawerSideFromExtra(extra)) {
                    return true;
                }
                const name = (part.name || '').toLowerCase();
                if (/ящик\s+(сол|оң)\s+жақ/i.test(name)) {
                    return true;
                }
            }
            return false;
        }

        function disposeEdgeHighlight(part) {
            if (!part || !part.edgeGroup) return;
            const grp = part.edgeGroup;
            if (grp.parent) grp.parent.remove(grp);
            grp.traverse(obj => {
                if (obj.geometry) obj.geometry.dispose();
                if (obj.material) obj.material.dispose();
            });
            part.edgeGroup = null;
        }

        function rebuildEdgeHighlightForPart(part) {
            if (!part || !part.mesh) return;
            disposeEdgeHighlight(part);
            const e = part.edge || {};
            const hasEdge = e.front || e.back || e.left || e.right;
            if (!hasEdge) return;

            const band = 1;
            const w = Math.abs(part.width || 0);
            const h = Math.abs(part.height || 0);
            const d = Math.abs(part.depth || 0);
            const group = new THREE.Group();
            const baseMat = new THREE.MeshBasicMaterial({ color: 0xdd0000, transparent: false });

            const addBand = (bw, bh, bd, x, y, z) => {
                const g = new THREE.BoxGeometry(Math.max(1, bw), Math.max(1, bh), Math.max(1, bd));
                const m = baseMat.clone();
                const mesh = new THREE.Mesh(g, m);
                mesh.position.set(x, y, z);
                mesh.userData.partId = part.id;
                group.add(mesh);
            };

            const tLower = (part.type || '').toLowerCase();
            const isVerticalPanel = isVerticalPanelPart(part);
            const isPlinth = (tLower === 'plinth');
            const isBottomPanel = (tLower === 'bottom');
            const isTopPanel = (tLower === 'top');

            const frontFlag = !!e.front;
            const backFlag  = !!e.back;
            const leftFlag  = !!e.left;
            const rightFlag = !!e.right;

            // Map edge flags to faces
            let bottomFlag = (isBottomPanel || isTopPanel) ? false : (isVerticalPanel ? leftFlag  : (isPlinth ? frontFlag : frontFlag));
            let topFlag    = (isBottomPanel || isTopPanel) ? false : (isVerticalPanel ? rightFlag : (isPlinth ? backFlag  : backFlag));
            const sideLeft   = isVerticalPanel ? backFlag  : leftFlag;
            const sideRight  = isVerticalPanel ? frontFlag : rightFlag;
            // Беттерге кромка: есікке тек үсті/асты қыр, фронт/бэк беті боялмасын
            let frontFace  = isPlinth ? false : frontFlag;
            let backFace   = isPlinth ? false : backFlag;
            const isDrawerPanel = (tLower === 'drawer_panel');
            const isDrawerFacade = (tLower === 'drawer_facade');
            const isDrawerEdgePanelFlag = isDrawerEdgePanel(part);
            if (tLower === 'door') {
                frontFace = false;
                backFace = false;
                // Есікте фронт флагын төменгіге, бэкті жоғарғыға қолданамыз
                bottomFlag = frontFlag;
                topFlag = backFlag;
            }
            if (isDrawerPanel) {
                frontFace = false;
                backFace = false;
            }
            if (isDrawerFacade || isDrawerEdgePanelFlag) {
                frontFace = false;
                backFace = false;
                bottomFlag = frontFlag;
                topFlag = backFlag;
            }

            // Полка: төмен/жоғары кромкасыз
            if ((part.type || '').toLowerCase() === 'shelf') {
                bottomFlag = false;
                topFlag = false;
            }

            if (frontFace) addBand(w, h, band, 0, 0, d / 2 + band / 2);
            if (backFace)  addBand(w, h, band, 0, 0, -d / 2 - band / 2);

            if (bottomFlag) addBand(w, band, d, 0, -h / 2 - band / 2, 0);
            if (topFlag)    addBand(w, band, d, 0,  h / 2 + band / 2, 0);
            if (!isVerticalPanel) {
                if (sideLeft)  addBand(band, h, d, -w / 2 - band / 2, 0, 0);
                if (sideRight) addBand(band, h, d,  w / 2 + band / 2, 0, 0);
            }

            const sx = part.mesh.scale.x || 1;
            const sy = part.mesh.scale.y || 1;
            const sz = part.mesh.scale.z || 1;
            group.scale.set(1 / sx, 1 / sy, 1 / sz); // avoid double-scaling when mesh already scaled
            part.mesh.add(group);
            part.edgeGroup = group;
            part.edgeGroup.visible = !!(edgeHighlightEnabled && (frontFlag || backFlag || leftFlag || rightFlag));
        }

        function getEdgeVisualFlags(part) {
            const e = part.edge || {};
            const typeLower = (part.type || '').toLowerCase();
            const isVerticalPanel = isVerticalPanelPart(part);
            const isPlinth = (typeLower === 'plinth');
            const isBottomPanel = (typeLower === 'bottom');
            const isTopPanel = (typeLower === 'top');

            if (isVerticalPanel) {
                return {
                    top: !!e.right,
                    bottom: !!e.left,
                    left: !!e.back,
                    right: !!e.front
                };
            }
            if (isPlinth) {
                return {
                    top: !!e.back,
                    bottom: !!e.front,
                    left: !!e.left,
                    right: !!e.right
                };
            }
            if (isBottomPanel) {
                return {
                    top: !!e.back,
                    bottom: !!e.front,
                    left: !!e.left,
                    right: !!e.right
                };
            }
            if (isTopPanel) {
                return {
                    top: !!e.back,
                    bottom: !!e.front,
                    left: !!e.left,
                    right: !!e.right
                };
            }
            if (typeLower === 'shelf') {
                return {
                    top: false,
                    bottom: !!e.front,
                    left: !!e.left,
                    right: !!e.right
                };
            }
            return {
                top:   !!e.back,
                bottom:!!e.front,
                left:  !!e.left,
                right: !!e.right
            };
        }

        function applyPartOffsets(part) {
            if (!part || !part.mesh) return;
            const base = part.baseDims || { width: part.width || 0, height: part.height || 0, depth: part.depth || 0 };
            const offs = part.offsets || { front:0, back:0, bottom:0, top:0 };
            const baseWidth = Math.max(1, base.width || 0.001);
            const baseDepth = Math.max(1, base.depth || 0.001);
            const baseHeight = Math.max(1, base.height || 0.001);
            const newDepth = Math.max(1, base.depth + (offs.front || 0) + (offs.back || 0));
            const newHeight = Math.max(1, base.height + (offs.top || 0) + (offs.bottom || 0));
            const newWidth = Math.max(1, base.width + (offs.left || 0) + (offs.right || 0));
            const scaleZ = newDepth / baseDepth;
            const scaleY = newHeight / baseHeight;
            const scaleX = newWidth / baseWidth;

            part.mesh.scale.set(scaleX, scaleY, scaleZ);

            const basePos = part.meshBasePosition || new THREE.Vector3();
            const dz = ((offs.front || 0) - (offs.back || 0)) / 2;
            const dy = ((offs.top || 0) - (offs.bottom || 0)) / 2;
            const dx = ((offs.right || 0) - (offs.left || 0)) / 2;
            const frontOffsetVal = parseFloat(part.frontOffset) || 0;
            const frontShift = -frontOffsetVal;
            part.mesh.position.set(basePos.x + dx, basePos.y + dy, basePos.z + dz + frontShift);

            part.height = newHeight;
            part.depth  = newDepth;
            part.width  = newWidth;

            rebuildEdgeHighlightForPart(part);
            applyEdgeHighlightVisibility();
        }

        function applyEdgeHighlightVisibility() {
            Object.values(parts || {}).forEach(p => {
                const e = p.edge || {};
                const hasEdge = e.front || e.back || e.left || e.right;
                if (edgeHighlightEnabled && hasEdge && !p.edgeGroup) {
                    rebuildEdgeHighlightForPart(p);
                }
                if (p.edgeGroup) {
                    p.edgeGroup.visible = !!(edgeHighlightEnabled && hasEdge);
                }
            });
            if (toggleEdgeBtn) {
                toggleEdgeBtn.classList.toggle('active', edgeHighlightEnabled);
            }
        }

        function getPartPreviewAxisLabels(part) {
            const t = (part && part.type || '').toLowerCase();
            if (t === 'side' || t === 'divider') {
                return { horizontal: 'Тереңдік', vertical: 'Биіктік' };
            }
            if (t === 'back' || t === 'door') {
                return { horizontal: 'Ені', vertical: 'Биіктік' };
            }
            if (t === 'top' || t === 'bottom' || t === 'shelf' || t === 'plinth') {
                return { horizontal: 'Ені', vertical: 'Тереңдік' };
            }
            return { horizontal: 'Ені', vertical: 'Биіктік' };
        }

        function getPartPreviewAxes(part) {
            const emptyAxes = {
                horizontal: { value: 0, label: 'Ені' },
                vertical: { value: 0, label: 'Биіктік' }
            };
            if (!part) return emptyAxes;
            const type = (part.type || '').toLowerCase();
            const dims = getDisplayDimsThicknessLast(part);
            if (type === 'side' || type === 'divider') {
                return {
                    horizontal: { value: dims[1] || 0, label: 'Тереңдік' },
                    vertical: { value: dims[0] || 0, label: 'Биіктік' }
                };
            }
            const labels = getPartPreviewAxisLabels(part);
            return {
                horizontal: { value: dims[0] || 0, label: labels.horizontal },
                vertical: { value: dims[1] || 0, label: labels.vertical }
            };
        }

        function getDisplayDimsByType(part) {
            const t = (part && part.type || '').toLowerCase();
            const w = part ? (part.width || 0) : 0;
            const h = part ? (part.height || 0) : 0;
            const d = part ? (part.depth || 0) : 0;
            if (t === 'side' || t === 'divider') {
                return [h, d, w];
            }
            if (t === 'plinth') {
                return [w, h, d];
            }
            if (t === 'falsh') {
                return [w, h, d].slice().sort((a, b) => b - a);
            }
            if (t === 'bottom' || t === 'top' || t === 'shelf') {
                return [w, d, h];
            }
            if (t === 'back' || t === 'door') {
                return [w, h, d];
            }
            return [w, h, d];
        }

        function getDisplayDimsThicknessLast(part) {
            const base = getDisplayDimsByType(part).map(v => Math.abs(v || 0));
            if (!base.length) return [0, 0, 0];
            const minValue = Math.min(...base);
            const minIndex = base.indexOf(minValue);
            let dims = base.slice();
            dims.splice(minIndex, 1);
            dims.push(minValue);
            const name = (part && part.name) || '';
            const type = (part && part.type || '').toLowerCase();
            if (type === 'drawer' && typeof name === 'string' && /сол\s+жақ|оң\s+жақ/i.test(name)) {
                if (dims.length >= 2) {
                    [dims[0], dims[1]] = [dims[1], dims[0]];
                }
            }
            if (dims.length < 3) {
                while (dims.length < 3) dims.push(0);
            }
            return dims;
        }

        function formatPartDims(part) {
            if (!part) return '–';
            const dims = getDisplayDimsThicknessLast(part).map(v => Math.round(v));
            const type = (part && part.type || '').toLowerCase();
            if (type === 'door' && dims.length >= 2 && dims[0] < dims[1]) {
                [dims[0], dims[1]] = [dims[1], dims[0]];
            } else if (type === 'back' && dims.length >= 2 && dims[0] > dims[1]) {
                [dims[0], dims[1]] = [dims[1], dims[0]];
            }
            return dims.join(' × ');
        }

        function renderPartPreview(part) {
            if (!partPreviewCanvas || !partPreviewCtx) return;
            const dpr = window.devicePixelRatio || 1;
            const displayWidth  = partPreviewCanvas.clientWidth  || 320;
            const displayHeight = partPreviewCanvas.clientHeight || 200;
            const targetW = Math.round(displayWidth * dpr);
            const targetH = Math.round(displayHeight * dpr);
            if (partPreviewCanvas.width !== targetW || partPreviewCanvas.height !== targetH) {
                partPreviewCanvas.width  = targetW;
                partPreviewCanvas.height = targetH;
            }

            const ctx = partPreviewCtx;
            ctx.save();
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            ctx.clearRect(0, 0, displayWidth, displayHeight);

            if (!part) {
                if (partPreviewEmpty) partPreviewEmpty.style.display = 'flex';
                if (partPreviewCaption) partPreviewCaption.textContent = '–';
                if (partPreviewName) partPreviewName.textContent = 'Бөлшек таңдалмаған';
                ctx.restore();
                return;
            }

            if (partPreviewEmpty) partPreviewEmpty.style.display = 'none';
            if (partPreviewName) partPreviewName.textContent = part.name || 'Бөлшек';

            const axes = getPartPreviewAxes(part);
            const horizVal = Math.abs(axes.horizontal.value || 0);
            const vertVal  = Math.abs(axes.vertical.value  || 0);
            const safeHoriz = Math.max(1, horizVal);
            const safeVert  = Math.max(1, vertVal);

            if (partPreviewCaption) {
                const dimsText = formatPartDims(part) + ' мм';
                const matLabel = getMaterialLabelForPart(part);
                partPreviewCaption.textContent = matLabel ? `${dimsText} · ${matLabel}` : dimsText;
            }

            const padding = 18;
            const scale = Math.min(
                (displayWidth - padding * 2) / safeHoriz,
                (displayHeight - padding * 2) / safeVert
            );
            const rectW = Math.max(24, safeHoriz * scale);
            const rectH = Math.max(24, safeVert * scale);
            const x = (displayWidth - rectW) / 2;
            const y = (displayHeight - rectH) / 2;

            ctx.fillStyle = '#ecf1fb';
            ctx.strokeStyle = '#4b5b78';
            ctx.lineWidth = 1.4;
            ctx.beginPath();
            ctx.rect(x, y, rectW, rectH);
            ctx.fill();
            ctx.stroke();

            const edgeFlags = getEdgeVisualFlags(part);
            const edgeThickness = 8;
            ctx.fillStyle = 'rgba(220, 40, 40, 0.32)';
            if (edgeFlags.bottom) ctx.fillRect(x, y + rectH - edgeThickness, rectW, edgeThickness);
            if (edgeFlags.top)    ctx.fillRect(x, y, rectW, edgeThickness);
            if (edgeFlags.left)   ctx.fillRect(x, y, edgeThickness, rectH);
            if (edgeFlags.right)  ctx.fillRect(x + rectW - edgeThickness, y, edgeThickness, rectH);

            ctx.fillStyle = '#1d2433';
            ctx.font = '12px system-ui, -apple-system, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(
                formatPartDims(part) + ' мм',
                displayWidth / 2,
                displayHeight / 2
            );

            ctx.restore();
        }

        function refreshPartPreview() {
            const p = (selectedPartId && parts[selectedPartId]) ? parts[selectedPartId] : null;
            renderPartPreview(p);
        }

        function getSelectLabel(select) {
            if (!select) return '';
            const idx = select.selectedIndex;
            if (idx >= 0) {
                const opt = select.options[idx];
                if (opt) {
                    const text = opt.textContent || opt.innerText || '';
                    if (text) return text.trim();
                }
            }
            return (select.value || '').trim();
        }

        function getEffectiveFacadeMaterialLabel() {
            const custom = facadeMaterialNameInput ? facadeMaterialNameInput.value.trim() : '';
            if (custom) return custom;
            const selectLabel = getSelectLabel(facadeMaterial);
            if (selectLabel) return selectLabel;
            return 'Белый';
        }

        function getDrawerFacadeMaterialLabel() {
            const customDrawer = drawerFacadeMaterialNameInput ? drawerFacadeMaterialNameInput.value.trim() : '';
            if (customDrawer) return customDrawer;
            const val = drawerFacadeMaterial ? drawerFacadeMaterial.value : '';
            if (val === 'ldsp') {
                return corpusMaterial ? (corpusMaterial.value || '') : '';
            }
            if (val === 'mdf') {
                return getEffectiveFacadeMaterialLabel();
            }
            const selectLabel = getSelectLabel(drawerFacadeMaterial);
            return selectLabel || getEffectiveFacadeMaterialLabel();
        }

        function getBackMaterialLabel() {
            return getSelectLabel(backMaterial);
        }

        function getPlinthMaterialLabel() {
            const custom = plinthMaterialNameInput ? plinthMaterialNameInput.value.trim() : '';
            if (custom) return custom;
            return getEffectiveFacadeMaterialLabel();
        }

        function getMaterialLabelForPart(part) {
            if (!part) return '';
            if (part.material) return part.material;
            if (part.materialName) return part.materialName;
            const extra = part.extra || {};
            if (extra.materialName) return extra.materialName;
            if (extra.material) return extra.material;
            const type = (part.type || '').toLowerCase();
            if (!type) return '';
            const corpusLabel = corpusMaterial ? (corpusMaterial.value || '') : '';
            const facadeLabel = getEffectiveFacadeMaterialLabel();
            const drawerFacLabel = getDrawerFacadeMaterialLabel();
            const backLabel = getBackMaterialLabel();
            if (type === 'door') return facadeLabel || corpusLabel;
            if (type === 'drawer_facade') return drawerFacLabel || facadeLabel || corpusLabel;
            if (type === 'back') return backLabel || facadeLabel || corpusLabel;
            if (type === 'falsh') return facadeLabel || corpusLabel;
            if (type === 'drawer' || type === 'drawer_panel' || type === 'drawer_panel_front') return corpusLabel || facadeLabel;
            if (type === 'plinth') return getPlinthMaterialLabel();
            if (['side','top','bottom','divider','shelf','runner','pipe','flange','leg'].includes(type)) return corpusLabel;
            return corpusLabel || facadeLabel;
        }

        function updatePartUI() {
            if (!partNameInput) return;
            const syncEdgeLabels = (part) => {
                const t = (part && part.type) ? part.type.toLowerCase() : '';
                const partName = (part && part.name) ? String(part.name) : '';
                const isVerticalPanel = (t === 'side' || t === 'divider');
                const isPlinth = (t === 'plinth');
                const isDrawerPanel = (t === 'drawer_panel');
                const isDoorPanel = (t === 'door');
                const isDrawerFacade = (t === 'drawer_facade');
                const isDrawerEdgePanelFlag = isDrawerEdgePanel(part);
                const isDrawerSidePanel = t === 'drawer' && /ящик\s+(сол|оң)\s+жақ/i.test(partName);
                const isBackPanel = (t === 'back');
                const useBottomTopForLeftRight = isVerticalPanel || isDrawerSidePanel;
                const leftTxt   = isPlinth ? 'Сол'   : (useBottomTopForLeftRight ? 'Асты' : 'Сол');
                const rightTxt  = isPlinth ? 'Оң'    : (useBottomTopForLeftRight ? 'Үсті' : 'Оң');
                const useFacadeLabels = isPlinth || isDrawerPanel || isDoorPanel || isDrawerFacade || isDrawerEdgePanelFlag || isBackPanel;
                const frontTxt  = useFacadeLabels ? 'Асты'  : 'Алды';
                const backTxt   = useFacadeLabels ? 'Үсті'  : 'Арты';

                if (edgeLeftLabel)   edgeLeftLabel.textContent   = leftTxt;
                if (edgeRightLabel)  edgeRightLabel.textContent  = rightTxt;
                if (edgeFrontLabel)  edgeFrontLabel.textContent  = frontTxt;
                if (edgeBackLabel)   edgeBackLabel.textContent   = backTxt;
                if (offsetBottomLabel) offsetBottomLabel.textContent = leftTxt;
                if (offsetTopLabel)    offsetTopLabel.textContent    = rightTxt;
                if (offsetFrontLabel)  offsetFrontLabel.textContent  = frontTxt;
                if (offsetBackLabel)   offsetBackLabel.textContent   = backTxt;
            };
            if (partPreviewDeleteBtn) {
                partPreviewDeleteBtn.disabled = !selectedPartId || !parts[selectedPartId];
            }
            if (!selectedPartId || !parts[selectedPartId]) {
                partNameInput.value    = '';
                partTypeInput.value    = '';
                partSectionInput.value = '';
                partSizeInput.value    = '';
                partOffsetFrontInput.value = 0;
                if (edgeFrontInput) edgeFrontInput.checked = false;
                if (edgeFrontInput) edgeFrontInput.disabled = false;
                if (edgeBackInput)  edgeBackInput.checked  = false;
                if (edgeBackInput) edgeBackInput.disabled = false;
                if (edgeLeftInput)  edgeLeftInput.checked  = false;
                if (edgeRightInput) edgeRightInput.checked = false;
                if (offsetFrontInput) offsetFrontInput.value = 0;
                if (offsetBackInput)  offsetBackInput.value  = 0;
                if (offsetBottomInput) {
                    offsetBottomInput.value = 0;
                    offsetBottomInput.disabled = false;
                }
                if (offsetTopInput) {
                    offsetTopInput.value = 0;
                    offsetTopInput.disabled = false;
                }
                if (partDrillingInput) partDrillingInput.value = '';
                if (partEmptyState) partEmptyState.style.display = 'block';
                syncEdgeLabels(null);
                refreshPartPreview();
                return;
            }
            const p = parts[selectedPartId];
            partNameInput.value    = p.name || '';
            partTypeInput.value    = p.type || '';
            partSectionInput.value = p.sectionId != null ? String(p.sectionId) : '';
            const materialLabel = getMaterialLabelForPart(p);
            partSizeInput.value    = formatPartDims(p) + ' мм' + (materialLabel ? ' · ' + materialLabel : '');

            const isLeftFrontPanel = !!(
                (p.extra && p.extra.side === 'left-front') ||
                (typeof p.name === 'string' && p.name.includes('Фронтальный панель (сол)'))
            );
            const isRightFrontPanel = !!(
                (p.extra && p.extra.side === 'right-front') ||
                (typeof p.name === 'string' && p.name.includes('Фронтальный панель (оң)'))
            );
            const typeLower = (p.type || '').toLowerCase();
            const isDrawerFacade = (typeLower === 'drawer_facade');
            const isDrawerEdgePanelFlag = isDrawerEdgePanel(p);
            const drawerPart = resolveDrawerValueFromExtra(p && p.extra, 'drawerPart');
            const isDrawerBottomPanel = drawerPart === 'bottom';
            const isDoorPanel = (typeLower === 'door');
            const isTopPanel = (typeLower === 'top');
            const isShelfPanel = (typeLower === 'shelf');
            const isBottomPanel = (typeLower === 'bottom');
            const isBackPanel = (typeLower === 'back');
            const isHorizontalPanel = isTopPanel || isShelfPanel;
            const forcedEdgeState = isLeftFrontPanel
                ? { front: false, back: false, left: false, right: true }
                : isRightFrontPanel
                    ? { front: false, back: false, left: true, right: false }
                    : null;

            // ЛДСП фасадында есік кромкасы барлық қырда болсын
            if ((p.type || '').toLowerCase() === 'door' && facadeMaterial && facadeMaterial.value === 'ldsp') {
                p.edge = { front: true, back: true, left: true, right: true };
                rebuildEdgeHighlightForPart(p);
                applyEdgeHighlightVisibility();
            }

            partOffsetFrontInput.value = p.frontOffset || 0;
            const edgeState = forcedEdgeState || (p.edge || {});
            if (forcedEdgeState) p.edge = edgeState;
            if (edgeFrontInput) edgeFrontInput.checked = !!edgeState.front;
            if (edgeBackInput)  edgeBackInput.checked  = !!edgeState.back;
            if (edgeLeftInput)  edgeLeftInput.checked  = !!edgeState.left;
            if (edgeRightInput) edgeRightInput.checked = !!edgeState.right;
            const offs = p.offsets || { front:0, back:0, bottom:0, top:0, left:0, right:0 };
            const bottomVal = offs.bottom || 0;
            const topVal = offs.top || 0;
            const leftVal = offs.left || 0;
            const rightVal = offs.right || 0;
            const useFacadeOffsetMode = isDrawerFacade || isDrawerEdgePanelFlag || isDoorPanel || isBackPanel;
            const useLeftRightFromBottomTop = useFacadeOffsetMode || isHorizontalPanel || isBottomPanel || isDrawerBottomPanel;
            if (offsetFrontInput) offsetFrontInput.value = useFacadeOffsetMode ? bottomVal : (offs.front || 0);
            if (offsetBackInput)  offsetBackInput.value  = useFacadeOffsetMode ? topVal : (offs.back || 0);
            if (offsetBottomInput) {
                offsetBottomInput.value = useLeftRightFromBottomTop ? leftVal : bottomVal;
                offsetBottomInput.disabled = false;
            }
            if (offsetTopInput) {
                offsetTopInput.value = useLeftRightFromBottomTop ? rightVal : topVal;
                offsetTopInput.disabled = false;
            }
            if (partDrillingInput) partDrillingInput.value = p.drilling || '';
            if (partEmptyState) partEmptyState.style.display = 'none';
            syncEdgeLabels(p);
            applyPartOffsets(p);
            rebuildEdgeHighlightForPart(p);
            applyEdgeHighlightVisibility();
            refreshPartPreview();
        }

        function disposeSelectionHelpers() {
            if (selectedPartBoxHelper) {
                if (selectedPartBoxHelper.parent) {
                    selectedPartBoxHelper.parent.remove(selectedPartBoxHelper);
                }
                selectedPartBoxHelper.traverse(obj => {
                    if (obj.geometry) obj.geometry.dispose();
                    if (obj.material) obj.material.dispose();
                });
                selectedPartBoxHelper = null;
            }
        }

        function rebuildSelectionHighlightHelpers() {
            disposeSelectionHelpers();
            if (!selectedPartIds.size) return;
            const group = new THREE.Group();
            selectedPartIds.forEach(id => {
                const part = parts[id];
                if (!part || !part.mesh) return;
                const helper = new THREE.BoxHelper(part.mesh, 0x4fa3ff);
                helper.update();
                group.add(helper);
            });
            if (!group.children.length) return;
            selectedPartBoxHelper = group;
            scene.add(group);
        }

        function selectPart(partId, opts = {}) {
            if (!parts[partId]) return;

            const skipSelectionSetUpdate = !!opts.skipSelectionSetUpdate;
            const preserveMultiSelection = !!opts.preserveMultiSelection;
            const idStr = String(partId);
            if (!skipSelectionSetUpdate) {
                if (!preserveMultiSelection) {
                    selectedPartIds = new Set([idStr]);
                } else if (!selectedPartIds.has(idStr)) {
                    const next = new Set(selectedPartIds);
                    next.add(idStr);
                    selectedPartIds = next;
                }
            }
            selectedPartId = partId;
            multiSelectAnchorId = idStr;
            rebuildSelectionHighlightHelpers();

            const secId = parts[partId].sectionId;
            if (secId) {
                const secExists = sections.some(s => s.id === secId);
                if (secExists) {
                    selectedSectionId = secId;
                    updateSelectedSectionHelper();
                    rebuildSectionSelect();
                    rebuildShelvesUI();
                }
            }

            // Панельді сыртқы settings файл ашады
            if (window.QDApp && typeof window.QDApp.activatePanel === 'function') {
                window.QDApp.activatePanel('part');
            } else {
                const btn = document.querySelector('.tool-tab[data-panel="part"]');
                const panel = document.getElementById('panel-part');
                if (btn) {
                    document.querySelectorAll('.tool-tab').forEach(b => {
                        b.classList.toggle('active', b === btn);
                    });
                }
                if (panel) {
                    document.querySelectorAll('.tool-panel').forEach(p => {
                        p.classList.toggle('active', p === panel);
                    });
                }
            }

            updatePartUI();
            syncStructureSelection();
            updateSectionFaceHighlight();
        }

        function purgePartsByType(typesToRemove) {
            const typeSet = new Set(typesToRemove || []);
            if (!typeSet.size) return;

            // Remove helpers for selected part if it gets deleted
            if (selectedPartId && parts[selectedPartId] && typeSet.has((parts[selectedPartId].type || '').toLowerCase())) {
                disposeSelectionHelpers();
                selectedPartIds.clear();
                selectedPartId = null;
            }

            const removeMeshRefs = new Set();
            Object.keys(parts).forEach(pid => {
                const p = parts[pid];
                if (p && typeSet.has((p.type || '').toLowerCase())) {
                    disposeEdgeHighlight(p);
                    if (p.mesh) removeMeshRefs.add(p.mesh);
                    delete parts[pid];
                }
            });

            allMeshes = allMeshes.filter(m => !removeMeshRefs.has(m));
            allEdges  = allEdges.filter(e => !removeMeshRefs.has(e.__parentMesh));

            updatePartUI();
        }

        function clearSelectedPartSelection() {
            disposeSelectionHelpers();
            selectedPartIds.clear();
            selectedPartId = null;
            updateSectionFaceHighlight();
        }

        function removeShelfHeightFromData(part) {
            if (!part) return false;
            const secId = part.sectionId;
            if (secId == null) return false;
            const height = part.extra ? Number(part.extra.shelfHeight) : NaN;
            if (!isFinite(height)) return false;
            const list = sectionShelves[secId] || [];
            const tol = 0.0001;
            const idx = list.findIndex(v => Math.abs((v || 0) - height) < tol);
            if (idx === -1) return false;
            list.splice(idx, 1);
            sectionShelves[secId] = list;
            return true;
        }

        function removeObjectFromScene(root) {
            if (!root) return { meshes: new Set(), edges: new Set() };
            const meshes = new Set();
            const edges = new Set();
            root.traverse(obj => {
                if (obj.isMesh) meshes.add(obj);
                if (obj.type === 'LineSegments') edges.add(obj);
            });
            if (root.parent) {
                root.parent.remove(root);
            }
            root.traverse(obj => {
                if (obj.geometry) obj.geometry.dispose();
                disposeMat(obj.material);
            });
            return { meshes, edges };
        }

        function deletePart(partId) {
            const part = parts[partId];
            if (!part) return;
            const typeLower = (part.type || '').toLowerCase();
            disposeEdgeHighlight(part);
            clearSelectedPartSelection();
            if (typeLower === 'shelf') {
                const removedFromData = removeShelfHeightFromData(part);
                delete parts[partId];
                if (removedFromData) {
                    syncShelves();
                    updatePartUI();
                    return;
                }
                // fallthrough to normal deletion if shelf data stayed the same
            }

            let root = null;
            if (part.mesh && part.mesh.userData && part.mesh.userData.hinge) {
                root = part.mesh.userData.hinge;
            } else if (part.mesh) {
                root = part.mesh.parent || part.mesh;
            }

            if (root) {
                const { meshes, edges } = removeObjectFromScene(root);
                if (meshes.size) {
                    allMeshes = allMeshes.filter(m => !meshes.has(m));
                }
                if (edges.size) {
                    allEdges = allEdges.filter(e => !edges.has(e));
                }
            }

            delete parts[partId];
            selectedPartId = null;
            rebuildStructureList();
            updatePartUI();
            updateSectionFaceHighlight();
        }
