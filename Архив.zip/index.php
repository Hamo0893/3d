<?php
/* -------------------------------------------------------
 * QDESIGN · шкаф конструктор (ratio секциялар, фасад, стойка, артқы қабырға)
 * -----------------------------------------------------*/
$defaultWidth  = isset($_GET['w']) ? (int)$_GET['w'] : 1400;
$defaultHeight = isset($_GET['h']) ? (int)$_GET['h'] : 2400;
$defaultDepth  = isset($_GET['d']) ? (int)$_GET['d'] : 580;
?>
<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <title>QDESIGN · шкаф конструктор</title>
    <link rel="stylesheet" href="assets/font-awesome6/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="main-layout">
    <!-- Сол жақ: 3D ЭКРАН -->
    <div id="canvas-wrap">
        <div id="errorBox">
            <span id="errorText"></span>
            <span id="errorClose" title="Жабу">×</span>
        </div>
        <!-- Undo/Redo + Save/Load -->
        <div id="history-toolbar" style="position:absolute;left:10px;top:10px;z-index:5;">
            <button id="saveProjectBtn" type="button" title="Сақтау"><i class="fa-solid fa-floppy-disk" aria-hidden="true"></i></button>
            <button id="loadProjectBtn" type="button" title="Ашу"><i class="fa-solid fa-folder-open" aria-hidden="true"></i></button>
            <input id="loadProjectInput" type="file" accept="application/json" style="display:none">
            <button id="undoBtn" type="button" title="Артқа (Undo)"><i class="fa-solid fa-rotate-left" aria-hidden="true"></i></button>
            <button id="redoBtn" type="button" title="Алға (Redo)"><i class="fa-solid fa-rotate-right" aria-hidden="true"></i></button>
        </div>

        <!-- Видтер, режим, анимация -->
        <div id="canvas-toolbar">
            <div class="toolbar-group">
                <button class="toolbar-btn active" data-view="shadow" title="Көлеңкемен"><i class="fa-solid fa-sun" aria-hidden="true"></i></button>
                <button class="toolbar-btn" data-view="sketch" title="Эскиз"><i class="fa-solid fa-pencil" aria-hidden="true"></i></button>
                <button class="toolbar-btn" data-view="xray" title="Ренген"><i class="fa-solid fa-eye" aria-hidden="true"></i></button>
            </div>
            <div class="toolbar-group">
                <button class="toolbar-btn" data-mode="cabinet" title="Модуль таңдау"><i class="fa-solid fa-cubes" aria-hidden="true"></i></button>
                <button class="toolbar-btn active" data-mode="section" title="Секция таңдау"><i class="fa-solid fa-columns" aria-hidden="true"></i></button>
                <button class="toolbar-btn" data-mode="part" title="Бөлшек таңдау"><i class="fa-solid fa-puzzle-piece" aria-hidden="true"></i></button>
            </div>
            <div class="toolbar-group">
                <button class="toolbar-btn" id="animToggleBtn" title="Есік анимациясы"><i class="fa-solid fa-film" aria-hidden="true"></i></button>
            </div>
        </div>

        <div id="dimensionBox"></div>

        <!-- Құрылым (бөлшектер тізімі) -->
        <div id="structure-panel">
            <div class="structure-header">
                <div id="cabinetIconList" class="cabinet-icons-inline"></div>
            </div>
            <div id="structureList"></div>
            <div style="margin-top:6px;display:flex;justify-content:flex-end;">
                <button type="button" id="cabinetHideBtn" class="line-btn" title="Шкафты жасыру" style="display:none;"><i class="fa-solid fa-eye-slash" aria-hidden="true"></i></button>
                <button type="button" id="cabinetDeleteBtn" class="line-btn" title="Шкафты өшіру" style="display:none;"><i class="fa-solid fa-trash" aria-hidden="true"></i></button>
            </div>
        </div>

        <div id="materialNamePopup" class="material-name-popup">
            <div class="material-name-popup__backdrop" id="materialNamePopupBackdrop"></div>
            <div class="material-name-popup__card">
                <div class="material-name-popup__head">
                    <div class="material-name-popup__title">Материал атын өзгерту</div>
                    <button type="button" class="material-name-popup__close" id="materialNamePopupClose">&times;</button>
                </div>
                <p class="material-name-popup__help">Ctrl+/Shift-мен таңдаған бөлшектердің аты бір уақытта өзгереді. Кіру үшін ағылшынша <strong>M</strong> немесе орысша <strong>Ь</strong> пернесін басыңыз.</p>
                <input type="text" id="materialNamePopupInput" class="material-name-popup__input" placeholder="Мысалы: Egger W980">
                <button type="button" id="materialNamePopupApply" class="material-name-popup__apply">Жазып өзгерту</button>
            </div>
        </div>

	        <!-- Төменгі тулбар: өлшем иконкасы + фасад иконкасы -->
	        <div id="bottom-toolbar" style="position:absolute;left:50%;bottom:10px;transform:translateX(-50%);z-index:5;display:flex;gap:8px;">
	            <div id="view-toolbar" class="toolbar-group view-toolbar">
	                <button type="button" class="toolbar-btn line-btn" data-cam="front" title="Алды вид"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i></button>
	                <button type="button" class="toolbar-btn line-btn" data-cam="side"  title="Жаны вид"><i class="fa-solid fa-arrows-left-right" aria-hidden="true"></i></button>
	                <button type="button" class="toolbar-btn line-btn" data-cam="top"   title="Үсті вид"><i class="fa-solid fa-arrow-up" aria-hidden="true"></i></button>
	                <button type="button" class="toolbar-btn line-btn" data-cam="iso"   title="Изометрия"><i class="fa-solid fa-cube" aria-hidden="true"></i></button>
	            </div>
	            <div id="visibility-toolbar" class="toolbar-group toolbar-box">
	                <button id="toggleDimsBtn" class="line-btn" type="button" title="Өлшемдерді көрсету/жасыру"><i class="fa-solid fa-ruler-combined" aria-hidden="true"></i></button>
	                <button id="toggleFacadeBtn" class="line-btn" type="button" title="Фасадтарды жасыру/көрсету"><i class="fa-solid fa-door-open" aria-hidden="true"></i></button>
	                <button id="toggleEdgeBtn" class="line-btn" type="button" title="Кромканы көрсету/жасыру"><i class="fa-solid fa-square" aria-hidden="true"></i></button>
	            </div>
	            <button id="toggleInfoBtn" class="line-btn" type="button" title="Ақпаратты көрсету/жасыру"><i class="fa-solid fa-circle-info" aria-hidden="true"></i></button>
	        </div>
	    </div>

    <!-- Оң жақ: КОНСТРУКТОР -->
    <div class="sidebar">
        <!-- ИКОНКА ТІЗІМІ -->
        <div class="tool-tabs">
            <button class="tool-tab active" data-panel="wall2"   title="Стена"><i class="fa-solid fa-building" aria-hidden="true"></i><span>Стена</span></button>
            <button class="tool-tab"        data-panel="sizes"   title="Өлшемдер"><i class="fa-solid fa-ruler-combined" aria-hidden="true"></i><span>Өлшем</span></button>
            <button class="tool-tab"        data-panel="corpus"  title="Корпус · цоколь · артқы қабырға"><i class="fa-solid fa-cube" aria-hidden="true"></i><span>Корпус</span></button>
            <button class="tool-tab"        data-panel="facade"  title="Фасад"><i class="fa-solid fa-door-open" aria-hidden="true"></i><span>Фасад</span></button>
            <button class="tool-tab"        data-panel="sections"title="Секциялар"><i class="fa-solid fa-table-cells" aria-hidden="true"></i><span>Секция</span></button>
            <button class="tool-tab"        data-panel="shelves" title="Полкалар"><i class="fa-solid fa-bars" aria-hidden="true"></i><span>Полка</span></button>
            <button class="tool-tab"        data-panel="drawer"  title="Наполнение"><i class="fa-solid fa-inbox" aria-hidden="true"></i><span>Н/П</span></button>
            <button class="tool-tab"        data-panel="part"    title="Бөлшек"><i class="fa-solid fa-puzzle-piece" aria-hidden="true"></i><span>Бөлшек</span></button>
        </div>

        <!-- ПАНЕЛЬ: ЖАҢА СТЕНА -->
        <div class="tool-panel active" id="panel-wall2">
            <div class="fields-row" style="flex-wrap:wrap;align-items:center;gap:10px;">
                <div class="field inline-field compact" style="flex:0 0 auto;align-items:center;">
                    <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
                        <button id="addWallFrontalBtn" type="button" class="line-btn compact-btn">+ Фронталды</button>
                        <button id="addWallVerticalBtn" type="button" class="line-btn compact-btn">+ Вертикалды</button>
                    </div>
                </div>
            </div>
            <div class="fields-row">
                <div class="field" style="width:100%;">
                    <label>Стена тізімі</label>
                    <div id="newWallList" class="simple-list"></div>
                </div>
            </div>
        </div>

        <!-- ПАНЕЛЬ: ӨЛШЕМДЕР -->
        <div class="tool-panel" id="panel-sizes">
            <div class="size-grid">
                <div class="size-row">
                    <label for="widthInput">Ені (мм)</label>
                    <div class="size-field">
                        <input id="widthInput" type="number"
                               value="<?php echo htmlspecialchars($defaultWidth, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                </div>

                <div class="size-row">
                    <label for="heightInput">Биіктігі (мм)</label>
                    <div class="size-field">
                        <input id="heightInput" type="number"
                               value="<?php echo htmlspecialchars($defaultHeight, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                </div>

                <div class="size-row">
                    <label for="depthInput">Тереңдігі (мм)</label>
                    <div class="size-field">
                        <input id="depthInput" type="number"
                               value="<?php echo htmlspecialchars($defaultDepth, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                </div>

                <div class="size-row">
                    <label for="plinthHeight">Цоколь биіктігі (мм)</label>
                    <div class="size-field">
                        <input id="plinthHeight" type="number" value="100">
                    </div>
                </div>
                <div class="size-row">
                    <label for="plinthMaterialName">Материал аты</label>
                    <div class="size-field">
                        <input id="plinthMaterialName" type="text" placeholder="Мысалы: Egger W980" value="Белый">
                    </div>
                </div>

                <div class="size-row">
                    <label for="wallGapInput">Отступ от стены (мм)</label>
                    <div class="size-field">
                        <input id="wallGapInput" type="number" value="10">
                    </div>
                </div>
            </div>
        </div>

        <!-- ПАНЕЛЬ: КОРПУС · ЦОКОЛЬ · АРТҚЫ ҚАБЫРҒА -->
        <div class="tool-panel" id="panel-corpus">
            <div class="corpus-grid">
                <div class="corpus-row">
                    <label for="corpusMaterial">Корпус материалы</label>
                    <div class="corpus-field corpus-field--wide">
                        <input id="corpusMaterial" type="text" value="ЛДСП белый базовый">
                    </div>
                </div>

                <div class="corpus-row">
                    <label for="corpusThickness">Корпус қалыңдығы (мм)</label>
                    <div class="corpus-field">
                        <input id="corpusThickness" type="number" value="16" min="8" max="40" step="1">
                    </div>
                </div>

                <div class="corpus-row">
                    <label for="corpusColor">Корпус түсі</label>
                    <div class="corpus-field">
                        <input id="corpusColor" type="color" value="#f5f5f5">
                    </div>
                </div>

                <div class="corpus-row">
                    <label for="bottomMount">Дно түрі</label>
                    <div class="corpus-field">
                        <select id="bottomMount">
                            <option value="vkladnoy">Вкладной (ішке)</option>
                            <option value="nakladnoy" selected>Накладной (сыртынан)</option>
                        </select>
                    </div>
                </div>

                <div class="corpus-row corpus-row--stack">
                    <div class="corpus-field">
                        <div class="corpus-inline-group">
                            <select id="falshSide">
                                <option value="left">Сол планка</option>
                                <option value="right">Оң планка</option>
                                <option value="top">Төбе планка</option>
                            </select>
                            <input id="falshSize" type="number" min="10" step="1" value="50" title="Фальш өлшемі (мм)">
                            <button id="addFalshBtn" type="button" class="line-btn compact-btn" aria-label="Қосу"><i class="fa-solid fa-plus" aria-hidden="true"></i></button>
                        </div>
                        <div class="corpus-inline-group corpus-inline-group--mt">
                            <select id="falshOverlaySide" title="Қосымша фальш панель түрі">
                                <option value="left">Сол жақ фальш панель</option>
                                <option value="right">Оң жақ фальш панель</option>
                                <option value="top">Қосымша төбе фальш панель</option>
                            </select>
                            <input id="falshOverlaySize" type="number" min="10" step="1" value="600" title="Қосымша фальш панель тереңдігі (мм)">
                            <button id="addFalshOverlayBtn" type="button" class="line-btn compact-btn" aria-label="Қосу"><i class="fa-solid fa-plus" aria-hidden="true"></i></button>
                        </div>
                        <div id="falshList" class="simple-list" style="margin-top:8px;">
                            <div id="falshListItems" class="simple-list"></div>
                        </div>
                    </div>
                </div>

                <div class="corpus-row corpus-row--stack">
                    <label for="backMaterial">Артқы қабырға материалы</label>
                    <div class="corpus-field">
                        <select id="backMaterial">
                            <option value="hdf" selected>ХДФ (4 мм)</option>
                            <option value="ldsp">ЛДСП</option>
                        </select>
                    </div>
                </div>
                <div class="corpus-row corpus-row--stack">
                    <label>Орналасуы</label>
                    <div class="corpus-field">
                        <input type="text" value="Накладной (сыртынан)" readonly>
                    </div>
                </div>
            </div>
        </div>

        <!-- ПАНЕЛЬ: ФАСАД -->
        <div class="tool-panel" id="panel-facade">
                <div class="facade-grid">
                <div class="facade-row">
                    <label for="facadeMaterial">Фасад материалы</label>
                    <div class="facade-field">
                        <select id="facadeMaterial">
                            <option value="ldsp" selected>ЛДСП</option>
                            <option value="mdf">МДФ</option>
                            <option value="glass">Стекло</option>
                            <option value="glass_frame">Стекло рамка</option>
                        </select>
                    </div>
                </div>
                <div class="facade-row">
                    <label for="facadeMaterialName">Материал аты</label>
                    <div class="facade-field">
                        <input id="facadeMaterialName" type="text" placeholder="Мысалы: Egger W980" value="Белый">
                    </div>
                </div>
                <div class="facade-row">
                    <label for="drawerFacadeMaterial">Фасад материалы (ящик)</label>
                    <div class="facade-field">
                        <select id="drawerFacadeMaterial">
                            <option value="ldsp" selected>ЛДСП</option>
                            <option value="mdf">МДФ</option>
                            <option value="glass">Стекло</option>
                            <option value="glass_frame">Стекло рамка</option>
                        </select>
                    </div>
                </div>
                <div class="facade-row">
                    <label for="drawerFacadeMaterialName">Материал аты (ящик)</label>
                    <div class="facade-field">
                        <input id="drawerFacadeMaterialName" type="text" placeholder="Мысалы: Egger W980" value="Белый">
                    </div>
                </div>
                <div class="facade-row">
                    <label for="facadeThickness">Фасад қалыңдығы (мм)</label>
                    <div class="facade-field">
                        <input id="facadeThickness" type="number" value="16" min="4" max="40" step="1">
                    </div>
                </div>
                <div class="facade-row">
                    <label for="facadeType">Фасад түрі</label>
                    <div class="facade-field">
                        <select id="facadeType">
                            <option value="vkladnoy">Вкладной</option>
                            <option value="nakladnoy" selected>Накладной</option>
                        </select>
                    </div>
                </div>
                <div class="facade-row">
                    <label for="facadeColor">Фасад түсі</label>
                    <div class="facade-field">
                        <input id="facadeColor" type="color" value="#ffffff">
                    </div>
                </div>
                <div class="facade-row">
                    <label for="facadeStyle">Фрезировка стилі</label>
                    <div class="facade-field">
                        <select id="facadeStyle">
                            <option value="modern" selected>Модерн (тегіс)</option>
                            <option value="frame">Рамкамен</option>
                            <option value="refl">Рефленный</option>
                        </select>
                    </div>
                </div>
                <div class="facade-row">
                    <label for="facadeFrameWidth">Рамка ені (мм)</label>
                    <div class="facade-field">
                        <input id="facadeFrameWidth" type="number" value="60" min="10" max="120" step="1">
                    </div>
                </div>
            </div>
        </div>

        <!-- ПАНЕЛЬ: СЕКЦИЯЛАР -->
        <div class="tool-panel" id="panel-sections">
            

            <div class="fields-row">
                <div class="field">
                    <label>Секциялар (ID · ені, мм)</label>
                    <div id="sectionSelect" class="section-list"></div>
                    
                </div>
            </div>

            <div class="fields-row">
                <div class="field">
                    <label>Секция ені (мм)</label>
                    <input id="sectionWidthInput" type="number" min="100">
                    
                </div>
            </div>

            <div class="fields-row">
                <div class="field">
                    <label>Бөліну pattern</label>
                    <select id="splitPattern">
                        <option value="1/1">1 / 1</option>
                        <option value="2">2</option>
                        <option value="2/1">2 / 1</option>
                        <option value="1/2">1 / 2</option>
                        <option value="1/1/1">1 / 1 / 1</option>
                    </select>
                </div>
                <div class="field" style="flex:0 0 auto;">
                    <label>&nbsp;</label>
                    <button id="splitSectionBtn" type="button">Секцияны бөлу</button>
                </div>
            </div>

            
        </div>

        <!-- ПАНЕЛЬ: ПОЛКАЛАР -->
        <div class="tool-panel" id="panel-shelves">
            

            <!-- Саны / 3 / Авто қою -->
            <div class="fields-row">
                <div class="field" style="display:flex;align-items:center;gap:8px;">
                    <label style="margin:0;white-space:nowrap;">Саны</label>
                    <input id="shelfCountInput" type="number" value="3" min="1" style="max-width:70px;">
                    <button id="autoShelvesBtn" type="button">Авто қою</button>
                </div>
            </div>

            <!-- Бір полка қосу -->
            <div class="fields-row">
                <div class="field">
                    <label>Полка биіктігі (мм)</label>
                    <input id="shelfHeightInput" type="number" min="0" step="1">
                </div>
                <div class="field" style="flex:0 0 auto;">
                    <label>&nbsp;</label>
                    <button id="addShelfBtn" type="button">Полка қосу</button>
                </div>
            </div>

            <!-- Алдынан отступ -->
            <div class="fields-row">
                <div class="field">
                    <label>Алдынан отступ (мм)</label>
                    <input id="shelfOffsetInput" type="number" value="0" min="0" step="1">
                    
                </div>
            </div>

            <!-- Полкалар / Полка1 / 600 / өзгерту / 🗑 -->
            <div class="fields-row">
                <div class="field">
                    <label>Полкалар</label>
                    <div id="shelfList" class="simple-list"></div>
                    
                </div>
            </div>

            
        </div>

        <!-- ПАНЕЛЬ: ЯЩИК -->
        <div class="tool-panel" id="panel-drawer">
            
            <div class="fields-row">
                <div class="field">
                    <label>Полка аралығы</label>
                    <div id="drawerSubList" class="simple-list"></div>
                    
                </div>
            </div>

            <div class="fields-row">
                <div class="field" style="display:flex;align-items:center;gap:8px;">
                    <label style="margin:0;white-space:nowrap;">Наполнение</label>
                    <select id="insertTypeSelect" style="max-width:150px;">
                        <option value="pipe">Труба</option>
                        <option value="drawer">Ящик</option>
                    </select>
                    <button id="addInsertBtn" type="button">+</button>
                </div>
            </div>
            <div class="fields-row pipe-settings">
                <div class="field">
                    <label>Труба түсі</label>
                    <input id="pipeColor" type="color" value="#111111">
                </div>
            </div>
            <div class="fields-row drawer-settings">
                <div class="field">
                    <label>Направляющий типі</label>
                    <select id="drawerRunnerType">
                        <option value="softclose">С доводчиком</option>
                        <option value="push">Пуш-ап</option>
                        <option value="basic">Без доводчика</option>
                    </select>
                </div>
                <div class="field">
                    <label>Ящик түрі</label>
                    <select id="drawerVariantSelect">
                        <option value="telescope">Телескопический</option>
                        <option value="tandem">Тандем</option>
                        <option value="tandembox">Тандем бокс</option>
                    </select>
                </div>
                <div class="field">
                    <label>Глубина ящика (мм)</label>
                    <select id="drawerDepthSelect">
                        <option value="250">250</option>
                        <option value="300">300</option>
                        <option value="350">350</option>
                        <option value="400">400</option>
                        <option value="450">450</option>
                        <option value="500">500</option>
                        <option value="550">550</option>
                    </select>
                </div>
                <div class="field">
                    <label>Фирма</label>
                    <select id="drawerDepthBrandSelect">
                        <option value="standard">Cтандарт</option>
                        <option value="blum">Блюм</option>
                        <option value="china">Китай</option>
                    </select>
                </div>
                <div class="field">
                    <label>Фасад зазоры (мм)</label>
                    <input id="drawerFacadeGap" type="number" min="0" step="0.5" value="3">
                </div>
                <div class="field">
                    <label>Алдынан отступ (мм)</label>
                    <input id="drawerFrontOffset" type="number" min="0" step="1" value="16">
                </div>
                <div class="field">
                    <label>Ящик биіктігі (мм)</label>
                    <input id="drawerBodyHeight" type="number" min="40" step="1" value="120">
                </div>
                <div class="field">
                    <label>Ящик аралығы (мм)</label>
                    <input id="drawerStackGap" type="number" min="0" step="0.5" value="0">
                </div>
                <div class="field">
                    <label>Направляющий қалыңдығы (мм)</label>
                    <input id="drawerRunnerThk" type="number" min="0" step="0.5" value="13">
                </div>
                <div class="field">
                    <label>Панелдер (сол / оң, мм)</label>
                    <div style="display:flex;gap:6px;">
                        <input id="insertGapLeft" type="number" min="0" step="1" value="50" placeholder="сол">
                        <input id="insertGapRight" type="number" min="0" step="1" value="50" placeholder="оң">
                    </div>
                </div>
            </div>
            <div class="fields-row">
                <div class="field">
                    <label>Қойылған наполнения</label>
                    <div id="insertList" class="simple-list"></div>
                    
                </div>
            </div>
        </div>

<!-- ПАНЕЛЬ: БӨЛШЕК -->
        <div class="tool-panel" id="panel-part">
            <div class="part-panel">
                <div class="part-panel__lead part-hide-above">
                    <div class="part-lead-text">
                        <div class="part-kicker">Таңдалған бөлшек</div>
                        <input id="partName" class="part-title-input" type="text" readonly placeholder="Бөлшек таңдалмаған">
                    </div>
                    <div class="part-chip-row part-chip-row--hidden">
                        <div class="part-chip">
                            <span>Типі</span>
                            <input id="partType" type="text" readonly>
                        </div>
                        <div class="part-chip">
                            <span>Секция</span>
                            <input id="partSection" type="text" readonly>
                        </div>
                    </div>
                </div>

                <div class="part-panel__grid">
                    <div class="part-meta-card part-hide-above">
                        <div class="field compact part-size-field">
                            <label>Өлшемдері (Е × Б × Т, мм)</label>
                            <input id="partSize" type="text" readonly>
                        </div>
                        <div class="field compact part-offset-field">
                            <label>Алдынан отступ (мм)</label>
                            <input id="partOffsetFront" type="number" value="0">
                        </div>
                    </div>

                    <div class="part-preview-card">
                        <div class="part-preview-head">
                            <div>
                        <div class="part-kicker">2D көрініс</div>
                        <div class="part-preview-name" id="partPreviewName">Бөлшек таңдалмаған</div>
                        <div class="part-preview-caption" id="partPreviewCaption">–</div>
                    </div>
                    <button id="partPreviewDeleteBtn" type="button" class="part-preview-delete-btn" title="Таңдалған бөлшекті жою"><i class="fa-solid fa-trash" aria-hidden="true"></i></button>
                </div>
                <div class="part-preview-canvas-wrap">
                    <canvas id="partPreviewCanvas"></canvas>
                    <div class="part-preview-empty" id="partPreviewEmpty">3D эскизден бөлшекті таңдаңыз</div>
                </div>
            </div>
                </div>

                    <div class="field">
                        <label>Кромка</label>
                        <div class="edge-chip-row edge-chip-row--with-inputs">
                            <label class="edge-chip">
                                <div class="edge-chip-main">
                                    <input type="checkbox" id="edgeFront">
                                    <span id="edgeFrontLabel">Алды</span>
                                </div>
                                <input type="number" id="offsetFront" value="0" step="1" class="edge-chip-input">
                            </label>
                            <label class="edge-chip">
                                <div class="edge-chip-main">
                                    <input type="checkbox" id="edgeBack">
                                    <span id="edgeBackLabel">Арты</span>
                                </div>
                                <input type="number" id="offsetBack" value="0" step="1" class="edge-chip-input">
                            </label>
                            <label class="edge-chip">
                                <div class="edge-chip-main">
                                    <input type="checkbox" id="edgeLeft">
                                    <span id="edgeLeftLabel">Сол</span>
                                </div>
                                <input type="number" id="offsetBottom" value="0" step="1" class="edge-chip-input">
                            </label>
                            <label class="edge-chip">
                                <div class="edge-chip-main">
                                    <input type="checkbox" id="edgeRight">
                                    <span id="edgeRightLabel">Оң</span>
                                </div>
                                <input type="number" id="offsetTop" value="0" step="1" class="edge-chip-input">
                            </label>
                        </div>
                    </div>

                <div class="field">
                    <label>Присадка / ескертпе</label>
                    <textarea id="partDrilling" placeholder="Мысалы: петля 37 мм, 2 шт, алдыңғыдан 90 мм, үстінен 100 мм..."></textarea>
                </div>

                <div class="part-empty" id="partEmptyState">
                    Бөлшек блогы 3D эскизден нақты бөлшек таңдағанда толтырылады.
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Three.js + OrbitControls -->
<script src="https://unpkg.com/three@0.128.0/build/three.min.js"></script>
<script src="https://unpkg.com/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
<script src="app.bundle.php"></script>
<script src="app-settings.js"></script>
<script src="wall-settings.js"></script>



</body>
</html>
