// wall-settings.js
(function () {
    const Q = window.QDApp;
    if (!Q) return;

    const {
        wallAngleInput,
        wallThicknessInput,
        wallColorInput,
        wallWidthInput,
        wallHeightInput,
        rebuildWalls,
        rebuildWallsUI,
        addWallFromForm,
        updateSelectedWallFromForm
    } = Q;

    const setWallEnabled = (flag) => { Q.wallEnabled = !!flag; };
    const isWallEnabled = () => !!Q.wallEnabled;

    function handleWallChange() {
        if (!isWallEnabled()) return;
        Q.runUndoable(() => {
            updateSelectedWallFromForm();
            rebuildWallsUI();
            rebuildWalls();
        });
    }

    [wallAngleInput, wallThicknessInput, wallColorInput, wallWidthInput, wallHeightInput].forEach(el => {
        if (!el) return;
        const isNumber = el.tagName && el.tagName.toLowerCase() === 'input' && el.type === 'number';
        const evt = isNumber ? 'input' : 'change';
        el.addEventListener(evt, handleWallChange);
        el.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                e.stopPropagation();
                handleWallChange();
                if (typeof el.blur === 'function') el.blur();
            }
        });
    });

    // Негізгі қабырға: егер жоқ болса, enter немесе өзгеріс кезінде жаңасын құру
    const ensureBaseWall = () => {
        if (Q.walls && Q.walls.length) return;
        setWallEnabled(true);
        addWallFromForm();
        rebuildWallsUI();
        rebuildWalls();
    };
    if (wallAngleInput) {
        wallAngleInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                ensureBaseWall();
            }
        });
    }
})();
